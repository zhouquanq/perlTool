use strict;
use warnings;
use FindBin;

##########################################
#
# 工具模块
#    提供相应的工具函数
#
##########################################

package Utils;

sub load_ini
{
	my ($file) = @_;
    
    return load_ini_from_buffer(readin($file));
}

sub load_ini_from_buffer
{
    my ($buffer) = @_;
    
    my @lines = split(/\r?\n/, $buffer);
    
	my @ret;
	my $section_name = "";
	my $kvs;

	for(@lines)
	{
		my $line = $_;
		next if $line=~ /^\s*$/ or $line =~ /^\s*\#/;

		$line =~ s/^\s+//;
		$line =~ s/\s+$//;

		if ($line =~ /^\[([^\]]+)\]$/) {
			my $tmp_name = $1;
			$tmp_name =~ s/^\s+//;
			$tmp_name =~ s/\s+$//;

			if (length($section_name) > 0) {
				my %ini_info;
				$ini_info{'name'} = $section_name;
				$ini_info{'kvs'} = $kvs;

				push @ret, \%ini_info;
			}

			my @arKvs;
			$kvs = \@arKvs;
			$section_name = $tmp_name;
		}
		elsif ($line =~ /^([^=]+)=(.*)$/){
			my $key = $1;
			my $value = $2;

			$key =~ s/^\s+//;
			$key =~ s/\s+$//;

			$value =~ s/^\s+//;
			$value =~ s/\s+$//;

			if (length($section_name) > 0) {
				my %kv;
				$kv{'key'} = $key;
				$kv{'value'} = $value;

				push @{$kvs}, \%kv;
			}
		}
	}

	if (length($section_name) > 0) {
		my %ini_info;
		$ini_info{'name'} = $section_name;
		$ini_info{'kvs'} = $kvs;

		push @ret, \%ini_info;
	}

	return \@ret;
}

sub readin
{
    my ($file) = @_;
    
    my $len = -s $file;
    return "" unless $len>0;

    my $f;
    open $f, $file or return "";
    binmode $f;
    my $cont = "";
    sysread($f, $cont, $len);
    close $f;
    
    return $cont;
}

sub get_section_value
{
	my ($section, $key, $default_value) = @_;

	for (@{$section->{'kvs'}}) {
		my $kv = $_;
		
		if (lc($kv->{'key'}) eq lc($key)) {
			if (length($kv->{'value'})>0) {
				return $kv->{'value'};
			}
		
			return defined($default_value)?$default_value:"";
		}
	}

	return defined($default_value)?$default_value:"";
}

sub format_time
{
	my ($time) = @_;

	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);
	$mon++;
	$year += 1900;

	return "$year-$mon-$mday $hour:$min:$sec";
}

sub concatIni
{
	my ($ini) = @_;
	
	my $str = "";
	my @arr = ();
	for(@$ini)
	{
		my $ini_info = $_;
		my $name = $ini_info->{name};
		push @arr, "[$name]\n";
		my $kvs = $ini_info->{kvs};
		for(@$kvs)
		{
			my $kv = $_;
			my $name = $kv->{key};
			my $value = $kv->{value};
			push @arr, "$name=$value\n";
		}
		push @arr, "\n";
	}
	$str = join "", @arr;
	return $str;
}

1;