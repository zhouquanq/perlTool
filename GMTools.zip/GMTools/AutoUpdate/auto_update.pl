#!/usr/bin/perl
use strict;
use warnings;
use JSON;
use Digest::MD5;
use LWP::UserAgent;
use Net::FTP;
use FindBin;
use Encode;
use Compress::Zlib;
use File::Path qw(make_path remove_tree);
use Archive::Zip qw( :ERROR_CODES :CONSTANTS );
use Cwd;

##########################################
#
# 更新游戏服务器工具程序
#    用于更新游戏服务器
#
##########################################
my $ctx = Digest::MD5->new;


BEGIN
{
	use PerlIO::encoding;
	our $continue = 1;
    our $AppPath = $FindBin::Bin;
    chdir($FindBin::Bin);
	push( @INC, $FindBin::Bin);
}

use Utils;
use Moby::Business::LoggerMan;
use Moby::Business::TimeMan;

{
	our $WARN_LOCKCOUNT = 0;
	our $last_okreporttime = 0;
	our $okreport_space = 3600*3;
	our $apprun_space = 60;
	our $ressvr_dlmaxsec = 50;
	our $AppName = "CheckTools";
    
	our $timeMan = Moby::Business::TimeMan->new();
    our $loggerMan = Moby::Business::LoggerMan->new(
        timeMan=>$::timeMan,
        apppath=>$::AppPath
    );
	our $logger = $::loggerMan->getLogger();
    $::timeMan->setLogger( $::logger);
	
	$::logger->info( "server start...");
	
	$::status_file = shift(@ARGV);
	if (!defined($::status_file) || length($::status_file) <= 0) {
	die "perl -w auto_update.pl path_of_status_file";
	}	
	
	for(@ARGV){
		next unless /^\-srv$/i;
		
		my $pid = fork();
		if ($pid < 0) {
			die "fork: $!";
		}
		elsif ($pid) {
			exit 0;
		}
	
		chdir($FindBin::Bin);
	
		open(STDIN,  "</dev/null");
		open(STDOUT, ">/dev/null");
		open(STDERR, ">&STDOUT");
		last;
	}
	
	$::WARN_LOCKCOUNT = 0;
    
	$SIG{TERM} = sub { $::continue = 0 };

	$SIG{__WARN__} = sub{
	
        my ($text) = @_;
        my @loc = caller(0);
        chomp($text);
        
        my $text_ = $text ? $text : "";
        $::logger->warn('warn: '. $text_); 
        
        my $index = 1;
        for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
        {
            $::logger->warn( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
        };
        return 1;
    };

    $SIG{__DIE__} = sub{
        
        my ($text) = @_;
        my @loc = caller(0);
        chomp($text);

        my $text_ = $text ? $text : "";
        $::logger->warn('error: '. $text_); 
        
        my $index = 1;
        for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
        {
            $::logger->warn( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
        };
        return 1;
    };
}


$|=1;
while($::continue)
{
	run();
	sleep(10);
}

sub run
{

	$::timeMan->runTick();
    $::loggerMan->runTick();
    
	my $tmNow = time();
	print "now: ", Utils::format_time($tmNow),"\n";
 	my $cfg_ini = Utils::load_ini($::AppPath . "/auto_update.cfg");
	for (@{$cfg_ini})
	{
		my $section = $_;
		my $name = $section->{'name'};
		my $serverid = Utils::get_section_value($section, "serverid", "");
		my $posturl = Utils::get_section_value($section, "posturl", "");
		my $sign = Utils::get_section_value($section, "sign", "");
		my $local_root = Utils::get_section_value($section, "local_root", "");
		my $restart_script= Utils::get_section_value($section, "restart_script", "");
		my $download_path = Utils::get_section_value($section, "download_path", "");
		my $version = Utils::get_section_value($section, "version", "");
	#################################################################################
		my $jsonResponse;
		my $checkouthash ={};
		$checkouthash->{serverid}=$serverid;
		$checkouthash->{version}=$version;
		$jsonResponse = httpPort($posturl,$sign,'checkout',$checkouthash);
		if(!defined($jsonResponse)){
			$::logger->info("checkout post failed!");
   	   		next;
		} 
	  #query 接口
	   my $queryhash ={};
	   $queryhash->{serverid}=$serverid;
   	   $jsonResponse = httpPort($posturl,$sign,'query',$queryhash);
   	   if(!defined($jsonResponse))
   	   {
   	   	$::logger->info("query post failed!");
   	   	next;
   	   }
		#json 解析	
		if($jsonResponse->{status} eq 'fail')
		{
			if($jsonResponse->{code}==-1){
				$::logger->info("query need more params");
			}
			if($jsonResponse->{code}==-2){
				$::logger->info("query no access");
			}
			if($jsonResponse->{code}==-3){
				$::logger->info("query serverid illegal");
			}
			next;
		}
		elsif($jsonResponse->{status} eq 'succ')
		{
			if($jsonResponse->{code}==2){
			 next;
			}
			elsif($jsonResponse->{code}==1){
				my $data = $jsonResponse->{data};
				if(!defined($data)){
					$::logger->info("query getdata error:data is empty");
					next;
				}
				my $cmdid = $data->{cmdid};
				#post反馈获取
				my $acquirehash ={};
	   			$acquirehash->{serverid}=$serverid;
	   			$acquirehash->{cmdid}=$cmdid;
   	   			$jsonResponse = httpPort($posturl,$sign,'acquire',$acquirehash);
   	   			if(!defined($jsonResponse)){
   	   				$::logger->info("acquire post failed!");
   	   				next;
   	   			}
   	   			#处理反馈结果
   	   			if($jsonResponse->{status} eq 'fail')
   	   			{
   	   				if($jsonResponse->{code}==-5)
   	   				{
   	   					$::logger->info("acquire cmdid already mark");
   	   				}
   	   				elsif($jsonResponse->{code}==-1)
   	   				{
   	   					$::logger->info("acquire need more params");
   	   					next;
   	   				}
   	   				elsif($jsonResponse->{code}==-2)
   	   				{
   	   					$::logger->info("acquire no access");
   	   					next;
   	   				}
   	   				elsif($jsonResponse->{code}==-3)
   	   				{
   	   					$::logger->info("acquire serverid illegal");
   	   					next;
   	   				}
   	   				elsif($jsonResponse->{code}==-4)
   	   				{
   	   					$::logger->info("acquire serverid illegal");
   	   					next;
   	   				}
   	   				elsif($jsonResponse->{code}==-6)
   	   				{
   	   					$::logger->info("acquire update fail");
   	   					next;
   	   				}
   	   				else
   	   				{
   	   					$::logger->info("unknown acquire code");
   	   					next;
   	   				}
   	   			}
   	   			elsif($jsonResponse->{status} ne 'succ')
   	   			{
   	   				$::logger->info("unknown acquire status");
   	   				next;
   	   			}
				#解析指令并执行
				my $cmdstr = $data->{cmd};
				my ($cmd,$argv)= split (/,/,$cmdstr);
				my $donehash ={};
				$donehash->{serverid} = $serverid;
				$donehash->{cmdid} = $cmdid;
				if($cmd eq 'U'){
					my $result = update($download_path,$donehash,$argv,$local_root,$sign,$posturl,$section,$cfg_ini);
					if(!$result){
						next;
					}
				}
				elsif($cmd eq 'P')
				{
					my $result = stopServer($restart_script,$donehash,$sign,$posturl,$local_root);
					if(!$result){
						next;
					}
				}
				elsif($cmd eq 'R')
				{
					my $result = restartServer($restart_script,$donehash,$sign,$posturl,$local_root);
					if(!$result){
						next;
					}
				}
				elsif($cmd eq 'U&R')
				{
					my $result = update($download_path,$donehash,$argv,$local_root,$sign,$posturl,$section,$cfg_ini);
					if(!$result){
						next;
					}
					$result = restartServer($restart_script,$donehash,$sign,$posturl,$local_root);
					if(!$result){
						next;
					}
				}
				else
				{
					$::logger->info("unknown cmd");
				}
					
			}
			else{
				$::logger->info("unknown query code");
			}
						
		}
		else
		{
			$::logger->info("unknown query status");
		}
		
	}

	open(F_STATUS, ">$::status_file") or die "can't write status output file: $::status_file";
	print F_STATUS time();
	close F_STATUS;
}

sub stopServer
{
	my ($restart_script,$data,$sign,$posturl,$local_root) = @_;
	my $jsonResponse;
	$data->{desc}="stop...";
	$jsonResponse = httpPort($posturl,$sign,'done',$data);
   	if(!defined($jsonResponse)){
   	   	$::logger->info("done post stop... fail");
   	}
	my $stop = system ("perl $restart_script stop");
    unless ($stop ==0)
	 {
		$data->{desc}="stop server fail";
		$jsonResponse = httpPort($posturl,$sign,'done',$data);
   	   	if(!defined($jsonResponse)){ 
   	   		$::logger->info("done post stop server fail");
   	   	}
   	   	$::logger->info("stop server fail");
		return 0;
	 }
	 $data->{desc}="stop succ";
	$jsonResponse = httpPort($posturl,$sign,'done',$data);
   	if(!defined($jsonResponse)){
   		$::logger->info("done post succ fail");
   	}	
   	return 1;
}

sub restartServer
{
	my ($restart_script,$data,$sign,$posturl,$local_root) = @_;
	
	my $jsonResponse;
	$data->{desc}="restart...";
	$jsonResponse = httpPort($posturl,$sign,'done',$data);
   	if(!defined($jsonResponse)){
   	   	$::logger->info("done post restart... fail");
   	}
	my $stop = system ("perl $restart_script stop");
    unless ($stop ==0)
	{
		$data->{desc}="stop server fail";
		$jsonResponse = httpPort($posturl,$sign,'done',$data);
   	   	if(!defined($jsonResponse)){ 
   	   		$::logger->info("done post stop server fail");
   	   	}
   	   	$::logger->info("stop server fail");
		return 0;
	}
	my $start = system ("perl $restart_script start");
	unless ($start ==0)
	{
		$data->{desc}="start server fail";
		$jsonResponse = httpPort($posturl,$sign,'done',$data);
   	   	if(!defined($jsonResponse)){
   	   		$::logger->info("done post start server fail"); 
   	   	}
   	   	$::logger->info("start server fail");
		return 0;
	}
	 #判断服务器是否启动完成
	 my $succ =1;
	 my $time =time();
	 my $log_time = format_log_time(time()); 
	 my $logfile = "server-".$log_time.".log";
	 my $result = `grep -E "服务器启动完成|服務器啟動完成" ${local_root}Release/$logfile|wc -l`;
	 chomp $result;
	 my $count = $result;
	 my $error = `grep "called by" ${local_root}Release/$logfile|wc -l`;
	 chomp $error;
	 my $errcount = $error;
	 while($result == $count)
	 {
	 	$log_time = format_log_time(time());
	 	if(time()-$time>2400){
	 		last;
	 	}
	 	$logfile = "server-".$log_time.".log";
	 	$error = `grep "called by" ${local_root}Release/$logfile|wc -l`;
	 	chomp $error;
	 	if($error != $errcount){
	 		$succ =0;
	 		last;
	 	}
	 	$result =`grep -E "服务器启动完成|服務器啟動完成" ${local_root}Release/$logfile|wc -l`;
	 	chomp $result;
	 }
	 if(!$succ){
	 	$data->{desc}="start server fail";
		$jsonResponse = httpPort($posturl,$sign,'done',$data);
   	   	if(!defined($jsonResponse)){ 
   	   		$::logger->info("done post start server fail");
   	   	}
		$::logger->info("server can not start!");
		return 0;
	}
	$data->{desc}="restart succ";
	$jsonResponse = httpPort($posturl,$sign,'done',$data);
   	if(!defined($jsonResponse)){
   		$::logger->info("done post succ fail");
   	   die "done post restart failed!\n"; 
   	}	
   	return 1;	
}

sub update
{
	my ($download_path,$donehash,$version,$local_root,$sign,$posturl,$section,$cfg_ini) = @_;
	my $jsonResponse;
	my $content;
	my $filename;
	##########################
	#版本检查
	#my $server_version_txt = `cat ${local_root}Release/server-version.txt`;
	#$server_version_txt =~ /\$Rev:\s*(\d+)/;
	#my $current_version = $1;
	my $current_version = Utils::get_section_value($section, "version", "");
	$::logger->info("current version :$current_version");
	if($current_version >= $version){
		$donehash->{desc} = "version too old";
		$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
		if(!defined($jsonResponse)){
			$::logger->info("done post version too old fail"); 
		}
		$::logger->info("version too old");
		return 0;
	}
	$donehash->{desc} = "update...";
	$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
	if(!defined($jsonResponse)){
		$::logger->info("done post update... fail"); 
	}	
	my $data ={};
	$data->{serverid} = $donehash->{serverid};
	$data->{version} = $version;
	$content = httpPort($posturl,$sign,'download',$data);
	if(!defined($content->[1])){
		$donehash->{desc}="download fail";
		$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
		if(!defined($jsonResponse)){ 
			$::logger->info("done post download fail");
		}
		$::logger->info("download file failed!");
		return 0;
	}
	 make_path($download_path);
	 $filename = "GMServer_${version}_standard_Update.zip";
	 open FILE ,">$download_path/$filename" or die "create file $filename failed!\n ";
	 binmode( FILE, ":raw");
	 print FILE $content->[1];
	 close FILE;
	 $ctx->add($content->[1]);
	 my $filemd5 = $ctx->hexdigest;
	 my $downmd5 = $content->[0];
	 #md5 校验
	 if ($filemd5 ne $downmd5){
	 	$donehash->{desc}="download fail";
		$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
		if(!defined($jsonResponse)){ 
			$::logger->info("done post download fail");
		}
		$::logger->info("download file md5 check failed!");
		return 0;
	 }
	 $donehash->{desc}="download succ";
	 $jsonResponse = httpPort($posturl,$sign,'done',$donehash);
	 if(!defined($jsonResponse)){
		$::logger->info("done post download fail"); 
	 }
	my $somezip = Archive::Zip->new();
	unless ( $somezip->read("$download_path/$filename") == AZ_OK ) 
	{
		$donehash->{desc}="decompression fail";
	 	$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
			if(!defined($jsonResponse)){ 
				$::logger->info("done post read zip failed!");
			}
			$::logger->info("decompression fail");
	   return 0;
	}
	
	#检测libMobyServer.so文件是否存在
	foreach my $member ($somezip->members()){
        my $filelist  = $member->fileName();
        if($filelist =~/libMobyServer\.so$/){
			$donehash->{desc}="update zip libMobyServer.so is exists!";
			$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
			if(!defined($jsonResponse)){ 
				$::logger->info("done post update zip libMobyServer.so is exists!");
			}
			$::logger->info("update zip libMobyServer.so is exists!");
             return 0;
        }
    }
	$somezip->extractTree(undef, $local_root);
	##################
	#更新本地版本号
	updateLocalVersion($version, $section, $cfg_ini, $::AppPath . "/auto_update.cfg");
						
	$donehash->{desc}="update succ";
	$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
	if(!defined($jsonResponse)){
		$::logger->info("done post succ fail"); 
	}
	return 1;	
}

sub httpPort
{
	my ($posturl,$sign,$action,$hash)= @_;
	print "port type :$action\n";
	my $request;
	my $response;
    my $jsonResponse;
	my $content;
	my $httpclient = new LWP::UserAgent();
	$posturl =~ s/{__ACTION__}/$action/;
	my $json_text = to_json($hash,{ utf8  => 1 });
	my $data = "$sign$action$json_text";
	print "$data\n";
	$ctx->add($data);
	my $digest = $ctx->hexdigest;
	$posturl .= $digest;
	#post 数据
	$request = HTTP::Request->new( "POST", $posturl);
	$request->content($json_text);
	my $iTryCount = 0;
	 my $bIsOk = 0;
	 while( !$bIsOk && $iTryCount < 5) {
		$iTryCount++;
 	   	eval
  	  	{
    	 $response = $httpclient->request( $request);
   	     if(!$response->is_success) 
     	   {
				die( $!);
		   }
   		 };
  	  	if($@)
   		 {
    	    print "report error:$@\n";
    	    $bIsOk = 0;
    	    next;
   		 }
   	    $content = $response->content;
  		if($action eq 'download'){
  			print $action,"\n";
  			if(!defined($content)){
  				print "download content is empty\n";
  				$bIsOk = 0;
  				next;
  			}
  			else{
  				$bIsOk = 1;
  				next;
  			}
  		}
  	  	eval
   	 	{
   	  	   $jsonResponse = JSON->new->utf8->decode( $content);
   		 };
   		 if($@)
   	 	{
    	   print "json decode error:$@\n";
    	    $bIsOk = 0;
    	    next;
   		 }
    	if( "HASH" ne ref( $jsonResponse) || !$jsonResponse->{status} || !$jsonResponse->{code} || !$jsonResponse->{data}) 
   		 {
   	   	  print "getdata error:illegal json format";
      	  $bIsOk = 0;
      	  next;
   		 }
  	  $bIsOk = 1;
	 }

	if( !$bIsOk) {
		return undef;
	}
	if($action eq 'download'){
		#$request->header($field)
		my $head = $response->header("Moby-Mgrsvr-FileMd5");
		my $download =[];
		push @{$download},$head;
		push @{$download},$content;
		print $download->[0],"\n";
		return $download;
	}
	return $jsonResponse;   
}

sub format_log_time
{
	my ($time) = @_;

	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);
	$mon++;
	$year += 1900;

	return sprintf("%04d-%02d-%02d-%02d", $year, $mon, $mday, $hour);
}

sub updateLocalVersion
{
	my ($version, $section, $ini, $filePath) = @_;
	for (@{$section->{'kvs'}}) {
		my $kv = $_;
		if (lc($kv->{'key'}) eq "version") 
		{
			$kv->{'value'} = $version;
			last;
		}
	}
	
	my $str = Utils::concatIni($ini);
	open FILE, ">$filePath" or die "can't write local file: $filePath";
	binmode(FILE, ":encoding(utf8)");
	print FILE  $str;
	close FILE;
}