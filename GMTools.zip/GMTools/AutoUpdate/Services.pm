use strict;
use warnings;
use FindBin;
use Utils;

##########################################
#
# 服务模块
#    提供系统服务启动,停止等方法
#
##########################################

package Services;

sub StartServicesByFile
{
	my ($file) = @_;
	my $p = sort_services($file);
	for(@{$p})
	{
		print $_->{'name'},"\n";
		StartService($_->{'name'});
	}
}

sub StopServicesByFile
{
	my ($file) = @_;
	my $p = sort_services($file);
	my $count = @{$p};
	for(my $i=$count-1; $i>=0; $i--)
	{
		print $p->[$i]->{'name'},"\n";
		StopService($p->[$i]->{'name'});
	}
}

sub parse_tree
{
	my ($cfg_file, $servicesHash) = @_;
	my $cfg_ini = Utils::load_ini($cfg_file);

	for (@{$cfg_ini})
	{
		my $section = $_;
		my $name = $section->{'name'};

		my $depend = Utils::get_section_value($section, "depend", "");
		my $cmd = Utils::get_section_value($section, "cmd", "");

		my %s;
		my @ar;
		$s{'name'} = $name;
		$s{'depend'} = $depend;
		$s{'cmd'} = $cmd;
		$s{'child'} = \@ar;

		push @{get_parent($depend, $servicesHash)->{'child'}}, \%s;
	}
}

sub sort_services
{
	my ($cfg_file) = @_;
	my %services;
	my @empty_child = ();
	$services{'name'} = "";
	$services{'child'} = \@empty_child;
	parse_tree($cfg_file, \%services);

	my @service_list;

	my @s;
	push @s, \%services;

	while(@s>0)
	{
		my $p = shift @s;

		if ($p->{'name'} !~ /^\s*$/) {
			push @service_list, $p;
		}

		for(@{$p->{'child'}})
		{
			push @s, $_;
		}
	}

	return \@service_list;
}

sub get_parent
{
	my ($name, $servicesHash) = @_;

	return $servicesHash if $name =~ /^\s*$/;

	my @s;
	push(@s, $servicesHash);

	while(@s > 0)
	{
		my $pAr = shift @s;

		if ($pAr->{'name'} eq $name) {
			return $pAr;
		}

		for(@{$pAr->{'child'}})
		{
			push @s, $_;
		}
	}

	return $servicesHash;
}

sub usage
{
	die "serivces.pl  start|stop|install|remove";
}


sub StartService
{
	my ($name) = @_;
	#run service
	{
		print "start..\n";
		my @cmds;
		push @cmds, "service";
		push @cmds, $name;
		push @cmds, "start";

		system(@cmds) == 0
			or print "system @cmds failed: $?";
	}
}

sub StopService
{
	my ($name) = @_;
	#stop service
	{
		print "start..\n";
		my @cmds;
		push @cmds, "service";
		push @cmds, $name;
		push @cmds, "stop";

		system(@cmds) == 0
			or print "system @cmds failed: $?";
	}
}

1;