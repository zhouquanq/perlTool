#!/usr/bin/perl
use strict;
use warnings;
use utf8;
use JSON;
use Digest::MD5;
use LWP::UserAgent;
use Net::FTP;
use FindBin;
use Encode;
use Compress::Zlib;
use File::Path qw(make_path remove_tree);
use Archive::Zip qw( :ERROR_CODES :CONSTANTS );
use Cwd;

##########################################
#
# 更新工具程序
#    用于更新工具和资源服
#支持多个运营商以"_"分割longyin_leyi_ledou
##########################################
$::APPLICATION_PATH = $FindBin::Bin;
my $ctx = Digest::MD5->new;
my $exc = "$::APPLICATION_PATH/../services/restart.sh";
my $exc_cfg = "$::APPLICATION_PATH/../services/install.cfg";

BEGIN
{
	use PerlIO::encoding;
	our $continue = 1;
    our $AppPath = $FindBin::Bin;
    chdir($FindBin::Bin);
	push( @INC, $FindBin::Bin);
}

use Utils;
use Moby::Business::LoggerMan;
use Moby::Business::TimeMan;

{
	our $WARN_LOCKCOUNT = 0;
	our $last_okreporttime = 0;
	our $okreport_space = 3600*3;
	our $apprun_space = 60;
	our $ressvr_dlmaxsec = 50;
	our $AppName = "CheckTools";
    
	our $timeMan = Moby::Business::TimeMan->new();
    our $loggerMan = Moby::Business::LoggerMan->new(
        timeMan=>$::timeMan,
        apppath=>$::AppPath
    );
	our $logger = $::loggerMan->getLogger();
    $::timeMan->setLogger( $::logger);
	
	$::logger->info( "server start...");
	
	$::status_file = shift(@ARGV);
	if (!defined($::status_file) || length($::status_file) <= 0) {
	die "perl -w update_tools.pl path_of_status_file";
	}
	
	for(@ARGV){
		next unless /^\-srv$/i;
		
		my $pid = fork();
		if ($pid < 0) {
			die "fork: $!";
		}
		elsif ($pid) {
			exit 0;
		}
	
		chdir($FindBin::Bin);
	
		open(STDIN,  "</dev/null");
		open(STDOUT, ">/dev/null");
		open(STDERR, ">&STDOUT");
		last;
	}
	
	$::WARN_LOCKCOUNT = 0;
    
	$SIG{TERM} = sub { $::continue = 0 };

	$SIG{__WARN__} = sub{
	
        my ($text) = @_;
        my @loc = caller(0);
        chomp($text);
        
        my $text_ = $text ? $text : "";
        $::logger->warn('warn: '. $text_); 
        
        my $index = 1;
        for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
        {
            $::logger->warn( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
        };
        return 1;
    };

    $SIG{__DIE__} = sub{
        
        my ($text) = @_;
        my @loc = caller(0);
        chomp($text);

        my $text_ = $text ? $text : "";
        $::logger->warn('error: '. $text_); 
        
        my $index = 1;
        for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
        {
            $::logger->warn( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
        };
        return 1;
    };
}


$|=1;
while($::continue)
{
	run();
	sleep(10);
}

sub run
{

	$::timeMan->runTick();
    $::loggerMan->runTick();
    my $posturl = "";#post 地址
    my $server = ""; #服务器标志
    my $ops = "";#支持多运营商标志"_"分隔
    my $packagefilepath = "";#包路径
    my $sign = "";#校验码
    my $local_root = "";
    
    
	my $tmNow = time();
	print "now: ", Utils::format_time($tmNow),"\n";
 	my $cfg_ini = Utils::load_ini($::AppPath . "/update_tools.cfg");
	for (@{$cfg_ini})
	{
		my $section = $_;
		
		my $name = lc($section->{'name'});
		$name =~ s/^\s+//;
		$name =~ s/\s+$//;
		if($name eq "serverinfo")
		{
			 $posturl = Utils::get_section_value($section, "posturl", "");
			 $server = Utils::get_section_value($section, "server", "");
			 $ops = Utils::get_section_value($section, "op", "");
			 $packagefilepath = Utils::get_section_value($section, "package_path", "");
			 $sign = Utils::get_section_value($section, "sign", "");
			 next;
		}
		my $type = "";
		my $version = "";
		my $local_root = "";
		if($server =~ /ga/)
		{
			next if($name !~/ga/);
			$type = Utils::get_section_value($section, "type", "");
			$version = Utils::get_section_value($section, "version", "");
			$local_root = Utils::get_section_value($section, "local_root", "");
		}
		if($server =~ /gs(\d+)/)
		{
			next if ($name !~/gs/);
			$type = Utils::get_section_value($section, "type", "");
			$version = Utils::get_section_value($section, "version", "");
			$local_root = Utils::get_section_value($section, "local_root", "");
		}
		if($server =~ /res/)
		{
			next if ($name !~/res/);
			$type = Utils::get_section_value($section, "type", "");
			$version = Utils::get_section_value($section, "version", "");
			$local_root = Utils::get_section_value($section, "local_root", "");
		}
		my @op = split ('_',$ops);
		foreach my $op (@op)
		{
    		#checkout 接口
    		my $jsonResponse;
   		
    		my $checkouthash ={};
    		$checkouthash->{op}= $op;
    		$checkouthash->{server}= $server;
    		$checkouthash->{type}= $type;
    		$checkouthash->{version}= $version;
    		$jsonResponse = httpPort($posturl,$sign,'checkout',$checkouthash);
    		if(!defined($jsonResponse)){
    			$::logger->info("checkout post failed!");
       	   		next;
    		}
			#die "checkout test\n";   		 
    		#query  接口
    	    my $queryhash ={};
    	    $queryhash->{op}= $op;
    	    $queryhash->{server}= $server;
    	    $queryhash->{type}= $type;
       	    $jsonResponse = httpPort($posturl,$sign,'query',$queryhash);
       	    if(!defined($jsonResponse))
       	    {
    			$::logger->info("query post failed!");
    			next;
       	    }
    		#query 反馈json 解析	
    		if($jsonResponse->{status} eq 'fail')
    		{
    			if($jsonResponse->{code}==-1){
    				$::logger->info("query need more params");
    			}
    			if($jsonResponse->{code}==-2){
    				$::logger->info("query no access");
    			}
    			next;
    		}
    		elsif($jsonResponse->{status} eq 'succ')
    		{
    			if($jsonResponse->{code}==2){
    			print "no cmd!\n";
    			next;
    			}
    			elsif($jsonResponse->{code}==1){
    				my $data = $jsonResponse->{data};
    				if(!defined($data)){
    					$::logger->info("query getdata error:data is empty");
    					next;
    				}
    				my $cmdid = $data->{cmdid};
    				#反馈获取
    				my $acquirehash ={};
    				$acquirehash->{cmdid}=$cmdid;
       	   			$jsonResponse = httpPort($posturl,$sign,'acquire',$acquirehash);
       	   			if(!defined($jsonResponse)){
       	   				$::logger->info("acquire post failed!");
       	   				next;
       	   			}
       	   			#处理反馈结果
       	   			if($jsonResponse->{status} eq 'fail')
       	   			{
       	   				if($jsonResponse->{code}==-5)
       	   				{
       	   					$::logger->info("acquire cmdid already mark");
       	   				}
       	   				elsif($jsonResponse->{code}==-1)
       	   				{
       	   					$::logger->info("acquire need more params");
       	   					next;
       	   				}
       	   				elsif($jsonResponse->{code}==-2)
       	   				{
       	   					$::logger->info("acquire no access");
       	   					next;
       	   				}
       	   				elsif($jsonResponse->{code}==-4)
       	   				{
       	   					$::logger->info("acquire cmdid not exist");
       	   					next;
       	   				}
       	   				elsif($jsonResponse->{code}==-6)
       	   				{
       	   					$::logger->info("acquire update fail");
       	   					next;
       	   				}
       	   				else
       	   				{
       	   					$::logger->info("unknown acquire code");
       	   					next;
       	   				}
       	   			}
       	   			elsif($jsonResponse->{status} ne 'succ')
       	   			{
       	   				$::logger->info("unknown acquire status");
       	   				next;
       	   			}
       	   			#更新
       	   			my $cmd5 = $data->{cmd5};
       	   			my $cmdline = $data->{cmdline};
       	   			my $update_version = $data->{version};
    				my $donehash ={};
    				$donehash->{cmdid} = $cmdid;
    				my $result = update($type,$cmd5,$cmdline,$packagefilepath,$local_root,$donehash,$update_version,$sign,$posturl,$section,$cfg_ini);
       	   			if(!$result){
    					next;
    				}
    			}
    		}
    		else
    		{
    			$::logger->info("unknown query status");
    		}
    	}	
	}
	open(F_STATUS, ">$::status_file") or die "can't write status output file: $::status_file";
	print F_STATUS time();
	close F_STATUS;
}



sub update
{
	my ($type,$cmd5,$cmdline,$packagefilepath,$local_root,$donehash,$version,$sign,$posturl,$section,$cfg_ini) = @_;
	my $jsonResponse;
	my $content;
	my $filename;
	##########################
	#版本检查
	my $local_version = Utils::get_section_value($section, "version", "");
	$::logger->info("local version:$local_version\t update version:$version");
	if($local_version > $version){
		$donehash->{desc} = "version too old";
		$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
		if(!defined($jsonResponse)){
			$::logger->info("done post version too old fail"); 
		}
		$::logger->info("version too old");
		return 0;
	}
	$donehash->{desc} = "update...";
	$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
	if(!defined($jsonResponse)){
		$::logger->info("done post update... fail"); 
	}	
	if($local_version < $version){
		#下载包
		$::logger->info("download package...");
		my $package ={};
		$package->{type} = $type;
		$package->{version} = $version;
		$content = httpPort($posturl,$sign,'download',$package);
		if(!defined($content->[1])){
			$donehash->{desc}="download package fail";
			$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
			if(!defined($jsonResponse)){ 
				$::logger->info("done post download package fail");
			}
			$::logger->info("download package failed!");
			return 0;
		}
		 make_path($packagefilepath);
		 $filename = "${type}_${version}_.zip";
		 open FILE ,">$packagefilepath/$filename" or die "create file $filename failed!\n ";
		 binmode( FILE, ":raw");
		 print FILE $content->[1];
		 close FILE;
		 $ctx->add($content->[1]);
		 my $filemd5 = $ctx->hexdigest;
		 my $downmd5 = $content->[0];
		 #md5 校验
		 if ($filemd5 ne $downmd5){
			$donehash->{desc}="download package md5 check fail";
			$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
			if(!defined($jsonResponse)){ 
				$::logger->info("done post package md5 check fail");
			}
			$::logger->info("download package md5 check failed!");
			return 0;
		 }
		 $donehash->{desc}="download package succ";
		 $jsonResponse = httpPort($posturl,$sign,'done',$donehash);
		 if(!defined($jsonResponse)){
			$::logger->info("done post download package fail"); 
		 }
		 $::logger->info("download package succ");
		 $::logger->info("decompression package path :$local_root");
		my $somezip = Archive::Zip->new();
		unless ( $somezip->read("$packagefilepath/$filename") == AZ_OK ) 
		{
			$donehash->{desc}="decompression package fail";
			$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
				if(!defined($jsonResponse)){ 
					$::logger->info("done post read zip failed!");
				}
				$::logger->info("decompression package fail");
		   return 0;
		}
		$somezip->extractTree(undef, $local_root);
		$::logger->info("decompression package succ");
		updateLocalVersion($version, $section, $cfg_ini, $::AppPath . "/update_tools.cfg");
	}
	#die "download test\n";
	##################

	#处理命令文件
	if($cmdline){
		$ctx->add($cmdline);
		my $cmdlinemd5 = $ctx->hexdigest;
		if($cmdlinemd5 ne $cmd5){
			$donehash->{desc}="cmd5 check fail";
			$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
			if(!defined($jsonResponse)){ 
			$::logger->info("done post cmd5 check fail");
			}
			$::logger->info(" cmd5 check failed!");
			return 0;
		}
		
    	foreach my $cmd (split/;/,$cmdline){
    		if(!$cmd){
    			next;
    		}
    		$::logger->info("exec $cmd");
			if($cmd =~/service\s*(.*)\s*restart/){
				my $service = $1;
				my $cmd = "$exc $exc_cfg stop $service";
				my $result = system ($cmd);
				unless ($result == 0){	
					$donehash->{desc}="exec $cmd fail";
					$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
					if(!defined($jsonResponse)){ 
						$::logger->info("done post exec $cmd  fail");
					}
					$::logger->info("exec $cmd failed!");
					return 0;
				}
				$cmd = "$exc $exc_cfg start $service";
				$result = system ($cmd);
				unless ($result == 0){	
					$donehash->{desc}="exec $cmd fail";
					$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
					if(!defined($jsonResponse)){ 
						$::logger->info("done post exec $cmd  fail");
					}
					$::logger->info("exec $cmd failed!");
					return 0;
				}
			}
			else{
				my $result = system ($cmd);
				unless ($result == 0){	
					$donehash->{desc}="exec $cmd fail";
					$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
					if(!defined($jsonResponse)){ 
						$::logger->info("done post exec $cmd fail");
					}
					$::logger->info("exec $cmd failed!");
					return 0;
				}
			}
    	}
    	$donehash->{desc}="exec cmdline succ";
	 	$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
		 if(!defined($jsonResponse)){
			$::logger->info("done post exec cmdline fail"); 
	 	 }
	 	 $::logger->info("exec cmdline succ");
    }
	else{
		
		print "cmd5:$cmd5  sign:$sign\n";
		if($cmd5 ne $sign){
			$donehash->{desc}="cmd5 check fail";
			$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
			if(!defined($jsonResponse)){ 
			$::logger->info("done post cmd5 check fail");
			}
			$::logger->info(" cmd5 check failed!");
			return 0;	
		}
		
		if ($type eq 'RST' || $type eq 'RSC'){
			my $cmd = "service GM_FileSvr restart";
			my $result = system ("$cmd");
			unless ($result == 0){	
				$donehash->{desc}="exec $cmd fail";
    			$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
    			if(!defined($jsonResponse)){ 
    				$::logger->info("done post exec cmd fail");
    			}
				$::logger->info("exec $cmd failed!");
				return 0;
			}
		}
	}
	#更新本地版本号
	$donehash->{desc}="update succ";
	$jsonResponse = httpPort($posturl,$sign,'done',$donehash);
	if(!defined($jsonResponse)){
		$::logger->info("done post succ fail"); 
	}
	return 1;	
}

sub httpPort
{
	my ($posturl,$sign,$action,$hash)= @_;
	print "$posturl\n";
	print "port type :$action\n";
	my $request;
	my $response;
    my $jsonResponse;
	my $content;
	my $httpclient = new LWP::UserAgent();
	$posturl =~ s/{__ACTION__}/$action/;
	my $json_text = to_json($hash,{ utf8  => 1 });
	my $data = "$sign$action$json_text";
	print "$data\n";
	$ctx->add($data);
	my $digest = $ctx->hexdigest;
	$posturl .= $digest;
	#post 数据
	print "$posturl\n";
	$request = HTTP::Request->new( "POST", $posturl);
	$request->content($json_text);
	my $iTryCount = 0;
	 my $bIsOk = 0;
	 while( !$bIsOk && $iTryCount < 5) {
		$iTryCount++;
 	   	eval
  	  	{
    	 $response = $httpclient->request( $request);
   	     if(!$response->is_success) 
     	   {
				die( $!);
		   }
   		 };
  	  	if($@)
   		 {
    	    print "report error:$@\n";
    	    $bIsOk = 0;
    	    next;
   		 }
   	    $content = $response->content;
  #####################
   	    if($action ne 'download'){
   	    	print $content,"\n";
   		}
   	    #print $content,"\n";
   	    #die "query content\n";
  		if($action eq 'download'){
  			print $action,"\n";
  			if(!defined($content)){
  				print "download content is empty\n";
  				$bIsOk = 0;
  				next;
  			}
  			else{
  				$bIsOk = 1;
  				next;
  			}
  		}
  	  	eval
   	 	{
   	  	   $jsonResponse = JSON->new->utf8->decode( $content);
   		 };
   		 if($@)
   	 	{
    	   print "json decode error:$@\n";
    	    $bIsOk = 0;
    	    next;
   		 }
    	if( "HASH" ne ref( $jsonResponse) || !$jsonResponse->{status} || !$jsonResponse->{code} || !$jsonResponse->{data}) 
   		 {
   	   	  print "getdata error:illegal json format";
      	  $bIsOk = 0;
      	  next;
   		 }
  	  $bIsOk = 1;
	 }

	if( !$bIsOk) {
		return undef;
	}
	if($action eq 'download'){
		#$request->header($field)
		my $head = $response->header("Moby-Mgrsvr-FileMd5");
		my $download =[];
		push @{$download},$head;
		push @{$download},$content;
		print $download->[0],"\n";
		return $download;
	}
	return $jsonResponse;   
}

sub format_log_time
{
	my ($time) = @_;

	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);
	$mon++;
	$year += 1900;

	return sprintf("%04d-%02d-%02d-%02d", $year, $mon, $mday, $hour);
}

sub updateLocalVersion
{
	my ($version, $section, $ini, $filePath) = @_;
	for (@{$section->{'kvs'}}) {
		my $kv = $_;
		if (lc($kv->{'key'}) eq "version") 
		{
			$kv->{'value'} = $version;
			last;
		}
	}
	
	my $str = Utils::concatIni($ini);
	open FILE, ">$filePath" or die "can't write local file: $filePath";
	binmode(FILE, ":encoding(utf8)");
	print FILE  $str;
	close FILE;
}