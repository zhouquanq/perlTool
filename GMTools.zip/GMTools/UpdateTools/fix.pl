#########################################
#修改GMTools下各个工具配置文件和服务重启
#########################################

#! perl -w
use strict;
use FindBin;
use Tie::File;

$::APPLICATION_PATH = $FindBin::Bin;
my $tools_cfg = {
	'FileUpload' => {
					service => 'GM_FileUpload',
					cfg => 'config.ini',
					example => 'check_tools.cfg.example',	
					},

	'AutoBak' => {
					 service => 'GM_AutoBak',
					 cfg     => 'auto_bak.cfg',
					 example => 'check_tools.cfg.example',
					 },
	'AutoClean' => {
					 service => 'GM_AutoClean',
					 cfg     => 'auto_clean.cfg',
					 example => 'check_tools.cfg.example',
					 },
	'AutoUpdate' =>  {
					  service => 'GM_AutoUpdate',
					  cfg     => 'auto_update.cfg',
					  example => 'check_tools.cfg.example',
					 },
	'CheckTools' =>  {
						 service => 'GM_CheckTools',
						 cfg     => 'check_tools.cfg',
						 example => 'check_tools.cfg.example',
					 },	
};
=pod
my $path = $::APPLICATION_PATH;
my $workpath;
if($path =~ /(.*?)\/GMTools/)
{
    $workpath =$1;
}
my $services = $workpath . "/GMTools/services/services.cfg";
my @array =();
tie @array, 'Tie::File', $services or die "file map list false $!";
if(-e $services)
{
        my $newstr = "[GM_SaveGame]\ndepend=GM_GameServer\ncmd=$workpath/GMServer/Release/StartGMSaveGame -fp $workpath/GMTools/status_file/savegame.status -srv 1";
        $array[scalar @array+1] = $newstr;
        untie @array;
}
@array =();
my $install_cfg = $workpath . "/GMTools/services/install.cfg";
tie @array, 'Tie::File', $install_cfg or die "file map list false $!";
if(-e $install_cfg)
{
        my $newstr = "[GM_SaveGame]\ndepend=GM_GameServer\ncmd=$workpath/GMServer/Release/StartGMSaveGame -fp $workpath/GMTools/status_file/savegame.status -srv 1";
        $array[scalar @array+1] = $newstr;
        untie @array;
}
@array =();
my $check_tools = $workpath . "/GMTools/CheckTools/check_tools.cfg";
tie @array, 'Tie::File', $check_tools or die "file map list false $!";
if(-e $check_tools)
{
        my $newstr = "[status_file]\nname=savegame\nfile=$workpath/GMTools/status_file/savegame.status\ntime=600";
        $array[scalar @array+1] = $newstr;
        untie @array;
}
=cut
#安装perl-514 版本
#my $cmd ='wget http://pkgload.ly.ta.cn/feiyuhd/perl5.zip';
#die "$cmd exec false $!" unless (0 == system($cmd));
#$cmd = 'unzip -o perl5.zip -d /';
#die "$cmd exec false $!" unless (0 == system($cmd));
my $exc = "$::APPLICATION_PATH/../services/restart.sh";
my $exc_bak = "$::APPLICATION_PATH/../services/restart_bak.sh";
my $exc_cfg = "$::APPLICATION_PATH/../services/install.cfg";
my $exc_cfg_example = "$::APPLICATION_PATH/../services/install.cfg.example";


foreach my $app (keys %{$tools_cfg}){
	if($app eq 'FileUpload'){
		my $file_cfg = $tools_cfg->{$app}->{cfg};
		my $service = $tools_cfg->{$app}->{service};

		$file_cfg = "$::APPLICATION_PATH/../$app/$file_cfg";
		# my @array = ();
		# tie @array, 'Tie::File', $file_cfg or die "file map list false $!";
		# foreach my $i (0..@array){
			# next unless (defined $array[$i]);
			# next if($array[$i] =~ /\s*#/);
			# if($array[$i] =~ /name\s*=\s*update_tools/)
			# {
				# my $j = $i+2;
				# $array[$j] = "time = 1200";
			# }
			# $array[$i] =~ s/mobile/filemove/ if($array[$i] =~ /(log|db)\.mobile/);

			# if($array[$i] =~ /(log|db)\.fileformat/){
					# my $type = $1;
					# my $j = $i+1;
					# if (defined($array[$j]) && $array[$j] =~ /$type\.buffer/){
							# next;
					# }else{
							# $array[$i] .= "\n$type.buffer = 1024";
					# }
			# }
		# }
		# untie @array;

		#my $cmd = "$exc_bak $exc_cfg stop $service";
		#die "$service stop false $!" unless (0 == system($cmd));
		my $cmd =  "sed -i 's/124.232.163.82/log.dc.ta.cn/g;s/124.232.163.34/db.dc.ta.cn/g' $file_cfg";
		die "$cmd exec false $!" unless (0 == system($cmd));
		$cmd = "$exc $exc_cfg stop $service";
		die "$service stop false $!" unless (0 == system($cmd));
		$cmd = "$exc $exc_cfg start $service";
		die "$service start false $!" unless (0 == system($cmd));
	}
	
	
	if($app eq 'AutoBak'){
		my $file_cfg = $tools_cfg->{$app}->{cfg};
		my $service = $tools_cfg->{$app}->{service};
		$file_cfg = "$::APPLICATION_PATH/../$app/$file_cfg";
		my $file_cfg_example  = "$::APPLICATION_PATH/../$app/auto_bak.cfg.example";
		#用新的auto_bak.cfg 覆盖,修改对应的配置文件
		my $cmd = "cp -f $file_cfg_example $file_cfg";
		die "$cmd exec false $!" unless (0 == system($cmd));
		
		my $path = $::APPLICATION_PATH;
		my $workpath;
		if($path =~ /(.*?)\/GMTools/)
		{
			$workpath =$1;
		}
		my @array = ();
		tie @array, 'Tie::File', $file_cfg or die "file map list false $!";
		foreach my $i (0..@array){
			next unless (defined $array[$i]);
			 if($array[$i] =~ /GMServer/)
			{
				$array[$i] =~ s/\/GMServer/$workpath\/GMServer/g;
			 }
			  if($array[$i] =~ /data/)
			{
				$array[$i] =~ s/\/data/$workpath\/data/g;
			 }
		}
		untie @array;
		$cmd = "$exc $exc_cfg stop $service";
		die "$service stop false $!" unless (0 == system($cmd));
		$cmd = "$exc $exc_cfg start $service";
		die "$service start false $!" unless (0 == system($cmd));
	}
	
	if($app eq 'AutoClean'){
		my $file_cfg = $tools_cfg->{$app}->{cfg};
		my $service = $tools_cfg->{$app}->{service};
		$file_cfg = "$::APPLICATION_PATH/../$file_cfg";
		my @array = ();
		tie @array, 'Tie::File', $file_cfg or die "file map list false $!";
		untie @array;
		#my $cmd = "$exc_bak $exc_cfg stop $service";
		#die "$service stop false $!" unless (0 == system($cmd));
	}
	
	if($app eq 'AutoUpdate'){
		my $file_cfg = $tools_cfg->{$app}->{cfg};
		my $service = $tools_cfg->{$app}->{service};
		$file_cfg = "$::APPLICATION_PATH/../$app/$file_cfg";
		my @array = ();
		tie @array, 'Tie::File', $file_cfg or die "file map list false $!";
		#foreach my $i (0..@array){
		#	 if($array[$i] =~ /restart_script\s*=(.*)serverRestart.pl/)
		#	{
		#		my $path = $1;
		#		$path =~s/\/GMServer\/Release/\/GMTools\/services/g;
		#	   $array[$i] = "restart_script =". $path . "serverRestart.pl";
		#	 }
#
		#}
		untie @array;
#		my $cmd = "$exc $exc_cfg stop $service";
#		die "$service stop false $!" unless (0 == system($cmd));
#		$cmd = "$exc $exc_cfg start $service";
#		die "$service start false $!" unless (0 == system($cmd));
#		
	   # $service = "GM_AutoRestart";
       # my $cmd = "$exc_bak $exc_cfg stop $service";
		#die "$service stop false $!" unless (0 == system($cmd));
		#$cmd = "$exc $exc_cfg start $service";
		#die "$service start false $!" unless (0 == system($cmd));
		#my $cmd = "$exc $exc_cfg stop $service";
		#die "$service stop false $!" unless (0 == system($cmd));
		#$cmd = "$exc $exc_cfg start $service";
		#die "$service start false $!" unless (0 == system($cmd));
	}
	
	if($app eq 'CheckTools'){
		my $file_cfg = $tools_cfg->{$app}->{cfg};
		my $service = $tools_cfg->{$app}->{service};
#		 my $workpath ="";
#         if($::APPLICATION_PATH =~/(\/dragonstamp.*)\/GMTools/){
#         	$workpath = $1;
#        }
#        else{
#        	$workpath = "";
#        }
#		my $serverId ="";
#		my $manageUrl = "";
#		my $file_cfg = $tools_cfg->{$app}->{cfg};
#		my $service = $tools_cfg->{$app}->{service};
#		$file_cfg = "$::APPLICATION_PATH/../$app/$file_cfg";
#		my $example_cfg = $tools_cfg->{$app}->{example};
#		$example_cfg = "$::APPLICATION_PATH/../$app/$example_cfg";
#		my $fh;
#		open ($fh ,"<$file_cfg") || die "can't open $file_cfg!";
#		while(my $line = <$fh>){
#			if ($line =~/name\s*=\s*gs(\d+)/){
#				$serverId = $1;
#			}
#			if ($line =~/posturl\s*=\s*http:\/\/(.*)\/index.php/){
#				$manageUrl = $1;
#			}
#		}
#		close ($fh);
#		if($serverId)
#		{
#    		print `cp  -f $example_cfg $file_cfg`;
#    		my $filebak = [];
#    		tie @{$filebak}, 'Tie::File', $file_cfg or die "file map list false $!";
#    		for(0..@{$filebak}-1){
#    			my $index = $_;
#    			my $line = $filebak->[$index];
#        		if($line =~ /{__SID__}/){
#        			$line =~ s/{__SID__}/$serverId/g;
#        			$filebak->[$index] = $line;
#        			next;
#        		}
#        		if($line =~ /posturl\s*=\s*/){
#        			$line =~ s/{__HOSTNAME__}/$manageUrl/g;
#        			$filebak->[$index] = $line;
#        			next;
#        		}
#        		if($line =~ /\/GMTools/){
#    				$line =~ s/\/GMTools/$workpath\/GMTools/g;
#    				$filebak->[$index] = $line;
#    			}
#    			if($line =~ /\/GMServer/){
#    				$line =~ s/\/GMServer/$workpath\/GMServer/g;
#    				$filebak->[$index] = $line;
#    			}
#    			
#    			if($line =~ /\/data/){
#    				$line =~ s/\/data/$workpath\/data/g;
#    				$filebak->[$index] = $line;
#    				next;
#    			}	
#    		}
#    		untie @{$filebak};
#    	}	
		#my $cmd = "$exc_bak $exc_cfg stop $service";
		#die "$service stop false $!" unless (0 == system($cmd));
		#$cmd = "$exc $exc_cfg start $service";
		#die "$service start false $!" unless (0 == system($cmd));
	}

}
=pod
my  $service = 'GM_AutoRestart';
$cmd =  "$exc_bak $exc_cfg stop $service";
die "$service stop false $!" unless (0 == system($cmd));

#用新的install.cfg 覆盖,修改对应的配置文件
$cmd = "cp -f $exc_cfg_example $exc_cfg";
die "$cmd exec false $!" unless (0 == system($cmd));
{
	my $path = $::APPLICATION_PATH;
	my $workpath;
	if($path =~ /(.*?)\/GMTools/)
	{
		$workpath =$1;
	}

	my $filebak = [];
	my $install_cfg = $workpath . "/GMTools/services/install.cfg";
	tie @{$filebak}, 'Tie::File', $install_cfg or die "file map list false $!";
	if(-e $install_cfg)
	{
		   for(0..@{$filebak}-1){
	    			my $index = $_;
	    			my $line = $filebak->[$index];
					if($line =~ /\/GMTools/){
	    				$line =~ s/\/GMTools/$workpath\/GMTools/g;
						$filebak->[$index] = $line;
	    			}
			}
	    		
	}
	untie @{$filebak};
}

foreach my $app (keys %{$tools_cfg}){
	my $service = $tools_cfg->{$app}->{service};
	my  $cmd = "$exc $exc_cfg start $service";
	die "$service start false $!" unless (0 == system($cmd));
}
$service = 'GM_AutoRestart';
$cmd =  "$exc $exc_cfg start $service";
die "$service start false $!" unless (0 == system($cmd));
=cut
