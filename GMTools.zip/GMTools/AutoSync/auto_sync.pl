#!/usr/bin/perl
BEGIN {
	use FindBin;
	my ($_parent_dir) = $FindBin::Bin =~ /(.*\/).*/;
	push(@INC, $FindBin::Bin, $_parent_dir);
}
use strict;
use warnings;

use File::Path;
use File::Copy;

require 'srv.pl';
require 'common.pl';

our $g_app_path;
our $g_continue;

my $WARN_LOCKCOUNT;


main();
sub main 
{
	$| = 1;
	$g_app_path = $FindBin::Bin;
	$g_continue = 1;

	my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
	my $cfg_file = "$base_file.cfg";
	die "cfg file: '$cfg_file' not exists!" unless -e $cfg_file;

	my $status_file = "$base_file.sta";

	while ($g_continue) {
		my $cfg_ini = load_ini($cfg_file);
		foreach my $section(@{$cfg_ini}) {
			my ($src, $ext, $host, $syncusr, $syncpas, $des, $remote_path);	
			
			$src = get_section_value($section, "src", "");
			$ext = get_section_value($section, "ext", "");
			$host = get_section_value($section, "host", "");					
			$syncusr = get_section_value($section, "syncusr", "");
			$syncpas = get_section_value($section, "syncpas", "");
			$des  = get_section_value($section, "des", "");
			$remote_path  = get_section_value($section, "remote_path", "");

			sync($src, $ext, $host, $syncusr, $syncpas, $des, $remote_path);
		}

		open(F_STATUS, ">$status_file") or die "can't write status output file: $status_file";
		print F_STATUS time();
		close F_STATUS;
		
		my $now = ts2str(time());
		print "now: $now Sleeping...\n";
		sleep( 300);
	}
}
			

sub sync
{
	my ($src, $ext, $host, $syncusr, $syncpas, $des, $remote_path) = @_;
	
	my $passfile = "$g_app_path/rsync_client.pass";

	$src =~ s/[\\\/]\s*$//;
	$remote_path = $remote_path.'/' unless $remote_path =~ /\/$/;

	my %exts;
	my @tmp_exts = split(/\s*,\s*/, $ext);
	foreach my $e(@tmp_exts) {
		$e =~ s/^\s+//;
		$e =~ s/\s+$//;
		$exts{lc($e)} = 1;
	}

	if (!-e $src) {
		mkpath($src, 0, 0755);
	}		

	open FHP, ">$passfile" or die "can't write rsync client password file: $passfile";
	print FHP $syncpas;
	close FHP;
	chmod(0600, $passfile) or die "can't chmod rsync client password file: $passfile";

	if (opendir(DIR_SCAN, $src)) {
		my @files = sort(readdir(DIR_SCAN));
		closedir DIR_SCAN;
		@files = scalar( @files) > 5 ? splice( @files, 0, 5) : @files;
		foreach my $filename(@files) {
			if (-f "$src/$filename" && 
				$filename =~ /.*?\.([^\.]*)?$/ &&
				exists($exts{$1})) 
			{
				my $cmd;
				$cmd = "rsync -vz --timeout=600 --password-file=$passfile $src/$filename ${syncusr}\@${host}::gmsync$remote_path --temp-dir=/.synctmp";
				if (0 == cmd($cmd)) {
					unlink("$src/$filename");
				} else {
					log2("rsync failed: $src/$filename");
				}
				sleep((rand() * 100) % 10);
			}
		}
	}
}