#!/usr/bin/perl
use strict;
use warnings;
use JSON;
use Digest::MD5;
use LWP::UserAgent;
use Net::FTP;
use FindBin;
use Encode;
use Compress::Zlib;
use File::Path qw(make_path remove_tree);
use Archive::Zip qw( :ERROR_CODES :CONSTANTS );
use Cwd;
use Services;
use Utils;
##########################################
#
# 更新游戏资源服工具程序
#    用于更新资源服务器
#
##########################################


BEGIN
{
	use PerlIO::encoding;
	our $continue = 1;
    our $AppPath = $FindBin::Bin;
    chdir($FindBin::Bin);
}


use Moby::Business::LoggerMan;
use Moby::Business::TimeMan;

{
	our $WARN_LOCKCOUNT = 0;
	our $last_okreporttime = 0;
	our $okreport_space = 3600*3;
	our $apprun_space = 60;
	our $ressvr_dlmaxsec = 50;
	our $AppName = "CheckTools";
    
	our $timeMan = Moby::Business::TimeMan->new();
    our $loggerMan = Moby::Business::LoggerMan->new(
        timeMan=>$::timeMan,
        apppath=>$::AppPath
    );
	our $logger = $::loggerMan->getLogger();
    $::timeMan->setLogger( $::logger);
	
	$::logger->info( "server start...");
	
	$::status_file = shift(@ARGV);
	if (!defined($::status_file) || length($::status_file) <= 0) {
	die "perl -w auto_update.pl path_of_status_file";
	}

	$::restart_cfg_file = shift(@ARGV);
	if (!defined($::restart_cfg_file) || length($::restart_cfg_file) <= 0) {
	die "perl -w auto_update.pl path_of_restart_cfg_file";
	}
	
	
	for(@ARGV){
		next unless /^\-srv$/i;
		
		my $pid = fork();
		if ($pid < 0) {
			die "fork: $!";
		}
		elsif ($pid) {
			exit 0;
		}
	
		chdir($FindBin::Bin);
	
		open(STDIN,  "</dev/null");
		open(STDOUT, ">/dev/null");
		open(STDERR, ">&STDOUT");
		last;
	}
	
	$::WARN_LOCKCOUNT = 0;
    
	$SIG{TERM} = sub { $::continue = 0 };

	$SIG{__WARN__} = sub{
	
        my ($text) = @_;
        my @loc = caller(0);
        chomp($text);
        
        my $text_ = $text ? $text : "";
        $::logger->warn('warn: '. $text_); 
        
        my $index = 1;
        for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
        {
            $::logger->warn( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
        };
        return 1;
    };

    $SIG{__DIE__} = sub{
        
        my ($text) = @_;
        my @loc = caller(0);
        chomp($text);

        my $text_ = $text ? $text : "";
        $::logger->warn('error: '. $text_); 
        
        my $index = 1;
        for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
        {
            $::logger->warn( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
        };
        return 1;
    };
}


$|=1;
while($::continue)
{
	run();
	sleep(10);
}

sub run
{

	$::timeMan->runTick();
    $::loggerMan->runTick();
    
	my $tmNow = time();
	print "now: ", Utils::format_time($tmNow),"\n";
 	my $cfg_ini = Utils::load_ini($::AppPath . "/auto_update.cfg");
	for (@{$cfg_ini})
	{
		my $section = $_;
		my $name = $section->{'name'};
		my $ops = Utils::get_section_value($section, "op", "");
		my $posturl = Utils::get_section_value($section, "posturl", "");
		my $local_root = Utils::get_section_value($section, "local_root", "");
		my $restart_script= Utils::get_section_value($section, "restart_script", "");
		my $download_path = Utils::get_section_value($section, "download_path", "");
		my $version = Utils::get_section_value($section, "version", "");
	#################################################################################
		foreach my $op (split('_',$ops))
		{
			#更新 接口
		   my $params ={};
		   $params->{op}=$op;
		   $params->{version}= $version;
	   	   my $jsonResponse = httpPort($posturl,$params);
	   	   if(!defined($jsonResponse))
	   	   {
	   	   	$::logger->info("post failed!");
	   	   	next;
	   	   }
	   	   
			#json 解析
			my $msg = $jsonResponse->{msg};
			if($jsonResponse->{code} != 0)
			{
				$::logger->info($msg);
				next;
			}
			else
			{
				#获取更新数据
				my $data = $jsonResponse->{data};
				if(!defined $data){
					$::logger->info("get data error");
					next;
				}
				my $version = $data->{version};
				my $downurl = $data->{packageurl};
				my $result = update($version,$downurl,$cfg_ini,$section,$local_root,$download_path);
				if(!$result){
					next;
				}
				$result = restartServer($restart_script);
				if(!$result){
					next;
				}	
				$::logger->info("restart succ");
			}
			
		}
	  		
	}

	open(F_STATUS, ">$::status_file") or die "can't write status output file: $::status_file";
	print F_STATUS time();
	close F_STATUS;
}


sub restartServer
{
	my ($restart_script) = @_;
	$::logger->info("restart server ...");
	my $stop = system ("$restart_script $::restart_cfg_file stop");
    unless ($stop ==0)
	{
   	   	$::logger->info("stop server fail");
		return 0;
	}
	my $start = system ("$restart_script $::restart_cfg_file start");
	unless ($start ==0)
	{
   	   	$::logger->info("start server fail");
		return 0;
	}
   	return 1;	
}

sub update
{
	my ($version,$downurl,$cfg_ini,$section,$local_root,$download_path) = @_;
	$::logger->info("update to version: $version");
	my $jsonResponse;
	my $content;
	my $filename;
	##########################
	#版本检查
	my $current_version = Utils::get_section_value($section, "version", "");
	if($current_version >= $version){
		$::logger->info("current version too hign: $current_version");
		return 0;
	}
	make_path($download_path);
	if($downurl =~/.*\/(.*.zip)$/){
	 	$filename = $1;
	}
	my $file = "$download_path/$filename";
	my $result = system("wget $downurl -O $file");
	unless($result == 0)
	{
		$::logger->info("download file fail: $downurl");
		return 0;
	}
	$::logger->info("download succ");
	my $somezip = Archive::Zip->new();
	unless ( $somezip->read($file) == AZ_OK ) 
	{
		$::logger->info("decompression fail");
	    return 0;
	}
	$somezip->extractTree(undef, $local_root);
	##################
	#更新本地版本号
	updateLocalVersion($version, $section, $cfg_ini, $::AppPath . "/auto_update.cfg");
	$::logger->info("update succ");
	return 1;	
}

sub httpPort
{
	my ($posturl,$params)= @_;
	my $response;
    my $jsonResponse;
	my $content;
	my $httpclient = new LWP::UserAgent();
	#post 数据
	$response   = $httpclient->post( $posturl, $params, 'Content_Type'=>'application/x-www-form-urlencoded');
	my $iTryCount = 0;
	 my $bIsOk = 0;
	 while( !$bIsOk && $iTryCount < 5) {
		$iTryCount++;
 	   	eval
  	  	{
   	     if(!$response->is_success) 
     	   {
				die( $!);
		   }
   		 };
  	  	if($@)
   		 {
    	    print "report error:$@\n";
    	    $bIsOk = 0;
    	    next;
   		 }
   	    $content = $response->content;
  	  	eval
   	 	{
   	  	   $jsonResponse = JSON->new->utf8->decode( $content);
   		 };
   		 if($@)
   	 	 {
    	   print "json decode error:$@\n";
    	    $bIsOk = 0;
    	    next;
   		 }
    	if( "HASH" ne ref( $jsonResponse)|| !defined($jsonResponse->{code})|| !defined($jsonResponse->{msg})) 
   		 {
   	   	  print "getdata error:illegal json format";
      	  $bIsOk = 0;
      	  next;
   		 }
  	    $bIsOk = 1;
	 }

	if( !$bIsOk) {
		return undef;
	}
	return $jsonResponse;   
}


sub updateLocalVersion
{
	my ($version, $section, $ini, $filePath) = @_;
	for (@{$section->{'kvs'}}) {
		my $kv = $_;
		if (lc($kv->{'key'}) eq "version") 
		{
			$kv->{'value'} = $version;
			last;
		}
	}
	
	my $str = Utils::concatIni($ini);
	open FILE, ">$filePath" or die "can't write local file: $filePath";
	binmode(FILE, ":encoding(utf8)");
	print FILE  $str;
	close FILE;
}