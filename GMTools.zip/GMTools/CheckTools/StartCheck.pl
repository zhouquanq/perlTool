#!/usr/bin/perl
use strict;
use warnings;
use FindBin;
use JSON;
use LWP::UserAgent;
use Digest::MD5;
use Data::Dump qw{dump};

my $json = JSON->new;
my $ctx = Digest::MD5->new;
my $AppPath = $FindBin::Bin;

my %tag_process = (
	'status_file'	=> \&process_status_file,
	'check_disk'	=> \&process_check_disk,
	'check_file'    => \&process_check_file,
);

my $continue = 1;

BEGIN {
	use FindBin;
	use File::Path;
	use POSIX qw(strftime);
    
    chdir( $FindBin::Bin);
	push( @INC, $FindBin::Bin);
    
	
    
	$|=1;
	our $APP_PATH = $FindBin::Bin;
	
}

use Moby::Business::LoggerMan;
use Moby::Business::TimeMan;

{
    our $continue = 1;
	our $WARN_LOCKCOUNT = 0;
	our $last_okreporttime = 0;
	our $okreport_space = 3600*3;
	our $apprun_space = 60;
	our $ressvr_dlmaxsec = 50;
	our $AppName = "CheckTools";
    
	our $timeMan = Moby::Business::TimeMan->new();
    our $loggerMan = Moby::Business::LoggerMan->new(
        timeMan=>$::timeMan,
        apppath=>$::APP_PATH
    );
	our $logger = $::loggerMan->getLogger();
    $::timeMan->setLogger( $::logger);
	
	$::logger->info( "server start...");
	
	$::status_file = shift(@ARGV);
	if (!defined($::status_file) || length($::status_file) <= 0) {
		die "perl -w check_tools.pl path_of_status_file";
	}
	
	for(@ARGV){
		next unless /^\-srv$/i;
		
		my $pid = fork();
		if ($pid < 0) {
			die "fork: $!";
		}
		elsif ($pid) {
			exit 0;
		}
	
		chdir($FindBin::Bin);
	
		open(STDIN,  "</dev/null");
		open(STDOUT, ">/dev/null");
		open(STDERR, ">&STDOUT");
		last;
	}
	
	$::WARN_LOCKCOUNT = 0;
    
	$SIG{TERM} = sub { $::continue = 0 };

	$SIG{__WARN__} = sub{
	
        my ($text) = @_;
        my @loc = caller(0);
        chomp($text);
        
        my $text_ = $text ? $text : "";
        $::logger->warn('warn: '. $text_); 
        
        my $index = 1;
        for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
        {
            $::logger->warn( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
        };
        return 1;
    };

    $SIG{__DIE__} = sub{
        
        my ($text) = @_;
        my @loc = caller(0);
        chomp($text);

        my $text_ = $text ? $text : "";
        $::logger->warn('error: '. $text_); 
        
        my $index = 1;
        for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
        {
            $::logger->warn( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
        };
        return 1;
    };
}

$|=1;
while($continue)
{
	run();
	sleep(60);
}

sub run
{
	my $error_msg = "";#记录错误消息
    my $server = "";#获得服务器标示
    my $posturl = "";#同步状态信息的地址
    my $checkcode = "";#获取校验码
    my %hash_status = ();#记录各个服务的状态信息
 
 	
 
    $::timeMan->runTick();
    $::loggerMan->runTick();
 
    my $output = sprintf( "%s\n", time());
	my $cfg_ini = load_ini($AppPath . "/check_tools.cfg");
	for (@{$cfg_ini})
	{
		my $section = $_;

		my $name = lc($section->{'name'});
		$name =~ s/^\s+//;
		$name =~ s/\s+$//;

        if($name eq "server_info")
        {
            my $sz = $section->{'kvs'};
            for(@{$sz})
            {
                my $ref = $_;
                if($ref->{key} eq "posturl")
                {
                    $posturl = $ref->{value};
                }
                if($ref->{key} eq "name")
                {
                    $server = $ref->{value};
                }
                if($ref->{key} eq "checkcode")
                {
                    $checkcode = $ref->{value};
                }
            }
        }

		next unless exists $tag_process{$name};

		my $func = $tag_process{$name};

		my $item_name = get_section_value($section, "name", "");

		print "processing $name => $item_name ... \n";
        $::logger->info( "processing $name => $item_name ... ");
		my ($code, $result) = &$func($section);
		if (length($item_name)>0 && defined($code)) 
        {
            $hash_status{$item_name} = $result;
            
            $output .= "[$item_name]\n";
			$output .= "code=$code\n";
			$output .= "result=$result\n";

			if ($code != 0) {
				$error_msg .= "$item_name@" . $result . "|";
			}
		}
	}
    
    {#写入状态文件
        open F_OUTPUT, ">", $::status_file or die "can't write status output file: $::status_file";
        print F_OUTPUT $output;
        close F_OUTPUT;
    }
    
    my %hash = ();
    
    $hash{"svrkey"} = $server;
    $hash{"svrstatus"} = \%hash_status;
    my $ref = \%hash;
    my $json_text = to_json($ref,{ utf8  => 1 });

    #GET提交MD5加密数据进行校验
    my $data = "$checkcode$json_text";
    $ctx->add($data);
    my $digest = $ctx->hexdigest;
    $posturl .= $digest;
    
    #POST提交数据
    my $httpclient = new LWP::UserAgent();
    my $request = HTTP::Request->new( "POST", $posturl); 
    $request->content($json_text);
    my $response;
    my $jsonResponse;
    
    my $iTryCount = 0;
    my $bIsOk = 0;
    while( !$bIsOk && $iTryCount < 5) {
    	$iTryCount++;
	    eval{
	        $response = $httpclient->request( $request);
	        if(!$response->is_success) 
	        {
				die( $!);
			}
	    };
	    if($@){
	        $::logger->warn("reprot error:$@");
	        $bIsOk = 0;
	        next;
	    }
	    
	    my $content = $response->content;
	    
	    eval{
	        $jsonResponse = JSON->new->utf8->decode( $content);
	    };
	    if($@){
	        $::logger->warn("json decode error:$@");
	        $bIsOk = 0;
	        next;
	    }
	    
	    if( "HASH" ne ref( $jsonResponse) || !$jsonResponse->{status} || !$jsonResponse->{msg} || !$jsonResponse->{code}){
	        $::logger->warn("getdata error:illegal json format");
	        $bIsOk = 0;
	        next;
	    }
	    $bIsOk = 1;
	}
	if( !$bIsOk) {
		return undef;
	}
    my $str = dump( $jsonResponse);
    # $::logger->info("$str");
    
    $::logger->info("success! $str") if($jsonResponse->{code} == 1);#MSG is OK
    $::logger->info("error Illegal user! $str") if($jsonResponse->{code} == -1);#非法用户
    $::logger->info("error server not exists! $str") if($jsonResponse->{code} == -2);#服务器ID无效
    $::logger->info("error Parameter is not complete! $str") if($jsonResponse->{code} == -3);#参数不全
    $::logger->info("error sql connect false! $str") if($jsonResponse->{code} == -4);#数据库连接失败
    $::logger->info("error updata data false! $str") if($jsonResponse->{code} == -6);#更新失败
}

sub process_check_disk
{
	my ($section) = @_;
	my $volume = get_section_value($section, "volume", 70);
	my @dflines =();
	open(CMDINPUT, "df -Pm | grep / | grep -v proc | grep -v none |");
  	@dflines = <CMDINPUT>;
  	close(CMDINPUT);
	my $str ='';
	foreach my $line (@dflines){
	chomp $line;
	$line =~ s/ +/,/g;
	$line =~ s/\%//g;
	my ($filesystem, $totalmb, $usedmb, $freemb , $pct, $mount) = split ",",$line;
	if($pct >= $volume){
        if(length($str)>0){
        $str .=',';
        }
        $str .= "$filesystem =>${pct}%";
	}
	}
	if(length($str)>0){
        return (-1, "$str");
	}
	
	return (0, "ok");
}

sub process_check_file
{
	my ($section) = @_;
	my $logpath = get_section_value($section, "logpath", '');
	my $logcount = get_section_value($section, "logcount", 3);
	
	my $dbpath = get_section_value($section, "dbpath", '');
	my $dbcount = get_section_value($section, "dbcount", 3);
	my $str = '';
	if(defined $logpath && defined $logcount){
		$logpath =~ s/\/$// if $logpath =~ /\/$/;
		my @sz = glob("$logpath/*.lzo");
		my $lognum = scalar @sz;
		@sz = sort @sz;
		if($lognum >= $logcount){
			$str .= "logdata Backlog $lognum";
		}
	}
	if(defined $dbpath && defined $dbcount){
		$dbpath =~ s/\/$// if $dbpath =~ /\/$/;
		my @sz = glob("$dbpath/*.tar.gz");
		my $lognum = scalar @sz;
		@sz = sort @sz;
		if($lognum >= $dbcount){
			if($str){
				$str .= " and dbdata Backlog $lognum";
			}else{
				$str .= "dbdata Backlog $lognum";
			}
		}
	}
	
	if($str){
		return (-1, $str);
	}else{
		return (0, "ok");
	}
}

sub process_status_file
{
	my ($section) = @_;

	my $file = get_section_value($section, "file", "");#获取服务的状态文件
	my $time = get_section_value($section, "time", 360);#获取状态时间

	if (length($file)<=0 || ! -f $file) {
		isdown( $section, 0);
		return (-1, "file not found!");
	}
	
	my $cont = "";#读取状态文件里的时间戳
	my $count = 5;
	my $tryCount = 0;
	while($tryCount<$count)
	{
		$cont = readin($file);
		last if $cont =~ /^\s*\d+\s*$/;
		
		sleep(2);
		$tryCount ++;
		$cont = "";
	}
	
	if (length($cont)<=0)
	{
		isdown( $section, 0);
		return (-1, "err, status file is empty");
	}
	
	my $tm = int($cont);

	if (time()-$tm>$time) {
		isdown( $section, $tm);
		return (-1, "err, last_update:".format_time($tm));
	}

	return (0, "ok");
}

sub isdown {
	my ($section, $tm) = @_;
	my $time = get_section_value($section, "time", 360);
	my $srvname = get_section_value($section, "srvname", "");
	my $dn_start = $srvname ? get_section_value($section, "dn_start", $srvname ? 1 : 0) : 0;
	my $dnstarttime = get_section_value($section, "dnstarttime", 360);
	
	if( $dn_start) {
		if( time()-$tm > $time+$dnstarttime) {
			StopService( $srvname);
			sleep( 10);
			StartService( $srvname);
		}
	}
}

sub readin
{
    my ($file) = @_;
    
    my $len = -s $file;
    return "" unless $len>0;

    my $f;
    open $f, $file;
    binmode $f;
    my $cont = "";
    sysread($f, $cont, $len);
    close $f;
    
    return $cont;
}


sub load_ini_from_buffer
{
    my ($buffer) = @_;
    
    my @lines = split(/\r?\n/, $buffer);
    
	my @ret;
	my $section_name = "";
	my $kvs;

	for(@lines)
	{
		my $line = $_;
		next if $line=~ /^\s*$/ or $line =~ /^\s*\#/;

		$line =~ s/^\s+//;
		$line =~ s/\s+$//;

		if ($line =~ /^\[([^\]]+)\]$/) {
			my $tmp_name = $1;
			$tmp_name =~ s/^\s+//;
			$tmp_name =~ s/\s+$//;

			if (length($section_name) > 0) {
				my %ini_info;
				$ini_info{'name'} = $section_name;
				$ini_info{'kvs'} = $kvs;

				push @ret, \%ini_info;
			}

			my @arKvs;
			$kvs = \@arKvs;
			$section_name = $tmp_name;
		}
		elsif ($line =~ /^([^=]+)=(.*)$/){
			my $key = $1;
			my $value = $2;

			$key =~ s/^\s+//;
			$key =~ s/\s+$//;

			$value =~ s/^\s+//;
			$value =~ s/\s+$//;

			if (length($section_name) > 0) {
				my %kv;
				$kv{'key'} = $key;
				$kv{'value'} = $value;

				push @{$kvs}, \%kv;
			}
		}
	}

	if (length($section_name) > 0) {
		my %ini_info;
		$ini_info{'name'} = $section_name;
		$ini_info{'kvs'} = $kvs;

		push @ret, \%ini_info;
	}

	return \@ret;
}


sub load_ini
{
	my ($file) = @_;
    
    return load_ini_from_buffer(readin($file));
}

sub get_section_value
{
	my ($section, $key, $default_value) = @_;

	for (@{$section->{'kvs'}}) {
		my $kv = $_;
		
		if (lc($kv->{'key'}) eq lc($key)) {
			if (length($kv->{'value'})>0) {
				return $kv->{'value'};
			}
		
			return defined($default_value)?$default_value:"";
		}
	}

	return defined($default_value)?$default_value:"";
}

#将时间戳转换成时间格式
sub format_time
{
	my ($time) = @_;

	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);
	$mon++;
	$year += 1900;

	return "$year-$mon-$mday $hour:$min:$sec";
}

#开启服务
sub StartService
{
	my ($name) = @_;
	#run service
	{
		print "start..\n";
		my @cmds;
		push @cmds, "../services/restart_bak.sh";
		push @cmds, "../services/services.cfg";
		push @cmds, "start";
		push @cmds, $name;

		system(@cmds) == 0
			or print "system @cmds failed: $?";
	}
}

#停止服务
sub StopService
{
	my ($name) = @_;
	#stop service
	{
		print "start..\n";
		my @cmds;
		push @cmds, "../services/restart_bak.sh";
		push @cmds, "../services/services.cfg";
		push @cmds, "stop";
		push @cmds, $name;
		
		system(@cmds) == 0
			or print "system @cmds failed: $?";
	}
}
