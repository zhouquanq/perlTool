use strict;
use warnings;
use Time::HiRes qw( usleep );
use LWP::UserAgent;
use Digest::MD5 qw(md5 md5_hex);
#use Date::Parse;
use IO::Socket;
use Encode; 

$::startTime   = 0;
$::phoneNumber = '13476069136';
$::phoneNumber2 = '13886180510';
$::phoneNumber3 = '13554297529';
print "����ʼ......\r\n\r\n";

#sleep(10);
my $i            = 1;
my $IntervalTime = 1*60;
my $url          = 'http://gp.ta.cn';
my $username     = '13886180510';
my $userpassword = '335833';

while(1)
{
	my $time = time();
	if($time-$::startTime > $IntervalTime)
	{
		print "��$i�μ�⣬[".dateTimeToString($time)."] ��ʼ���......\r\n";
		checkSub($url,$username,$userpassword);
		print "��$i�μ�⣬[".dateTimeToString(time())."] �������......\r\n\r\n";
		$i++;
		$::startTime = $time;
	}	
	Time::HiRes::usleep(1);

}

sub checkSub
{
	my ($url,$username,$userpassword) = @_;
	my $backUrl = sendurl($url,$username,$userpassword);
	my @arr = split('\|',$backUrl);
	if($arr[0]==0)
	{
		my $accountServer = $arr[1];
		print '����ٴη��ʵĵ�ַ��'. $accountServer ."\r\n";
		my $gameparam='gamelist';
		$backUrl = $accountServer."?gameparam=$gameparam";
		print "$backUrl\r\n";
		$backUrl = sendurl($backUrl,$username,$userpassword);
		my @arr = split('\|',$backUrl);
		if($arr[0]==0)
		{
			my $arrIndex = $arr[1]+2;
			@arr = split('\,',$arr[$arrIndex]);
			my $hostArr = $arr[1];
			@arr = split('\:',$hostArr);
			my $host = $arr[0];
			my $port = $arr[1];
			print "got $host:$port\n";
			my $socket = IO::Socket::INET->new
			(
				PeerAddr	=> $host,
				PeerPort	=> $port,
				Type		=> IO::Socket::SOCK_STREAM,
				Proto		=> 'tcp'
			);
			my $urlString;
			if($socket)
			{
				$urlString = "socket connection success\r\n";
				print "$urlString";
				SaveFile("check_server.txt",$urlString);
			}
			else
			{
				$urlString = "socket connection fail\r\n";
				print "$urlString";
				SaveFile("check_server.txt",$urlString);
				sendmsg($::phoneNumber,"socket [$hostArr] error");
				sendmsg($::phoneNumber2,"socket [$hostArr] error");
				sendmsg($::phoneNumber3,"socket [$hostArr] error");			
			}
		}
		else
		{
			print "�����Ĳ�������\r\n";
		}
	}
	else
	{
		print "�����Ĳ�������\r\n";
	}
}

sub sendurl
{
	my ($url,$uid,$pwd) = @_;
	my %login_form=(
	'username'=>$uid,
	'userpassword'=>$pwd,
	);	
	my $moby_imei='1234567890123456';
	my $moby_auth=getAuth($moby_imei);
	my @http_form=
	(
		'moby_auth'=>$moby_auth,
		'moby_imei'=>$moby_imei,
		'moby_pb'=>'moby',
		'Cookie'=>'cookie',
		'Referer'=>'referer',
		'moby_op'=>'op',
		'moby_ua'=>'ua',
		'moby_sdk'=>'sdk',
		'moby_bv'=>'bv',
		'Cookie'=>'cookie',
		'Referer'=>'referer',
	);
	
	SaveFile("check_server.txt",$url);
	my $urlString = requestUrl($url,\%login_form,\@http_form);
	$urlString = encode("gb2312", decode("utf-8", $urlString));
	SaveFile("check_server.txt",$urlString);
	print "��Զ�̻�õ���ҳ:$urlString\r\n";
	return $urlString;
}

sub dateTimeToString
{
	my ($strDate) = @_;
	my ($sec, $min, $hour, $day, $mon, $year) = localtime($strDate);
	$year += 1900;
	$mon  += 1;
	return "$year-$mon-$day $hour:$min:$sec";
}

sub sendmsg
{
	my ($phone,$msg) = @_;
	return if $phone =~ /^\s*$/i;

	$msg = "*sms2* ".$msg; 

	my $url      = "http://localhost:8800/?PhoneNumber=$phone&Text=$msg";
#	print $url;
#	return;
	my $browser  = LWP::UserAgent->new;
	my $response = $browser->get($url);	
	if($response)
	{
		print "���ŷ��ͳɹ�!���͵��ֻ�������:$phone,���͵������ǣ�$msg";
	}
}

sub SaveFile
{
	my ($filename,$filecontent)=@_;
	$filecontent = "[".dateTimeToString(time())."] $filecontent\r\n";
	open FILEHANDLE, ">>$filename";
	print FILEHANDLE $filecontent;
	close FILEHANDLE; 
}

sub requestUrl
{
	my ($url,$param,$http_form)=@_;
	#print 'URL=> ' . $url . "\r\n";
	my $tryCount = 5;
	my $curCount = 0;
	my $bSuccess = 0;
	my $content = "";

	while(!$bSuccess && $curCount < $tryCount)
	{
		my $browser    = new LWP::UserAgent;
		$browser->agent("NokiaN72/ 5.0741.4.0.1 Series60/2.8 Profile/MIDP-2.0 Configuration/CLDC-1.1");
		#$browser->default_header(@http_form);
		#my $response   = $browser->post($url,\%login_form,'Content_Type' => 'application/x-www-form-urlencoded'); 
		$browser->default_header(@$http_form);
		my $response = $browser->post($url,$param,'Content_Type' => 'application/x-www-form-urlencoded');  
		$bSuccess = $response->is_success;
		$content = $response->content;
		$curCount ++;
	}

	if($bSuccess)
	{ 
	   SaveFile("http_reqcharge.txt",$content);
	  # print 'RES=> '.$response->content; 
	  # print "\r\n";
	} 
	else 
	{ 
	   print "RES=> Bad luck this time\n"; 
	   sendmsg($::phoneNumber,"request [$url] error");
	   sendmsg($::phoneNumber2,"request [$url] error");
	   sendmsg($::phoneNumber3,"request [$url] error");
	}
	return 	$content;
}

sub getAuth
{
	my ($imei)=@_;
	#my $timeString = dateTimeToString();
	#$timeString = Digest::MD5::md5_hex($timeString);
	my $str = Digest::MD5::md5_hex($imei);
	#print $str."\n";
	my $strlength = length($str);
	my $i=0;
	my $newstr='';
	my $newstr1='';
	while($i<$strlength)
	{
		
		$newstr=$newstr.substr($str,$i,1);
		$newstr1=$newstr1.substr($str,$i+1,1);
		$i +=2;
	}
	#print $newstr."\n";
	#print $newstr1."\n";	
	my $getstr = $newstr1.'moby'.$newstr;
	return Digest::MD5::md5_hex($getstr);	
}
