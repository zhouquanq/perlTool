#!/usr/bin/perl
use strict;
use warnings;
use PerlIO::encoding;
use Data::Dumper;
use File::Path;
use Time::Local;
use FindBin;

use strict; 
use Data::Dumper;
use Spreadsheet::ParseExcel; 
use Spreadsheet::ParseExcel::FmtUnicode; #字符编码

use utf8;
binmode(STDIN, ':encoding(utf8)');
binmode(STDOUT, ':encoding(utf8)');
binmode(STDERR, ':encoding(utf8)');

$::APPLICATION_PATH = scalar( $FindBin::Bin);
my ($infile, $outfile, $nameid_file) = @ARGV;
$infile = $::APPLICATION_PATH.'/1_attlog.dat' if !defined($infile);
$outfile = $::APPLICATION_PATH.'/outfile.txt' if !defined($outfile);
$nameid_file = $::APPLICATION_PATH.'/name_id.xls' if !defined($nameid_file);

#print $infile,"\n", $outfile, "\n", $nameid_file, "\n";
#system("pause");

my $parser = Spreadsheet::ParseExcel->new(); 
my $formatter = Spreadsheet::ParseExcel::FmtUnicode->new(Unicode_Map=>"CP936");#设置字符编码
#my $workbook = $parser->parse($nameid_file, $formatter);#按所设置的字符编码解析
my $workbook = $parser->parse($nameid_file);#按所设置的字符编码解析
 
if ( !defined $workbook ) {
	die $parser->error(), ".\n"; 
}

my $name_vs_id = {};
for my $worksheet ( $workbook->worksheets() ) {

	my ( $row_min, $row_max ) = $worksheet->row_range();
	my ( $col_min, $col_max ) = $worksheet->col_range();

	for my $row ( $row_min .. $row_max ) {
		my $cell_id = $worksheet->get_cell( $row, 2);
		my $cell_name = $worksheet->get_cell( $row, 3);
		next unless $cell_id;
		next unless $cell_name;
		next unless $cell_id->value();
		my $id = scalar($cell_id->value()) + 0;
		my $name = $cell_name->value();
		next unless $id;
		$name_vs_id->{$id} = $name;
	}
}

die('there is no card record file!\n') unless -e $infile;
open FH, "< $infile";
my $id_time = {};					#编号对应的上下班时间
my $workdays = {};					#有人打卡的天
my $shouldworkdays = {};			#应该上班的天
my $min_count = 20;					#最少上班人数,如果有超过这个数的人打卡,就认为当天正常上班
my ($last_mon,$last_year) = (localtime(time - 86400*30))[4,5];
$last_mon += 1;
$last_year += 1900;
print Dumper($last_year.'-'.$last_mon);
while (<FH>) {
	next unless $_ =~ /(\d+)\t+(((\d+-\d+)-\d+) \d+:\d+:\d+)/;
	my ($id, $time, $day, $mon) = ($1, $2, &str2ts($3), $4);
	next if &str2ts($mon."-01") != &str2ts("$last_year-$last_mon-01");
	if(!defined($id_time->{$id}) || !defined($id_time->{$id}->{$day})) {
		$id_time->{$id}->{$day}->{max} = $time;
		$id_time->{$id}->{$day}->{min} = $time;
	} else {
		$id_time->{$id}->{$day}->{max} = $time if str2ts($id_time->{$id}->{$day}->{max}) < str2ts($time);
		$id_time->{$id}->{$day}->{min} = $time if str2ts($id_time->{$id}->{$day}->{min}) > str2ts($time);
	}
	if(!defined($workdays->{$day}) || !defined($workdays->{$day}->{$id})) {
		$workdays->{$day}->{$id} = 1;
	}
}
close FH;

foreach my $sday (keys %{$workdays}) {
	$shouldworkdays->{$sday} = 1 if scalar(keys %{$workdays->{$sday}}) >= $min_count;
}
print Dumper($shouldworkdays);sleep 1;

open OUTFILE, "> $outfile";
foreach my $tid (sort {$a <=> $b} (keys %{$id_time})) {
	next if !defined($name_vs_id->{$tid});
	print OUTFILE "指纹编号:".$tid."\t"."姓名:".$name_vs_id->{$tid}." -----------------------\n";
	my $come_late = {};			#迟到
	my $leave_early = {};		#早退
	my %tmp_shouldworkdays = %{$shouldworkdays};	#未打卡
	foreach my $tday (sort {$a <=> $b} (keys %{$id_time->{$tid}})) {
		my $tday_str = &ts2str($tday,1);
		print OUTFILE "日期:".$tday_str."\n";
		print OUTFILE "上班打卡时间:".$id_time->{$tid}->{$tday}->{min}."\n";
		print OUTFILE "下班打卡时间:".$id_time->{$tid}->{$tday}->{max}."\n";
		$come_late->{$tday} = str2ts($id_time->{$tid}->{$tday}->{min}) - str2ts($tday_str." 09:00:59") if &str2ts($tday_str." 09:00:59") < str2ts($id_time->{$tid}->{$tday}->{min});
		$leave_early->{$tday} = str2ts($tday_str." 18:30:00") - str2ts($id_time->{$tid}->{$tday}->{max}) if str2ts($tday_str." 18:30:00") > str2ts($id_time->{$tid}->{$tday}->{max});
		delete $tmp_shouldworkdays{$tday} if defined $tmp_shouldworkdays{$tday};
	}
	
	print OUTFILE "应到天数:".scalar(keys %{$shouldworkdays})."\t实到天数:".scalar(keys %{$id_time->{$tid}})."\n";
	print OUTFILE "参考迟到早退情况:\n";
	print OUTFILE "\t无\n" unless (scalar(keys %{$come_late}) || scalar(keys %{$leave_early}));
	foreach my $lday (sort {$a <=> $b} (keys %{$come_late})) {
		print OUTFILE "\t".&ts2str($lday,1)." 迟到 ".$come_late->{$lday}." 秒\n";
	}
	foreach my $lday (sort {$a <=> $b} (keys %{$leave_early})) {
		print OUTFILE "\t".&ts2str($lday,1)." 早退 ".$leave_early->{$lday}." 秒\n";
	}
	print OUTFILE "参考未打卡情况:\n";
	print OUTFILE "\t无\n" unless scalar(keys %tmp_shouldworkdays);
	foreach my $lday (sort {$a <=> $b} (keys %tmp_shouldworkdays)) {
		print OUTFILE "\t".&ts2str($lday,1)." 未打卡\n";
	}
	print OUTFILE "\n\n";
}
close OUTFILE;

#print Dumper($id_time);












sub str2ts
{
	my $str = shift(@_);
	
	if ($str !~ /\d{4}-\d+-\d+(\s+\d+:\d+:\d+)?/) {
		die ("Illegal datetime str($str).\n");
	}

	$str =~ s/(\d+)-(\d+)-(\d+)//;
	my ($year, $month, $day) = ($1, $2, $3);

	my ($hour, $minute, $second);
	if ($str =~ /(\d+):(\d+):(\d+)/) {
		($hour, $minute, $second) = split(':', $str);
	} else {
		($hour, $minute, $second) = (0, 0, 0);
	}
	
	my $timestamp = timelocal($second, $minute, $hour, $day, $month - 1, $year);

	return $timestamp;
}

sub ts2str
{
	my ($ts, $only_date) = @_;

	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($ts);
	$mon++;
	$year += 1900;
	
	$mon = '0'.$mon if $mon < 10;
	$mday = '0'.$mday if $mday < 10;
	$hour = '0'.$hour if $hour < 10;
	$min = '0'.$min if $min < 10;
	$sec = '0'.$sec if $sec < 10;
	
	if (defined($only_date) && 1 == $only_date) {
		return "$year-$mon-$mday";
	} else {
		return "$year-$mon-$mday $hour:$min:$sec";
	}
}