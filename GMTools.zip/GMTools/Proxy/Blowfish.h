/*
 * Blowfish.h
 *
 *  Created on: 2009-11-3
 *      Author: WangXu
 */

#ifndef BLOWFISH_H_
#define BLOWFISH_H_

#include <uv.h>
#define uint8_t unsigned char
#define uint16_t unsigned short
#define uint32_t unsigned int


#define NUM_SUBKEYS  18
#define NUM_S_BOXES  4
#define NUM_ENTRIES  256


class Blowfish
{
public:
    Blowfish(const char* key, int keylen = -1);

    bool Encrypt(void* data, size_t datalen);
    bool Decrypt(void* data, size_t datalen);

private:
    static uint32_t dataToInt32(const char* data);
    static void int32ToData(char* data, uint32_t d);

    void Blowfish_init(const char* key, size_t keylen);
    void Blowfish_encipher(uint32_t *l, uint32_t *r);
    void Blowfish_decipher(uint32_t *l, uint32_t *r);
    uint32_t F(uint32_t);

    static const uint32_t INIT_PA[NUM_SUBKEYS];
    static const uint32_t INIT_SB[NUM_S_BOXES][NUM_ENTRIES];

    uint32_t PA[NUM_SUBKEYS];
    uint32_t SB[NUM_S_BOXES][NUM_ENTRIES];
};


#endif /* BLOWFISH_H_ */
