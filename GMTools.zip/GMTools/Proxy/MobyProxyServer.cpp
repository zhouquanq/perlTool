// MobyProxyServer.cpp : Defines the entry point for the console application.
//
//#include "stdafx.h"

//#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <assert.h>
//#include <crtdbg.h>

#include <uv.h>
#include <map>

#include "zlib.h"
#include "Blowfish.h"

using namespace std;

static uv_loop_t*	moby_uv_loop;
static uv_tcp_t		moby_server;

static map<uv_tcp_t*,  uv_tcp_t*>	moby_all_clients;


void on_uv_close_server(uv_handle_t* handle);

int init()
{
	moby_uv_loop = uv_default_loop();
	return 0;
}

void shut()
{
	//free all clients
	{
		map<uv_tcp_t*, uv_tcp_t*>::iterator i;
		i = moby_all_clients.begin();

		while( i != moby_all_clients.end())
		{
			free(i->first);

			i++;
		}

		moby_all_clients.clear();
	}
}

#define CHUNK  1024

int __inflate(unsigned char* pCompressed, int nLen,  unsigned char** ppOut, int* pOutLen)
{
    z_stream c_stream; /* compression stream */
//    c_stream.zalloc = Z_NULL;
 //   c_stream.zfree = Z_NULL;
  //  c_stream.opaque = Z_NULL;
	memset(&c_stream, 0, sizeof(z_stream));

    int err = inflateInit(&c_stream);
	if(Z_OK != err)
		return -1;
	
	unsigned char bufChunk[CHUNK];
	
	int nUncompressed = 0;
	unsigned char* pUncompressed = (unsigned char*)malloc(CHUNK);
	memset(pUncompressed, 0, CHUNK);
	
	c_stream.next_in = pCompressed;
	c_stream.avail_in = nLen;

	do 
	{
		c_stream.avail_out = CHUNK;
		c_stream.next_out = bufChunk;
		
		err = inflate(&c_stream, Z_FINISH);
		if (err == Z_STREAM_ERROR)
		{
			inflateEnd(&c_stream);
			free(pUncompressed);
			return -1;
		}
		//assert(err != Z_STREAM_ERROR);
		
		int nHave = CHUNK - c_stream.avail_out;
		pUncompressed = (unsigned char*)realloc(pUncompressed, nUncompressed + nHave);
		memcpy(pUncompressed+nUncompressed, bufChunk, nHave);
		
		nUncompressed += nHave;
		
	} while (c_stream.avail_out == 0);
	
	
    inflateEnd(&c_stream);
	
	*ppOut = pUncompressed;
	*pOutLen = nUncompressed;
	
	return 0;
}

int __deflate(unsigned char* pUncompress, int nLen,  unsigned char** ppOut, int* pOutLen)
{
    z_stream c_stream; /* compression stream */
 //   c_stream.zalloc = Z_NULL;
   // c_stream.zfree = Z_NULL;
//    c_stream.opaque = Z_NULL;
	memset(&c_stream, 0, sizeof(z_stream));

	
	
    int err = deflateInit(&c_stream, Z_DEFAULT_COMPRESSION);
	if(Z_OK != err)
		return -1;
	
	unsigned char bufChunk[CHUNK];

	int nCompressed = 0;
	unsigned char* pCompressed = (unsigned char*)malloc(CHUNK);
	memset(pCompressed, 0, CHUNK);

	c_stream.next_in = pUncompress;
	c_stream.avail_in = nLen;

	do 
	{
		c_stream.avail_out = CHUNK;
		c_stream.next_out = bufChunk;

		err = deflate(&c_stream, Z_FINISH);
		if (err == Z_STREAM_ERROR)
		{
			deflateEnd(&c_stream);
			free(pCompressed);
			return -1;
		}
		//assert(err != Z_STREAM_ERROR);

		int nHave = CHUNK - c_stream.avail_out;
		pCompressed = (unsigned char*)realloc(pCompressed, nCompressed + nHave);
		memcpy(pCompressed+nCompressed, bufChunk, nHave);

		nCompressed += nHave;

	} while (c_stream.avail_out == 0);


    deflateEnd(&c_stream);

	*ppOut = pCompressed;
	*pOutLen = nCompressed;

	return 0;
}

int __codec(bool bEncrypt, unsigned char* data, int nLen, unsigned char** ppOut, int* pOutLen)
{
	const char* szKey = "\x78\x10\xA6\xEF\x8B\x6A\xCD\xEB";

    Blowfish* pBlowfish = new Blowfish(szKey, strlen(szKey));
	int nInputBufferLength = nLen;
	if(bEncrypt)
	{
		nInputBufferLength += 8 - 1;
		nInputBufferLength /= 8;
		nInputBufferLength *= 8;
	}
	unsigned char* pInputBuffer = (unsigned char*)malloc(nInputBufferLength);
	memset(pInputBuffer, 0, nInputBufferLength);
	memcpy(pInputBuffer, data, nLen);

	int bRet = false;
	if(bEncrypt)
	{
		bRet = pBlowfish->Encrypt(pInputBuffer, nInputBufferLength);
	}
	else
	{
		bRet = pBlowfish->Decrypt(pInputBuffer, nInputBufferLength);
		nInputBufferLength = strlen((const char*)pInputBuffer);
	}

	if (bRet)
	{
		*ppOut = pInputBuffer;
		*pOutLen = nInputBufferLength;
	}
	else
	{
		free(pInputBuffer);
		pInputBuffer = NULL;
		nInputBufferLength = 0;
	}

	delete pBlowfish;
	return bRet;
}

long moby_encode(unsigned char* pBuf, int nLen, unsigned char** ppOut, int* pOutLen)
{
	char* pUtf8 = (char*)pBuf;
	int nUtf8 = strlen(pUtf8);

	int nZlibLen = 0;
	unsigned char* pZlibDest = NULL;
	if( __deflate((unsigned char*)pUtf8, nUtf8, &pZlibDest, &nZlibLen) < 0)
	{
		return -1;
	}

	unsigned char* pPkg = (unsigned char*)malloc(nZlibLen+sizeof(int));
	int nPkgLen = htonl(nZlibLen);
	memcpy(pPkg, &nPkgLen, sizeof(int));
	memcpy(pPkg+sizeof(int), pZlibDest, nZlibLen);

	free(pZlibDest);

	unsigned char* pEncrypted = NULL;
	int nEncryptedLen = 0;
	
	if (!__codec(true, pPkg, nZlibLen+sizeof(int), &pEncrypted, &nEncryptedLen))
	{
		free(pPkg);
		return -1;
	}
	free(pPkg);

	int n = htonl(nEncryptedLen);
	*ppOut = (unsigned char*)malloc(nEncryptedLen+sizeof(int));
	memcpy(*ppOut, &n, sizeof(int));
	memcpy((*ppOut)+sizeof(int),  pEncrypted, nEncryptedLen);

	*pOutLen = nEncryptedLen + sizeof(int);

	return 0;
}

long moby_decode(unsigned char* pBuf, int nLen, unsigned char** ppOut, int* pOutLen)
{
	unsigned char* pDecrypted = NULL;
	int nDecrypted = 0;

	if (!__codec(false, pBuf, nLen, &pDecrypted, &nDecrypted))
	{
		return -1;
	}

	int nUnzlibLen = 0;
	unsigned char* pUnzlibDest = NULL;

	if (__inflate(pDecrypted+sizeof(int), nDecrypted-sizeof(int), &pUnzlibDest, &nUnzlibLen) < 0)
	{
		free(pDecrypted);
		return -2;
	}
	free(pDecrypted);

	*ppOut = (unsigned char*)pUnzlibDest;
	*pOutLen = nUnzlibLen;
	return 0;
}

void moby_uv_close(uv_handle_t* handle, uv_close_cb cb)
{
  if (uv_is_closing(handle)) {
    return;
  }

  uv_close(handle, cb);
}

bool client_exists(uv_tcp_t* client)
{
	map<uv_tcp_t*, uv_tcp_t*>::iterator i =	moby_all_clients.find(client);
	if ( i != moby_all_clients.end())
	{
		return true;
	}

	return false;
}

void add_client(uv_tcp_t* client)
{
	//assert(client_exists(client) == false);

	moby_all_clients[client] = NULL;
}


void remove_client(uv_tcp_t* client)
{
	if (client_exists(client))
	{
		moby_all_clients.erase(client);
	}
}

uv_buf_t moby_uv_alloc_buffer(uv_handle_t *handle, size_t suggested_size)
{
    return uv_buf_init((char*) malloc(suggested_size), suggested_size);
}

void on_uv_close_client(uv_handle_t* handle)
{
	if (handle->data)
	{
		((uv_handle_t*)handle->data)->data = NULL;
		moby_uv_close((uv_handle_t*)handle->data, on_uv_close_server);
	}

	remove_client((uv_tcp_t*)handle);
	free(handle);
}

void on_uv_main_loop_close(uv_handle_t* handle)
{
	uv_stop(moby_uv_loop);
}


void on_uv_write_client(uv_write_t* req, int status)
{
	uv_handle_t* stream = (uv_handle_t*)req->handle;

	free(req->write_buffer.base);
	free(req);

	if (status == 0)
		return;

	fprintf(stderr, "on_uv_write_client error\n");

	if (status == UV_ECANCELED)
		return;

	//assert(status == UV_EPIPE);
	moby_uv_close((uv_handle_t*)stream, on_uv_close_client);
}

void on_uv_close_server(uv_handle_t* handle)
{
	if (handle->data)
	{
		((uv_handle_t*)handle->data)->data = NULL;
		moby_uv_close((uv_handle_t*)handle->data, on_uv_close_client);
	}

	remove_client((uv_tcp_t*)handle);
	free(handle);
}

void on_uv_read_server(uv_stream_t* stream, ssize_t nread, uv_buf_t buf)
{
	int r;

	if (nread < 0)
	{
		if (buf.base) 
		{
			free(buf.base);
		}

		moby_uv_close((uv_handle_t*)stream, on_uv_close_server);
		return;
	}

	if (nread == 0 || stream->data == NULL) 
	{
		/* Everything OK, but nothing read. */
		free(buf.base);
		return;
	}

	uv_write_t *wr;
	wr = (uv_write_t*) malloc(sizeof *wr);
	wr->write_buffer = uv_buf_init(buf.base, nread);

	r = uv_write(wr, (uv_stream_t*)stream->data, &wr->write_buffer, 1, on_uv_write_client);
	//assert(r == 0);
}

void on_uv_write_server(uv_write_t* req, int status)
{
	uv_handle_t* stream = (uv_handle_t*)req->handle;

	free(req->write_buffer.base);
	free(req);

	if (status == 0)
		return;

	fprintf(stderr, "on_uv_write_server error\n");

	if (status == UV_ECANCELED)
		return;

	//assert(status == UV_EPIPE);
	moby_uv_close((uv_handle_t*)stream, on_uv_close_server);
}

void on_uv_connect_server(uv_connect_t* req, int status)
{
	int rid = *((int*)(req->data));

	fprintf(stdout, "on_uv_connect_server rid=%d\n", rid);
	
	uv_stream_t* server = req->handle;
	free(req->data);
	free(req);

	if (status == 0)
	{
		if (server->data)
		{
			
			char strData[50];
			int nDataLen = sprintf(strData, "%d connect 0", rid);

			fprintf(stdout, "write to client %s\n", strData);

			unsigned char* pOut = NULL;
			int nOutLen = 0;
			int r = 0;
			r = moby_encode((unsigned char*)strData, nDataLen, &pOut, &nOutLen);
			
			if (r != 0)
			{
				moby_uv_close((uv_handle_t*)server, on_uv_close_server);
				return;				
			}

			uv_buf_t buf;
			buf.base = (char*)pOut;
			buf.len = nOutLen;

			uv_write_t *wr;
			wr = (uv_write_t*) malloc(sizeof *wr);
			wr->write_buffer = buf;

			r = uv_write(wr, (uv_stream_t*)server->data, &wr->write_buffer, 1, on_uv_write_client);
			if (r != 0)
			{
				free(buf.base);
				free(wr);

				moby_uv_close((uv_handle_t*)server, on_uv_close_server);
				return;
			}

			r = uv_read_start(server, moby_uv_alloc_buffer, on_uv_read_server);
			//assert(r == 0);

			return;
		}
	}

	moby_uv_close((uv_handle_t*)server, on_uv_close_server);
}

void on_uv_read_client(uv_stream_t* stream, ssize_t nread, uv_buf_t buf)
{
	int r;

	fprintf(stdout, "on_uv_read_client %d\n", nread);
	
	if (nread < 0)
	{
		if (buf.base) 
		{
			free(buf.base);
		}

		moby_uv_close((uv_handle_t*)stream, on_uv_close_client);
		return;
	}

	if (nread == 0) 
	{
		/* Everything OK, but nothing read. */
		free(buf.base);
		return;
	}

	if (stream->data == NULL)
	{
		if (nread > 4 && nread < 1024)
		{
			unsigned char* pData = NULL;
			int nLen = 0;
			
			//fprintf(stdout, "recv data: %s\n", buf.base);
			
			r = moby_decode((unsigned char*)(buf.base+4), nread-4, &pData, &nLen);
			free(buf.base);
			
			fprintf(stdout, "moby_decode %d\n", r);
			
			if (r != 0)
			{
				moby_uv_close((uv_handle_t*)stream, on_uv_close_client);
				return;
			}
			
			fprintf(stdout, "%s\n", pData);
			
			int server_port = -1;
			int rid = -1;
			
			char strNum[32];
			int nNumPos = 0;
			memset(strNum, 0, 32);
			
			for(int i=0; i< nLen; i++)
			{
				if (rid < 0)
				{
					if (pData[i] >= '0' && pData[i]<='9')
					{
						strNum[nNumPos] = pData[i];
						nNumPos ++;
					}
					else
					{
						rid = atoi(strNum);
						nNumPos = 0;
						memset(strNum, 0, 32);
					}
					continue;
				}
				
				if (server_port < 0)
				{
					if (pData[i] >= '0' && pData[i]<='9')
					{
						strNum[nNumPos] = pData[i];
						nNumPos ++;
						
						if ( i == nLen-1 )
						{
							server_port = atoi(strNum);
						}
					}
					continue;				
				}
			}
			
			free(pData);
			
			fprintf(stdout, "rid=%d  server_port=%d\n", rid, server_port);
	
			if (server_port > 0)
			{
				uv_tcp_t* server_socket = (uv_tcp_t*)malloc(sizeof *server_socket);
				uv_tcp_init(moby_uv_loop, server_socket);
	
				int* pRid = (int*)malloc(sizeof(int));
				*pRid = rid;
				
				uv_connect_t* req = (uv_connect_t*)malloc(sizeof *req);
				req->data = (void*)pRid;
	
				struct sockaddr_in dest = uv_ip4_addr("127.0.0.1", server_port);
	
				r = uv_tcp_connect(req, server_socket, dest, on_uv_connect_server);
	
				if (r != 0)
				{
					free(server_socket);
					free(req->data);
					free(req);
	
					moby_uv_close((uv_handle_t*)stream, on_uv_close_client);
				}
				else
				{
					stream->data = server_socket;
					server_socket->data = stream;
	
					add_client(server_socket);
				}
	
				return;
			}
			else
			{
				moby_uv_close((uv_handle_t*)stream, on_uv_close_client);
				return;
			}			
		}
		else
		{
			free(buf.base);
			moby_uv_close((uv_handle_t*)stream, on_uv_close_client);
			return;
		}

	}
	else
	{
		uv_write_t *wr;
		wr = (uv_write_t*) malloc(sizeof *wr);
		wr->write_buffer = uv_buf_init(buf.base, nread);

		r = uv_write(wr, (uv_stream_t*)stream->data, &wr->write_buffer, 1, on_uv_write_server);
		//assert(r == 0);
	}
}

void on_uv_new_connection(uv_stream_t* server, int status)
{
	fprintf(stdout, "on_uv_new_connection\n");

	int r;

	if (status != 0)
	{
	    fprintf(stderr, "on new connection error\n");
	    return;
	}

	uv_tcp_t* client = (uv_tcp_t*) malloc(sizeof(uv_tcp_t));
	assert(client != NULL);

	r = uv_tcp_init(moby_uv_loop, client);
	assert(r == 0);

	r = uv_accept(server, (uv_stream_t*)client);
	assert(r == 0);

	r = uv_read_start((uv_stream_t*)client, moby_uv_alloc_buffer, on_uv_read_client);
	assert(r == 0);

	client->data = NULL;
	add_client(client);
}

int init_server(int port)
{
	int r;

	fprintf(stdout, "uv_tcp_init...\n");
	r = uv_tcp_init(moby_uv_loop, &moby_server);
	if (r)
	{
		fprintf(stderr, "Socket creation error\n");
		return r;
	}

	sockaddr_in bind_addr = uv_ip4_addr("0.0.0.0", port);

	fprintf(stdout, "uv_tcp_bind...\n");
	r = uv_tcp_bind(&moby_server, bind_addr);
	if (r)
	{
	    fprintf(stderr, "Bind error\n");
		return r;
	}

	fprintf(stdout, "uv_listen...\n");
	r = uv_listen((uv_stream_t*)(&moby_server), 1024, on_uv_new_connection);
	if (r)
	{
		fprintf(stderr, "Listen error\n");
		return r;
	}

	fprintf(stdout, "return...\n");
	return 0;
}

void usage()
{
	fprintf(stdout, "MobyProxyServer [PORT]\n");
	exit(0);
}


int main(int argc, char* argv[])
{
	fprintf(stdout, "MobyProxyServer init...\n");
	
	int port = 443;
	if (argc == 2)
	{
		port = atoi(argv[1]);
	}
	else if (argc > 2)
	{
		usage();
		return -1;
	}
	
	
	int r;

	r = init();
	if (r)
	{
	    fprintf(stderr, "init error\n");
		exit(r);		
	}


	r = init_server(port);
	if (r)
	{
		fprintf(stderr, "init server error\n");
		exit(r);
	}

	fprintf(stdout, "Listen %d r=%d\n", port, r);

	uv_run(moby_uv_loop, UV_RUN_DEFAULT);


	shut();

	//_CrtDumpMemoryLeaks();

	return 0;
}
