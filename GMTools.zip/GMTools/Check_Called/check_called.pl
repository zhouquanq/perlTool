#!/usr/bin/perl -w
use POSIX qw(strftime);
use FindBin;
$::APPLICATION_PATH = $FindBin::Bin;

die("the mode sendEmail no exists!") unless (-e "sendEmail");
die("the log_record file no exists!") unless (-e "log_record.sta");
die("the config file no exists!") unless (-e "config.ini");

open FILE, "config.ini" or die ("config.ini open false! $!");
my $serverid = <FILE>;
my $path = <FILE>;
my $sender = <FILE>;
my $sleep = <FILE>;
close FILE;

$serverid =~ s/^\s+//;
$serverid =~ s/\s+$//;
die ("serverid error!") unless $serverid =~ /^\d+ /;

$path =~ s/^\s+//;
$path =~ s/\s+$//;
die ("no set check file path!") unless $path;

my $senders = [split(/,/, $sender)];
die ("no set sender!") unless scalar @$senders;
foreach my $user (@{$senders}){
        die ("send name wrong!") unless $user =~ /\@/;
}

$sleep =~ s/^\s+//;
$sleep =~ s/\s+$//;
die("set sleep time error!") unless $sleep =~ /^\d+$/;

while(1){
	open FILE, ">check_called.status";
	print FILE time();
	close FILE;	

	open FILE, "log_record.sta" or die ("log_record.sta open false! $!");
	my $file_sta = <FILE>;
	close FILE;

	my @record = split(/\t/, $file_sta);
	die ("log_record.sta error") if(scalar(@record) != 3);
	my $last_file = $record[0];
	my $index = $record[1];
	my $size = $record[2];

	die ("last_file record error!") unless($last_file =~ /server-\d{4}-\d{2}-\d{2}-\d{2}\.log$/);

	my ($date) = $last_file =~ /(\d{4}-\d{2}-\d{2}-\d{2})/;

	$date = join('',split(/-/, $date));

	$path =~ s/\/$//;
	my @sz = sort(glob("$path/server-*.log"));
	unless (scalar @sz){
		&logs("$path is not find file!");
		next;
	}

	my @log = ();
	foreach my $file_log (@sz){
		$file_log =~ /(\d{4})-(\d{2})-(\d{2})-(\d{2})/;
		my $cur_date = "$1$2$3$4";
		push @log, $file_log if($cur_date >= $date);
	}
	
	unless (scalar @log){
		&logs("check file is empty!");
		next;	
	}
	foreach my $file_log (@log){
		my $cur_filesize = -s $file_log;
		next if($cur_filesize == $size);
		$file_log =~ /(\d{4})-(\d{2})-(\d{2})-(\d{2})/;
		my $cur_date = "$1$2$3$4";
		if($cur_date > $date){
			$size = 0;
			$index = 0;
		}

		open FILE, "$file_log" or die ("$file_log open false! $!");
		&logs($file_log);
		my @file = <FILE>;
		close FILE;
		
		my $start = -2;
		my $end = -2;
		my $called = [];
		my $count = scalar @file;
		die("file line record error!")if($index < 0);
		$index++ if($index > 0);
		for(; $index < $count - 1; $index++){
			if($file[$index] =~ /called by/){
				if($start == -2){
					$start = $index;
				}else{
					$end = $index;
				}
				
				if($index == $count - 1){
					my $i = $start--;
					$i = 0 if($i < 0);
					for(; $i <= $end ; $i++){
							push @$called, $file[$i];
					}
					&fun_sendmail($called, $senders, $serverid);
					$start = -2;
					$end = -2;
					$called = [];
					sleep ($sleep);
				}
			}else{
				if($index - $end == 1){
					my $i = $start-1;
					$i = 0 if($i < 0);
					for(; $i < $index ; $i++){
							push @$called, $file[$i];
					}
					&fun_sendmail($called, $senders, $serverid);
					$start = -2;
					$end = -2;
					$called = [];
					sleep ($sleep);
				}
			}
		}
		
		open SAVE, ">log_record.sta" or die ("log_record.sta write info false! $!");
		print SAVE "$file_log\t$index\t$cur_filesize";
		close SAVE;
	}
	&logs ("----------------------sleep--------------------------");
	sleep(5);
}

sub fun_sendmail
{
	my ($data, $senders, $serverid) = @_;

	my $from = 'tianya2009@qq.com';
	my $password = '274209764';
	my $title = 'called by'." from $serverid";
	my $smtp = 'smtp.qq.com:25';
	foreach my $to (@$senders){
		$to =~ s/^\s+//;
		$to =~ s/\s+$//;
		my $content = undef;
		foreach my $line (@{$data}){
				chomp $line;
				$line =~ s/\(//g;
				$line =~ s/\)//g;
				$line =~ s/-/_/g;
				$content .= $line.'\\\n';
		}
		if(0 == system("$::APPLICATION_PATH/sendEmail -t $to -f $from -s $smtp -xu $from -xp $password -m $content -u $title")){
			logs("$to success");
		}else{
			logs("$to false!");
			logs("=====================================================");
			logs($content);
			logs("=====================================================");
		}
	}
}

sub logs
{
	my ($str) = @_;

	my $timestr = strftime("%Y-%m-%d %H:%M:%S",localtime);
	open SAVE, ">>check_called.log";
	print SAVE "[$timestr] $str\n";
	print  "[$timestr] $str\n";
	close SAVE;
}
		
