#!/bin/bash


#################################################################
#
#作用范围:
#   该脚本作用是切割nginx日志##
#   把nginx日志路径赋值给nginx_log_path变量
#   把nginx日志文件名赋值给log_filenames变量
#   把nginx备份分区路径赋给nginx_oldlog_path变量
#
#useage:
#   nginxLogSplit.sh <nginx log path> <backup log path>
#example:
#   nginxLogSplit.sh /usr/local/nginx/logs /databak/nginx_old_log
#
#################################################################

nginx_log_path=$1
nginx_oldlog_path=$2
log_filenames=`/bin/ls $nginx_log_path/*.log`


##调试前一部分程序是否运行正常
#exit
for log_path in ${log_filenames[@]}
do
log_name=${log_path/$nginx_log_path/}
log_name=${log_name/\//}
log_target_path=$nginx_oldlog_path/$log_name.`date +'%F-%H-%M-%S'`
mkdir -p $nginx_oldlog_path/
/bin/mv $log_path $log_target_path
done

#nginx restart
/usr/local/nginx/sbin/nginx -s reload