#!/usr/bin/perl -w
use DBI;
use POSIX qw(strftime);
use FindBin;
# $::APPLICATION_PATH = $FindBin::Bin;
#online nowonlinecount count={{10}};

# die("the log_record file no exists!") unless (-e "log_record.sta");
die("the online.cfg file no exists!") unless (-e "online.cfg");

open FILE, "online.cfg" or die ("config.ini open false! $!");
my @file = <FILE>;
close FILE;

my $cfg = {};
foreach $line (@file){
	$line =~ s/\s//g;
	my @sz = split(/=/, $line);
	if(scalar @sz == 2){
		$cfg->{$sz[0]} = $sz[1];
	}
}

die ("serverid no specified!") if(!exists $cfg->{serverid});
die ("host no specified!") if(!exists $cfg->{host});
die ("user no specified!") if(!exists $cfg->{user});
die ("pwd no specified!") if(!exists $cfg->{pwd});
die ("sdb no specified!") if(!exists $cfg->{sdb});
die ("path no specified!") if(!exists $cfg->{path});

eval{
	my $serverid = $cfg->{serverid};
	my $path = $cfg->{path};
	my $sdb = $cfg->{sdb};
	my $host = $cfg->{host};
	my $pwd = $cfg->{pwd};
	my $user = $cfg->{user};
	my $port = $cfg->{port}?$cfg->{port}:3306;
	my $db=DBI->connect("DBI:mysql:database=$sdb:$host:$port",$user,$pwd);  #连接数据库
	# print "connect database success!\n";

	$db->do("SET character_set_client='utf8'");
	$db->do("SET character_set_connection='utf8'");
	$db->do("SET character_set_results='utf8'");
	
	while(1){
		unless(-e "log_record.sta"){
			open FILE, ">log_record.sta";
			close FILE;
		}
		open FILE, "log_record.sta";
		my $file_sta = <FILE>;
		close FILE;
		
		my @record = split(/\t/, $file_sta) if (defined $file_sta);
		my $last_file = undef;
		my $index = 0;
		my $size = 0;
		
		$path =~ s/\/$//;
		my @sz = sort(glob("$path/server-*.log"));
		unless (scalar @sz){
			sleep(10);
			next;
		}
		if(scalar(@record) != 3){
			$last_file = shift @sz;
		}else{
			$last_file = $record[0];
			$index = $record[1];
			$size = $record[2];
		}
		
		die ("last_file record error!") unless($last_file =~ /server-\d{4}-\d{2}-\d{2}-\d{2}\.log$/);
		my ($date) = $last_file =~ /(\d{4}-\d{2}-\d{2}-\d{2})/;

		$date = join('',split(/-/, $date));
		
		my @log = ();
		foreach my $file_log (@sz){
			$file_log =~ /(\d{4})-(\d{2})-(\d{2})-(\d{2})/;
			my $cur_date = "$1$2$3$4";
			push @log, $file_log if($cur_date >= $date);
		}
		
		unless (scalar @log){
			sleep(10);
			next;	
		}
		my $data = [];
		foreach my $file_log (@log){
			my $cur_filesize = -s $file_log;
			next if($cur_filesize == $size);
			$file_log =~ /(\d{4})-(\d{2})-(\d{2})-(\d{2})/;
			my $cur_date = "$1$2$3$4";
			if($cur_date > $date){
				$size = 0;
				$index = 0;
			}

			open FILE, "$file_log" or die ("$file_log open false! $!");
			my @file = <FILE>;
			close FILE;
			
			my $count = scalar @file;
			for(; $index < $count; $index++){
				if(my ($datetime, $num) = $file[$index] =~ /\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\].*online nowonlinecount count=\{\{(\d+)\}\};/){
					push @$data, "($serverid, '$datetime', $num)";
				}
			}
			
			open SAVE, ">log_record.sta" or die ("log_record.sta write info false! $!");
			print SAVE "$file_log\t$index\t$cur_filesize";
			close SAVE;
		}
		if(scalar @$data){
			my $theday = strftime("%Y-%m-%d", localtime(time));
			my $sql_delete = "delete from meta_online where left(theday,10) < '$theday' and serverid = $serverid";
			$db->do($sql_delete);
			
			my $sql = "insert into meta_online (`serverid`, `theday`, `count`) values ".join(',',@$data);
			my $ret = $db->do($sql);
			if($ret !~ /\d+/){
				$db->disconnect();  #断开连接
				$db=DBI->connect("DBI:mysql:database=$sdb:$host:$port",$user,$pwd);  #连接数据库
				# print "connect database success!\n";

				$db->do("SET character_set_client='utf8'");
				$db->do("SET character_set_connection='utf8'");
				$db->do("SET character_set_results='utf8'");
			}
			# print $sql."\n";
		}
		# print "================================sleep(30)============================\n";
		sleep(30);
		
	}
};

if($@){
	print "$@";
}