use strict;
use warnings;
use utf8;

use DBI;
use JSON;
use Net::FTP;
use Encode;
use IO::Socket;
use URI::Escape;
use MIME::Base64;
use Compress::Zlib;
use LWP::UserAgent;
use POSIX qw{ strftime};
use Time::HiRes qw( usleep );
use Digest::MD5 qw(md5 md5_hex);

use Protocol;
use MysqlX;
require "common.pl";

#############################################
# version 2.0
# 
# 用于龙印,宗师接收修改密码短信
# 发送修改密码成功短信
# 
# 需要模块
#     ppm install Log::Log4perl
#
#############################################

BEGIN {
	use FindBin;
	use File::Path qw(make_path remove_tree mkpath);
	use POSIX qw(strftime);
	
	chdir( $FindBin::Bin);
    push( @INC, $FindBin::Bin);
    
	$|=1;
	our $APP_PATH = $FindBin::Bin;
	our $WARN_LOCKCOUNT = 0;
	our $last_okreporttime = 0;
	our $okreport_space = 3600*3;
	our $apprun_space = 60;
	our $ressvr_dlmaxsec = 50;
	our $AppName = "CheckTools";

	our $last_db_okreporttime = 0;
	our $last_db_notokreporttime = 0;
	our $db_okreport_space = 3600*5;	
	our $db_notokreport_space = 3600*2;	
	
	binmode( STDOUT, ":encoding(gbk)");
	$|=1;
}

for(@ARGV){
    next unless /^\-srv$/i;
    
    my $pid = fork();
    if ($pid < 0) {
        die "fork: $!";
    }
    elsif ($pid) {
        exit 0;
    }

    chdir($FindBin::Bin);

    #open(STDIN,  "</dev/null");
    #open(STDOUT, ">/dev/null");
    #open(STDERR, ">&STDOUT");
    last;
}

$::WARN_LOCKCOUNT = 0;
$::continue = 1;
$SIG{TERM} = sub { $::continue = 0 };

$SIG{__WARN__} = sub{

    my ($text) = @_;
    my @loc = caller(0);
    chomp($text);
    
    my $text_ = $text ? $text : "";
    $::logger->warn('warn: '. $text_); 
    
    my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
    {
        $::logger->warn( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
    };
    return 1;
};

$SIG{__DIE__} = sub{
    
    my ($text) = @_;
    my @loc = caller(0);
    chomp($text);

    my $text_ = $text ? $text : "";
    if( $::logger) {
	    $::logger->warn('error: '. $text_); 
	} 
	else {
		printf( 'error: %s\n', $text_);
	}
	
    my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index)) {
    	if( $::logger) {
	        $::logger->warn( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	    }
	    else {
	    	printf( " callby %s(%s) %s\n", $loc[1], $loc[2], "$loc[3]");
	    }
    };
    return 1;
};

use Moby::Business::LoggerMan;
use Moby::Business::TimeMan;

our $timeMan = Moby::Business::TimeMan->new();
our $loggerMan = Moby::Business::LoggerMan->new(
    timeMan=>$::timeMan,
    apppath=>$::APP_PATH,
    issvrmode=>1,
);
our $logger = $::loggerMan->getLogger();
$::timeMan->setLogger( $::logger);

$::logger->info( "server start...");

my $json = JSON->new;
my $req	= new LWP::UserAgent();

my $AppPath = $FindBin::Bin;
my $duty = "";
$duty = get_duty();

my $last_sms_check_time = 0;
my $sms_check_status = 0;
my $sms_check_id = 0;
my $sms_check_remain = 0;
my $remain = 0;

my $status_file = shift(@ARGV);
if (!defined($status_file) || length($status_file) <= 0) {
	die "perl -w check_tools_ly.pl path_of_status_file";
}

my %tag_process = (
    'common'				=> \&process_common,
	'sms_report'			=> \&process_sms_report,
	'status_file'			=> \&process_status_file,
	'sqlserver'				=> \&process_sqlserver,
	'ftp_server'			=> \&process_ftp_server,
#	'flow_check'			=> \&process_flow_check,
	'flow_check_json'		=> \&process_flow_check_json,
	'flow_check_blowfish'	=> \&process_flow_check_blowfish,
	'socket_server' 		=> \&process_socket_server,
	'check_tools'			=> \&process_check_tools,
    'check_tool_by_http' 	=> \&process_check_tools_by_http,
	#'check_sms_channel' 	=> \&check_sms_channel,#获取短信条数
	'check_db_restore'		=> \&process_check_db_restore,
);

my $sms_report;


while( $::continue) {
	run();
	sleep(100);
}

sub get_duty
{
	my ($code, $content) = request_url("http://heroes.ta.cn:8080/Redmine/onduty.php", []);

	if ($code != 0) {
		$::logger->warn( "get_duty fail: $content");
		return $duty;
	}
	$duty = $content;
	return $duty;
}

sub run
{

    $::timeMan->runTick();
    $::loggerMan->runTick();
    
	$sms_report = undef;

	my $tmNow = time();
	$::logger->info( sprintf( "now: %s", strftime( "%Y-%m-%d %H:%M:%S", localtime( $tmNow))));

	my $error_msg = "";
	my $error_msg_db_restore = '';

	my $cfg_ini = load_ini($AppPath . "/check_tools_ly.cfg");
	for (@{$cfg_ini})
	{
		my $section = $_;

		my $name = lc($section->{'name'});
		$name =~ s/^\s+//;
		$name =~ s/\s+$//;

		next unless exists $tag_process{$name};

		my $func = $tag_process{$name};

		my $item_name = get_section_value($section, "name", "");

		$::logger->info( "processing $name => $item_name start ");
		if($name ne 'check_db_restore') {
			my ($code, $result) = &$func($section);
			if (length($item_name)>0 && defined($code)) {
				if ($code != 0) {
					$error_msg .= "$item_name@" . $result . "|";
				}
			}
		} else {
			my ($code, $result) = &$func($section);
			if (length($item_name)>0 && defined($code)) {
				if ($code != 0) {
					$error_msg_db_restore .= "$item_name@" . $result . "|";
				}
			}
		}
		$::logger->info( "processing $name => $item_name done ");
	}

	$error_msg =~ s/\|$//;
	if($error_msg !~ /^\s*$/){
		$::logger->info( "************************************************");
		$::logger->info( "error!!! ");
		$::logger->info( "\t" . $error_msg);
		$::logger->info( "************************************************");
		report_sms($error_msg);
		#print "$error_msg\n";
		$::last_okreporttime = time();
	}else {
		$::logger->info( "ok");
		if( time() - $::last_okreporttime > $::okreport_space) {
			#report_sms( "all server ok! number of SMS is $remain!");
			report_sms( "all server ok!");
			#print "all server ok! number of SMS is $remain!\n";
			$::last_okreporttime = time();
		}
	}
	
	$error_msg_db_restore =~ s/\|$//;
	if($error_msg_db_restore !~ /^\s*$/)
	{
		$::logger->info( "************************************************");
		$::logger->info( "error!!! ");
		$::logger->info( "\t" . $error_msg_db_restore);
		$::logger->info( "************************************************");
		if(time() - $::last_db_notokreporttime > $::db_notokreport_space) {
			report_db_restore_sms($error_msg_db_restore);
			$::last_db_notokreporttime = time();
			$::last_db_okreporttime = time();
		}
	}
    else {
		$::logger->info( "ok");
		if( time() - $::last_db_okreporttime > $::db_okreport_space) {
			report_db_restore_sms( 'all db can be restored!');
			$::last_db_okreporttime = time();
		}
	}
}

sub process_common{
    my ($section) = @_;
	$::selecturl = get_section_value($section, "selecturl", "");
	$::restoredburl = get_section_value($section, "restoredburl", "");
}

sub process_status_file
{
	my ($section) = @_;

	my $file = get_section_value($section, "file", "");
	my $time = get_section_value($section, "time", 360);

	if (length($file)<=0 || ! -f $file) {
		return (-1, "file not found!");
	}
	
	my $cont = "";
	my $count = 5;
	my $tryCount = 0;
	while( $tryCount < $count) {
		$cont = readin($file);
		last if $cont =~ /^\s*\d+\s*$/;
		
		sleep(2);
		$tryCount ++;
		$cont = "";
	}
	
	if ( length( $cont)<=0) {
		return (-1, "err, status file is empty");
	}
	
	my $tm = int( $cont);

	if ( time() - $tm > $time) {
		return ( -1, "err, last_update:".strftime( "%Y-%m-%d %H:%M:%S", localtime($tm)));
	}

	return ( 0, "ok");
}

sub process_sqlserver {
	my ($section) = @_;

	my $server = get_section_value($section, "server", "");
	my $username = get_section_value($section, "username", "");
	my $password = get_section_value($section, "password", "");

	my $dbs = "dbi:ODBC:DRIVER={SQL Server};SERVER={$server}";
	my $dbh = DBI->connect($dbs, $username, $password);

	if (defined($dbh)) {
		$dbh->disconnect;
		return (0, "ok");
	}

	return (-1, "connect to db error");
}

sub process_ftp_server {
	my ($section) = @_;

	my $server = get_section_value($section, "server", "");
	my $port = get_section_value($section, "port", "");
	my $username = get_section_value($section, "username", "");
	my $password = get_section_value($section, "password", "");

	my $ftp = Net::FTP->new($server, Port  => $port) or return (-1, "connect to ftp error");
    $ftp->login($username, $password) or return (-2, "login to ftp error");
	$ftp->quit;

	return (0, "ok");
}

sub simple_request_url
{
	my ($url, $http_header, $http_param)=@_;

	my $tryCount = 20;
	my $curCount = 0;
	my $bSuccess = 0;
	my $content = "";

	while( !$bSuccess && $curCount < $tryCount) {
		my $browser = new LWP::UserAgent;
		$browser->agent("Mozilla/5.0 (compatible; MSIE 10.6; Windows NT 6.1; Trident/5.0; InfoPath.2; SLCC1; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 2.0.50727) 3gpp-gba UNTRUSTED/1.0");
        if( $http_header && 'ARRAY' eq ref( $http_header) && scalar( @{$http_header}) > 0) {
			$browser->default_header( @$http_header);
		}

		my $response;
		if( $http_param) {
			$response = $browser->post( $url, $http_param, );
		} 
		else {
			$response = $browser->get( $url);
		}
		$bSuccess = $response->is_success;
		$content = $response->content;
		$curCount ++;
	}

	if($bSuccess) { 
		return( 0, $content);
	} 

	return ( -1, $content);
}

sub request_url_blowfish{
	my ($url, $http_header, $http_param)=@_;
	my $tryCount = 20;
	my $curCount = 0;
	my $bSuccess = 0;
	my $content = "";
	
	my $paramcontent = '';
	my $request = HTTP::Request->new( POST => $url);
	if( $http_param) {
		eval{
			$paramcontent = JSON->new->encode( $http_param);
		};
		$paramcontent = Protocol::encodeData( $paramcontent);
	}
	$request->content( $paramcontent);
	while( !$bSuccess && $curCount < $tryCount) {
		my $browser = new LWP::UserAgent;
		$browser->agent("NokiaN72/ 5.0741.4.0.1 Series60/2.8 Profile/MIDP-2.0 Configuration/CLDC-1.1");
        if( $http_header && 'ARRAY' eq ref( $http_header) && scalar( @{$http_header}) > 0) {
			$browser->default_header( @$http_header);
		}
		my $response;
		eval{
			$response = $browser->request( $request);
			$content 		= $response->content;
			$content 		= Protocol::decodeData( $content);
			if( !$response->is_success) {
				$content = "the request false!";
				return ( -1, $content);
				# die( $!);
			}
		};
		if( $@) {
			$::logger->warn( $@);
			$bSuccess = 0;
		}
		else {
			$bSuccess = $response->is_success;
		}

		$curCount ++;
	}

	if($bSuccess) { 
		return( 0, $content);
	} 

	return ( -1, $content);
}

sub request_url {
	my ($url, $http_header, $http_param)=@_;

	my $tryCount = 20;
	my $curCount = 0;
	my $bSuccess = 0;
	my $content = "";

	while( !$bSuccess && $curCount < $tryCount) {
		my $browser = new LWP::UserAgent;
		$browser->agent("NokiaN72/ 5.0741.4.0.1 Series60/2.8 Profile/MIDP-2.0 Configuration/CLDC-1.1");
        if( $http_header && 'ARRAY' eq ref( $http_header) && scalar( @{$http_header}) > 0) {
			$browser->default_header( @$http_header);
		}
		my $response;
		eval{
			
			if( $http_param) {
				$response = $browser->post( $url, $http_param, 'Content_Type' => 'application/x-www-form-urlencoded');
			} 
			else {
				$response = $browser->get( $url);
			}
		};
		if( $@) {
			$::logger->warn( $@);
			$bSuccess = 0;
		}
		else {
			$bSuccess = $response->is_success;
		}

		
		$content = $response->content;
		$curCount ++;
	}

	if($bSuccess) { 
		return( 0, $content);
	} 

	return ( -1, $content);
}

sub request_url_supp_redirect {
	my ($url, $http_header, $http_param)=@_;

	my $tryCount = 20;
	my $curCount = 0;
	my $bSuccess = 0;
	my $content = "";
	my $isredirect = 0;
	my $newurl = '';
	while( !$bSuccess && $curCount < $tryCount) {
		my $browser = new LWP::UserAgent;
		$browser->agent("NokiaN72/ 5.0741.4.0.1 Series60/2.8 Profile/MIDP-2.0 Configuration/CLDC-1.1");
        if( $http_header && 'ARRAY' eq ref( $http_header) && scalar( @{$http_header}) > 0) {
			$browser->default_header( @$http_header);
		}
		my $response;
		eval{
			
			if( $http_param) {
				$response = $browser->post( $url, $http_param, 'Content_Type' => 'application/x-www-form-urlencoded');
			} 
			else {
				$response = $browser->get( $url);
			}
		};
		if( $@) {
			$::logger->warn( $@);
			$bSuccess = 0;
		}
		else {
			$bSuccess = $response->is_success;
			
			

			if( $response->code() == 302) {
				
				$newurl = $response->header( 'location');
				$isredirect = 1;
				my( $_code, $_content) = request_url( $newurl, $http_header, $http_param);

				printf( "request_url_supp_redirect url:%s start\n", $url);
				printf( "code:%s\n", $response->code());
				printf( "newurl:%s\n", $response->header( 'location'));

				if( $_code == 0) {
					return ( $_code, $_content);
				}
				
			}
		}

		
		$content = $response->content;
		$curCount ++;
	}

	if( $isredirect) {
		return 
	}

	if($bSuccess) { 
		return( 0, $content);
	} 

	return ( -1, $content);
}

sub iDreamSky_request_url
{
	my ($url, $http_header, $data)=@_;

	my $tryCount = 3;
	my $curCount = 0;
	my $bSuccess = 0;
	my $content = "";

	while(!$bSuccess && $curCount < $tryCount) {
		my $browser    = new LWP::UserAgent;
		$browser->agent('SkyNet/1.3.1(android:2.3.4;package:com.idreamskyDSClient;lang:zh_CN;app_version:3.02;channel:;device_brand:samsung;device_model:GT-I9100;resolution:600X1024;udid:ffffffff-883c-091b-3c0a-da0d303e46a8;cpu_freq:0;google_account:null;phone_number:unknown;game_name:\\x99p;sdk_version:1.3;is_social_game:true)');
		
		my $request;

		if ( defined($data) )  {
			$request = HTTP::Request->new( "POST", $url, $http_header, $data )
		}
		else {
			$request = HTTP::Request->new( "GET", $url, $http_header)
		}

		my $response;
		$response = $browser->request( $request);

		$bSuccess = $response->is_success;
		$content = $response->content;
		$curCount ++;
	}

	if( $bSuccess) { 
		return (0, $content);
	} 

	$::logger->info($content);
	
	return 	(-1, $content);
}

sub get_iDreamSky_account
{
	# get auth token
	my $auth_token = "";
	{
		my $url = "http://v1-secure.idreamsky.com/oauth/request_token";
		my @http_header=
		(
			'Authorization'=>'OAuth oauth_consumer_key="d6aa204af88749f559c9", oauth_signature_method="HMAC-SHA1", oauth_signature="kwj%2FQUTEiM0u2wjd7rWM%2FVtQEVw%3D", oauth_timestamp="1348721336", oauth_nonce="8817954983821245991", oauth_version="1.0", oauth_callback="dgc-request-token-callback"',
		);

		my ($code, $content) = iDreamSky_request_url($url, \@http_header, "");
		
		if ($code != 0)
		{
			return ($code, "get auth token failed!");
		}
		
		if ($content =~ /^oauth_token=([^\&]+)&/i)
		{
			$auth_token = $1;
		}
		else
		{
			return (-1, "parse auth token failed!");
		}
	}
	
	#get openid and sessionid
	my $openid = "";
	my $sessionid = "";
	{
		my $url = "http://ly.feed.uu.cc/account/openid_sessionid";
		my @http_header=
		(
			'Authorization'=>'OAuth oauth_consumer_key="d6aa204af88749f559c9", oauth_token="a75721f2118e33a5fc1b5a9f9b5d0ab705063dab9", oauth_signature_method="HMAC-SHA1", oauth_signature="pLzvzK%2BtyiEQbVklEnkHDy%2BTleA%3D", oauth_timestamp="1348721339", oauth_nonce="6236913762774287920", oauth_version="1.0"',
		);

		my ($code, $content) = iDreamSky_request_url($url, \@http_header, '{"extraInfo":"moby_imei=248319024695123&moby_sdk=android_gingerbread&moby_op=&moby_ua=GT-I9100+samsung\\/GT-I9100\\/GT-I9100:2.3.4\\/GRJ22\\/eng.build.20120314.185218:eng\\/release-key"}');
		
		if ($code != 0)
		{
			return ($code, "get openid and sessionid failed!");
		}
		
		if ($content =~ /"openid":"([^\"]+)","sessionid":"([^\"]+)"/i)
		{
			$openid = $1;
			$sessionid = $2;
		}
		else
		{
			return (-1, "parse openid and sessionid failed!");
		}
	}
	
	return (0, "ok", $openid, $sessionid);
}

sub process_flow_check_json
{
	my ($section) = @_;

	my $url = get_section_value($section, "url", "");
	my $pubs = get_section_value($section, "pubs", "");
	my $imei = get_section_value($section, "imei", "");
	my $sdk = get_section_value($section, "sdk", "");
	my $sv = get_section_value($section, "sv", "27000");
	my $username = get_section_value($section, "username", "");
	my $password = get_section_value($section, "password", "");
	my $ischkpay = get_section_value($section, "ischkpay", "");
	my $ischkpcpay = get_section_value($section, "ischkpcpay", 0);

	for(split(/,/, $pubs))
	{
		next if /^\s*$/;

		my $pub = $_;
		$pub =~ s/^\s+//;
		$pub =~ s/\s+$//;

		my $moby_auth=get_auth($imei);
		my @http_header=
		(
			'moby_auth'=>$moby_auth,
			'moby_imei'=>$imei,
			'moby_pb'=>$pub,
			'moby_sdk'=>$sdk,
			'moby_op'=>'op',
			'moby_ua'=>'ua',
			'moby_bv'=>'bv',
			'moby_sv'=>$sv,
		);
#'moby_sv'=>'23089', '24792'
		
		#账号 密码 都要加密处理  --------------------------------------------
		#加密方式 D:\workspace\DataCenter_ly\gamemasteraccount_new\test\Protocol.pm  encodeData
		my %http_param = (
			'username' => &Protocol::encodeData($username),
			'userpassword'=> &Protocol::encodeData($password),
		);
print "$url\n";
		my ($code, $content) = request_url($url, \@http_header, \%http_param);

		if ($code != 0) {
			$::logger->warn( "check_getaddr fail: $content");
			return (-1, "autoupdate_url $pub: error");
		}

		# 顺序:   更新  充值   登录
		#return format modify    getaddr-------------------------------------------- 
		    # {
				# "code":0,
				# "msg":"请求成功",
				# "data":{
					# "accsvrurl":"<账号服务器url>", 
					# "payurl":"<充值请求url>",
					# "bbsurl":"<论坛跳转url>",
				# }
			# }
		my $jsonResponse ;
		eval {
            $jsonResponse = JSON->new->utf8->decode( $content);
        };
        if($@) {
			$::logger->info( "getaddr json_decode error: $@   content:$content ");
			return (-9, "getaddr json_decode error");
        }
		
		if ($jsonResponse->{code} != 0) {
			$::logger->info( "getaddr code error: $@   content:$content ");
			return (-2, "autoupdate return error $pub :" . $jsonResponse->{code});
		}
		#check_web_pay
		my $account_server_url = $jsonResponse->{data}->{accsvrurl};
		my $pay_url = $jsonResponse->{data}->{payurl};



		if ($pub =~ /^ledou_/i && 0) #因为乐逗参数变化导致模拟失败，需要重新抓包解决
		{
			my ($code, $msg, $openid, $sessionid) = get_iDreamSky_account();
			if ($code != 0)
			{
				$::logger->warn( "get ledou account fail: $msg");
				return (-1, "Ledou_SDK_error $pub: $msg");
			}
			%http_param = (
				'username' => Protocol::encodeData( $openid),
				'userpassword'=> Protocol::encodeData( $sessionid),
			);
		}
		

		if( $pub =~ /twly_/i) {
			my $tmp = {@http_header};
			#$tmp->{moby_pb} = 'moby';
			@http_header = %{$tmp};
		}
		
		# gamelist 协议 变成 acclogin 协议  --------------------------------------------
		#check_login
		($code, $content) = request_url($account_server_url."?gameparam=acclogin", \@http_header, \%http_param);

		$::logger->info( sprintf( "acclogin response %s", Encode::decode( "utf8", $content)));
		if ($code != 0) {
			print $account_server_url."?gameparam=acclogin"."\n";
			$::logger->warn( "check_login fail:".$content);
			return (-3, "account_server_url $pub: error");
		}
		
		eval {
            $jsonResponse = JSON->new->utf8->decode( $content);
        };
        if($@) {
			$::logger->info( "acclogin json_decode error: $@");
			return (-9, "acclogin json_decode error");
        }
		
		#  json_decode($content)  该过程也需判断   --------------------------------------------
		
		if ($jsonResponse->{code} != 0) {
			return (-2, "acclogin return error $pub ");
		}

		#$ischkpcpay去掉 登录(acclogin  BANK_Pay键)之后 根据返回的充值方式个数验证  -------------------------------------------- 
		if ( defined( $jsonResponse->{data}->{gamesettings}->{payment}) && 'HASH' eq ref( $jsonResponse->{data}->{gamesettings}->{payment}) && defined($jsonResponse->{data}->{gamesettings}->{payment}->{BANK_Pay})) {
			#检查网银充值
			my $wap_url = $jsonResponse->{data}->{gamesettings}->{payment}->{BANK_Pay}->{payurl};
			$::logger->info( "$pub=>wap_url:$wap_url\n");
			($code, $content) = request_url($wap_url, \@http_header, \%http_param);
			if($code !=0){
				$::logger->warn( "check_web_pay fail: $wap_url");
				return (-1, "wap_url $pub: error");
			}
			my $web_pay_url ="";
			if($content =~ /<br \/>\s*(http:\/\/[^\s]+)\s*<\/p>/){
				$web_pay_url = $1;
			}
			if(!$web_pay_url){
				$::logger->warn( "check_web_pay fail: can not match web_pay_url! content:$content");
				return (-2, "web_pay_url $pub: error");
			}

			($code, $content) = request_url_supp_redirect($web_pay_url, \@http_header, \%http_param);
			if($code !=0){
				$::logger->warn( "check_web_pay getaddr fail: $web_pay_url");
				return (-3, "web_pay_url $pub: error");
			}
			my $web_content = decode("utf8",$content);
			if($web_content !~ /一元面值人民币可换取10元宝|首次充值超过10元/){
				$::logger->warn( "check_web_pay content fail: $web_pay_url");
				return (-4, "web_pay_url $pub: error");
			}
		}
		
		#check_pay

		if ( defined( $jsonResponse->{data}->{gamesettings}->{payment}) && 'HASH' eq ref( $jsonResponse->{data}->{gamesettings}->{payment}) && defined($jsonResponse->{data}->{gamesettings}->{payment}->{CARD_Pay})) {
			($code, $content) = request_url($pay_url."?payparam=cardtypelist", \@http_header, \%http_param);
			if ($code != 0) {
				$::logger->warn( "check_pay fail: $pay_url $content");
				return (-3, "pay_url $pub: error");
			}
		}

		
		my $i=0;
		#循环检查游戏服务器和资源服务器
		for my $item (@{$jsonResponse->{data}->{servers}})
		{
			if ( $item->{state} <10 && $item->{open})
			{
				my $server_name = $item->{name};
				my @game_server_ip_port = split(/:/, $item->{ip});
				my @file_server_ip_port = split(/:/, $item->{res_ip});
				my $proxyip = defined( $item->{proxyip}) ? $item->{proxyip} : "";
				
				if (@game_server_ip_port == 2 && @file_server_ip_port == 2) 
				{
					if (!connect_to($game_server_ip_port[0], $game_server_ip_port[1], 5, $proxyip))
					{
						return (-5, "1 $pub game_server ". $item->{ip} ." connect error");
					}
					
					my $dlsec = connect_to_res($file_server_ip_port[0], $file_server_ip_port[1], 5);
					if ( $dlsec < 0)
					{
						return (-5, "2 $pub res_server ". $item->{res_ip} ." connect error". $dlsec);
					}
					if ( $dlsec > $::ressvr_dlmaxsec) {
						return (-5, "2 $pub res_server ". $item->{res_ip} ." download more than ".$::ressvr_dlmaxsec." second");
					}
				}
				else
				{
					return (-4, "3 server_list format error $pub: $item");
				}
			}
			else {
				$::logger->info( sprintf( "skip connect by gameserver(%s)", $item->{ip}));
				$::logger->info( sprintf( "skip connect by resserver(%s)", $item->{res_ip}));
			}
		}
		
	}

	return (0, "ok");
}

sub process_flow_check_blowfish
{
	my ($section) = @_;

	my $url = get_section_value($section, "url", "");
	my $pubs = get_section_value($section, "pubs", "");
	my $imei = get_section_value($section, "imei", "");
	my $sdk = get_section_value($section, "sdk", "");
	my $sv = get_section_value($section, "sv", "27000");
	my $username = get_section_value($section, "username", "");
	my $password = get_section_value($section, "password", "");
	my $ischkpay = get_section_value($section, "ischkpay", "");
	my $ischkpcpay = get_section_value($section, "ischkpcpay", 0);

	for(split(/,/, $pubs))
	{
		next if /^\s*$/;

		my $pub = $_;
		$pub =~ s/^\s+//;
		$pub =~ s/\s+$//;

		my $moby_auth=get_auth($imei);
		my @http_header=
		(
			'moby_auth'=>$moby_auth,
			'moby_imei'=>$imei,
			'moby_pb'=>$pub,
			'moby_sdk'=>$sdk,
			'moby_op'=>'op',
			'moby_ua'=>'ua',
			'moby_bv'=>'bv',
			'moby_sv'=>$sv,
		);
#'moby_sv'=>'23089', '24792'
		
		#账号 密码 都要加密处理  --------------------------------------------
		#加密方式 D:\workspace\DataCenter_ly\gamemasteraccount_new\test\Protocol.pm  encodeData
		
print "$url\n";
		my ($code, $content) = request_url_blowfish($url, \@http_header, undef);

		if ($code != 0) {
			$::logger->warn( "check_getaddr fail: $content");
			return (-1, "autoupdate_url $pub: error");
		}

		# 顺序:   更新  充值   登录
		#return format modify    getaddr-------------------------------------------- 
		    # {
				# "code":0,
				# "msg":"请求成功",
				# "data":{
					# "accsvrurl":"<账号服务器url>", 
					# "payurl":"<充值请求url>",
					# "bbsurl":"<论坛跳转url>",
				# }
			# }
		my $jsonResponse ;
print "resp:$content\n";
		eval {
            $jsonResponse = JSON->new->decode( $content);
        };
        
        if($@) {
			$::logger->info( "getaddr json_decode error: $@   content:$content ");
			return (-9, "getaddr json_decode error");
        }
		
		if ($jsonResponse->{code} != 0) {
			$::logger->info( "getaddr code error: $@   content:$content ");
			return (-2, "autoupdate return error $pub :" . $jsonResponse->{code});
		}
		#check_web_pay
		my $account_server_url = $jsonResponse->{data}->{accsvrurl};
		my $pay_url = $jsonResponse->{data}->{payurl};

		my %http_param = (
			'username' => $username,
			'userpassword'=> $password,
		);

		if ($pub =~ /^ledou_/i && 0) #因为乐逗参数变化导致模拟失败，需要重新抓包解决
		{
			my ($code, $msg, $openid, $sessionid) = get_iDreamSky_account();
			if ($code != 0)
			{
				$::logger->warn( "get ledou account fail: $msg");
				return (-1, "Ledou_SDK_error $pub: $msg");
			}
			%http_param = (
				'username' => $openid,
				'userpassword'=> $sessionid,
			);
		}
		

		if( $pub =~ /twly_/i) {
			my $tmp = {@http_header};
			#$tmp->{moby_pb} = 'moby';
			@http_header = %{$tmp};
		}
		
		# gamelist 协议 变成 acclogin 协议  --------------------------------------------
		#check_login
		($code, $content) = request_url_blowfish($account_server_url."?gameparam=acclogin", \@http_header, \%http_param);
print "url:$account_server_url\n";
		
		$::logger->info( sprintf( "acclogin response %s", $content));
		if ($code != 0) {
			print $account_server_url."?gameparam=acclogin"."\n";
			$::logger->warn( "check_login fail:".$content);
			return (-3, "account_server_url $pub: error");
		}
print "resp:$content\n";	
		eval {
            $jsonResponse = JSON->new->decode( $content);
        };
        if($@) {
			$::logger->info( "acclogin json_decode error: $@");
			return (-9, "acclogin json_decode error");
        }
		
		#  json_decode($content)  该过程也需判断   --------------------------------------------
		
		if ($jsonResponse->{code} != 0) {
			return (-2, "acclogin return error $pub ");
		}

		#$ischkpcpay去掉 登录(acclogin  BANK_Pay键)之后 根据返回的充值方式个数验证  -------------------------------------------- 
		if ( defined( $jsonResponse->{data}->{gamesettings}->{payment}) && 'HASH' eq ref( $jsonResponse->{data}->{gamesettings}->{payment}) && defined($jsonResponse->{data}->{gamesettings}->{payment}->{BANK_Pay})) {
			#检查网银充值
			my $wap_url = $jsonResponse->{data}->{gamesettings}->{payment}->{BANK_Pay}->{payurl};
			$::logger->info( "$pub=>wap_url:$wap_url\n");
			($code, $content) = request_url($wap_url, \@http_header, \%http_param);
			if($code !=0){
				$::logger->warn( "check_web_pay fail: $wap_url");
				return (-1, "wap_url $pub: error");
			}
			my $web_pay_url ="";
			if($content =~ /<br \/>\s*(http:\/\/[^\s]+)\s*<\/p>/){
				$web_pay_url = $1;
			}
			if(!$web_pay_url){
				$::logger->warn( "check_web_pay fail: can not match web_pay_url! content:$content");
				return (-2, "web_pay_url $pub: error");
			}

			($code, $content) = request_url_supp_redirect($web_pay_url, \@http_header, \%http_param);
			if($code !=0){
				$::logger->warn( "check_web_pay getaddr fail: $web_pay_url");
				return (-3, "web_pay_url $pub: error");
			}
			my $web_content = decode("utf8",$content);
			if($web_content !~ /一元面值人民币可换取10元宝|首次充值超过10元/){
				$::logger->warn( "check_web_pay content fail: $web_pay_url");
				return (-4, "web_pay_url $pub: error");
			}
		}
		
		#check_pay
		if ( defined( $jsonResponse->{data}->{gamesettings}->{payment}) && 'HASH' eq ref( $jsonResponse->{data}->{gamesettings}->{payment}) && defined($jsonResponse->{data}->{gamesettings}->{payment}->{CARD_Pay})) {
			($code, $content) = request_url_blowfish($pay_url."?payparam=cardtypelist", \@http_header, \%http_param);
			if ($code != 0) {
				$::logger->warn( "check_pay fail: $pay_url $content");
				return (-3, "pay_url $pub: error");
			}
		}

		my $i=0;
		#循环检查游戏服务器和资源服务器
		for my $item (@{$jsonResponse->{data}->{servers}})
		{
			if ( $item->{state} <10 && $item->{open})
			{
				my $server_name = $item->{name};
				my @game_server_ip_port = split(/:/, $item->{ip});
				my @file_server_ip_port = split(/:/, $item->{res_ip});
				my $proxyip = defined( $item->{proxyip}) ? $item->{proxyip} : "";
				
				if (@game_server_ip_port == 2 && @file_server_ip_port == 2) 
				{
					if (!connect_to($game_server_ip_port[0], $game_server_ip_port[1], 5, $proxyip))
					{
						return (-5, "1 $pub game_server ". $item->{ip} ." connect error");
					}
					
					my $dlsec = connect_to_res($file_server_ip_port[0], $file_server_ip_port[1], 5);
					if ( $dlsec < 0)
					{
						return (-5, "2 $pub res_server ". $item->{res_ip} ." connect error". $dlsec);
					}
					if ( $dlsec > $::ressvr_dlmaxsec) {
						return (-5, "2 $pub res_server ". $item->{res_ip} ." download more than ".$::ressvr_dlmaxsec." second");
					}
				}
				else
				{
					return (-4, "3 server_list format error $pub: $item");
				}
			}
			else {
				$::logger->info( sprintf( "skip connect by gameserver(%s)", $item->{ip}));
				$::logger->info( sprintf( "skip connect by resserver(%s)", $item->{res_ip}));
			}
		}
		
	}

	return (0, "ok");
}

sub connect_to
{
	my ($ip, $port, $tryCount, $proxyip) = @_;
	my $isproxy = 0;
	my $realport = 0;
	if( $proxyip) {
		$isproxy = 1;
		my @proxy_server_ip_port = split(/:/, $proxyip);
		my $ip_ = $ip;
		$realport = $port;
		$ip = $proxy_server_ip_port[0];
		$port = $proxy_server_ip_port[1];
	}
	
	my $msg = "create connect by gameserver($ip:$port) ";

	my $count = 0;
	while( $count < $tryCount) {
		$count ++;
		my $socket = IO::Socket::INET->new (
			PeerAddr	=> $ip,
			PeerPort	=> $port,
			Type		=> IO::Socket::SOCK_STREAM,
			Proto		=> 'tcp',
			Timeout     => 60
		);
		use Data::Dump qw{dump};
					
		if ($socket) {
			my $iRidCounter=0;
			my $resselect = new IO::Select();
			$resselect->add( $socket);
			
			my $issendcom = 0;
			my $lastrecving = {};
			my $isrecvcom = 0;
			my $sLog = "";
			if( $isproxy) {
				my $starttime = time();
				$sLog = "create connect by proxyserver($ip:$port)";
				$issendcom = 0;
				while( !$issendcom) {
					my @hWrite = $resselect->can_write();
					
					if( scalar( @hWrite) >= 1) {
						$issendcom = 1;
						
						foreach my $fh( @hWrite) {
							my $rid = ++$iRidCounter;
							my $sendcmd = sprintf( "%d connect %d", $rid, $realport);
							$::logger->info( sprintf( "sendmsg:%s", $sendcmd));
							$fh->send( decode_base64( Protocol::encodeData( $sendcmd)));
						}
					}
				}
				#$::logger->info( "select socket create success and info send ok!");
				$lastrecving = {};
				$isrecvcom = 0;
				my $receData = "";
				while ( !$isrecvcom) {
					my @hReady = $resselect->can_read();
					foreach my $fh( @hReady) {
						my $data = undef;
						$fh->recv( $data, 409600, 0);
						if( length( $data)) {
							$data = $lastrecving->{$fh} ? $lastrecving->{$fh} . $data : $data;
				
							while( length( $data) >= 4) {
								my $length = unpack( "N", substr( $data, 0, 4));
						
								if( length( $data) >= $length + 4) {
									my $data2 = substr( $data, 4, $length);
									if( $data2) { 
										$isrecvcom = 1;
										$receData = Protocol::decodeData( encode_base64( $data2));
										$::logger->info( sprintf( "receivemsg:%s", $receData));
									}
									$data = "";
								}
								else {
									last;
								}
							}
							
							$lastrecving->{$fh} = $data if($fh);
						}
						else {
							$isrecvcom = 1;
							last;
						}
					}
				}
				if( !$isrecvcom) {
					$resselect->remove( $socket);
					$socket->close();
					next;
				}
				my $receiveDatas = [split( / /, $receData)];
				if( !defined( $receiveDatas->[2]) || $receiveDatas->[2] ne '0') {
					$resselect->remove( $socket);
					$socket->close();
					next;
				}
				my $endtime = time();
				my $usetime = $endtime - $starttime;
				my $usetimeshow = $usetime < 1 ? "<1" : "$usetime";
				$sLog = $sLog. " succ use time:" . $usetimeshow;
				$::logger->warn( $sLog);
				
			}
			else{
				$sLog = "create connect by gameserver($ip:$port)";
			}
			
			my $starttime = time();
			$issendcom = 0;
			while( !$issendcom) {
				my @hWrite = $resselect->can_write();
				if( scalar( @hWrite) >= 1) {
					$issendcom = 1;
					foreach my $fh( @hWrite) {
						my $rid = ++$iRidCounter;
						my $sendcmd = sprintf( "%d keeplife", $rid);
						$::logger->info( sprintf( "sendmsg:%s", $sendcmd));
						$fh->send( decode_base64( Protocol::encodeData( $sendcmd)));
					}
				}
			}
			#$::logger->info( "select socket create success and info send ok!");
			$lastrecving = {};
			$isrecvcom = 0;
			my $receData = "";
			while ( !$isrecvcom) {
				my @hReady = $resselect->can_read();
				dump( scalar( @hReady));
				foreach my $fh( @hReady) {
					my $data = undef;
					
					$fh->recv( $data, 1024, 0);
					dump( length( $data));
					if( length( $data)) {
						$data = $lastrecving->{$fh} ? $lastrecving->{$fh} . $data : $data;
			
						while( length( $data) >= 4) {
							my $length = unpack( "N", substr( $data, 0, 4));
					
							if( length( $data) >= $length + 4) {
								my $data2 = substr( $data, 4, $length);
								if( $data2) { 
									$isrecvcom = 1;
									dump( encode_base64( $data2));
									$receData = Protocol::decodeData( encode_base64( $data2));
									$::logger->info( sprintf( "receivemsg:%s", $receData));
								}
								$data = "";
							}
							else {
								last;
							}
						}
						
						$lastrecving->{$fh} = $data if($fh);
					}
					else {
						$isrecvcom = 1;
						last;
					}
				}
			}
			if( !$isrecvcom) {
				$resselect->remove( $socket);
				$socket->close();
				next;
			}
			my $receiveDatas = [split( / /, $receData)];
			if( !defined( $receiveDatas->[2]) || $receiveDatas->[2] ne '0') {
				$resselect->remove( $socket);
				$socket->close();
				next;
			}
			my $endtime = time();
			my $usetime = $endtime - $starttime;
			my $usetimeshow = $usetime < 1 ? "<1" : "$usetime";
			$sLog = $sLog. " succ use time:" . $usetimeshow;
			$::logger->warn( $sLog);
			
			$resselect->remove( $socket);
			$socket->close();
			return $usetime || 1;
		} 
		else {
			$::logger->info( "\t\tcreate connect fail host:$ip, port:$port");
		}
		
		sleep(3);
	}

	$msg = $msg."fail";
	$::logger->info( $msg);
	return 0;
}

#connect to res
sub connect_to_res {
	my ( $ip, $port, $tryCount) = @_;
	my $count = 0;
	my $sendcmd = "GET md5/ea6e1b28bff7fc479f72b74ffec3bfd5";
	my $length = length( $sendcmd);
	$sendcmd = pack( "N", $length) . $sendcmd;
	my $sLog = "create connect by resserver($ip:$port)";
	while( $count < $tryCount) {
		
		my $starttime = time();
		my $socket = IO::Socket::INET->new (
			PeerAddr	=> $ip,
			PeerPort	=> $port,
			Type		=> IO::Socket::SOCK_STREAM,
			Proto		=> 'tcp',
			Timeout     => 60
		);
		
		if ($socket) {
			my $resselect = new IO::Select();
			$resselect->add( $socket);
			my @hWrite = $resselect->can_write();
			foreach my $fh( @hWrite) {
				$fh->send( $sendcmd);
			}
			#$::logger->info( "select socket create success and info send ok!");
			my $lastrecving = {};
			my $isrecvcom = 0;
			while ( !$isrecvcom) {
				my @hReady = $resselect->can_read();
				foreach my $fh( @hReady) {
					my $data = undef;
					$fh->recv( $data, 409600, 60);
					if( length( $data)) {
						$data = $lastrecving->{$fh} ? $lastrecving->{$fh} . $data : $data;
			
						while( length( $data) >= 4) {
							my $length = unpack( "N", substr( $data, 0, 4));
					
							if( length( $data) >= $length + 4) {
								my $data2 = substr( $data, 4, $length);
								if( $data2) { 
									$isrecvcom = 1;
								}
								$data = "";
							}
							else {
								last;
							}
						}
						
						$lastrecving->{$fh} = $data if($fh);
					}
					else {
						$isrecvcom = 1;
						last;
					}
				}
			}
			if( $isrecvcom) {
				my $endtime = time();
				my $usetime = $endtime - $starttime;
				my $usetimeshow = $usetime < 1 ? "<1" : "$usetime";
				$sLog = $sLog. " succ use time:" . $usetimeshow;
				$::logger->warn( $sLog);
				
				return $usetime;
			}
			
			$resselect->remove( $socket);
			$socket->close();
		} 
		else {
			$::logger->info( "\t\tcreate connect fail host:$ip, port:$port");
		}
		
		$count ++;
		sleep(3);
	}
	$sLog = $sLog. " fail $tryCount times";
	$::logger->warn( $sLog);
	return -1;
}

sub process_socket_server {
	my ( $section) = @_;

	my $server = get_section_value( $section, "server", "");
	my $port = get_section_value( $section, "port", "");

	my $socket = IO::Socket::INET->new(
		PeerAddr	=> $server,
		PeerPort	=> $port,
		Type		=> IO::Socket::SOCK_STREAM,
		Proto		=> 'tcp'
	);
	if( !$socket) {
		return ( -1, "connect $server:$port error");
	}
	$socket = undef;
	return (0, "ok");
}

sub _connect_to_ftp_and_get_file {
	my ( $server, $port, $passive, $username, $password, $server_path, $local_path) = @_;

	my $ftp;
	my $get_file_try_count = 0;
	my $login_try_count = 0;
	
L_CONNECT: 
	{
		$ftp = 0;
		my $tryCount = 5;
		my $count = 0;
		while( $count < $tryCount && !$ftp) {
			$ftp = Net::FTP->new( $server, Port  => $port, Debug => 0, Passive => $passive);
			if( !$ftp) {
				sleep(3);
			}
			$count++;
		}
	}
	
	if( !$ftp) {
		return (-1, "connect to ftp error");
	}
	
L_LOGIN: 
	{
		my $tryCount = 5;
		while( $login_try_count < $tryCount) {
			my $bOk = 0;
			eval {
				if( $ftp && $ftp->login( $username, $password)) {
					$bOk = 1;
				}
			};
			if( $bOk) {
				last;
			}
			sleep( 3);
			$login_try_count ++;
			goto L_CONNECT;
		}
		
		if( $login_try_count >= $tryCount) {
			return ( -2, "login to ftp error");
		}
	}
	
  
L_GETFILE: 
	{
		my $tryCount = 5;
		while( $get_file_try_count < $tryCount) {
			my $bOk = 0;
			eval {
				if( $ftp) {
					if ( $ftp->get( $server_path, $local_path)) {
						$bOk = 1;
					}
					$ftp->quit();
					$ftp->close();
				}
			};
			if( $bOk) {
				return ( 0, "ok");
			}
			sleep( 3);
			$get_file_try_count++;
			goto L_CONNECT;
		}
	}

	return ( -3, "get status file error");
}

sub process_check_db_restore {
	my( $section) = @_;
	
	my $name = get_section_value( $section, "name", "");
	my $sdbcnf = get_section_value( $section, "sdbcnf", "");
	my $rdbcnf = get_section_value( $section, "rdbcnf", "");
	
	#查找需要还原的服务器
	my $db_name = {};
	$db_name->{$name."_ga"} = 1;
	
	my %sdbcnf = str2arr($sdbcnf);
	my $sdbconn;
	for(my $i = 1; $i <= 5; $i++){
		eval{
			$sdbconn = MysqlX::genConn(\%sdbcnf);
		};
		if($@){
			if ($i==5){
				$::logger->info("error $sdbcnf connet false!");
				return (6, "check_db_restore $sdbcnf{name} connect false!");
			}
		}else{
			last;
		}
	}

	my $db = new MysqlX($sdbconn);
	my $theday = strftime("%Y-%m-%d",localtime());
	my $sql = "SELECT * FROM needrunserver WHERE theday = '$theday'";
	my $servers;
	for(my $i = 1; $i <= 5; $i++){
		eval{
			$servers = $db->fetchAll($sql);
		};
		if($@){
			if ($i==5){
				$::logger->info("error $sdbcnf{name} select needrunserver false!");
				return (6, "$sdbcnf{name} select needrunserver false!");
			}
		}else{
			last;
		}
	}
	
	foreach (@{$servers}) {
		my $serverid = $_->{'serverid'};
		$db_name->{$name."_gs".$serverid} = 1;
	}
	my $db_name_str = join("','", keys %$db_name);
	$db_name_str = "'".$db_name_str."'";
	
	#查看服务器的还原状态
	my %rdbcnf = str2arr($rdbcnf);
	my $rdbconn;
	for(my $i = 1; $i <= 5; $i++){
		eval{
			$rdbconn = MysqlX::genConn(\%rdbcnf);
		};
		if($@){
			if ($i==5){
				$::logger->info("error $rdbcnf connet false!");
				return (6, "db_restore_info $rdbcnf{host} check false!");
			}
		}else{
			last;
		}
	}
	
	my $rdb = new MysqlX($rdbconn);
	$sql = "
		SELECT * FROM restore_info WHERE db_name IN ($db_name_str) ORDER BY db_name
	";
	my $resultset;
	for(my $i = 1; $i <= 5; $i++){
		eval{
			$resultset = $rdb->fetchAll($sql);
		};
		if($@){
			if ($i==5){
				$::logger->info("error $rdbcnf{host} select restore_info false!");
				return (6, "$rdbcnf{host} select restore_info false!");
			}
		}else{
			last;
		}
	}
	
	my $unreducible = [];
	my $old = [];
	foreach my $result (@$resultset) {
		if ($result->{reducible} == 0) {
			push @$unreducible, $result->{db_name};
		}
		if ($result->{isold} == 1) {
			push @$old, $result->{db_name};
		}
		delete $db_name->{$result->{db_name}};
	}
	
	#返回信息
	my $msg = '';
	if(scalar(@$unreducible)) {
		$msg .= "unreducible db:".join(",", sort(@$unreducible));
	}
	if(scalar(@$old)) {
		$msg .= "old than 2 hours db:".join(",", sort(@$old));
	}
	if(scalar(keys %$db_name)) {
		$msg .= "haven't restored db:".join(",", sort(keys %$db_name));
	}
	
	if($msg eq '') {
		return (0, 'all db can be restored!');
	} else {
		return (6, $msg);
	}
}

sub process_check_tools_by_http {
    my( $section) = @_;
    my $geturl = get_section_value( $section, "geturl", "");
	my $checkcode = get_section_value( $section, "checkcode", "");
    
    my $digest = md5_hex( $checkcode);
    $geturl .= $digest;
    
    # my $response_get;
    my $response_get;#接受 get 后的返回值
    my $jsonResponse;#将获取后的内容解json
    my $content_get;#获得get后的内容
    my $is_success = 0;
    my $iTryCount = 0;#失败后重试的次数
    
    while( !$is_success && $iTryCount < 10) {
        $iTryCount++;
        eval {
            $response_get = $req->get($geturl);
            if( !$response_get->is_success) {
                die("http get error!");
            }
        };
        if($@){
            $is_success = 0;
            next;
        }

        $content_get = $response_get->content;
        eval {
            $jsonResponse = JSON->new->utf8->decode( $content_get);
        };
        if($@) {
            $is_success = 0;
            next;
        }
        $is_success = 1;
    }
    
    if( !$is_success){
        $::logger->info("json decode error:$@, content:$content_get");
        return (2, "json decode error");
    }

	if( "HASH" ne ref( $jsonResponse) || !$jsonResponse->{status} || !$jsonResponse->{msg} || !$jsonResponse->{code}) 
    {
        $::logger->info( "getdata error:illegal json format");
        return ( 3, "getdata error:illegal json format");
    }
    if( $jsonResponse->{status} eq "succ") {
        if( 'all server ok' eq $jsonResponse->{msg}) {
            return ( 0, "ok");
        } 
        else {
           return ( -1, $jsonResponse->{msg});
        }
    } 
    else {
        return ( $jsonResponse->{code}, $jsonResponse->{msg});
    }
}

sub process_check_tools {
	my ($section) = @_;

	my $server 		= get_section_value( $section, "server", "");
	my $port 		= get_section_value( $section, "port", "");
	my $username 	= get_section_value( $section, "username", "");
	my $password 	= get_section_value( $section, "password", "");
	my $status_path = get_section_value( $section, "status_path", "");
	my $time 		= get_section_value( $section, "time", 360);
	my $passive 	= get_section_value( $section, "passive", 1);

	my ($code, $result) = _connect_to_ftp_and_get_file( $server, $port, $passive, $username, $password, $status_path, $AppPath."/remote_check_tools.status");
	if ($code != 0) {
		return ($code, $result);
	}

	my $last_check;
	open(F_STATUS, $AppPath."/remote_check_tools.status") or return (-4, "open status file error");
	my $content = <F_STATUS>;
	$content =~ s/^\s+//;
	$content =~ s/\s+$//;

	if ($content !~ /^\d+$/) {
		close F_STATUS;
		return (-5, "status file format error");
	}
	$last_check = int($content);

	if(time() - $last_check>$time) {
		close F_STATUS;
		return (-6, "last_update:".strftime( "%Y-%m-%d %H:%M:%S", localtime( $last_check)));
	}

	$content = "";
	while(<F_STATUS>) {
		$content .= $_;
	}
	close F_STATUS;

	my $my_code = 0;
	my $my_result = "";

	my $status_ini = load_ini_from_buffer($content);
	for (@{$status_ini}) {
		my $sec = $_;

		my $name = lc($sec->{'name'});
		my $code = get_section_value($sec, "code", 0);
		my $result = get_section_value($sec, "result", "");

		if ($code != 0) {
			$my_code = -1;
			$my_result .= $name."@".$result."|";
		}
	}

	$my_result =~ s/\|$//;
	return ($my_code, $my_result);
}

sub process_sms_report {
	my ($section) = @_;

	my %sms_report_info;
	$sms_report_info{'sendurl'} = get_section_value($section, "sendurl", "");

	my %dm;
	my $duty_list = get_section_value($section, "duty", "");
	
	{
		my @dl = split( /,/, $duty_list);
		for( @dl) {
			my ($name, $phone) = split(/\s+/, $_);
			$dm{$name} = $phone;
		}
	}
	$sms_report_info{'duty'} = \%dm;
	my @arPhones;
	$sms_report_info{'phones'} = \@arPhones;


	my @phs = split(/,/, get_section_value($section, "phones", ""));
	for(@phs) {
		next if /^\s*$/;

		my $p = $_;
		$p =~ s/^\s+//;
		$p =~ s/\s+$//;

		push @{$sms_report_info{'phones'}}, $p;
	}

	$sms_report = \%sms_report_info;

	return (0, "");
}

sub get_remain
{
	return get_remain_new();
	my ($code, $content) = request_url("http://202.85.214.57:8089/API/GET/GetBalance.aspx?uid=lykf&pwd=131105", []);

	if ($code == -1) {
		$::logger->warn( "get_duty fail: $content");
		return "check_sms_channel unknown error!";
	}

	if ($code == -99) {
		$::logger->warn( "get_duty fail: $content");
		return "check_sms_channel account or password error!";
	}

	if ($content =~ /<Balance>(.+?)<\/Balance>/i)
	{
		return $1;
	}

	return "check_sms_channel $content!";
}

sub get_remain_new() {
	my $url = "http://service.ly.ta.cn/index.php?action=sms&operate=balance&sign=889201356e0624ce92553bd18ab6ba6b";
	my( $code, $content) = request_url( $url, []);
	if ($code != 0) {
		$::logger->warn( "get_remain fail: $content");
		return "check_sms_channel unknown error!";
	}
	my $jsonResponse;
	eval {
		$jsonResponse = JSON->new->utf8->decode( $content);
	};
	if( $@) {
		$::logger->info( "get_remain json_decode error: $@   content:$content ");
		return "get_remain json_decode error";
	}
	if( $jsonResponse->{code} != 0) {
		$::logger->warn( "get sms balance error:".$jsonResponse->{msg});
		return "get sms balance error";
	}
	return  $jsonResponse->{result};
}

sub check_sms_channel
{
	my ($section) = @_;

	# my $duration = get_section_value($section, "duration",  60*10);
	my $min_remain = get_section_value($section, "min_remain", 1000);
	
	
	# my $now = time();
	$remain = get_remain();
	if($min_remain !~ /\d+/){
		$::logger->info( "ERROR confing min_remain is not number" );
		return (-1, "confing min_remain($min_remain) is not number");
	}
	if($remain =~ /^\d+$/){
		if($remain < $min_remain){
			# $::logger->info( "ERROR Waiting minimum number of SMS is $remain!" );
			$::logger->info( "Warning Now only $remain SMS!" );
			return (-1, "Warning Now only $remain SMS!");
		}else{
			$::logger->info( "the number of SMS is $remain!" );
			return (0, "the number of SMS is $remain!");
		}
	}else{
		$::logger->info( "ERROR current sms get wrong is $remain!" );
		return (-1, "ERROR current sms get wrong is $remain!");
	}
}


sub report_sms
{
	my ($msg) = @_;

	return unless length($msg)>0 && defined($sms_report) && length($sms_report->{'sendurl'})>0 && @{$sms_report->{'phones'}}>0;
	
	my $tmNow = time();

	my $g_need_remain = 0;
	my $sms_sign = ""; #【龙印客服】
	my $max_sms_len = 10000;

	if ($g_need_remain)
	{
		my $remain = get_remain();
		$msg = sprintf( "sendtime:%s|remain:%s|%s\r\n%s", strftime( "%Y-%m-%d %H:%M:%S", localtime( $tmNow)), $remain, $msg, $::selecturl);
	}
	else
	{
		$msg = sprintf( "sendtime:%s|%s\r\n%s", strftime( "%Y-%m-%d %H:%M:%S", localtime( $tmNow)), $msg, $::selecturl);
	}
    

	my $dm = get_duty();
	$msg = uri_escape( $msg);
	
	my $sign = "";
	if (length($sms_sign) > 0)
	{
		$sign = uri_escape($sms_sign);
	}

	for( @{$sms_report->{'phones'}}) {
		my $phone = $_;
		
		if( $phone =~ /__DUTY__/i && exists($sms_report->{'duty'}->{$dm})) {
			$phone = $sms_report->{'duty'}->{$dm};
		}


		my $sms_part = "";
		my $msg_send = $msg;
		do
		{
			my $len = $max_sms_len - length($sign);
			if (length($msg_send) < $len)
			{
				$len = length($msg_send);
			}

			$sms_part = substr($msg_send, 0, $len) . $sign;
			$msg_send = substr($msg_send, $len);

			my $url = $sms_report->{'sendurl'};
			$url =~ s/__PHONE__/$phone/ig;
			$url =~ s/__MSG__/$sms_part/ig;

			$::logger->info( sprintf( "send msg url:%s", $url));
			$::logger->info( sprintf( "send msg content:%s", $msg));
			
			my $browser  = LWP::UserAgent->new;
			my $response = $browser->get($url);	
			
			if( $response->is_success) {
				my $rescontent = $response->content;
				$::logger->info( "send msg succ");
			} 
			else { 
				$::logger->warn( "send msg error info:$!");
			}
		}
		while(length($msg_send)>0);
	}
}

sub report_db_restore_sms 
{
	my ($msg) = @_;
	return unless length($msg)>0 && defined($sms_report) && length($sms_report->{'sendurl'})>0 && @{$sms_report->{'phones'}}>0;
	
	my $tmNow = time();
	$msg = sprintf( "sendtime:%s|%s\r\n%s", strftime( "%Y-%m-%d %H:%M:%S", localtime( $tmNow)), $msg, $::restoredburl);
    
	my $dm = get_duty();
	$msg = uri_escape( $msg);
		
	for( @{$sms_report->{'phones'}}) {
		my $phone = $_;
		
		if( $phone =~ /__DUTY__/i && exists($sms_report->{'duty'}->{$dm})) {
			$phone = $sms_report->{'duty'}->{$dm};
		}

		my $url = $sms_report->{'sendurl'};
		$url =~ s/__PHONE__/$phone/ig;
		$url =~ s/__MSG__/$msg/ig;

		$::logger->info( sprintf( "send msg url:%s", $url));

		my $browser  = LWP::UserAgent->new;
		my $response = $browser->get($url);	
		
		if( $response->is_success) {
			my $rescontent = $response->content;
			$::logger->info( "send msg succ");
		} 
		else { 
			$::logger->warn( "send msg error info:$!");
		}
	}
}

sub get_auth {
	my ($imei)=@_;
	my $str = Digest::MD5::md5_hex($imei);

	my $strlength = length($str);
	my $i=0;
	my $newstr='';
	my $newstr1='';
	
	while( $i < $strlength) {
		$newstr=$newstr.substr($str,$i,1);
		$newstr1=$newstr1.substr($str,$i+1,1);
		$i +=2;
	}

	my $getstr = $newstr1.'moby'.$newstr;
	return Digest::MD5::md5_hex($getstr);	
}

sub readin {
    my ($file) = @_;
    
    my $len = -s $file;
    return "" unless $len>0;

    my $f;
    open $f, $file;
    binmode $f;
    my $cont = "";
    sysread($f, $cont, $len);
    close $f;
    
    return $cont;
}


sub load_ini_from_buffer {
    my ($buffer) = @_;
    
    my @lines = split(/\r?\n/, $buffer);
    
	my @ret;
	my $section_name = "";
	my $kvs;

	for( @lines) {
		my $line = $_;
		next if $line=~ /^\s*$/ or $line =~ /^\s*\#/;

		$line =~ s/^\s+//;
		$line =~ s/\s+$//;

		if ($line =~ /^\[([^\]]+)\]$/) {
			my $tmp_name = $1;
			$tmp_name =~ s/^\s+//;
			$tmp_name =~ s/\s+$//;

			if (length($section_name) > 0) {
				my %ini_info;
				$ini_info{'name'} = $section_name;
				$ini_info{'kvs'} = $kvs;

				push @ret, \%ini_info;
			}

			my @arKvs;
			$kvs = \@arKvs;
			$section_name = $tmp_name;
		}
		elsif ($line =~ /^([^=]+)=(.*)$/){
			my $key = $1;
			my $value = $2;

			$key =~ s/^\s+//;
			$key =~ s/\s+$//;

			$value =~ s/^\s+//;
			$value =~ s/\s+$//;

			if (length($section_name) > 0) {
				my %kv;
				$kv{'key'} = $key;
				$kv{'value'} = $value;

				push @{$kvs}, \%kv;
			}
		}
	}

	if (length($section_name) > 0) {
		my %ini_info;
		$ini_info{'name'} = $section_name;
		$ini_info{'kvs'} = $kvs;

		push @ret, \%ini_info;
	}

	return \@ret;
}

sub compress_file {
	my ( $src_file, $dst_file) = @_;
	
	my $dest = compress( readin( $src_file), Z_BEST_COMPRESSION);
	
	open( F_ZLIB_FILE, ">$dst_file") or die "can't create dst file $dst_file";
	binmode F_ZLIB_FILE;
	print F_ZLIB_FILE $dest;
	close F_ZLIB_FILE;
	
	return 1;
}

sub load_ini {
	my ($file) = @_;
    
    return load_ini_from_buffer(readin($file));
}

sub get_section_value {
	my ($section, $key, $default_value) = @_;

	for (@{$section->{'kvs'}}) {
		my $kv = $_;
		
		if (lc($kv->{'key'}) eq lc($key)) {
			if (length($kv->{'value'})>0) {
				return $kv->{'value'};
			}
		
			return defined( $default_value) ? $default_value : "";
		}
	}

	return defined( $default_value) ? $default_value : "";
}