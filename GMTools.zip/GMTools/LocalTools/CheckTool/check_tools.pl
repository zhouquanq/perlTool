#!/opt/ActivePerl-5.14/bin/perl
use strict;
use warnings;
use Proc::Daemon;

use Time::HiRes qw( usleep );
use LWP::UserAgent;
use URI::Escape;
use Digest::MD5 qw(md5 md5_hex);
use IO::Socket;
use DBI;
use Net::FTP;
use Encode; 
use FindBin;
use Compress::Zlib;
use File::Path qw(make_path remove_tree);
use Archive::Zip qw( :ERROR_CODES :CONSTANTS );

Proc::Daemon::Init;

my $AppPath = $FindBin::Bin;

my $status_file = shift(@ARGV);
if (!defined($status_file) || length($status_file) <= 0) {
	die "perl -w check_tools.pl path_of_status_file";
}

my %tag_process = (
	'sms_report'	=> \&process_sms_report,
	'status_file'	=> \&process_status_file,
	'sqlserver'		=> \&process_sqlserver,
	'ftp_server'	=> \&process_ftp_server,
	'flow_check'	=> \&process_flow_check,
	'socket_server' => \&process_socket_server,
	'check_tools'	=> \&process_check_tools,
);

my $sms_report;

my $continue = 1;
$SIG{TERM} = sub { $continue = 0 };

$|=1;
while($continue)
{
	run();
	sleep(60);
}

sub run
{
	$sms_report = undef;

	my $tmNow = time();
	print "now: ", format_time($tmNow),"\n";

	my $output = time() . "\n";
	my $error_msg = "";

	my $cfg_ini = load_ini($AppPath . "/check_tools.cfg");
	for (@{$cfg_ini})
	{
		my $section = $_;

		my $name = lc($section->{'name'});
		$name =~ s/^\s+//;
		$name =~ s/\s+$//;

		next unless exists $tag_process{$name};

		my $func = $tag_process{$name};

		my $item_name = get_section_value($section, "name", "");

		print "\t processing $name => $item_name ... ";
		my ($code, $result) = &$func($section);
		if (length($item_name)>0 && defined($code)) {
			$output .= "[$item_name]\n";
			$output .= "code=$code\n";
			$output .= "result=$result\n";

			if ($code != 0) {
				$error_msg .= "$item_name@" . $result . "|";
			}
		}
		print "done.\n";
	}

	open F_OUTPUT, ">$status_file" or die "can't write status output file: $status_file";
	print F_OUTPUT $output;
	close F_OUTPUT;

	#print $output;

	$error_msg =~ s/\|$//;
	if($error_msg !~ /^\s*$/)
	{
		print "************************************************\n";
		print "error!!! \n";
		print "\t" . $error_msg, "\n";
		print "************************************************\n";
		report_sms($error_msg);
	}
}

sub process_status_file
{
	my ($section) = @_;

	my $file = get_section_value($section, "file", "");
	my $time = get_section_value($section, "time", 360);

	if (length($file)<=0 || ! -f $file) {
		return (-1, "file not found!");
	}
	
	my $cont = "";
	my $count = 5;
	my $tryCount = 0;
	while($tryCount<$count)
	{
		$cont = readin($file);
		last if $cont =~ /^\s*\d+\s*$/;
		
		sleep(2);
		$tryCount ++;
		$cont = "";
	}
	
	if (length($cont)<=0)
	{
		return (-1, "err, status file is empty");
	}
	
	my $tm = int($cont);

	if (time()-$tm>$time) {
		return (-1, "err, last_update:".format_time($tm));
	}

	return (0, "ok");
}

sub process_sqlserver
{
	my ($section) = @_;

	my $server = get_section_value($section, "server", "");
	my $username = get_section_value($section, "username", "");
	my $password = get_section_value($section, "password", "");

	my $dbs = "dbi:ODBC:DRIVER={SQL Server};SERVER={$server}";
	my $dbh = DBI->connect($dbs, $username, $password);

	if (defined($dbh))
	{
		$dbh->disconnect;
		return (0, "ok");
	}

	return (-1, "connect to db error");
}

sub process_ftp_server
{
	my ($section) = @_;

	my $server = get_section_value($section, "server", "");
	my $port = get_section_value($section, "port", "");
	my $username = get_section_value($section, "username", "");
	my $password = get_section_value($section, "password", "");

	my $ftp = Net::FTP->new($server, Port  => $port) or return (-1, "connect to ftp error");
    $ftp->login($username, $password) or return (-2, "login to ftp error");
	$ftp->quit;

	return (0, "ok");
}

sub request_url
{
	my ($url, $http_header, $http_param)=@_;

	my $tryCount = 5;
	my $curCount = 0;
	my $bSuccess = 0;
	my $content = "";

	while(!$bSuccess && $curCount < $tryCount)
	{
		my $browser    = new LWP::UserAgent;
		$browser->agent("NokiaN72/ 5.0741.4.0.1 Series60/2.8 Profile/MIDP-2.0 Configuration/CLDC-1.1");
		$browser->default_header(@$http_header);
		my $response = $browser->post($url,$http_param,'Content_Type' => 'application/x-www-form-urlencoded');  
		$bSuccess = $response->is_success;
		if (!$bSuccess)
		{
			#print $url,"\n";
			#print $response->content;
		}
		$content = $response->content;
		$curCount ++;
	}

	if($bSuccess)
	{ 
		return (0, encode("gb2312", decode("utf-8", $content)));
	} 

	return 	(-1, encode("gb2312", decode("utf-8", $content)));
}


sub process_flow_check
{
	my ($section) = @_;

	my $url = get_section_value($section, "url", "");
	my $pubs = get_section_value($section, "pubs", "");
	my $imei = get_section_value($section, "imei", "");
	my $sdk = get_section_value($section, "sdk", "");
	my $username = get_section_value($section, "username", "");
	my $password = get_section_value($section, "password", "");

	for(split(/,/, $pubs))
	{
		next if /^\s*$/;

		my $pub = $_;
		$pub =~ s/^\s+//;
		$pub =~ s/\s+$//;

		my $moby_auth=get_auth($imei);
		my @http_header=
		(
			'moby_auth'=>$moby_auth,
			'moby_imei'=>$imei,
			'moby_pb'=>$pub,
			'moby_sdk'=>$sdk,
			'moby_op'=>'op',
			'moby_ua'=>'ua',
			'moby_bv'=>'bv',
			'moby_sv'=>'15071',
		);

		my %http_param = (
			'username' =>$username,
			'userpassword'=>$password,
		);

		my ($code, $content) = request_url($url, \@http_header, \%http_param);

		if ($code != 0) {
			print "$content";
			return (-1, "autoupdate_url $pub: error");
		}

		my @ret_params = split(/\|/, $content);
		if ($ret_params[0] != 0) {
			return (-2, "autoupdate return error $pub :" . $ret_params[0]);
		}

		my $account_server_url = $ret_params[1];
		my $pay_url = $ret_params[2];

		($code, $content) = request_url($pay_url."?payparam=cardtypelist", \@http_header, \%http_param);
		if ($code != 0) {
			print "$pay_url : $content";
			return (-3, "pay_url $pub: error");
		}
		

		($code, $content) = request_url($account_server_url."?gameparam=gamelist", \@http_header, \%http_param);
		if ($code != 0) {
			return (-3, "account_server_url $pub: error");
		}
		
		@ret_params = split(/\|/, $content);
		if ($ret_params[0] != 0) {
			return (-2, "gamelist return error $pub :" . $ret_params[0]);
		}

		next unless @ret_params>= 3;
		
		my $bNewProto = 0;
		if ($ret_params[2]=~/^((\d+),?)*$/)
		{
			$bNewProto = 1;
		}
		
		if ($bNewProto)
		{
			my $i=0;
			for($i=3; $i<@ret_params; $i++)
			{
				my $item = $ret_params[$i];
				my @server_param = split(/,/, $item);
				shift(@server_param);
				if (@server_param == 8) 
				{
					if ($server_param[2] && $server_param[1]<10)
					{
						my $server_name = $server_param[3];
						my @game_server_ip_port = split(/:/, $server_param[6]);
						my @file_server_ip_port = split(/:/, $server_param[7]);
		
						if (@game_server_ip_port == 2 && @file_server_ip_port == 2) 
						{
							if (!connect_to($game_server_ip_port[0], $game_server_ip_port[1], 5))
							{
								return (-5, "$pub game_server ". $server_param[6] ." connect error");
							}
		
							if (!connect_to($file_server_ip_port[0], $file_server_ip_port[1], 5))
							{
								return (-5, "$pub res_server ". $server_param[7] ." connect error");
							}
						}
						else
						{
							return (-4, "server_list format error $pub: $item");
						}
					}
				}
				else
				{
					return (-4, "server_list format error $pub: $item");
				}
			}
		}
		else
		{
			my $i=0;
			for($i=2; $i<@ret_params; $i++)
			{
				my $item = $ret_params[$i];
				my @server_param = split(/,/, $item);
				shift(@server_param);
				if (@server_param == 3) 
				{
					my $server_name = $server_param[0];
					my @game_server_ip_port = split(/:/, $server_param[1]);
					my @file_server_ip_port = split(/:/, $server_param[2]);
	
					if (@game_server_ip_port == 2 && @file_server_ip_port == 2) 
					{
						if (!connect_to($game_server_ip_port[0], $game_server_ip_port[1], 5))
						{
							return (-5, "$pub game_server ". $server_param[1] ." connect error");
						}
	
						if (!connect_to($file_server_ip_port[0], $file_server_ip_port[1], 5))
						{
							return (-5, "$pub res_server ". $server_param[2] ." connect error");
						}
					}
					else
					{
						return (-4, "server_list format error $pub: $item");
					}
				}
				else
				{
					return (-4, "server_list format error $pub: $item");
				}
			}
		}
	}

	return (0, "ok");
}

sub connect_to
{
	my ($ip, $port, $tryCount) = @_;

	my $count = 0;
	while($count < $tryCount)
	{
		my $socket = IO::Socket::INET->new
					(
						PeerAddr	=> $ip,
						PeerPort	=> $port,
						Type		=> IO::Socket::SOCK_STREAM,
						Proto		=> 'tcp'
					);
		if ($socket)
		{
			return 1;
		}

		$count ++;
		sleep(3);
	}

	return 0;
}

sub process_socket_server
{
	my ($section) = @_;

	my $server = get_section_value($section, "server", "");
	my $port = get_section_value($section, "port", "");

	my $socket = IO::Socket::INET->new
									(
										PeerAddr	=> $server,
										PeerPort	=> $port,
										Type		=> IO::Socket::SOCK_STREAM,
										Proto		=> 'tcp'
									);
	if(!$socket)
	{
		return (-1, "connect $server:$port error");
	}
	$socket = undef;

	return (0, "ok");
}

sub _connect_to_ftp_and_get_file
{
	my ($server, $port, $passive, $username, $password, $server_path, $local_path) = @_;

	my $ftp;
	my $get_file_try_count = 0;
	my $login_try_count = 0;
	
L_CONNECT:
	{
		$ftp = 0;
		my $tryCount = 5;
		my $count = 0;
		while($count<$tryCount && !$ftp)
		{
			$ftp = Net::FTP->new($server, Port  => $port, Debug => 0, Passive => $passive);
		
			if(!$ftp)
			{
				sleep(3);
			}
			$count++;
		}
	}
	
	if (!$ftp)
	{
		return (-1, "connect to ftp error");
	}
	
L_LOGIN:
	{
		my $tryCount = 5;

		while($login_try_count<$tryCount)
		{
			my $bOk = 0;
			eval
			{
				if($ftp->login($username, $password))
				{
					$bOk = 1;
				}
			};
			if ($bOk)
			{
				last;
			}
			sleep(3);
			$login_try_count ++;
			goto L_CONNECT;
		}
		
		if($login_try_count>=$tryCount)
		{
			return (-2, "login to ftp error");
		}
	}
	
  
L_GETFILE:
	{
		my $tryCount = 5;
		
		while($get_file_try_count<$tryCount)
		{
			my $bOk = 0;
			eval
			{
				if ($ftp->get($server_path, $local_path))
				{
					$bOk = 1;
				}
			};
			if ($bOk)
			{
				return (0, "ok");
			}
			sleep(3);
			$get_file_try_count++;
			goto L_CONNECT;
		}
	}

	return (-3, "get status file error");
}

sub process_check_tools
{
	my ($section) = @_;

	my $server = get_section_value($section, "server", "");
	my $port = get_section_value($section, "port", "");
	my $username = get_section_value($section, "username", "");
	my $password = get_section_value($section, "password", "");
	my $status_path = get_section_value($section, "status_path", "");
	my $time = get_section_value($section, "time", 360);
	my $passive = get_section_value($section, "passive", 1);

	my ($code, $result) = _connect_to_ftp_and_get_file($server, $port, $passive, $username, $password, $status_path, $AppPath."/remote_check_tools.status");
	if ($code != 0)
	{
		return ($code, $result);
	}

	my $last_check;
	open(F_STATUS, $AppPath."/remote_check_tools.status") or return (-4, "open status file error");
	my $content = <F_STATUS>;
	$content =~ s/^\s+//;
	$content =~ s/\s+$//;

	if ($content !~ /^\d+$/) {
		close F_STATUS;
		return (-5, "status file format error");
	}
	$last_check = int($content);

	if(time() - $last_check>$time)
	{
		close F_STATUS;
		return (-6, "last_update:".format_time($last_check));
	}

	$content = "";
	while(<F_STATUS>)
	{
		$content .= $_;
	}
	close F_STATUS;

	my $my_code = 0;
	my $my_result = "";

	my $status_ini = load_ini_from_buffer($content);
	for (@{$status_ini})
	{
		my $sec = $_;

		my $name = lc($sec->{'name'});
		my $code = get_section_value($sec, "code", 0);
		my $result = get_section_value($sec, "result", "");

		if ($code != 0) {
			$my_code = -1;
			$my_result .= $name."@".$result."|";
		}

	}

	$my_result =~ s/\|$//;
	return ($my_code, $my_result);
}

sub process_sms_report
{
	my ($section) = @_;

	my %sms_report_info;
	$sms_report_info{'sendurl'} = get_section_value($section, "sendurl", "");

	my @arPhones;
	$sms_report_info{'phones'} = \@arPhones;


	my @phs = split(/,/, get_section_value($section, "phones", ""));
	for(@phs)
	{
		next if /^\s*$/;

		my $p = $_;
		$p =~ s/^\s+//;
		$p =~ s/\s+$//;

		push @{$sms_report_info{'phones'}}, $p;
	}

	$sms_report = \%sms_report_info;

	return (0, "");
}

sub report_sms
{
	my ($msg) = @_;
#return 1;

	return unless length($msg)>0 && defined($sms_report) && length($sms_report->{'sendurl'})>0 && @{$sms_report->{'phones'}}>0;

	$msg = uri_escape($msg);
	for(@{$sms_report->{'phones'}})
	{
		my $phone = $_;

		my $url = $sms_report->{'sendurl'};
		$url =~ s/__PHONE__/$phone/ig;
		$url =~ s/__MSG__/$msg/ig;

		my $browser  = LWP::UserAgent->new;
		my $response = $browser->get($url);	
	}
}

sub get_auth
{
	my ($imei)=@_;
	my $str = Digest::MD5::md5_hex($imei);

	my $strlength = length($str);
	my $i=0;
	my $newstr='';
	my $newstr1='';
	while($i<$strlength)
	{
		$newstr=$newstr.substr($str,$i,1);
		$newstr1=$newstr1.substr($str,$i+1,1);
		$i +=2;
	}

	my $getstr = $newstr1.'moby'.$newstr;
	return Digest::MD5::md5_hex($getstr);	
}

sub calc_md5
{
	my ($file) = @_;
	
	my $ctx = Digest::MD5->new;
	open(FILE_MD5, $file) or die "can't open file for calc md5: $file";
	$ctx->addfile(*FILE_MD5);

	my $md5 = $ctx->hexdigest;
	close(FILE_MD5);

	return $md5;
}

sub readin
{
    my ($file) = @_;
    
    my $len = -s $file;
    return "" unless $len>0;

    my $f;
    open $f, $file;
    binmode $f;
    my $cont = "";
    sysread($f, $cont, $len);
    close $f;
    
    return $cont;
}


sub load_ini_from_buffer
{
    my ($buffer) = @_;
    
    my @lines = split(/\r?\n/, $buffer);
    
	my @ret;
	my $section_name = "";
	my $kvs;

	for(@lines)
	{
		my $line = $_;
		next if $line=~ /^\s*$/ or $line =~ /^\s*\#/;

		$line =~ s/^\s+//;
		$line =~ s/\s+$//;

		if ($line =~ /^\[([^\]]+)\]$/) {
			my $tmp_name = $1;
			$tmp_name =~ s/^\s+//;
			$tmp_name =~ s/\s+$//;

			if (length($section_name) > 0) {
				my %ini_info;
				$ini_info{'name'} = $section_name;
				$ini_info{'kvs'} = $kvs;

				push @ret, \%ini_info;
			}

			my @arKvs;
			$kvs = \@arKvs;
			$section_name = $tmp_name;
		}
		elsif ($line =~ /^([^=]+)=(.*)$/){
			my $key = $1;
			my $value = $2;

			$key =~ s/^\s+//;
			$key =~ s/\s+$//;

			$value =~ s/^\s+//;
			$value =~ s/\s+$//;

			if (length($section_name) > 0) {
				my %kv;
				$kv{'key'} = $key;
				$kv{'value'} = $value;

				push @{$kvs}, \%kv;
			}
		}
	}

	if (length($section_name) > 0) {
		my %ini_info;
		$ini_info{'name'} = $section_name;
		$ini_info{'kvs'} = $kvs;

		push @ret, \%ini_info;
	}

	return \@ret;
}

sub compress_file
{
	my ($src_file, $dst_file) = @_;
	
	my $dest = compress(readin($src_file), Z_BEST_COMPRESSION);
	
	open(F_ZLIB_FILE, ">$dst_file") or die "can't create dst file $dst_file";
	binmode F_ZLIB_FILE;
	print F_ZLIB_FILE $dest;
	close F_ZLIB_FILE;
	
	return 1;
}

sub load_ini
{
	my ($file) = @_;
    
    return load_ini_from_buffer(readin($file));
}

sub get_section_value
{
	my ($section, $key, $default_value) = @_;

	for (@{$section->{'kvs'}}) {
		my $kv = $_;
		
		if (lc($kv->{'key'}) eq lc($key)) {
			if (length($kv->{'value'})>0) {
				return $kv->{'value'};
			}
		
			return defined($default_value)?$default_value:"";
		}
	}

	return defined($default_value)?$default_value:"";
}

sub format_time
{
	my ($time) = @_;

	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);
	$mon++;
	$year += 1900;

	return "$year-$mon-$mday $hour:$min:$sec";
}
