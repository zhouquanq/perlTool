use strict;
use warnings;
use utf8;

use Compress::Zlib ;

package Protocol;

use Crypt::Blowfish;

use MIME::Base64;

our $ver20121200 = 20121200;
our $ver20130100 = 20130100;
our $verNewest = $ver20130100;

$::BLOWFISH_KEY = pack("H16", "noxgameformaster");
$::cipher = new Crypt::Blowfish $::BLOWFISH_KEY;

sub encodeRequest
{
	return encode(@_);
}

sub decodeRequest
{
	return decode(@_);
}

sub encodeResponse
{
	return encode(@_);
}

sub decodeResponse
{
	return decode(@_);
}

sub encodeForArr
{
	my ($params) = @_;
	my $data = "";
	if($params)
	{
		for(@$params)
		{
			$_ =~ s/&/&amp;/g;
			$_ =~ s/ /&nbsp;/g;
			$data .= $_ . " ";
		}
	}
	$data = substr($data, 0, length($data) - 1);
	#$data =~ s/\r/&#13;/g;
	#$data =~ s/\n/&#10;/g;
	
	return $data;
}

sub decodeForArr
{
	my ($data) = @_;
	#$data =~ s/&#13;/\r/g;
	#$data =~ s/&#10;/\n/g;
	
	my @params = split(/ /, $data, -1);
	for(@params)
	{
		$_ =~ s/&nbsp;/ /g;
		$_ =~ s/&amp;/&/g;
	}
	return \@params;
}

sub encodeData
{
	my ($data) = @_;
	
	utf8::encode($data);
	$data = compress($data);
	$data = encrypt($data);
	$data = pack("N", length( $data)) . $data;
	$data = encode_base64($data);
	#$data =~ s/&/&amp;/g;
	#$data =~ s/\r/&#13;/g;
	#$data =~ s/\n/&#10;/g;
		
	return $data;
}

sub encode
{
	my ($cmd, $rid, $params) = @_;
	my $data = encode2($cmd, $rid, $params);
	return encodeData($data);
}

sub encode2
{
	my ($cmd, $rid, $params) = @_;

	my $data = join ' ', map {my $str = $_; $str =~ s/&/&amp;/g; $str =~ s/ /&nbsp;/g; $str } $rid, $cmd, @$params;
	return $data;
}

sub decodeData
{
	my ($data) = @_;
	return undef if(!defined($data = decode_base64($data)));
	return undef if(!defined($data = decrypt($data)));
	return undef if(!defined($data = uncompress($data)));
	return undef if(!utf8::decode($data));
	return $data;
}

sub decode
{
	my ($data) = @_;
	return (undef) if(!defined($data = decodeData($data)));
	return decode2($data);
}

sub decode2
{
	my ($data) = @_;
	my @params = map {s/&nbsp;/ /g; s/&amp;/&/; $_ } split(/ /, $data, -1);
	my ($cmd, $rid) = parse(\@params);
	return ($cmd, $rid, \@params, $data);
}

sub parse
{
	my ($params) = @_;
	my $rid = shift(@$params);
	my $cmd = shift(@$params);
	return ($cmd, $rid);
}

sub encrypt
{
	my ($str) = @_;
	#return $str;

	my $len = length($str);
	$str = pack("N", $len) . $str;

	$len = length($str);
	my $count = int($len/8);
	$count++ if $count*8 < $len;
	my $rStr = "0";
	$str = $str . ($rStr x ($count*8 - $len));
	my $str2 = "";
	for(1 .. $count)
	{
		my $i = $_ - 1;
		my $tStr = substr($str, $i*8, 8);
		$str2 .= $::cipher->encrypt($tStr);
	}
	
	return $str2;
}

sub decrypt
{
	my ($str) = @_;
	#return $str;
	
	my $len = length($str);
	if($len % 8 != 0)
	{
		warn "impossible!";
		return undef;
	}
	
	my $count = $len/8;
	my $str2 = "";
	for(1 .. $count)
	{
		my $i = $_ - 1;
		$str2 .= $::cipher->decrypt(substr($str, $i*8, 8));
	}
	
	if(length($str2) < 4)
	{
		warn "impossible";
		return undef;
	}
	$len = unpack("N", substr($str2, 0, 4));
	
	if(length($str2) < 4 + $len)
	{
		warn "impossible";
		return undef;
	}
	$str2 = substr($str2, 4, $len);
	
	return $str2;
}

sub compress
{
	my ($str) = @_;
	#return $str;
	$str = Compress::Zlib::compress($str);
	return $str;
}

sub uncompress
{
	my ($str) = @_;
	#return $str;
	$str = Compress::Zlib::uncompress($str);
	return $str;
}


1;