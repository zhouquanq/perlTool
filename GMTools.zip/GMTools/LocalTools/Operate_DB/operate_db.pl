#!/usr/bin/perl
BEGIN {
	use FindBin;
	my ($_parent_dir) = $FindBin::Bin =~ /(.*\/).*/;
	push(@INC, $FindBin::Bin, $_parent_dir);
}
use warnings;
use strict;
use MysqlX;
use Data::Dumper;

require 'common.pl';

main();
sub main 
{
	$| = 1;
	
	my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
	my $cfg_file = "$base_file.cfg";
	die "cfg file: '$cfg_file' not exists!" unless -e $cfg_file;
		
	my $now = ts2str(time());
	print "now: $now Sleeping...\n";

	my $cfg_ini = load_ini($cfg_file);
	
	open OPERATE_DB,">> operate_db.log";
			
	foreach my $section(@{$cfg_ini}) {	
		my $section_name = $section->{'name'};
		
		my $dbinfo = get_section_value($section, 'dbinfo', '');	
		my %dbinfo = str2arr($dbinfo);
		
		my $conn = MysqlX::genConn(\%dbinfo);
		my $db = new MysqlX($conn);
		
		my $sql_select = "SELECT * FROM `specialsales`";
		my $sql_del = "DELETE FROM `specialsales`";
		my $sql_insert = "
			INSERT INTO `specialsales` (`ss_id`, `ss_protoid`, `ss_count`, `ss_timebeg`, `ss_timeend`, `ss_buylevel`, `ss_elementids`) VALUES 
			(1, 24006037, 2147483647, '2013-02-09 00:00:00', '2013-02-15 23:59:59', 0, '2,7,30,46,110,670,652,238,194,676,658,244,198,664,682,250,256,63,262,268'),
			(2, 24006038, 2147483647, '2013-02-09 00:00:00', '2013-02-15 23:59:59', 0, '2,7,30,46,110,670,652,238,194,676,658,244,198,664,682,250,256,63,262,268'),
			(3, 24006039, 2147483647, '2013-02-09 00:00:00', '2013-02-15 23:59:59', 0, '2,7,30,46,110,670,652,238,194,676,658,244,198,664,682,250,256,63,262,268'),
			(4, 24006040, 2147483647, '2013-02-09 00:00:00', '2013-02-15 23:59:59', 0, '2,7,30,46,110,670,652,238,194,676,658,244,198,664,682,250,256,63,262,268'),
			(5, 24006048, 2147483647, '2013-02-09 00:00:00', '2013-02-15 23:59:59', 0, '2,7,30,46,110,670,652,238,194,676,658,244,198,664,682,250,256,63,262,268'),
			(6, 24006049, 2147483647, '2013-02-09 00:00:00', '2013-02-15 23:59:59', 0, '2,7,30,46,110,670,652,238,194,676,658,244,198,664,682,250,256,63,262,268')		
		";
		print OPERATE_DB "--------------------- $section_name --------------------\n";
		
		print OPERATE_DB "before: \n";
		my $recordset = $db->fetchAll($sql_select);
		print OPERATE_DB Dumper($recordset);
		$db->_execute($sql_del);
		$db->_execute($sql_insert);
		print OPERATE_DB "after: \n";
		$recordset = $db->fetchAll($sql_select);
		print OPERATE_DB Dumper($recordset);		
	}

	print "Done!\n";	
	close OPERATE_DB;
}