#!/usr/bin/perl
#功能:将数据库mysqldump出来
BEGIN{
	use FindBin;
	$::APPLICATION_PATH = $FindBin::Bin;
	$::PARENT_PATH = $::APPLICATION_PATH."/../";
	push( @INC, $::APPLICATION_PATH, $::PARENT_PATH);
	chdir( $::APPLICATION_PATH);
	
	$::APPLICATION_ISRUN = 1;
	
	# 防止意外关闭
	$SIG{HUP} = sub {};
	$SIG{INT} = sub { $::APPLICATION_ISRUN = 0;};
	$| = 1;
}

use strict;
use warnings;

use File::Path qw(make_path remove_tree);
use File::Copy;

require 'srv.pl';
require 'common.pl';

main();
sub main 
{
	my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
	my $cfg_file = "$base_file.cfg";
	die "cfg file: '$cfg_file' not exists!" unless -e $cfg_file;
	
	my $cfg_ini = load_ini($cfg_file);
	
	my $olday = '';
	while ($::APPLICATION_ISRUN) {
		my $now = ts2str(time());		
		my ($day, $hour) = ($now =~ m/(\d{4}-\d+-\d+) (\d+):\d+:\d+/);
		
		if ($olday eq $day || '08' ne $hour) {							#每天8点时段计算一次
			print "[$now] Not in time. Skip.\n";
			sleep 1800;
			next;
		}
		
		foreach my $section(@{$cfg_ini}) {
			my ($dbname, $server, $port, $dbuser, $dbpass, $path);	
			
			$dbname = $section->{'name'};
			$server  = get_section_value($section, "server", "");
			$port = get_section_value($section, "port", "");
			$dbuser  = get_section_value($section, "dbuser", "");
			$dbpass  = get_section_value($section, "dbpass", "");					
			$path = get_section_value($section, "path", "");
			
			make_path($path) unless -d $path;
			
			next unless defined($dbname) && $dbname ne ''; 
			dbackup($dbname, $server, $port, $dbuser, $dbpass, $path);
			
			$now = ts2str(time());
			log2("export $dbname success");
		}
		
		$olday = $day;
	}
}

sub dbackup {
	my ($dbname, $server, $port, $dbuser, $dbpass, $path) = @_;
	
	my ($y, $m, $d, $h) = ts2str(time()) =~ m/(\d{4})-(\d+)-(\d+) (\d+):\d+:\d+/;
	my $tmp_file = $dbname."_$y$m$d$h\.sql";
	my $export_file = $path."/".$tmp_file;
	my $cmd = "mysqldump -u$dbuser -P$port -p$dbpass -h$server $dbname > $tmp_file";
	
	diecmd($cmd);
	
	move($tmp_file,$export_file);
}



################################################################################################################################
sub diecmd
{
	my ($cmd) = @_;
	print "$cmd\n";
	0 == system($cmd) or die("Fail:$cmd");
}

$SIG{__WARN__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);
   	
   	my $text_ = $text ? $text : "";
	log2('warn: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};

$SIG{__DIE__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);

	my $text_ = $text ? $text : "";
	log2('error: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};