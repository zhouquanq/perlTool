#!/usr/bin/perl
BEGIN {
	use FindBin;
	$::APPLICATION_PATH = $FindBin::Bin;
	$::PARENT_PATH = $::APPLICATION_PATH."/../";
	push( @INC, $::APPLICATION_PATH, $::PARENT_PATH, $::APPLICATION_PATH."/Mods/");
	chdir( $::APPLICATION_PATH);
}
use warnings;
use strict;
use Data::Dumper;
use POSIX;

require 'srv.pl';
use Mods::LoggerMan;
use Mods::Lib::Common;
use Mods::Lib::MysqlX;
use Mods::Lib::Config;
use Mods::Factory;

#创建日志记录对象

my $LoggerMan = Mods::LoggerMan::new({'apppath' => $::APPLICATION_PATH});
my $Logger = $LoggerMan->getLogger()->{logger};

my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
my $cfg_file = "$base_file.cfg";#配置文件
my $status_file = "$base_file.sta";#状态文件

#解析配置文件和创建数据库连接对象
my $db_conn = {};
die "cfg file: '$cfg_file' not exists!" unless -e $cfg_file;
my $cfg_obj = Mods::Lib::Config->new($cfg_file);
my $cfg = $cfg_obj->getCfg();

foreach my $item (@{$cfg}){
	my $op_name = $item->{name};
	my $db_info = $item->{kvs};
	if(scalar @{$db_info} == 2){
		foreach my $kv (@{$db_info}){
			my $db_name = $kv->{key};
			my $db_param = $kv->{value};
			$db_conn->{$op_name}->{$db_name} = MysqlX->new($db_param);
		}
	}
}

$| = 1;
my $g_continue = 1;
while($g_continue){
	#传入要分析的开始时间和结束时间
	my $startday = Mods::Lib::Common::ts2str(time() - 86400, 1);
	my $endday = Mods::Lib::Common::ts2str(time(), 1);
	# my $startday ='';
	# my $endday ='';
	
	foreach my $op_name(keys %{$db_conn}) {
		open(F_STATUS, ">$status_file") or die "can't write status output file: $status_file";
		print F_STATUS time();
		close F_STATUS;
		
		my $factory = Mods::Factory->new({'startday'=>$startday,'endday'=>$endday,'db'=>$db_conn->{$op_name},'logger'=>$Logger});

		my $mode_list = $factory->getlist();
		
		foreach my $mode (@{$mode_list}){
			$mode->run();
			# my $str = ref $mode;
			# $Logger->info("$str");
		}

		$LoggerMan->getLogger()->runTick();
	}
	
	#exit;
	sleep(60);
}
