package Mods::Business::Driver;

use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;
use DBI;

sub new{
	shift();
	my $this = shift;

	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	bless $this;
	return $this;
}

sub run{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	for(my $start_sec = Mods::Lib::Common::str2ts($startday);$start_sec <= Mods::Lib::Common::str2ts($stopday);$start_sec += 86400){
		my $theday = Mods::Lib::Common::ts2str($start_sec, 1);
		# $this->account($theday);
		$this->driver($theday);#
		$this->{logger}->info("Model driver");
	}
}

sub driver{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};	
	
	return if(Mods::Lib::Common::ts2str(time,1) ne $theday);
	
	my $info = {};
	my $total = 0;
	my $sql = "select ac.a_ua from account ac where left(ac.a_addtime, 10) = '$theday';";
	my $recordset = $sdb->fetchAll($sql);
	if(@$recordset){
		foreach my $record (@$recordset){
			my $line = $record->{a_ua};
			$total += 1;
			
			$line = lc($line);
			if($line =~ /samsung/){
				$info->{android}->{samsung} += 1;
			}elsif($line =~ /sony/){
				$info->{android}->{sony} += 1;
			}elsif($line =~ /htc/){
				$info->{android}->{htc} += 1;
			}elsif($line =~ /xiaomi/){
				$info->{android}->{xiaomi} += 1;
			}elsif($line =~ /oppo/){
				$info->{android}->{oppo} += 1;
			}elsif($line =~ /huawei/){
				$info->{android}->{huawei} += 1;
			}elsif($line =~ /lg/){
				$info->{android}->{lg} += 1;
			}elsif($line =~ /coolpad/){
				$info->{android}->{coolpad} += 1;
			}elsif($line =~ /nexus/){
				$info->{android}->{nexus} += 1;
			}elsif($line =~ /lenovo/){
				$info->{android}->{lenovo} += 1;
			}elsif($line =~ /touch/){
				$info->{android}->{touch} += 1;
			}elsif($line =~ /acer/){
				$info->{android}->{acer} += 1;
			}elsif($line =~ /nubia/){
				$info->{android}->{nubia} += 1;
			}elsif($line =~ /meizu/){
				$info->{android}->{meizu} += 1;
			}elsif($line =~ /zte/){
				$info->{android}->{zte} += 1;
			}elsif($line =~ /acer/){
				$info->{android}->{acer} += 1;
			}elsif($line =~ /vivo/){
				$info->{android}->{vivo} += 1;
			}elsif($line =~ /asus/){
				$info->{android}->{asus} += 1;
			}elsif($line =~ /iphone/){
				$info->{ios}->{iphone} += 1;
			}elsif($line =~ /winpone/){
				$info->{wp}->{winpone} += 1;
			}else{
				$info->{android}->{other} += 1;
			}
		}
	}
	
	my $row = undef;
	foreach my $type (keys %$info){
		foreach my $driver (keys %{$info->{$type}}){
			my $num = $info->{$type}->{$driver};
			my $rate = sprintf "%0.4f",$num/$total;
			$rate =~ s/,//g;
			$row .= "('$theday','$type','$driver',$num,$rate),";
		}
	}
	
	my $field = "(`theday`,`type`,`driver`,`num`,`rate`)";
	
	if($row && $row =~ s/,$//){
		my $sql_delete = "delete from meta_driver where theday = '$theday';";
		$gas->_execute($sql_delete);
		$this->{logger}->info($sql_delete);
		
		my $sql_insert = "insert into meta_driver $field values $row;";
		$gas->_execute($sql_insert);
		$this->{logger}->info($sql_insert);
	}
}

1;
