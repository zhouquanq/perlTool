package Mods::Business::FirstPay;
use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;

sub new{
	shift();
	my $this = shift;

	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	bless $this;
	return $this;
}

sub run{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	for(my $start_sec = Mods::Lib::Common::str2ts($startday);$start_sec <= Mods::Lib::Common::str2ts($stopday);$start_sec += 86400){
		my $theday = Mods::Lib::Common::ts2str($start_sec, 1);
		$this->firstpubpay($theday);
		$this->{logger}->info("Model firstpubpay");
	}
}

sub firstpubpay{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	my $sql = undef;
	my $recordset = [];
	
	my $prev_pay = {};
	my $cur_pay = {};
	
	$sql = "select pr.pr_channel, pr.pr_serverid, pr.pr_playerid, pr.pr_pub from payrecord pr 
			where left(pr.pr_addtime, 10) < '$theday' and pr.pr_success = 1 and pr.pr_money > 0";		
	$recordset = $sdb->fetchAll($sql);
	foreach my $record(@{$recordset}){
		my $opkey = $record->{'pr_channel'};
		my $serverid = $record->{'pr_serverid'};
		my $playerid = $record->{'pr_playerid'};
		my $pubkey = $record->{'pr_pub'};
		$prev_pay->{$opkey}->{$serverid}->{$playerid} = $pubkey;
	}

	$sql = "select pr.pr_channel, pr.pr_serverid, pr.pr_playerid, pr.pr_pub from payrecord pr 
			where left(pr.pr_addtime, 10) = '$theday' and pr.pr_success = 1 and pr.pr_money > 0";
		
	$recordset = $sdb->fetchAll($sql);
	foreach my $record(@{$recordset}){
		my $opkey = $record->{'pr_channel'};
		my $serverid = $record->{'pr_serverid'};
		my $playerid = $record->{'pr_playerid'};
		my $pubkey = $record->{'pr_pub'};
		$cur_pay->{$opkey}->{$serverid}->{$playerid} = $pubkey;
	}
	my $pub_firstpay = {};
	foreach my $opkey (keys %{$cur_pay}){
		foreach my $serverid (keys %{$cur_pay->{$opkey}}){
			foreach my $playerid (keys %{$cur_pay->{$opkey}->{$serverid}}){
				unless (exists $prev_pay->{$opkey}->{$serverid}->{$playerid}){
					my $pubkey = $cur_pay->{$opkey}->{$serverid}->{$playerid};
					$pub_firstpay->{$opkey}->{$serverid}->{$pubkey} += 1;
				}
			}
		}
	}
	
	my $row = undef;
	foreach my $opkey (keys %{$pub_firstpay}){
		foreach my $serverid (keys %{$pub_firstpay->{$opkey}}){
			foreach my $pubkey (keys %{$pub_firstpay->{$opkey}->{$serverid}}){
				my $num = $pub_firstpay->{$opkey}->{$serverid}->{$pubkey};
				$row .= "('$theday',$serverid,$num,'$opkey','$pubkey'),";
			}
		}
	}
	
	my $field = "(`theday`,`serverid`,`num`,`pub`,`op`)";

	if($row && $row =~ s/,$//){
		my $delete_sql = "DELETE FROM meta_firstpay WHERE theday = '$theday'";
		my $insert_sql = "INSERT INTO meta_firstpay $field VALUES $row";
		$gas->_execute($delete_sql);
		$gas->_execute($insert_sql);
		$this->{logger}->info($delete_sql);
		$this->{logger}->info($insert_sql);
	}
}
1;
