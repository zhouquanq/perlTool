package Mods::Business::Level;

use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;
use DBI;

sub new{
	shift();
	my $this = shift;

	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	bless $this;
	return $this;
}

sub run{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	for(my $start_sec = Mods::Lib::Common::str2ts($startday);$start_sec <= Mods::Lib::Common::str2ts($stopday);$start_sec += 86400){
		my $theday = Mods::Lib::Common::ts2str($start_sec, 1);
		# $this->account($theday);
		$this->level($theday);#等级分布
		$this->{logger}->info("Model level");
		
		$this->viplevel($theday);#vip等级分布
		$this->{logger}->info("Model level");
	}
}

sub level{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};	
	
	return if(Mods::Lib::Common::ts2str(time,1) ne $theday);
	
	my $info = {};
	
	my $sql = "select slc.serverid, slc.slc_host, slc.slc_port, slc.slc_odbc, slc.slc_user, slc.slc_pass from serverlistconfig slc
				inner join serverlist sl on sl.serverid = slc.serverid
				where sl.serverenable = 1";
	my $recordset = $gas->fetchAll($sql);
	if(@$recordset){
		foreach my $record (@$recordset){
			my $serverid = $record->{serverid};
			
			$info->{$serverid}->{host} = $record->{slc_host};
			$info->{$serverid}->{port} = $record->{slc_port};
			$info->{$serverid}->{db} = $record->{slc_odbc};
			$info->{$serverid}->{user} = $record->{slc_user};
			$info->{$serverid}->{pass} = $record->{slc_pass};
		}
	}
	
	my $ret = {};
	eval{
		foreach my $serverid (keys %{$info}){
			my $host = $info->{$serverid}->{host};
			my $port = $info->{$serverid}->{port};
			my $db = $info->{$serverid}->{db};
			my $user = $info->{$serverid}->{user};
			my $pass = $info->{$serverid}->{pass};
		
			my $dbi=DBI->connect("DBI:mysql:database=$db:$host:$port",$user,$pass);  #连接数据库
			# print "connect database success!\n";

			$dbi->do("SET character_set_client='utf8'");
			$dbi->do("SET character_set_connection='utf8'");
			$dbi->do("SET character_set_results='utf8'");
			
			my $sql = "select ch.char_level, count(*) as num, format(count(*)/(select count(*) from `character`),4) as ave from `character` ch group by ch.char_level";
			
			my $results = $dbi->prepare($sql);
			$results->execute();
			while(my $sz_refhash = $results->fetchrow_hashref()){
				my $level = $sz_refhash->{char_level};
				$ret->{$serverid}->{$level}->{num} = $sz_refhash->{num};
				$ret->{$serverid}->{$level}->{ave} = $sz_refhash->{ave};
			}
			
			$dbi->disconnect();  #断开连接
		}
	};
	if($@){
		$this->{logger}->info("db connect false!");
	}
	
	my $row = undef;
	foreach my $serverid(keys %$ret){
		foreach my $level (keys %{$ret->{$serverid}}){
			my $num = $ret->{$serverid}->{$level}->{num};
			my $ave = $ret->{$serverid}->{$level}->{ave};
			
			$row .= "('$theday',$serverid,$level,$num,$ave),";
		}
	}
	
	my $field = "(`theday`,`serverid`,`level`,`num`, `ave`)";
	
	if($row && $row =~ s/,$//){
		my $sql_delete = "delete from meta_level where theday = '$theday';";
		$gas->_execute($sql_delete);
		$this->{logger}->info($sql_delete);
		
		my $sql_insert = "insert into meta_level $field values $row;";
		$gas->_execute($sql_insert);
		$this->{logger}->info($sql_insert);
	}
}

sub viplevel{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};	
	
	return if(Mods::Lib::Common::ts2str(time,1) ne $theday);
	
	my $data_ingot = {};
	
	my $sql = "select ibr.serverid,ibr.char_id,sum(ibr.ibr_ingot) as num from ingotbuyrecord ibr where left(ibr.ibr_time,10) = '$theday' and ibr.ibr_ingot > 0
			group by ibr.char_id";
	
	$this->{logger}->info($sql);
	my $recordset = $sdb->fetchAll($sql);
	foreach my $record(@$recordset){
		my $serverid = $record->{'serverid'};
		my $char_id = $record->{'char_id'};
		my $num = $record->{'num'};
		
		$data_ingot->{$serverid}->{$char_id} = $num;
	}
	
	my $info = {};
	
	$sql = "select slc.serverid, slc.slc_host, slc.slc_port, slc.slc_odbc, slc.slc_user, slc.slc_pass from serverlistconfig slc
				inner join serverlist sl on sl.serverid = slc.serverid
				where sl.serverenable = 1";
	$recordset = $gas->fetchAll($sql);
	if(@$recordset){
		foreach my $record (@$recordset){
			my $serverid = $record->{serverid};
			
			$info->{$serverid}->{host} = $record->{slc_host};
			$info->{$serverid}->{port} = $record->{slc_port};
			$info->{$serverid}->{db} = $record->{slc_odbc};
			$info->{$serverid}->{user} = $record->{slc_user};
			$info->{$serverid}->{pass} = $record->{slc_pass};
		}
	}
	
	my $ret = {};
	eval{
		foreach my $serverid (keys %{$info}){
			my $host = $info->{$serverid}->{host};
			my $port = $info->{$serverid}->{port};
			my $db = $info->{$serverid}->{db};
			my $user = $info->{$serverid}->{user};
			my $pass = $info->{$serverid}->{pass};
		
			my $dbi=DBI->connect("DBI:mysql:database=$db:$host:$port",$user,$pass);  #连接数据库
			# print "connect database success!\n";

			$dbi->do("SET character_set_client='utf8'");
			$dbi->do("SET character_set_connection='utf8'");
			$dbi->do("SET character_set_results='utf8'");
			
			my $sql = "select ch.char_viplevel, count(*) as num, format(count(*)/(select count(*) from `character`),4) as ave from `character` ch group by ch.char_viplevel";
			
			my $results = $dbi->prepare($sql);
			$results->execute();
			while(my $sz_refhash = $results->fetchrow_hashref()){
				my $level = $sz_refhash->{char_viplevel};
				$ret->{$serverid}->{$level}->{num} = $sz_refhash->{num};
				$ret->{$serverid}->{$level}->{ave} = $sz_refhash->{ave};
			}
			
			my $str = join('\',\'',keys %{$data_ingot->{$serverid}});
			
			$results = $dbi->prepare("select ch.char_id,ch.char_viplevel from `character` ch where ch.char_id in ('$str');");
			$results->execute();
			while(my $sz_refhash = $results->fetchrow_hashref()){
				my $char_viplevel = $sz_refhash->{char_viplevel};
				my $char_id = $sz_refhash->{char_id};
				$ret->{$serverid}->{$char_viplevel}->{amount} += $data_ingot->{$serverid}->{$char_id};
			}
			
			$dbi->disconnect();  #断开连接
		}
	};
	if($@){
		$this->{logger}->info("db connect false!");
	}
	
	my $row = undef;
	foreach my $serverid(keys %$ret){
		foreach my $level (keys %{$ret->{$serverid}}){
			my $num = $ret->{$serverid}->{$level}->{num};
			my $ave = $ret->{$serverid}->{$level}->{ave};
			my $amount = $ret->{$serverid}->{$level}->{amount}?$ret->{$serverid}->{$level}->{amount}:0;
			
			$row .= "('$theday',$serverid,$level,$num,$ave,$amount),";
		}
		
	}
	
	my $field = "(`theday`,`serverid`,`level`,`num`, `ave`,`amount`)";
	
	if($row && $row =~ s/,$//){
		my $sql_delete = "delete from meta_viplevel where theday = '$theday';";
		$gas->_execute($sql_delete);
		$this->{logger}->info($sql_delete);
		
		my $sql_insert = "insert into meta_viplevel $field values $row;";
		$gas->_execute($sql_insert);
		$this->{logger}->info($sql_insert);
	}
}


1;
