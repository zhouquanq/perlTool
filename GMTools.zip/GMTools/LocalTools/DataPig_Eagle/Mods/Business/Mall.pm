package Mods::Business::Mall;

use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;
use DBI;

sub new{
	shift();
	my $this = shift;

	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	bless $this;
	return $this;
}

sub run{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	for(my $start_sec = Mods::Lib::Common::str2ts($startday);$start_sec <= Mods::Lib::Common::str2ts($stopday);$start_sec += 86400){
		my $theday = Mods::Lib::Common::ts2str($start_sec, 1);
		# $this->account($theday);
		$this->mall($theday);#
		$this->{logger}->info("Model mall");
	}
}

sub mall{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};	
	
	return if(Mods::Lib::Common::ts2str(time,1) ne $theday);
	
	my $info = {};
	
	my $sql = "select ibr.serverid,ibr.ibr_protoid, count(distinct ibr.char_id) as count, sum(ibr.ibr_itemcount) as num,sum(ibr.ibr_ingot) as amount,
			format(count(distinct ibr.char_id)/(select count(distinct char_id) from ingotbuyrecord where left(ibr_time,10) = '$theday' and ibr_type = 'buymallitem'),4) as rate_count
			, format(sum(ibr_itemcount)/(select sum(ibr_itemcount) from ingotbuyrecord where left(ibr_time,10) = '$theday' and ibr_type = 'buymallitem'),4) as rate_num
			 from ingotbuyrecord ibr 
			where left(ibr.ibr_time,10) = '$theday' and ibr.ibr_type = 'buymallitem'
			group by ibr.ibr_protoid";
	my $recordset = $sdb->fetchAll($sql);
	if(@$recordset){
		foreach my $record (@$recordset){
			my $serverid = $record->{serverid};
			my $ibr_protoid = $record->{ibr_protoid};
			
			$info->{$serverid}->{$ibr_protoid}->{count} = $record->{count};
			$info->{$serverid}->{$ibr_protoid}->{num} = $record->{num};
			$info->{$serverid}->{$ibr_protoid}->{amount} = $record->{amount};
			$info->{$serverid}->{$ibr_protoid}->{rate_count} = $record->{rate_count};
			$info->{$serverid}->{$ibr_protoid}->{rate_num} = $record->{rate_num};
		}
	}
	
	
	my $row = undef;
	foreach my $serverid(keys %$info){
		foreach my $protoid (keys %{$info->{$serverid}}){
			my $count = $info->{$serverid}->{$protoid}->{count};
			my $num = $info->{$serverid}->{$protoid}->{num};
			my $amount = $info->{$serverid}->{$protoid}->{amount};
			my $rate_count = $info->{$serverid}->{$protoid}->{rate_count};
			$rate_count =~ s/,//g;
			my $rate_num = $info->{$serverid}->{$protoid}->{rate_num};
			$rate_num =~ s/,//g;
			
			$row .= "('$theday',$serverid,$protoid,$count,$num,$amount,$rate_count,$rate_num),";
		}
	}
	
	my $field = "(`theday`,`serverid`,`protoid`,`count`,`num`,`amount`, `rate_count`,`rate_num`)";
	
	if($row && $row =~ s/,$//){
		my $sql_delete = "delete from meta_mall where theday = '$theday';";
		$gas->_execute($sql_delete);
		$this->{logger}->info($sql_delete);
		
		my $sql_insert = "insert into meta_mall $field values $row;";
		$gas->_execute($sql_insert);
		$this->{logger}->info($sql_insert);
	}
}

1;
