package Mods::Business::PubInfo;

use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;

sub new{
	shift();
	my $this = shift;

	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	bless $this;
	return $this;
}

sub run{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	for(my $start_sec = Mods::Lib::Common::str2ts($startday);$start_sec <= Mods::Lib::Common::str2ts($stopday);$start_sec += 86400){
		my $theday = Mods::Lib::Common::ts2str($start_sec, 1);
		$this->publevel($theday);
		$this->{logger}->info("Model publevel");
		
		$this->pubpay($theday);
		$this->{logger}->info("Model pubpay");
	}
}

# sub publevel{
	# my($this, $theday) = @_;
	
	# my $startday = $this->{startday};
	# my $stopday = $this->{endday};
	# my $sdb = $this->{db}->{sdb};
	# my $gas = $this->{db}->{gas};
	
	# my $sql = undef;
	# my $recordset = [];
	# my $row = undef;
	
	# $sql = "select pl.c_pb, pl.c_serverid, pl.char_level, count(*) as num from player pl group by pl.c_pb, pl.c_serverid, pl.char_level;"
	# $recordset = $sdb->fetchAll($sql);
	# foreach my $record (@{$recordset}){
		# my $c_pb = $record->{c_pb};
		# my $c_serverid = $record->{c_serverid};
		# my $char_level = $record->{char_level};
		# my $num = $record->{num};
		# $row .= "('$theday',$c_serverid,$c_pb,$char_level,$num)";
	# }

	# my $field = "(`theday`,`serverid`,`pub`,`level`,`num`)";
	# if($row && $row =~ s/,$//){
		# my $delete_sql = "DELETE FROM meta_publevel WHERE theday = '$startday'";
		# my $insert_sql = "INSERT INTO meta_publevel ($field) VALUES $row";
		# $gas->_execute($delete_sql);
		# $gas->_execute($insert_sql);
	# }
# }

sub publevel{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	my $nowday = Mods::Lib::Common::ts2str(time(), 1);
	return if($nowday eq $theday);
	
	my $data = {};
	# my $sql = "
		# select pl.c_serverid, pl.c_pb, pl.char_level, count(*) as num 
		# from player pl where left(pl.c_addtime, 10) = '$nowday' 
		# group by pl.c_serverid, pl.c_pb, pl.char_level
	# ";
	my $sql = "select pl.c_serverid, pl.c_pb, pl.char_level, count(*) as num 
			from loginplayer ll 
			inner join player pl on ll.serverid = pl.c_serverid and ll.playerid = pl.c_playerid
			where ll.theday = '$theday' and left(pl.c_addtime, 10) = '$theday'
			group by pl.c_serverid, pl.c_pb, pl.char_level";
	
	$this->{logger}->info($sql);
	
	my $recordset = $sdb->fetchAll($sql);
	if(scalar @{$recordset}) {
		foreach my $record (@{$recordset}){
			my $serverid = $record->{c_serverid};
			my $pub = $record->{c_pb};
			my $char_level = $record->{char_level};
			my $num = $record->{num};
			$data->{$serverid}->{$pub}->{$char_level} = $num if $char_level <= 10;
			$data->{$serverid}->{$pub}->{11} += $num if ($char_level > 10 && $char_level <= 15);
			$data->{$serverid}->{$pub}->{16} += $num if ($char_level > 15 && $char_level <= 20);
			$data->{$serverid}->{$pub}->{21} += $num if ($char_level > 20 && $char_level <= 25);
			$data->{$serverid}->{$pub}->{26} += $num if ($char_level > 25 && $char_level <= 30);
			$data->{$serverid}->{$pub}->{31} += $num if ($char_level > 30);
		}
	}
	
	my $row = undef;
	foreach my $serverid (keys %{$data}){
		foreach my $pub (keys %{$data->{$serverid}}){
			my $one = $data->{$serverid}->{$pub}->{1}?$data->{$serverid}->{$pub}->{1}:0;
			my $two = $data->{$serverid}->{$pub}->{2}?$data->{$serverid}->{$pub}->{2}:0;
			my $three = $data->{$serverid}->{$pub}->{3}?$data->{$serverid}->{$pub}->{3}:0; 
			my $four = $data->{$serverid}->{$pub}->{4}?$data->{$serverid}->{$pub}->{4}:0; 
			my $five = $data->{$serverid}->{$pub}->{5}?$data->{$serverid}->{$pub}->{5}:0; 
			my $six = $data->{$serverid}->{$pub}->{6}?$data->{$serverid}->{$pub}->{6}:0; 
			my $seven = $data->{$serverid}->{$pub}->{7}?$data->{$serverid}->{$pub}->{7}:0; 
			my $eight = $data->{$serverid}->{$pub}->{8}?$data->{$serverid}->{$pub}->{8}:0; 
			my $nine = $data->{$serverid}->{$pub}->{9}?$data->{$serverid}->{$pub}->{9}:0; 
			my $ten = $data->{$serverid}->{$pub}->{10}?$data->{$serverid}->{$pub}->{10}:0; 
			my $eleven_fifteen = $data->{$serverid}->{$pub}->{11}?$data->{$serverid}->{$pub}->{11}:0; 
			my $sixteen_twenty = $data->{$serverid}->{$pub}->{16}?$data->{$serverid}->{$pub}->{16}:0; 
			my $tone_tfive = $data->{$serverid}->{$pub}->{21}?$data->{$serverid}->{$pub}->{21}:0; 
			my $tsix_thirty = $data->{$serverid}->{$pub}->{26}?$data->{$serverid}->{$pub}->{26}:0; 
			my $thirtyup = $data->{$serverid}->{$pub}->{31}?$data->{$serverid}->{$pub}->{31}:0;
			$row .= "('$theday',$serverid,'$pub',$one,$two,$three,$four,$five,$six,$seven,$eight,$nine,$ten,$eleven_fifteen,$sixteen_twenty,$tone_tfive,$tsix_thirty,$thirtyup),";
		}
	}
	
	my $field = "(`theday`,`serverid`,`pub`,`one`,`two`,`three`,`four`,`five`,`six`,`seven`,`eight`,`nine`,`ten`,`eleven_fifteen`,`sixteen_twenty`,`tone_tfive`,`tsix_thirty`,`thirtyup`)";
	if($row && $row =~ s/,$//){
		$sql = "delete from meta_pubdata where theday = '$theday'";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
		
		$sql = "insert into meta_pubdata $field values $row";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
	}
}

sub pubpay{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	my $sql = "
		select pr.pr_channel, left(pr.pr_addtime, 10) as theday, pr.pr_originalsid as serverid, pr.pr_pub as pubkey, left(ac.a_sdk, 7) as sdk, pr.pr_maintype as paytype, count(pr.pr_playerid) as pay_count, count(distinct pr.pr_playerid) as pay_char, sum(pr.pr_money) as pay_sum 
		from payrecord pr 
		inner join account ac on ac.a_id = pr.pr_accountid
		where left(pr.pr_addtime, 10) between '$startday' and '$stopday' and pr.pr_money > 0 and pr.pr_success = 1
		group by left(pr.pr_addtime, 10), pr.pr_originalsid, pr.pr_pub, left(ac.a_sdk, 7), pr.pr_maintype, pr.pr_channel
		order by pr.pr_addtime
	";
	
	$this->{logger}->info($sql);
	
	my $recordset = $sdb->fetchAll($sql);

	my $field = "(`theday`,`serverid`,`sdk`,`pay_type`,`pay_count`,`pay_char`,`pay_sum`,`pub`,`op`)";

	my $row = undef;
	foreach my $record(@$recordset) {
		my $sdk = undef;
		if($record->{'sdk'} eq 'winphon'){
			$sdk = 'winphone8';
		}else{
			$sdk = $record->{'sdk'};
		}
		$row .= "('$record->{theday}',$record->{serverid},'$sdk','$record->{paytype}',$record->{pay_count},$record->{pay_char},$record->{pay_sum},'$record->{pubkey}','$record->{pr_channel}'),";
	}
	
	if($row && $row =~ s/,$//){
		$sql = "DELETE FROM meta_pubpay WHERE theday BETWEEN '$startday' AND '$stopday'";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
		
		$sql = "INSERT INTO meta_pubpay $field VALUES $row";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
	}
}

sub newoldpubpay{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	my $sql = undef;
	my $recordset = [];
	my $pay = {};
	my $row = undef;
	
	$sql = "select pr.pr_pub, pr.pr_serverid, pr.pr_playerid, pr.pr_money 
		from payrecord pr 
		where left(pr.pr_addtime, 10) = '$theday'
		and pr.pr_success = 1 and pr.pr_money > 0";
		
	$this->{logger}->info($sql);
	
	$recordset = $sdb->fetchAll($sql);
	foreach my $record (@{$recordset}){
		my $pr_pub = $record->{pr_pub};
		my $pr_serverid = $record->{pr_serverid};
		my $pr_playerid = $record->{pr_playerid};
		my $pr_money = $record->{pr_money};
		$pay->{$pr_serverid}->{$pr_pub}->{$pr_playerid} += $pr_money;
	}
	
	foreach my $serverid (keys %{$pay}){
		foreach my $pub (keys %{$pay->{$serverid}}){
			my $players = join(',', keys %{$pay->{$serverid}->{$pub}});
			my $old_new_pay = {};
			$sql = "select pl.c_playerid, left(pl.c_addtime, 10) as createtime from player pl where pl.c_playerid in ($players);";
			
			$this->{logger}->info($sql);
			
			$recordset = $sdb->fetchAll($sql);
			foreach my $record (@{$recordset}){
				my $c_playerid = $record->{c_playerid};
				my $createtime = $record->{createtime};
				if($createtime eq $theday){
					$old_new_pay->{$c_playerid} = 1;
				}else{
					$old_new_pay->{$c_playerid} = 0;
				}
			}
			my $new_pay = 0;
			my $new_user = 0;
			my $old_pay = 0;
			my $old_user = 0;
			foreach my $playerid (keys %{$pay->{$serverid}->{$pub}}){
				my $money = $pay->{$serverid}->{$pub}->{$playerid};
				my $index = $old_new_pay->{$playerid};
				if($index){
					$new_pay += $money;
					$new_user += 1;
				}else{
					$old_pay += $money;
					$old_user += 1;
				}
			}
			
			$row .= "('$theday',$serverid,'$pub',$new_pay,$new_user,$old_pay,$old_user),";
		}
	}
		# 
	
	my $field = "(`theday`,`serverid`,`pub`,`new_pay`,`new_user`,`old_pay`,`old_user`)";
	if($row && $row =~ s/,$//){
		my $delete_sql = "delete from meta_pubpay where theday = '$theday'";
		$this->{logger}->info($delete_sql);
		$gas->_execute($delete_sql);
		
		my $insert_sql = "insert into meta_pubpay $field values $row";
		$this->{logger}->info($insert_sql);
		$gas->_execute($insert_sql);
	}
}

1;
