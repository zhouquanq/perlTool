package Mods::Business::Account;

use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;
use Data::Dumper;

sub new{
	shift();
	my $this = shift;

	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	bless $this;
	return $this;
}

sub run{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	for(my $start_sec = Mods::Lib::Common::str2ts($startday);$start_sec <= Mods::Lib::Common::str2ts($stopday);$start_sec += 86400){
		my $theday = Mods::Lib::Common::ts2str($start_sec, 1);
		# $this->account($theday);
		$this->newaccount($theday);
		$this->{logger}->info("Model newaccount");
		
		$this->newimei($theday);
		$this->{logger}->info("Model newimei");
		
		$this->newchar($theday);
		$this->{logger}->info("Model newchar");
		
		$this->emptyaccount($theday);
		$this->{logger}->info("Model emptyaccount");
	}
}

sub newaccount{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	#新注册账号
	my $sql = "SELECT LEFT(ac.a_addtime, 10) AS theday, ac.a_firstserverid AS serverid, ac.a_pb AS pubkey, LEFT(ac.a_sdk, 7) AS sdk, COUNT(*) AS num, ac.a_channel
			FROM account ac
			WHERE LEFT(ac.a_addtime, 10) >= '$startday' AND LEFT(ac.a_addtime, 10) <= '$stopday'
			GROUP BY LEFT(ac.a_addtime, 10), ac.a_firstserverid, ac.a_pb, LEFT(ac.a_sdk, 7), ac.a_channel
			ORDER BY ac.a_addtime";
	$this->{logger}->info($sql);
	my $recordset = $sdb->fetchAll($sql);
	my $row = undef;
	foreach my $record(@$recordset) {
		my $sdk = undef;
		if($record->{'sdk'} eq 'winphon'){
			$sdk = 'winphone8';
		}else{
			$sdk = $record->{'sdk'};
		}
		$row .= "('$record->{'theday'}',$record->{'serverid'},'$sdk',$record->{'num'},'$record->{'pubkey'}','$record->{'a_channel'}'),";
	}
	
	# my $field = "`theday`,`serverid`,`pubid`,`sdk`,`num`, `opid`";
	my $field = "`theday`,`serverid`,`sdk`,`num`,`pub`,`op`";
	if($row && $row =~ s/,$//){
		$sql = "DELETE FROM meta_newaccount WHERE theday >= '$startday' AND theday <= '$stopday'";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
		
		$sql = "INSERT INTO meta_newaccount ($field) VALUES $row";
		$gas->_execute($sql);
		$this->{logger}->info($sql);
	}
}	

sub newimei{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};	
	#新注册串号数
	my $sql = "SELECT LEFT(ac.a_addtime, 10) AS theday, ac.a_firstserverid AS serverid,ac.a_pb AS pubkey, LEFT(ac.a_sdk, 7) AS sdk, COUNT(DISTINCT ac.a_imei) AS num, ac.a_channel
			FROM account ac
			WHERE LEFT(ac.a_addtime, 10) >= '$startday' AND LEFT(ac.a_addtime, 10) <= '$stopday' AND ac.a_imei NOT IN (SELECT ac.a_imei FROM account ac WHERE LEFT(ac.a_addtime, 10) < '$startday')
			GROUP BY LEFT(ac.a_addtime, 10), ac.a_firstserverid, ac.a_pb, LEFT(ac.a_sdk, 7), ac.a_channel
			ORDER BY ac.a_addtime";
			
	$this->{logger}->info($sql);
	
	my $recordset = $sdb->fetchAll($sql);
	my $row = undef;
	foreach my $record(@$recordset) {
		my $sdk = undef;
		if($record->{'sdk'} eq 'winphon'){
			$sdk = 'winphone8';
		}else{
			$sdk = $record->{'sdk'};
		}
		$row .= "('$record->{'theday'}',$record->{'serverid'},'$sdk',$record->{'num'},'$record->{'pubkey'}','$record->{'a_channel'}'),";
	}
	
	# $field = "`theday`,`serverid`,`pubid`,`sdk`,`num`, `opid`";
	my $field = "`theday`,`serverid`,`sdk`,`num`,`pub`,`op`";
	if($row && $row =~ s/,$//){
		$sql = "DELETE FROM meta_newimei WHERE theday >= '$startday' AND theday <= '$stopday'";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
		
		$sql = "INSERT INTO meta_newimei ($field) VALUES $row";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
	}
}

sub newchar{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};	
	#新注册角色
	my $sql = "SELECT LEFT(ch.c_addtime, 10) AS theday, ch.c_originalsid AS serverid, ac.a_pb AS pubkey,LEFT(ac.a_sdk, 7) AS sdk,COUNT(*) AS num, ac.a_channel
			FROM `player` ch INNER JOIN `account` ac ON  ch.a_id = ac.a_id
			WHERE LEFT(ch.c_addtime, 10) >= '$startday' AND LEFT(ch.c_addtime, 10) <= '$stopday'
			GROUP BY LEFT(ch.c_addtime, 10), ch.c_originalsid, ac.a_pb, LEFT(ac.a_sdk, 7), ac.a_channel";
			
	$this->{logger}->info($sql);
			
	my $recordset = $sdb->fetchAll($sql);
	my $row = undef;
	foreach my $record(@$recordset) {
		my $sdk = undef;
		if($record->{'sdk'} eq 'winphon'){
			$sdk = 'winphone8';
		}else{
			$sdk = $record->{'sdk'};
		}
		$row .= "('$record->{'theday'}',$record->{'serverid'},'$sdk',$record->{'num'},'$record->{'pubkey'}','$record->{'a_channel'}'),";
	}
	# $field = "`theday`,`serverid`,`pubid`,`sdk`,`num`, `opid`";
	my $field = "`theday`,`serverid`,`sdk`,`num`,`pub`,`op`";
	if($row && $row =~ s/,$//){
		$sql = "DELETE FROM meta_newchar WHERE theday >= '$startday' AND theday <= '$stopday'";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
		
		$sql = "INSERT INTO meta_newchar ($field) VALUES $row";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
	}
}

sub emptyaccount{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	#空账号-a_firstserverid = NULL
	my $sql = "SELECT LEFT(ac.a_addtime, 10) AS theday, NULL AS serverid, ac.a_pb AS pubkey, LEFT(ac.a_sdk,7) AS sdk, COUNT(*) AS num, ac.a_channel
			FROM account ac
			WHERE ac.a_id NOT IN (select p.a_id from player p) 
			AND LEFT(ac.a_addtime, 10) >= '$startday' AND LEFT(ac.a_addtime, 10) <= '$stopday'
			GROUP BY LEFT(ac.a_addtime, 10), ac.a_pb, LEFT(ac.a_sdk, 7), ac.a_channel";
			
	$this->{logger}->info($sql);
			
	my $recordset = $sdb->fetchAll($sql);
	my $row = undef;
	foreach my $record(@$recordset) {
		my $sdk = undef;
		if($record->{'sdk'} eq 'winphon'){
			$sdk = 'winphone8';
		}else{
			$sdk = $record->{'sdk'};
		}
		# $row .= "('$record->{'theday'}',".'\N'.",'$sdk',$record->{'num'},$record->{'pubkey'},$record->{'a_channel'}),";
		$row .= "('$record->{'theday'}','$sdk',$record->{'num'},'$record->{'pubkey'}','$record->{'a_channel'}'),";
	}
	
	# $field = "`theday`,`serverid`,`pubid`,`sdk`,`num`, `opid`";
	my $field = "`theday`,`sdk`,`num`,`pub`,`op`";
	if($row && $row =~ s/,$//){
		$sql = "DELETE FROM meta_emptyaccount WHERE theday >= '$startday' AND theday <= '$stopday'";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
	
		$sql = "INSERT INTO meta_emptyaccount ($field) VALUES $row";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
	}
}

# sub account{
	# my($this, $theday) = @_;
	
	# my $startday = $this->{startday};
	# my $stopday = $this->{endday};
	# my $sdb = $this->{db}->{sdb};
	# my $gas = $this->{db}->{gas};
	
	# my $sql = undef;
	# my $recordset = [];
	
	# my $reg_num = 0;
	# my $empty_reg_num = 0;
	# my $valid_reg_num = 0;
	# $sql = "select count(*) as num from account ac where left(ac.a_addtime, 10) = '$theday';"
	# $recordset = $sdb->fetchAll($sql);
	# foreach my $record (@{$recordset}){
		# $reg_num = $record->{num};
	# }

	# $sql = "select count(*) as num from account ac where left(ac.a_addtime, 10) = '$theday' and ac.a_firstserverid = 0;"
	# $recordset = $sdb->fetchAll($sql);
	# foreach my $record (@{$recordset}){
		# $empty_reg_num = $record->{num};
	# }
	
	# $valid_reg_num = $reg_num - $empty_reg_num;
	
	# #注册流失率 = （当天注册连接数 – 到达创建角色界面数）÷ 注册连接数
	# my $reg_lost = $empty_reg_num / $reg_num;
	
	# my $field = "(`theday`,`reg_num`,`valid_reg_num`,`empty_reg_num`,`reg_lost`)";
	# my $row = "('$theday',$serverid,$reg_num,$valid_reg_num,$empty_reg_num,$reg_lost)";
	# my $delete_sql = "DELETE FROM meta_userlost WHERE theday = '$startday'";
	# my $insert_sql = "INSERT INTO meta_userlost ($field) VALUES $row";
	# $gas->_execute($delete_sql);
	# $gas->_execute($insert_sql);
# }

1;
