package Mods::Business::Pay;

use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;

sub new{
	shift();
	my $this = shift;

	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	bless $this;
	return $this;
}

sub run{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	for(my $start_sec = Mods::Lib::Common::str2ts($startday);$start_sec <= Mods::Lib::Common::str2ts($stopday);$start_sec += 86400){
		my $theday = Mods::Lib::Common::ts2str($start_sec, 1);
		$this->newpaychar($theday);
		$this->{logger}->info("Model newpaychar");
		
		$this->oldpaychar($theday);
		$this->{logger}->info("Model oldpaychar");
	}
}

sub newpaychar
{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	# 当天注册充值人数 当天注册充值金额  新用户
	my $sql = "SELECT pr.pr_channel, LEFT(pr.pr_addtime, 10) AS theday, pr.pr_originalsid AS serverid, pr.pr_pub AS pubkey, COUNT(DISTINCT pr.pr_playerid) AS pay_char, SUM(pr.pr_money) AS pay_sum
				FROM `payrecord` pr WHERE LEFT(pr.pr_addtime, 10) = '$theday' AND pr.pr_money > 0 AND pr.pr_success = 1
				AND pr.pr_accountid IN (SELECT ac.a_id FROM account ac WHERE LEFT(ac.a_addtime, 10) = '$theday')
				GROUP BY LEFT(pr.pr_addtime, 10), pr.pr_originalsid, pr.pr_pub, pr.pr_channel";
				
	$this->{logger}->info($sql);
				
	my $recordset = $sdb->fetchAll($sql);
	my $row = undef;
	foreach my $record(@$recordset){
		$row .= "('$record->{'theday'}',$record->{'serverid'},$record->{'pay_char'},$record->{'pay_sum'},'$record->{'pr_channel'}','$record->{'pubkey'}'),";
	}
	
	my $field = "`theday`,`serverid`,`num`,`pay`,`op`,`pub`";
	if($row && $row =~ s/,$//){
		$sql = "DELETE FROM meta_newpaychar WHERE theday = '$theday'";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
		
		$sql = "INSERT INTO meta_newpaychar ($field) VALUES $row";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
	}
}

sub oldpaychar
{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	  
	# 老用户注册充值人数 老用户注册充值金额
	my $sql = "SELECT pr.pr_channel, LEFT(pr.pr_addtime, 10) AS theday, pr.pr_originalsid AS serverid, pr.pr_pub AS pubkey, COUNT(DISTINCT pr.pr_playerid) AS pay_char, SUM(pr.pr_money) AS pay_sum
			FROM `payrecord` pr
			WHERE LEFT(pr.pr_addtime, 10) = '$theday' AND pr.pr_money > 0 AND pr.pr_success = 1
			AND pr.pr_accountid IN (SELECT ac.a_id FROM account ac WHERE LEFT(ac.a_addtime, 10) < '$theday')
			GROUP BY LEFT(pr.pr_addtime, 10), pr.pr_originalsid, pr.pr_pub, pr.pr_channel";
			
	$this->{logger}->info($sql);
	
	my $recordset = $sdb->fetchAll($sql);
	my $row = undef;
	foreach my $record(@$recordset){
		$row .= "('$record->{'theday'}',$record->{'serverid'},$record->{'pay_char'},$record->{'pay_sum'},'$record->{'pubkey'}','$record->{'pr_channel'}'),";
	}
	
	my $field = "`theday`,`serverid`,`num`,`pay`,`pub`, `op`";
	if($row && $row =~ s/,$//){
		$sql = "DELETE FROM meta_oldpaychar WHERE theday = '$theday'";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
		
		$sql = "INSERT INTO meta_oldpaychar ($field) VALUES $row";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
	}
}

1;
