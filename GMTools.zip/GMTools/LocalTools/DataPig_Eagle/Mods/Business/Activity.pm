package Mods::Business::Activity;

use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;

sub new{
	shift();
	my $this = shift;

	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	bless $this;
	return $this;
}

sub run{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	for(my $start_sec = Mods::Lib::Common::str2ts($startday);$start_sec <= Mods::Lib::Common::str2ts($stopday);$start_sec += 86400){
		my $theday = Mods::Lib::Common::ts2str($start_sec, 1);
		$this->sysactive($theday);
		$this->{logger}->info("Model sysactive");
		
		$this->sysplay($theday);
		$this->{logger}->info("Model sysplay");
		
		$this->activity($theday);
		$this->{logger}->info("Model activity");
	}
}

#系统特色玩法 活动
sub sysactive
{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	my %proto = ('worship'=>1,'arenafight'=>1,'chessputdice'=>1,'breakstage'=>1,'mazestart'=>1,'worldbossattack'=>1,'startdart'=>1,'openteamcopy'=>1,'openfactionboss'=>1,'factionputdevote'=>1,'factionbattlesign'=>1,'openborderbattle'=>1,'inviteenterbattlefield'=>1,'campdesiresignup'=>1);

	my $str = join('\',\'', keys %proto);
	
	my $data_proto = {};
	my $data_ingot = {};
	
	# 系统特色玩法的人数次数
	my $sql = "select left(o.theday,10) as theday, o.serverid, o.proto, count(distinct o.playerid) as num, count(*) as count from onremoteinput o where left(o.theday,10) = '$theday' and 
			o.proto in ('$str')
			group by o.proto, o.serverid";
				
	$this->{logger}->info($sql);
	my $recordset = $gas->fetchAll($sql);
	foreach my $record(@$recordset){
		my $theday = $record->{'theday'};
		my $serverid = $record->{'serverid'};
		my $proto = $record->{'proto'};
		my $num = $record->{'num'};
		my $count = $record->{'count'};
		
		$data_proto->{$serverid}->{$proto}->{num} = $num;
		$data_proto->{$serverid}->{$proto}->{count} = $count;	
		
	}
	
	
	$sql = "select ibr.ibr_type, ibr.serverid, sum(ibr.ibr_ingot) as num from ingotbuyrecord ibr where left(ibr.ibr_time,10) = '$theday' 
				and  ibr.ibr_type in ('subsidyExchangeExp','worship','addarenafight','refresharenamalllist','chessdonow','mazeelementchange','mazeelementskip','mazemarketbuy','attackworldboss','getbackBonusesIngot','attackfactionboss','addopenbattlefield','modifyfamenameprefix')
				and ibr.ibr_ingot > 0
				group by ibr.ibr_type, ibr.serverid";
				
	$this->{logger}->info($sql);
	$recordset = $sdb->fetchAll($sql);
	foreach my $record(@$recordset){
		my $proto = $record->{'ibr_type'};
		my $serverid = $record->{'serverid'};
		my $num = $record->{'num'};
		
		$data_ingot->{$serverid}->{worship}->{num} = $num                if($proto eq 'subsidyExchangeExp' || $proto eq 'worship');		
		$data_ingot->{$serverid}->{arenafight}->{num} = $num             if($proto eq 'addarenafight' || $proto eq 'refresharenamalllist');	
		$data_ingot->{$serverid}->{chessputdice}->{num} = $num           if($proto eq 'chessdonow');
		$data_ingot->{$serverid}->{mazestart}->{num} = $num              if($proto eq 'mazeelementchange' || $proto eq 'mazeelementskip' || $proto eq 'mazemarketbuy');
		$data_ingot->{$serverid}->{worldbossattack}->{num} = $num        if($proto eq 'attackworldboss' || $proto eq 'getbackBonusesIngot');
		$data_ingot->{$serverid}->{openfactionboss}->{num} = $num        if($proto eq 'attackfactionboss');
		$data_ingot->{$serverid}->{inviteenterbattlefield}->{num} = $num if($proto eq 'addopenbattlefield' || $proto eq 'modifyfamenameprefix');
	}
	
	my $data = {};
	foreach my $proto (keys %proto){
		foreach my $serverid (keys %{$data_proto}){
			$data->{$serverid}->{$proto}->{num} = $data_proto->{$serverid}->{$proto}->{num}?$data_proto->{$serverid}->{$proto}->{num}:0;
			$data->{$serverid}->{$proto}->{count} = $data_proto->{$serverid}->{$proto}->{count}?$data_proto->{$serverid}->{$proto}->{count}:0;
		}
		
		foreach my $serverid (keys %{$data_ingot}){
			$data->{$serverid}->{$proto}->{ingot} = $data_ingot->{$serverid}->{$proto}->{num}?$data_ingot->{$serverid}->{$proto}->{num}:0;
		}
	}
	
	my $row = undef;
	foreach my $serverid (keys %$data){
		foreach my $proto (keys %{$data->{$serverid}}){
			my $num = $data->{$serverid}->{$proto}->{num}?$data->{$serverid}->{$proto}->{num}:0;
			my $count = $data->{$serverid}->{$proto}->{count}?$data->{$serverid}->{$proto}->{count}:0;
			my $ingot = $data->{$serverid}->{$proto}->{ingot}?$data->{$serverid}->{$proto}->{ingot}:0;
			$row .= "('$theday',$serverid,'$proto',$num,$count,$ingot),";
		}
	}
	
	my $field = "`theday`,`serverid`,`proto`,`num`,`count`,`ingot`";
	if($row && $row =~ s/,$//){
		$sql = "DELETE FROM meta_sysactivity WHERE theday = '$theday'";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
		
		$sql = "INSERT INTO meta_sysactivity ($field) VALUES $row";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
	}
}	
	
	#系统特色玩法
sub sysplay
{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	# 招募	heropump
	# 強化	armenhance
	# 洗練	armchangeproperty	
	# 魂鑄（鍛造裏面）	armchangesoul
	# 釣魚	fishing
	# 熔煉	heroarmlevelup
	# 精研	riseskilleffectlevel
	# 自創	combineSkillBook
	# 屠藍龍王	killdragon
	# 使用许愿池 usewishingwell
	# 使用返利转盘 userebateturntable 

	my %proto = ('heroarmconcise'=>1,'heroarmenhance'=>1,'armchangesoul'=>1,'heropump'=>1,'armenhance'=>1,'armchangeproperty'=>1,'fishing'=>1,'heroarmlevelup'=>1,'riseskilleffectlevel'=>1,'combineskillbook'=>1,'killdragon'=>1,'usewishingwell'=>1,'userebateturntable'=>1);

	my $str = join('\',\'', keys %proto);
	
	my $data_proto = {};
	my $data_ingot = {};
	
	# 系统特色玩法的人数次数
	my $sql = "select left(o.theday,10) as theday, o.serverid, o.proto, count(distinct o.playerid) as num, count(*) as count from onremoteinput o where left(o.theday,10) = '$theday' and 
			o.proto in ('$str')
			group by o.proto, o.serverid";
				
	$this->{logger}->info($sql);
	my $recordset = $gas->fetchAll($sql);
	foreach my $record(@$recordset){
		my $theday = $record->{'theday'};
		my $serverid = $record->{'serverid'};
		my $proto = $record->{'proto'};
		my $num = $record->{'num'};
		my $count = $record->{'count'};
		
		$data_proto->{$serverid}->{$proto}->{num} = $num;
		$data_proto->{$serverid}->{$proto}->{count} = $count;	
		
	}
	
	$sql = "select ibr.ibr_type, ibr.serverid, sum(ibr.ibr_ingot) as num from ingotbuyrecord ibr where left(ibr.ibr_time,10) = '$theday' 
				and  ibr.ibr_type in ('$str')
				and ibr.ibr_ingot > 0
				group by ibr.ibr_type, ibr.serverid";
				
	$this->{logger}->info($sql);
	$recordset = $sdb->fetchAll($sql);
	foreach my $record(@$recordset){
		my $proto = $record->{'ibr_type'};
		my $serverid = $record->{'serverid'};
		my $num = $record->{'num'};
		
		$data_ingot->{$serverid}->{$proto}->{num} = $num;
		
	}
	
	my $data = {};
	foreach my $proto (keys %proto){
		foreach my $serverid (keys %{$data_proto}){
			$data->{$serverid}->{$proto}->{num} = $data_proto->{$serverid}->{$proto}->{num}?$data_proto->{$serverid}->{$proto}->{num}:0;
			$data->{$serverid}->{$proto}->{count} = $data_proto->{$serverid}->{$proto}->{count}?$data_proto->{$serverid}->{$proto}->{count}:0;
		}
		
		foreach my $serverid (keys %{$data_ingot}){
			$data->{$serverid}->{$proto}->{ingot} = $data_ingot->{$serverid}->{$proto}->{num}?$data_ingot->{$serverid}->{$proto}->{num}:0;
		}
	}
	
	my $row = undef;
	foreach my $serverid (keys %$data){
		foreach my $proto (keys %{$data->{$serverid}}){
			my $num = $data->{$serverid}->{$proto}->{num}?$data->{$serverid}->{$proto}->{num}:0;
			my $count = $data->{$serverid}->{$proto}->{count}?$data->{$serverid}->{$proto}->{count}:0;
			my $ingot = $data->{$serverid}->{$proto}->{ingot}?$data->{$serverid}->{$proto}->{ingot}:0;
			$row .= "('$theday',$serverid,'$proto',$num,$count,$ingot),";
		}
	}
	
	my $field = "`theday`,`serverid`,`proto`,`num`,`count`,`ingot`";
	if($row && $row =~ s/,$//){
		$sql = "DELETE FROM meta_sysplay WHERE theday = '$theday'";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
		
		$sql = "INSERT INTO meta_sysplay ($field) VALUES $row";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
	}
}	
	
	#运营活动
sub activity
{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};

	#
	my $data = {};
	my $sql = "select a.theday,a.serverid, a.activity,a.subid,count(playerid) as num, 
				format((count(playerid)/(select count(playerid) from activity where theday = '$theday')),4) as rate
				from activity a 
				where a.theday = '$theday'
				group by a.serverid,a.activity,a.subid";
				
	$this->{logger}->info($sql);
	my $recordset = $gas->fetchAll($sql);
	foreach my $record(@$recordset){
		my $theday = $record->{'theday'};
		my $serverid = $record->{'serverid'};
		my $activity = $record->{'activity'};
		my $subid = $record->{'subid'};
		my $num = $record->{'num'};
		my $rate = $record->{'rate'};
		
		$data->{$serverid}->{$activity}->{$subid}->{num} = $num;
		$data->{$serverid}->{$activity}->{$subid}->{rate} = $rate;	
		
	}
	
	my $row = undef;
	foreach my $serverid (keys %$data){
		foreach my $activity (keys %{$data->{$serverid}}){
			foreach my $subid (keys %{$data->{$serverid}->{$activity}}){
				my $num = $data->{$serverid}->{$activity}->{$subid}->{num}?$data->{$serverid}->{$activity}->{$subid}->{num}:0;
				my $rate = $data->{$serverid}->{$activity}->{$subid}->{rate}?$data->{$serverid}->{$activity}->{$subid}->{rate}:0;
				$row .= "('$theday',$serverid,'$activity',$subid,$num,$rate),";
			}
		}
	}
	
	my $field = "`theday`,`serverid`,`activity`,`subid`,`num`,`rate`";
	if($row && $row =~ s/,$//){
		$sql = "DELETE FROM meta_activity WHERE theday = '$theday'";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
		
		$sql = "INSERT INTO meta_activity ($field) VALUES $row";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
	}
}

1;
