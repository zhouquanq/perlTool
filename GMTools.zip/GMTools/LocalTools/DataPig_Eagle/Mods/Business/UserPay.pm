package Mods::Business::UserPay;

use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;

sub new{
	shift();
	my $this = shift;

	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	bless $this;
	return $this;
}

sub run{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	for(my $start_sec = Mods::Lib::Common::str2ts($startday);$start_sec <= Mods::Lib::Common::str2ts($stopday);$start_sec += 86400){
		my $theday = Mods::Lib::Common::ts2str($start_sec, 1);
		$this->usepay($theday);
		$this->{logger}->info("Model usepay");
	}
}

sub usepay
{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	# 每天所有用户充值    金额, 人数, 次数, arpu
	my $sql = "select pr.pr_serverid, sum(pr.pr_money) as amount, count(distinct pr.pr_playerid) as people ,count(pr.pr_playerid) as num,
				 format(sum(pr.pr_money)/count(distinct pr.pr_playerid),2) as arpu 
				from payrecord pr where 
				left(pr.pr_addtime, 10) = '$theday' and pr.pr_success = 1
				group by pr.pr_serverid";
				
	$this->{logger}->info($sql);
	
	my $user = {};
	
	my $recordset = $sdb->fetchAll($sql);
	foreach my $record(@$recordset){
		my $serverid = $record->{'pr_serverid'};
		my $amount = $record->{'amount'}?$record->{'amount'}:0;
		my $people = $record->{'people'}?$record->{'people'}:0;
		my $num = $record->{'num'}?$record->{'num'}:0;
		my $arpu = $record->{'arpu'}?$record->{'arpu'}:0;
		$arpu =~ s/,//g;
		$user->{$serverid}->{amount} = $amount;
		$user->{$serverid}->{people} = $people;
		$user->{$serverid}->{num} = $num;
		$user->{$serverid}->{arpu} = $arpu;
	}
	
	# 每天新增用户充值    金额, 人数, 次数, arpu
	$sql = "select pr.pr_serverid, sum(pr.pr_money) as amount, count(distinct pr.pr_playerid) as people,
			count(pr.pr_playerid) as num, format(sum(pr.pr_money)/count(distinct pr.pr_playerid), 2) as arpu
			 from payrecord pr 
			where left(pr.pr_addtime, 10) = '$theday' and pr.pr_success = 1
			and pr.pr_playerid not in (select distinct prr.pr_playerid from payrecord prr 
			where left(prr.pr_addtime, 10) < '$theday' and prr.pr_success = 1)
			group by pr.pr_serverid
			;";
			
	$this->{logger}->info($sql);
				
	$recordset = $sdb->fetchAll($sql);
	foreach my $record(@$recordset){
		my $serverid = $record->{'pr_serverid'};
		my $amount = $record->{'amount'}?$record->{'amount'}:0;
		my $people = $record->{'people'}?$record->{'people'}:0;
		my $num = $record->{'num'}?$record->{'num'}:0;
		my $arpu = $record->{'arpu'}?$record->{'arpu'}:0;
		$arpu =~ s/,//g;
		$user->{$serverid}->{newamount} = $amount;
		$user->{$serverid}->{newpeople} = $people;
		$user->{$serverid}->{newnum} = $num;
		$user->{$serverid}->{newarpu} = $arpu;
	}
	
	my $row = undef;
	foreach my $serverid (keys %$user){
		my $amount = $user->{$serverid}->{amount}?$user->{$serverid}->{amount}:0;
		my $people = $user->{$serverid}->{people}?$user->{$serverid}->{people}:0;
		my $num = $user->{$serverid}->{num}?$user->{$serverid}->{num}:0;
		my $arpu = $user->{$serverid}->{arpu}?$user->{$serverid}->{arpu}:0;
		my $newamount = $user->{$serverid}->{newamount}?$user->{$serverid}->{newamount}:0;
		my $newpeople = $user->{$serverid}->{newpeople}?$user->{$serverid}->{newpeople}:0;
		my $newnum = $user->{$serverid}->{newnum}?$user->{$serverid}->{newnum}:0;
		my $newarpu = $user->{$serverid}->{newarpu}?$user->{$serverid}->{newarpu}:0;
		
		$row .= "('$theday',$serverid,$amount,$people,$num,$arpu,$newamount,$newpeople,$newnum,$newarpu),";
	}
	
	my $field = "`theday`,`serverid`,`amount`,`people`,`num`,`arpu`,`newamount`,`newpeople`,`newnum`,`newarpu`";
	if($row && $row =~ s/,$//){
		$sql = "DELETE FROM meta_userpay WHERE theday = '$theday'";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
		
		$sql = "INSERT INTO meta_userpay ($field) VALUES $row";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
	}
}

1;
