package Mods::Business::Lost;

use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;

sub new{
	shift();
	my $this = shift;

	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	bless $this;
	return $this;
}

sub run{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	for(my $start_sec = Mods::Lib::Common::str2ts($startday);$start_sec <= Mods::Lib::Common::str2ts($stopday);$start_sec += 86400){
		my $theday = Mods::Lib::Common::ts2str($start_sec, 1);
		$this->playerlost($theday);
		$this->{logger}->info("Model playerlost");
		
		$this->levellost($theday);
		$this->{logger}->info("Model levellost");
		
		$this->maplost($theday);
		$this->{logger}->info("Model maplost");
	}
}

sub playerlost{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	my $sql = undef;
	my $recordset = [];
	my $row = undef;
	
	my $create = {};
	my $lost = {};
	$sql = "select pl.c_serverid, count(*) as num from player pl where left(pl.c_addtime,10) = '$theday'
			group by pl.c_serverid;";
			
	$this->{logger}->info($sql);
	
	$recordset = $sdb->fetchAll($sql);
	foreach my $record (@{$recordset}){
		my $c_serverid = $record->{c_serverid};
		my $num = $record->{num};
		$create->{$c_serverid} = $num;
	}

	$sql = "select pl.c_serverid, count(*) as num from player pl where left(pl.c_addtime,10) = '$theday' and pl.c_firsttask = 0
			group by pl.c_serverid;";
			
	$this->{logger}->info($sql);
	
	$recordset = $sdb->fetchAll($sql);
	foreach my $record (@{$recordset}){
		my $c_serverid = $record->{c_serverid};
		my $num = $record->{num};
		$lost->{$c_serverid} = $num;
	}
	
	my $field = "(`theday`,`serverid`,`total`,`lost`)";
	
	foreach my $serverid (keys %{$create}){
		my $create_num = $create->{$serverid};
		my $lost_num = $lost->{$serverid}?$lost->{$serverid}:0;
		$row .= "('$theday',$serverid,$create_num,$lost_num),";
	}
	if($row && $row =~ s/,$//){
		my $delete_sql = "DELETE FROM meta_playerlost WHERE theday = '$theday'";
		$this->{logger}->info($delete_sql);
		$sdb->_execute($delete_sql);
		
		my $insert_sql = "INSERT INTO meta_playerlost $field VALUES $row";
		$this->{logger}->info($insert_sql);
		$sdb->_execute($insert_sql);
	}
}

sub levellost{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	my $sql = undef;
	my $recordset = [];
	my $row = undef;
	
	my $create = {};
	my $lost = {};
	$sql = "select pl.c_serverid, count(*) as num from player pl where left(pl.c_addtime,10) = '$theday'
			group by pl.c_serverid;";
			
	$this->{logger}->info($sql);
	
	$recordset = $sdb->fetchAll($sql);
	foreach my $record (@{$recordset}){
		my $c_serverid = $record->{c_serverid};
		my $num = $record->{num};
		$create->{$c_serverid} = $num;
	}

	$sql = "select pl.c_serverid, count(*) as num from player pl where left(pl.c_addtime,10) = '$theday' and pl.c_firsttask = 0
			group by pl.c_serverid;";
			
	$this->{logger}->info($sql);
			
	$recordset = $sdb->fetchAll($sql);
	foreach my $record (@{$recordset}){
		my $c_serverid = $record->{c_serverid};
		my $num = $record->{num};
		$lost->{$c_serverid} = $num;
	}
	
	my $field = "(`theday`,`serverid`,`level`,`lost`)";
	
	foreach my $serverid (keys %{$create}){
		my $create_num = $create->{$serverid};
		my $lost_num = $lost->{$serverid}?$lost->{$serverid}:0;
		$row .= "('$theday',$serverid,$create_num,$lost_num),";
	}
	if($row && $row =~ s/,$//){
		my $delete_sql = "DELETE FROM meta_levellost WHERE theday = '$theday'";
		$this->{logger}->info($delete_sql);
		$gas->_execute($delete_sql);
		
		
		my $insert_sql = "INSERT INTO meta_levellost $field VALUES $row";
		$this->{logger}->info($insert_sql);
		$gas->_execute($insert_sql);
	}
}

sub maplost{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	my $sql = undef;
	my $recordset = [];
	my $row = undef;
	
	my $create = {};
	my $lost = {};
	$sql = "select pl.c_serverid, count(*) as num from player pl where left(pl.c_addtime,10) = '$theday'
			group by pl.c_serverid;";
			
	$this->{logger}->info($sql);
			
	$recordset = $sdb->fetchAll($sql);
	foreach my $record (@{$recordset}){
		my $c_serverid = $record->{c_serverid};
		my $num = $record->{num};
		$create->{$c_serverid} = $num;
	}

	$sql = "select pl.c_serverid, count(*) as num from player pl where left(pl.c_addtime,10) = '$theday' and pl.c_firsttask = 0
			group by pl.c_serverid;";
			
	$this->{logger}->info($sql);
			
	$recordset = $sdb->fetchAll($sql);
	foreach my $record (@{$recordset}){
		my $c_serverid = $record->{c_serverid};
		my $num = $record->{num};
		$lost->{$c_serverid} = $num;
	}
	
	my $field = "(`theday`,`serverid`,`mapid`,`lost`)";
	
	foreach my $serverid (keys %{$create}){
		my $create_num = $create->{$serverid};
		my $lost_num = $lost->{$serverid}?$lost->{$serverid}:0;
		$row .= "('$theday',$serverid,$create_num,$lost_num),";
	}
	if($row && $row =~ s/,$//){
		my $delete_sql = "DELETE FROM meta_maplost WHERE theday = '$theday'";
		$this->{logger}->info($delete_sql);
		$gas->_execute($delete_sql);
		
		my $insert_sql = "INSERT INTO meta_maplost $field VALUES $row";
		$this->{logger}->info($insert_sql);
		$gas->_execute($insert_sql);
	}
}

1;
