package Mods::Business::OperationData;

use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;

sub new{
	shift();
	my $this = shift;

	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	bless $this;
	return $this;
}

sub run{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};

	for(my $start_sec = Mods::Lib::Common::str2ts($startday);$start_sec <= Mods::Lib::Common::str2ts($stopday);$start_sec += 86400){
		my $theday = Mods::Lib::Common::ts2str($start_sec, 1);
		# $this->account($theday);
		$this->daydate($theday);#运营日常数据
		$this->{logger}->info("Model daydate");
		
		$this->daydatetotal($theday);#运营日常数据
		$this->{logger}->info("Model daydatetotal");
	}
}

sub daydate{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	
	#日期,注册,创建,登录,活跃,次日留存,三日留存,七日留存,最高在线,平均在线,活跃时长,充值,充值人数,首充人数,充值次数,arpu
	#注册 为有效注册,
	#meta_userback 创建数,登录数,次日留存,三日留存,七日留存
	#meta_useractiveback #当天登录活跃角色数
	my $account_info = {};
	my $create_info = {};
	my $online_info = {};
	my $active_info = {};
	my $loginplayer_info = {};
	my $pay_info = {};
	my $firstpay_info = {};
	
	my $sql = "select mu.theday,mu.serverid,mu.`create`,mu.login,mu.yester_rate,mu.three_rate,mu.seven_rate from meta_userback mu where mu.theday = '$theday'";
	my $recordset = $gas->fetchAll($sql);
	if(@$recordset){
		foreach my $record (@$recordset){
			my $theday = $record->{theday};
			my $serverid = $record->{serverid};
			my $create = $record->{create};
			my $login = $record->{login};
			my $yester_rate = $record->{yester_rate};
			my $three_rate = $record->{three_rate};
			my $seven_rate = $record->{seven_rate};
			
			$create_info->{$theday}->{$serverid}->{create} = $create;
			$create_info->{$theday}->{$serverid}->{login} = $login;
			$create_info->{$theday}->{$serverid}->{yester_rate} = $yester_rate;
			$create_info->{$theday}->{$serverid}->{three_rate} = $three_rate;
			$create_info->{$theday}->{$serverid}->{seven_rate} = $seven_rate;
		}
	}
	
	$sql = "select mu.theday, mu.serverid, mu.active from meta_useractiveback mu where mu.theday = '$theday';";
	$recordset = $gas->fetchAll($sql);
	if(@$recordset){
		foreach my $record (@$recordset){
			my $theday = $record->{theday};
			my $serverid = $record->{serverid};
			my $active = $record->{active};
			
			$active_info->{$theday}->{$serverid} = $active;
		}
	}
	
	$sql = "select mn.theday,mn.serverid,sum(mn.num) as num from meta_newaccount mn where mn.serverid != 0 and mn.theday = '$theday' group by mn.serverid";
	$recordset = $gas->fetchAll($sql);
	if(@$recordset){
		foreach my $record (@$recordset){
			my $theday = $record->{theday};
			my $serverid = $record->{serverid};
			my $num = $record->{num};
			
			$account_info->{$theday}->{$serverid} = $num;
		}
	}
	
	$sql = "select left(pr.pr_addtime,10) as theday, pr.pr_serverid, sum(pr.pr_money) as amount,count(distinct pr.pr_playerid) as users, count(pr.pr_playerid) as num
				from payrecord pr 
				where left(pr.pr_addtime,10) = '$theday' and pr.pr_money > 0 and pr.pr_success = 1
				group by pr.pr_serverid";
	$recordset = $sdb->fetchAll($sql);
	if(@$recordset){
		foreach my $record (@$recordset){
			my $theday = $record->{theday};
			my $pr_serverid = $record->{pr_serverid};
			my $amount = $record->{amount};
			my $users = $record->{users};
			my $num = $record->{num};
			
			$pay_info->{$theday}->{$pr_serverid}->{amount} = $amount;
			$pay_info->{$theday}->{$pr_serverid}->{users} = $users;
			$pay_info->{$theday}->{$pr_serverid}->{num} = $num;
		}
	}
	
	$sql = "select mf.theday, mf.serverid,sum(mf.num) as num from meta_firstpay mf where mf.theday = '$theday' group by mf.serverid";			
	$recordset = $gas->fetchAll($sql);
	if(@$recordset){
		foreach my $record (@$recordset){
			my $theday = $record->{theday};
			my $serverid = $record->{serverid};
			my $num = $record->{num};
			
			$firstpay_info->{$theday}->{$serverid} = $num;
		}
	}
	
	$sql = "select ll.theday, ll.serverid, count(ll.playerid) as num, sum(ll.timelong) as timelongs from loginplayer ll where ll.theday = '$theday' and ll.times >= 600 group by ll.serverid";
	$recordset = $sdb->fetchAll($sql);
	if(@$recordset){
		foreach my $record (@$recordset){
			my $theday = $record->{theday};
			my $serverid = $record->{serverid};
			my $num = $record->{num};
			my $timelongs = $record->{timelongs};
			
			$loginplayer_info->{$theday}->{$serverid}->{num} = $num;
			$loginplayer_info->{$theday}->{$serverid}->{timelongs} = int($timelongs/$num);
		}
	}
	
	$sql = "select mo.theday, mo.serverid, mo.top_char from meta_onlinebyhour mo where mo.theday = '$theday'";
	$recordset = $gas->fetchAll($sql);
	if(@$recordset){
		foreach my $record (@$recordset){
			my $theday = $record->{theday};
			my $serverid = $record->{serverid};
			my $top_char = $record->{top_char};
			my @sz = split(/,/, $top_char);
			my $index = 0;
			my $num = 0;
			my $max = 0;
			foreach (my $i = 0; $i <= $#sz; $i++){
				my $item = $sz[$i];
				if($item > $max){
					$max = $item;
				}
				next if($item == 0);
				$num += $item;
				$index += 1;
			}
			
			next if($index == 0);
			$online_info->{$theday}->{$serverid}->{ave} = int($num/$index);
			$online_info->{$theday}->{$serverid}->{max} = $max;
		}
	}
	
	my $row = undef;
	
	$sql = "select sl.serverid from serverlist sl where sl.serverenable = 1";
	$recordset = $gas->fetchAll($sql);
	if(@$recordset){
		foreach my $record (@$recordset){
			my $serverid = $record->{serverid};
			
			my $account_num = $account_info->{$theday}->{$serverid}?$account_info->{$theday}->{$serverid}:0;
		
			my $create = $create_info->{$theday}->{$serverid}->{create}?$create_info->{$theday}->{$serverid}->{create}:0;
			my $login = $create_info->{$theday}->{$serverid}->{login}?$create_info->{$theday}->{$serverid}->{login}:0;
			my $yester_rate = $create_info->{$theday}->{$serverid}->{yester_rate}?$create_info->{$theday}->{$serverid}->{yester_rate}:0;
			my $three_rate = $create_info->{$theday}->{$serverid}->{three_rate}?$create_info->{$theday}->{$serverid}->{three_rate}:0;
			my $seven_rate = $create_info->{$theday}->{$serverid}->{seven_rate}?$create_info->{$theday}->{$serverid}->{seven_rate}:0;
			
			my $online_ave = $online_info->{$theday}->{$serverid}->{ave}?$online_info->{$theday}->{$serverid}->{ave}:0;
			my $online_max = $online_info->{$theday}->{$serverid}->{max}?$online_info->{$theday}->{$serverid}->{max}:0;
			my $active = $active_info->{$theday}->{$serverid}?$active_info->{$theday}->{$serverid}:0;
			
			my $loginplayer_num = $loginplayer_info->{$theday}->{$serverid}->{num}?$loginplayer_info->{$theday}->{$serverid}->{num}:0;
			my $timelongs = $loginplayer_info->{$theday}->{$serverid}->{timelongs}?$loginplayer_info->{$theday}->{$serverid}->{timelongs}:0;
			
			
			my $amount = $pay_info->{$theday}->{$serverid}->{amount}?$pay_info->{$theday}->{$serverid}->{amount}:0;
			my $users = $pay_info->{$theday}->{$serverid}->{users}?$pay_info->{$theday}->{$serverid}->{users}:0;
			my $pay_num = $pay_info->{$theday}->{$serverid}->{num}?$pay_info->{$theday}->{$serverid}->{num}:0;
			my $pay_ave = 0;
			if($users != 0){
				$pay_ave = sprintf("%.2f",($amount/$users));
			}
			my $firstpay_num = $firstpay_info->{$theday}->{$serverid}?$firstpay_info->{$theday}->{$serverid}:0;
			# 日期,注册,创建,登录,活跃,次日留存,三日留存,七日留存,最高在线,平均在线,活跃时长,充值,充值人数,首充人数,充值次数,arpu
			$row .= "('$theday',$serverid,$create,$account_num,$login,$active,$yester_rate,$three_rate,$seven_rate,$online_max,$online_ave,$timelongs,$amount,$users,$firstpay_num,$pay_num,$pay_ave),";
		}
		
		if($row && $row =~ s/,$//){
			my $field = "(`theday`,`serverid`,`create`,`register`,`login`,`active`,`yester_rate`,`three_rate`,`seven_rate`,`online_max`,`online_ave`,`activetimes`,`amount`,`users`,`firstpay`,`pay_num`,`pay_ave`)";
			
			my $sql_delete = "delete from meta_daydata where theday = '$theday';";
			my $sql_insert = "insert into meta_daydata $field values $row";
			$gas->_execute($sql_delete);
			$gas->_execute($sql_insert);
			$this->{logger}->info($sql_delete);
			$this->{logger}->info($sql_insert);
		}
		
		$theday = Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*7,1);#
		$sql = "select mu.theday, mu.serverid,mu.yester_rate,mu.three_rate,mu.seven_rate from meta_userback mu where mu.theday >= '$theday';";
		$recordset = $gas->fetchAll($sql);
		if(@$recordset){
			foreach my $record (@$recordset){
				my $theday = $record->{theday};
				my $serverid = $record->{serverid};
				my $yester_rate = $record->{yester_rate};
				my $three_rate = $record->{three_rate};
				my $seven_rate = $record->{seven_rate};
				
				my $sql_update = "update meta_daydata set `yester_rate` = $yester_rate,`three_rate` = $three_rate,`seven_rate` = $seven_rate 
				where theday = '$theday' and serverid = $serverid;";
				$gas->_execute($sql_update);
				$this->{logger}->info($sql_update);
			}
		}
	}
}

sub daydatetotal{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};	
	
	#当天登录角色数
	# return if(Mods::Lib::Common::ts2str(time,1) eq $theday);
	
	my $account_info = 0;#
	my $active_info = 0;
	my $pay_info = {'amount' => 0,'users' => 0, 'num' => 0, 'ave' => 0};
	my $firstpay_info = 0;
	#注册
	my $sql = "select sum(mn.num) as num from meta_newaccount mn where mn.serverid != 0 and mn.theday = '$theday'";
	my $recordset = $gas->fetchAll($sql);
	if(@$recordset){
		$account_info = $recordset->[0]->{num}?$recordset->[0]->{num}:0;
	}
	
	#活跃
	$sql = "select sum(mu.active) as active_num from meta_useractiveback mu where mu.theday = '$theday';";
	$recordset = $gas->fetchAll($sql);
	if(@$recordset){
		if($recordset->[0]->{active_num} =~ /^\d+$/){
			$active_info = $recordset->[0]->{active_num};
		}else{
			$active_info = 0;
		}
	}
	
	#充值
	$sql = "select left(pr.pr_addtime,10) as theday, sum(pr.pr_money) as amount,count(distinct pr.pr_playerid) as users, count(pr.pr_playerid) as num
				from payrecord pr 
				where left(pr.pr_addtime,10) = '$theday' and pr.pr_money > 0 and pr.pr_success = 1";
	$recordset = $sdb->fetchAll($sql);
	if(@$recordset){
		my $theday = $recordset->[0]->{theday};
		my $amount = $recordset->[0]->{amount};
		my $users = $recordset->[0]->{users};
		my $num = $recordset->[0]->{num};
		
		if($recordset->[0]->{amount} =~ /\d+(.?)\d+/){
			$pay_info->{amount} = $recordset->[0]->{amount};
		}else{
			$pay_info->{amount} = 0;
		}

		$pay_info->{users} = $users?$users:0;
		$pay_info->{num} = $num?$num:0;
		my $ave_tmp = 0;
		$ave_tmp = sprintf("%.4f", $amount/$num) if($num != 0);
		$ave_tmp =~ s/,//g;
		$pay_info->{ave} = $ave_tmp;
	}

	#首充
	$sql = "select sum(mf.num) as num from meta_firstpay mf where mf.theday = '$theday'";			
	$recordset = $gas->fetchAll($sql);
	if(@$recordset){
		if($recordset->[0]->{num} =~ /^\d+(.?)\d+$/){
			$firstpay_info = $recordset->[0]->{num};
		}else{
			$firstpay_info = 0;
		}
	}
	
	my $backdays = {
		'yester' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400,1),#昨注回头日期,
		'three' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*2,1),#三注回头日期
		'seven' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*6,1),#七注回头日期
	};
	
	#当天登录角色信息
	$sql = "select ll.serverid, ll.playerid from loginplayer ll where ll.theday = '$theday'";
	$recordset = $sdb->fetchAll($sql);
	if(@$recordset){
		my $playerinfo = {};#当天登录角色的所有id
		foreach my $record (@$recordset){
			$playerinfo->{playerids} .= "'".$record->{playerid}."',";
			$playerinfo->{num} += 1;
		}
		
		#当天创建角色数
		my $loginplayer_num = $playerinfo->{num};#当天登录角色数
		my $playerids = $playerinfo->{playerids};#当天登录角色数
		$playerids =~ s/,$//;
		
		$sql = "select count(*) as num from player pl where left(pl.c_addtime,10) = '$theday'";
		my $theday_create = $sdb->fetchAll($sql);
		my $theday_create_record = shift @$theday_create;
		my $create_num = $theday_create_record->{num};#当天该服创建角色数
		
		my $backinfo = {};
		$backinfo->{$theday}->{theday}->{create} = $create_num;
		$backinfo->{$theday}->{theday}->{login} = $loginplayer_num;
		
		#当天登录该服的角色在各注回头日期的创建情况
		foreach my $type (keys %$backdays){
			my $backday = $backdays->{$type};
			$sql = "select count(*) as num from player pl where left(pl.c_addtime,10) = '$backday' and pl.c_playerid in ($playerids);";
			my $back_login = $sdb->fetchAll($sql);
			my $back_login_record = shift @$back_login;
			my $longin_back_num = $back_login_record->{num};#在当天登录,并且在回头日期创建的用户
			
			$sql = "select sum(mu.create) as create_cout from meta_userback mu where mu.theday = '$backday';";
			my $back_create = $gas->fetchAll($sql);
			if(@$back_create){
				my $back_create_record = shift @$back_create;
				my $back_num = $back_create_record->{create_cout};#回头日期的 创建角色数量
				next if($back_num == 0);
				my $rate = sprintf("%.4f",($longin_back_num / $back_num));
				$rate =~ s/,//g;
				
				$backinfo->{$backday}->{$type}->{backnum} = $longin_back_num;
				$backinfo->{$backday}->{$type}->{rate} = $rate?$rate:0;
			}
			
		}

		foreach my $date (keys %$backinfo){
			foreach my $type (keys %{$backinfo->{$date}}){
				if($type eq 'theday'){
					my $create = $backinfo->{$date}->{$type}->{create};
					my $login = $backinfo->{$date}->{$type}->{login};
					#'`theday`,`serverid`,`create`,`login`,;
					my $sql_select = "select * from meta_daydatatotal where theday = '$date'";
					my $recordset_select = $gas->fetchAll($sql_select);
					if(@$recordset_select){
						my $sql_update = "update meta_daydatatotal set 
						`create`=$create, 
						`login`=$login, 
						`account` = $account_info,
						`active` = $active_info,
						`firstpay` = $firstpay_info,
						`amount` = $pay_info->{amount},
						`users` = $pay_info->{users},
						`num` = $pay_info->{num},
						`ave` = $pay_info->{ave}
						where theday='$theday'";
						$gas->_execute($sql_update);
						$this->{logger}->info($sql_update);
					}else{
						my $field = "(`theday`,`create`,`login`,`account`,`active`,`firstpay`,`amount`,`users`,`num`,`ave`)";
						my $row = "('$theday',$create,$login, $account_info,$active_info,$firstpay_info,$pay_info->{amount},$pay_info->{users},$pay_info->{num},$pay_info->{ave})";
						my $sql_insert = "insert into meta_daydatatotal $field values $row";
						$gas->_execute($sql_insert);
						$this->{logger}->info($sql_insert);
					}
				}else{
					my $backnum = $backinfo->{$date}->{$type}->{backnum};
					my $rate = $backinfo->{$date}->{$type}->{rate};
					my $field_rete = $type.'_rate';
					my $sql_update = "update meta_daydatatotal set $type = $backnum,$field_rete = $rate where theday = '$date';";
					$gas->_execute($sql_update);
					$this->{logger}->info($sql_update);
				}
			}
		}
	}else{
		my $sql_select = "select * from meta_daydatatotal where theday = '$theday'";
		my $recordset_select = $gas->fetchAll($sql_select);
		if(@$recordset_select){
			my $sql_update = "update meta_daydatatotal set 
			`create`= 0, 
			`login`= 0, 
			`account` = $account_info,
			`active` = $active_info,
			`firstpay` = $firstpay_info,
			`amount` = $pay_info->{amount},
			`users` = $pay_info->{users},
			`num` = $pay_info->{num},
			`ave` = $pay_info->{ave}
			where theday='$theday'";
			$gas->_execute($sql_update);
			$this->{logger}->info($sql_update);
		}else{
			my $field = "(`theday`,`create`,`login`,`account`,`active`,`firstpay`,`amount`,`users`,`num`,`ave`)";
			my $row = "('$theday',0,0, $account_info,$active_info,$firstpay_info,$pay_info->{amount},$pay_info->{users},$pay_info->{num},$pay_info->{ave})";
			my $sql_insert = "insert into meta_daydatatotal $field values $row";
			$gas->_execute($sql_insert);
			$this->{logger}->info($sql_insert);
		}
	}
}
1;
