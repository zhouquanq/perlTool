package Mods::Business::UpdataInfo;
use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;
sub new{
	shift();
	my $this = shift;

	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	bless $this;
	return $this;
}

sub run{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	for(my $start_sec = Mods::Lib::Common::ts2str($startday);$start_sec <= Mods::Lib::Common::ts2str($stopday);$start_sec += 86400){
		my $theday = Mods::Lib::Common::ts2str($start_sec, 1);
		$this->UpdatePlayerChannel($theday);
		$this->UpdatePlayer($theday);
		$this->UpdatePub();#更新pub表里和op对应关系
		$this->UpdataFirstserverid();#更新account表里和a_firstserverid对应关系
		# $this->Firstpay($theday);
	}
}


##########################################
###根据账号id查询出渠道名,然后更新到角色表
##########################################
sub UpdatePlayer{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	$this->{logger}->info("+++update c_pb start time()");

	#查询出角色表中未更新c_pb的a_id总数
	my $sql = "SELECT COUNT(DISTINCT(p.a_id)) AS aid_counts FROM player p WHERE p.c_pb IS NULL";
	my $recordset = $sdb->fetchAll($sql);
	my $aid_counts = $recordset->[0]->{aid_counts};
	my $cycle_times = 0;
	if($aid_counts > 1000) {
		$cycle_times = int($aid_counts/1000);
		$cycle_times = $cycle_times > 10 ? 10 : $cycle_times;
	} elsif ($aid_counts >= 1 && $aid_counts <= 1000) {
		$cycle_times = 1;
	} else {
		$cycle_times = 0;
	}
			
	while ($cycle_times-- > 0)
	{
		# print "+++last $cycle_times update c_pb start:".ts2str(time)."\n";
		#查询出1000个没更新c_pb的a_id
		$sql = "SELECT DISTINCT(p.a_id) FROM player p WHERE p.c_pb IS NULL LIMIT 1000";
		$recordset = $sdb->fetchAll($sql);
		
		my @a_ids;
		foreach my $record (@{$recordset}) {
			push @a_ids, "'$record->{a_id}'";
		}
		my $a_ids = join(",", @a_ids);
		$sql = "SELECT a.a_id, a.a_pb FROM account a WHERE a.a_id in ($a_ids)";
		$recordset = $sdb->fetchAll($sql);
		
		my $aid_pb = {};
		foreach my $record (@{$recordset}) {
			push @{$aid_pb->{$record->{a_pb}}} ,$record->{a_id};
		}
		
		foreach my $pub (keys %{$aid_pb}) {
			my $aids_str = join('\',\'', @{$aid_pb->{$pub}});
			$sql = "UPDATE player SET c_pb = '$pub' WHERE a_id IN ('$aids_str')";
			$sdb->_execute($sql);
		}
		# print "---last $cycle_times update c_pb stop:".ts2str(time)."\n";
	}

	$this->{logger}->info("---update c_pb stop time()");
}


##########################################
###根据账号id查询出运营商名,然后更新到角色表
##########################################
sub UpdatePlayerChannel{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	$this->{logger}->info("+++update c_channel start time()");
	
	#查询出角色表中未更新 c_channel 的a_id总数
	my $sql = "SELECT COUNT(DISTINCT(p.a_id)) AS aid_counts FROM player p WHERE p.c_channel = ''";
	my $recordset = $sdb->fetchAll($sql);
	my $aid_counts = $recordset->[0]->{aid_counts};
	my $cycle_times = 0;
	if($aid_counts > 1000) {
		$cycle_times = int($aid_counts/1000);
		$cycle_times = $cycle_times > 10 ? 10 : $cycle_times;
	} elsif ($aid_counts >= 1 && $aid_counts <= 1000) {
		$cycle_times = 1;
	} else {
		$cycle_times = 0;
	}
			
	while ($cycle_times-- > 0)
	{
		# print "+++last $cycle_times update c_channel start:".ts2str(time)."\n";
		#查询出1000个没更新 c_channel 的a_id
		$sql = "SELECT DISTINCT(p.a_id) FROM player p WHERE p.c_channel = '' LIMIT 1000";
		$recordset = $sdb->fetchAll($sql);
		
		my @a_ids;
		foreach my $record (@{$recordset}) {
			push @a_ids, "'$record->{a_id}'";
		}
		my $a_ids = join(",", @a_ids);
		$sql = "SELECT a.a_id, a.a_channel FROM account a WHERE a.a_id in ($a_ids)";
		$recordset = $sdb->fetchAll($sql);
		
		my $aid_channel = {};
		foreach my $record (@{$recordset}) {
			push @{$aid_channel->{$record->{a_channel}}} ,$record->{a_id};
		}
		
		foreach my $channel (keys %{$aid_channel}) {
			my $aids_str = join('\',\'', @{$aid_channel->{$channel}});
			$sql = "UPDATE player SET c_channel = '$channel' WHERE a_id IN ('$aids_str')";
			$sdb->_execute($sql);
		}
		# print "---last $cycle_times update c_channel stop:".ts2str(time)."\n";
	}
	$this->{logger}->info("---update c_channel stop time()");
}

sub UpdatePub{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	my $op = {};
	my $sql = "select * from op";
	my $recordset = $sdb->fetchAll($sql);
	foreach my $record (@{$recordset}){
		my $opname = $record->{opname};
		my $id = $record->{id};
		if($opname){
			$op->{$opname} = $id;
		}
	}

	my $pub = {};
	my $update_sql = undef;
	$sql = "select * from pub where op_id = ''";
	$recordset = $sdb->fetchAll($sql);
	foreach my $record (@{$recordset}){
		my $pubname = $record->{pubname};
		my $id = $record->{id};
		if($pubname =~ /_/){
			my @sz = split(/_/, $pubname);
			my $op_tmp = shift @sz;
			if(exists $op->{$op_tmp}){
				my $opid = $op->{$op_tmp};
				$update_sql = "update pub set op_id = $opid where id = $id;\n";
				$sdb->_execute($update_sql);
			}
		}else{
			my $op_tmp = $pubname;
			if(exists $op->{$op_tmp}){
				my $opid = $op->{$op_tmp};
				$update_sql = "update pub set op_id = $opid where id = $id;\n";
				$sdb->_execute($update_sql);
			}
		}
	}
	
#	if($update_sql){
#		$sdb->_execute($update_sql);
#	}
}

##########################################
##更新account.a_firstserverid
##########################################
sub UpdataFirstserverid {
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	my $sql = "SELECT a.a_id FROM account a WHERE a.a_firstserverid = 0";
	my $recordset = $sdb->fetchAll($sql);
	my @a_ids;
	foreach my $record (@{$recordset}) {
		push @a_ids, $record->{a_id};
	}
	my $a_ids = join("','", @a_ids);
		
	$sql = "SELECT p.a_id,p.c_serverid FROM player p
		WHERE p.a_id IN ('$a_ids')  AND p.c_serverid = p.c_originalsid
		ORDER BY p.c_index";
	$recordset = $sdb->fetchAll($sql);
	
	my @sql_update;
	my $i = 0;
	my %a_id_flag = ();
	foreach my $record (@$recordset) {
		my $c_serverid = $record->{c_serverid};
		my $a_id = $record->{a_id};
		unless(exists $a_id_flag{$a_id}){
			$sql_update[$i++] = "UPDATE account SET a_firstserverid = ".$record->{c_serverid}." WHERE a_id = '".$record->{a_id}."';\n";
			$a_id_flag{$a_id} = 1;
		}
	}
	
	while($i >= 0){
		$sdb->_execute($sql_update[$i--]);
	}
}


sub Firstpay{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};

	my $first_pay = {};#首充用户
	my $prev_pay = {};#以前充值
	my $cur_pay = {};#当天充值
	my $sql = "select pr.pr_channel, pr.pr_originalsid, pr.pr_playerid, count(pr.pr_playerid) 
			from payrecord pr 
			where left(pr.pr_addtime, 10) < '$theday' and pr.pr_success = 1 
			group by pr.pr_originalsid, pr.pr_playerid, pr.pr_channel";           
	my $recordset = $sdb->fetchAll($sql);
	if(scalar @{$recordset}){
		foreach my $record(@{$recordset}){
			my $opkey = $record->{'pr_channel'};
			my $serverid = $record->{'pr_originalsid'};
			my $playerid = $record->{'pr_playerid'};
			$prev_pay->{$opkey}->{$serverid}->{$playerid} = 1;
		}
	}
	
	$sql = "select pr.pr_channel, pr.pr_originalsid, pr.pr_playerid, count(pr.pr_playerid) 
			from payrecord pr 
			where left(pr.pr_addtime, 10) = '$theday' and pr.pr_success = 1 
			group by pr.pr_originalsid, pr.pr_playerid, pr.pr_channel";
	$recordset = $sdb->fetchAll($sql);
	if(scalar @{$recordset}){
		foreach my $record(@{$recordset}){
			my $opkey = $record->{'pr_channel'};
			my $serverid = $record->{'pr_originalsid'};
			my $playerid = $record->{'pr_playerid'};
			$cur_pay->{$opkey}->{$serverid}->{$playerid} = 1;
		}
	}
	
	foreach my $opkey (keys %{$cur_pay}){
		foreach my $serverid (keys %{$cur_pay->{$opkey}}){
			foreach my $playerid (keys %{$cur_pay->{$opkey}->{$serverid}}){
				$first_pay->{$opkey}->{$serverid}->{$playerid} = 1 unless(exists $prev_pay->{$opkey}->{$serverid}->{$playerid});
			}
		}
	}
}


1;
