package Mods::Business::Player;

use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;

sub new{
	shift();
	my $this = shift;

	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	bless $this;
	return $this;
}

sub run{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	for(my $start_sec = Mods::Lib::Common::str2ts($startday);$start_sec <= Mods::Lib::Common::str2ts($stopday);$start_sec += 86400){
		my $theday = Mods::Lib::Common::ts2str($start_sec, 1);
		# $this->account($theday);
		$this->newchar($theday);
		$this->{logger}->info("Model newchar");
		
		$this->newandoldchar($theday);
		$this->{logger}->info("Model newandoldchar");
	}
}

sub newchar{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};	
	#新注册角色
	my $sql = "SELECT LEFT(ch.c_addtime, 10) AS theday, ch.c_originalsid AS serverid, ac.a_pb AS pubkey,LEFT(ac.a_sdk, 7) AS sdk,COUNT(*) AS num, ac.a_channel
			FROM `player` ch INNER JOIN `account` ac ON  ch.a_id = ac.a_id
			WHERE LEFT(ch.c_addtime, 10) >= '$startday' AND LEFT(ch.c_addtime, 10) <= '$stopday'
			GROUP BY LEFT(ch.c_addtime, 10), ch.c_originalsid, ac.a_pb, LEFT(ac.a_sdk, 7), ac.a_channel";
			
	$this->{logger}->info($sql);
			
	my $recordset = $sdb->fetchAll($sql);
	my $row = undef;
	foreach my $record(@$recordset) {
		my $sdk = undef;
		if($record->{'sdk'} eq 'winphon'){
			$sdk = 'winphone8';
		}else{
			$sdk = $record->{'sdk'};
		}
		$row .= "('$record->{'theday'}',$record->{'serverid'},'$sdk',$record->{'num'},'$record->{'pubkey'}','$record->{'a_channel'}'),";
	}
	# $field = "`theday`,`serverid`,`pubid`,`sdk`,`num`, `opid`";
	my $field = "`theday`,`serverid`,`sdk`,`num`,`pub`,`op`";
	if($row && $row =~ s/,$//){
		$sql = "DELETE FROM meta_newchar WHERE theday >= '$startday' AND theday <= '$stopday'";
		#$sql = "DELETE FROM meta_newchar WHERE theday = '$theday'";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
		
		$sql = "INSERT INTO meta_newchar ($field) VALUES $row";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
	}
}


sub newandoldchar{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};

	my $total_char = {};
	my $old_char = {};
	my $new_char = {};
	
	my $sql = "SELECT pl.c_serverid, COUNT(*) as num FROM player pl GROUP BY pl.c_serverid";
	$this->{logger}->info($sql);
	
	my $recordset = $sdb->fetchAll($sql);
	foreach my $record(@$recordset) {
		my $serverid = $record->{'c_serverid'};
		my $num = $record->{'num'};
		$total_char->{$serverid} = $num;
	}
	
	$sql = "select ll.serverid, count(ll.playerid) as num from loginplayer ll 
			inner join player pl on ll.serverid = pl.c_serverid and ll.playerid = pl.c_playerid
			where ll.theday = '$theday' and left(pl.c_addtime, 10) = '$theday'
			group by ll.serverid";
			
	$this->{logger}->info($sql);
			
	$recordset = $sdb->fetchAll($sql);
	foreach my $record(@$recordset) {
		my $serverid = $record->{'serverid'};
		my $num = $record->{'num'};
		$old_char->{$serverid} = $num;
	}
	
	$sql = "select ll.serverid, count(ll.playerid) as num from loginplayer ll 
			inner join player pl on ll.serverid = pl.c_serverid and ll.playerid = pl.c_playerid
			where ll.theday = '$theday' and left(pl.c_addtime, 10) = '$theday'
			group by ll.serverid";
			
	$this->{logger}->info($sql);
	
	$recordset = $sdb->fetchAll($sql);
	foreach my $record(@$recordset) {
		my $serverid = $record->{'serverid'};
		my $num = $record->{'num'};
		$new_char->{$serverid} = $num;
	}
	
	
	my $row = undef;
	foreach my $serverid (keys %{$total_char}){
		my $total = $total_char->{$serverid};
		my $old = $old_char->{$serverid}?$old_char->{$serverid}:0;
		my $new = $new_char->{$serverid}?$new_char->{$serverid}:0;
		my $char = $old + $new;
		$row .= "('$theday',$serverid,$new,$old,$char,$total),";
	}
	
	my $field = "`theday`,`serverid`,`new_char`,`old_char`,`char`,`total_char`";
	if($row && $row =~ s/,$//){
		#$sql = "DELETE FROM meta_newandoldchar WHERE theday >= '$startday' AND theday <= '$stopday'";
		$sql = "DELETE FROM meta_newandoldchar WHERE theday = '$theday'";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
		
		$sql = "INSERT INTO meta_newandoldchar ($field) VALUES $row";
		$this->{logger}->info($sql);
		$gas->_execute($sql);
	}
	
}
1;
