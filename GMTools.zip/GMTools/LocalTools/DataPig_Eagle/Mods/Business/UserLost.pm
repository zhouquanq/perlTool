package Mods::Business::UserLost;

use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;

sub new{
	shift();
	my $this = shift;

	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	bless $this;
	return $this;
}

sub run{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	for(my $start_sec = Mods::Lib::Common::str2ts($startday);$start_sec <= Mods::Lib::Common::str2ts($stopday);$start_sec += 86400){
		my $theday = Mods::Lib::Common::ts2str($start_sec, 1);
		# $this->account($theday);
		$this->playerlost($theday);#用户流失(等级)
		$this->{logger}->info("Model playerback");
	}
}

sub playerlost{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};	
	
	#当天登录角色数
	return if(Mods::Lib::Common::ts2str(time,1) eq $theday);

	my $lostday = Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*8,1);
	my $day = Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400,1);
	
	my $playerlost = {};
	my $sql = "select ll.theday,ll.serverid, ll.playerid,ll.`level` from loginplayer ll where ll.theday = '$lostday'";
	my $recordset = $sdb->fetchAll($sql);
	if(@$recordset){
		foreach my $record (@$recordset){
			my $serverid = $record->{serverid};
			my $playerid = $record->{playerid};
			my $level = $record->{level};
			
			$playerlost->{$serverid}->{$playerid} = $level;
		}
	}
	
	foreach my $serverid (keys %{$playerlost}){
		my $playerids = join('\',\'', keys %{$playerlost->{$serverid}});
		$sql = "select ll.theday,ll.serverid, ll.playerid,ll.`level` from loginplayer ll 
		where ll.serverid = $serverid and ll.theday > '$lostday' and ll.theday <= '$day'
		and ll.playerid in ('$playerids')";
		
		$recordset = $sdb->fetchAll($sql);
		if(@$recordset){
			foreach my $record (@$recordset){
				delete $playerlost->{$serverid}->{$record->{playerid}};
			}
		}
	}
	
	my $row = undef;
	foreach my $serverid (keys %{$playerlost}){
		foreach my $playerid (keys %{$playerlost->{$serverid}}){
			my $level = $playerlost->{$serverid}->{$playerid};
			$row .= "('$lostday',$serverid,'$playerid',$level),";
		}
	}
	
	my $field = "(`theday`,`serverid`,`playerid`,`level`)";
	
	if($row && $row =~ s/,$//){
		my $sql_delete = "delete from meta_playerlost where theday = '$lostday';";
		$gas->_execute($sql_delete);
		$this->{logger}->info($sql_delete);
		
		my $sql_insert = "insert into meta_playerlost $field values $row;";
		$gas->_execute($sql_insert);
		$this->{logger}->info($sql_insert);
	}
}

1;
