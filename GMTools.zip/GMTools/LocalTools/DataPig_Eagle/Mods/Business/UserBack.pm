package Mods::Business::UserBack;

use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;

sub new{
	shift();
	my $this = shift;

	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	bless $this;
	return $this;
}

sub run{
	my($this) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	for(my $start_sec = Mods::Lib::Common::str2ts($startday);$start_sec <= Mods::Lib::Common::str2ts($stopday);$start_sec += 86400){
		my $theday = Mods::Lib::Common::ts2str($start_sec, 1);
		# $this->account($theday);
		$this->playerback($theday);#角色回头
		$this->{logger}->info("Model playerback");
		
		$this->playeractiveback($theday);#活跃角色回头
		$this->{logger}->info("Model playeractiveback");
		
		$this->playerbacktmp($theday);#角色回头
		$this->{logger}->info("Model playerbacktmp");
		
		$this->playeractivebacktmp($theday);
		$this->{logger}->info("Model playeractivebacktmp");
	}
}

sub playerback{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};	
	
	#当天登录角色数
	return if(Mods::Lib::Common::ts2str(time,1) eq $theday);

	my $backdays = {
		'yester' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400,1),#昨注回头日期,
		'three' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*2,1),#三注回头日期
		'four' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*3,1),#四注回头日期
		'five' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*4,1),#五注回头日期
		'six' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*5,1),#六注回头日期
		'seven' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*6,1),#七注回头日期
		'fifteen' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*14,1),#十五注回头日期
		'thirty' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*29,1),#三十注回头日期
	};
	
	#当天登录角色信息
	my $sql = "select ll.serverid, ll.playerid from loginplayer ll where ll.theday = '$theday'";
	my $recordset = $sdb->fetchAll($sql);
	if(@$recordset){
		my $playerinfo = {};#当天登录角色的所有id
		foreach my $record (@$recordset){
			$playerinfo->{$record->{serverid}}->{playerids} .= "'".$record->{playerid}."',";
			$playerinfo->{$record->{serverid}}->{num} += 1;
		}
		
		#当天创建角色数
		foreach my $serverid (keys %$playerinfo){
			my $loginplayer_num = $playerinfo->{$serverid}->{num};#当天登录角色数
			my $playerids = $playerinfo->{$serverid}->{playerids};#当天登录角色数
			$playerids =~ s/,$//;
			
			$sql = "select count(*) as num from player pl where left(pl.c_addtime,10) = '$theday' and pl.c_serverid = $serverid";
			my $theday_create = $sdb->fetchAll($sql);
			my $theday_create_record = shift @$theday_create;
			my $create_num = $theday_create_record->{num};#当天该服创建角色数
			
			my $backinfo = {};
			$backinfo->{$theday}->{theday}->{create} = $create_num;
			$backinfo->{$theday}->{theday}->{login} = $loginplayer_num;
			
			#当天登录该服的角色在各注回头日期的创建情况
			foreach my $type (keys %$backdays){
				my $backday = $backdays->{$type};
				$sql = "select count(*) as num from player pl where left(pl.c_addtime,10) = '$backday' and pl.c_playerid in ($playerids) and pl.c_serverid = $serverid;";
				my $back_login = $sdb->fetchAll($sql);
				my $back_login_record = shift @$back_login;
				my $longin_back_num = $back_login_record->{num};#在当天登录,并且在回头日期创建的用户
				
				$sql = "select mu.create from meta_userback mu where mu.theday = '$backday' and mu.serverid = $serverid;";
				my $back_create = $gas->fetchAll($sql);
				if(@$back_create){
					my $back_create_record = shift @$back_create;
					my $back_num = $back_create_record->{create};#回头日期的 创建角色数量
					next if($back_num == 0);
					my $rate = sprintf("%.4f",($longin_back_num / $back_num));
					
					$backinfo->{$backday}->{$type}->{backnum} = $longin_back_num;
					$backinfo->{$backday}->{$type}->{rate} = $rate;
				}
				
			}
			
			foreach my $date (keys %$backinfo){
				foreach my $type (keys %{$backinfo->{$date}}){
					if($type eq 'theday'){
						my $create = $backinfo->{$date}->{$type}->{create};
						my $login = $backinfo->{$date}->{$type}->{login};
						#'`theday`,`serverid`,`create`,`login`,;
						my $sql_select = "select * from meta_userback where theday = '$date' and serverid = $serverid";
						my $recordset_select = $gas->fetchAll($sql_select);
						if(@$recordset_select){
							my $sql_update = "update meta_userback set `create`=$create, `login`=$login where theday='$theday' and serverid=$serverid";
							$gas->_execute($sql_update);
							$this->{logger}->info($sql_update);
						}else{
							my $field = "(`theday`,`serverid`,`create`,`login`)";
							my $row = "('$theday',$serverid,$create,$login)";
							my $sql_insert = "insert into meta_userback $field values $row";
							$gas->_execute($sql_insert);
							$this->{logger}->info($sql_insert);
						}
					}else{
						my $backnum = $backinfo->{$date}->{$type}->{backnum};
						my $rate = $backinfo->{$date}->{$type}->{rate};
						my $field_rete = $type.'_rate';
						my $sql_update = "update meta_userback set $type = $backnum,$field_rete = $rate where theday = '$date' and serverid=$serverid;";
						$gas->_execute($sql_update);
						$this->{logger}->info($sql_update);
					}
				}
			}
		}
	}
}

sub playerbacktmp{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};	
	
	#当天登录角色数
	return if(Mods::Lib::Common::ts2str(time,1) eq $theday);

	my $backdays = {
		'yester' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400,1),#昨注回头日期,
		'three' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*2,1),#三注回头日期
		'four' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*3,1),#四注回头日期
		'five' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*4,1),#五注回头日期
		'six' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*5,1),#六注回头日期
		'seven' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*6,1),#七注回头日期
		'fifteen' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*14,1),#十五注回头日期
		'thirty' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*29,1),#三十注回头日期
	};
	
	#之前的老角色
	# my $sql = "select pl.c_serverid,pl.c_playerid from account_prev ac inner join player pl on ac.a_id = pl.a_id";
	my $sql = "select pl.c_serverid,pl.c_playerid from account ac inner join player pl on ac.a_id = pl.a_id where ac.a_imei in (select distinct imei from imei_old)";
	my $recordset = $sdb->fetchAll($sql);
	my $playerinfo_prev = {};#当天登录角色的所有id
	foreach my $record (@$recordset){
		$playerinfo_prev->{$record->{c_serverid}}->{$record->{c_playerid}} = 1;
	}
	#当天登录角色信息
	$sql = "select ll.serverid, ll.playerid from loginplayer ll where ll.theday = '$theday'";
	$recordset = $sdb->fetchAll($sql);
	if(@$recordset){
		my $playerinfo = {};#当天登录角色的所有id
		foreach my $record (@$recordset){
			if(!exists $playerinfo_prev->{$record->{serverid}}->{$record->{playerid}}){
				$playerinfo->{$record->{serverid}}->{playerids} .= "'".$record->{playerid}."',";
				$playerinfo->{$record->{serverid}}->{num} += 1;
			}
		}
		
		#当天创建角色数
		foreach my $serverid (keys %$playerinfo){
			my $loginplayer_num = $playerinfo->{$serverid}->{num};#当天登录角色数
			my $playerids = $playerinfo->{$serverid}->{playerids};#当天登录角色数
			$playerids =~ s/,$//;
			
			my $prev_players = join('\',\'',keys %{$playerinfo_prev->{$serverid}});
			$sql = "select count(*) as num from player pl where left(pl.c_addtime,10) = '$theday' and pl.c_serverid = $serverid and pl.c_playerid not in ('$prev_players')";
			my $theday_create = $sdb->fetchAll($sql);
			my $theday_create_record = shift @$theday_create;
			my $create_num = $theday_create_record->{num};#当天该服创建角色数
			
			my $backinfo = {};
			$backinfo->{$theday}->{theday}->{create} = $create_num;
			$backinfo->{$theday}->{theday}->{login} = $loginplayer_num;
			
			#当天登录该服的角色在各注回头日期的创建情况
			foreach my $type (keys %$backdays){
				my $backday = $backdays->{$type};
				$sql = "select count(*) as num from player pl where left(pl.c_addtime,10) = '$backday' and pl.c_playerid in ($playerids) and pl.c_serverid = $serverid  and pl.c_playerid not in ('$prev_players');";
				my $back_login = $sdb->fetchAll($sql);
				my $back_login_record = shift @$back_login;
				my $longin_back_num = $back_login_record->{num};#在当天登录,并且在回头日期创建的用户
				
				$sql = "select mu.create from meta_userback_new mu where mu.theday = '$backday' and mu.serverid = $serverid";
				my $back_create = $gas->fetchAll($sql);
				if(@$back_create){
					my $back_create_record = shift @$back_create;
					my $back_num = $back_create_record->{create};#回头日期的 创建角色数量
					next if($back_num == 0);
					my $rate = sprintf("%.4f",($longin_back_num / $back_num));
					
					$backinfo->{$backday}->{$type}->{backnum} = $longin_back_num;
					$backinfo->{$backday}->{$type}->{rate} = $rate;
				}
				
			}

			foreach my $date (keys %$backinfo){
				foreach my $type (keys %{$backinfo->{$date}}){
					if($type eq 'theday'){
						my $create = $backinfo->{$date}->{$type}->{create};
						my $login = $backinfo->{$date}->{$type}->{login};
						#'`theday`,`serverid`,`create`,`login`,;
						my $sql_select = "select * from meta_userback_new where theday = '$date' and serverid = $serverid";
						my $recordset_select = $gas->fetchAll($sql_select);
						if(@$recordset_select){
							my $sql_update = "update meta_userback_new set `create`=$create, `login`=$login where theday='$theday' and serverid=$serverid";
							$gas->_execute($sql_update);
							$this->{logger}->info($sql_update);
						}else{
							my $field = "(`theday`,`serverid`,`create`,`login`)";
							my $row = "('$theday',$serverid,$create,$login)";
							my $sql_insert = "insert into meta_userback_new $field values $row";
							$gas->_execute($sql_insert);
							$this->{logger}->info($sql_insert);
						}
					}else{
						my $backnum = $backinfo->{$date}->{$type}->{backnum};
						my $rate = $backinfo->{$date}->{$type}->{rate};
						my $field_rete = $type.'_rate';
						my $sql_update = "update meta_userback_new set $type = $backnum,$field_rete = $rate where theday = '$date' and serverid=$serverid;";
						$gas->_execute($sql_update);
						$this->{logger}->info($sql_update);
					}
				}
			}
		}
	}
}


sub playeractiveback{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	#当天登录角色数
	return if(Mods::Lib::Common::ts2str(time,1) eq $theday);

	my $backdays = {
		'yester' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400,1),#昨注回头日期,
		'three' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*2,1),#三注回头日期
		'four' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*3,1),#四注回头日期
		'five' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*4,1),#五注回头日期
		'six' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*5,1),#六注回头日期
		'seven' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*6,1),#七注回头日期
		'fifteen' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*14,1),#十五注回头日期
		'thirty' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*29,1),#三十注回头日期
	};
	
	my $playerinfo = {};
	my $sql = "select ll.serverid,ll.playerid from loginplayer ll where ll.theday = '$theday' and ll.times >= 600";
	my $recordset = $sdb->fetchAll($sql);
	if(@$recordset){
		foreach my $record (@$recordset){
			my $serverid = $record->{serverid};
			my $playerid = $record->{playerid};
			$playerinfo->{$serverid}->{playerids} .= "'".$playerid."',";
			$playerinfo->{$serverid}->{num} += 1;
		}
		
		foreach my $serverid (keys %$playerinfo){
			my $active_num = $playerinfo->{$serverid}->{num};
			my $playerids = $playerinfo->{$serverid}->{playerids};
			$playerids =~ s/,$//;
			#当天注册活跃
			$sql = "select count(*) as num from player pl where left(pl.c_addtime,10) = '$theday' and pl.c_serverid = $serverid and pl.c_playerid in ($playerids)";
			my $theday_active = $sdb->fetchAll($sql);
			my $theday_active_record = shift @$theday_active;
			my $create_active_num = $theday_active_record->{num};#当天注册活跃人数
			
			my $playeractivebackinfo = {};
			$playeractivebackinfo->{$theday}->{theday}->{active} = $active_num;
			$playeractivebackinfo->{$theday}->{theday}->{create_active} = $create_active_num;
			
			foreach my $type (keys %$backdays){
				my $backday = $backdays->{$type};
				
				$sql = "select count(*) as num from loginplayer ll 
				inner join player pl on ll.serverid = pl.c_serverid and ll.playerid = pl.c_playerid
				where ll.theday = '$backday' and ll.times >= 600 and ll.playerid in ($playerids) and left(pl.c_addtime,10) = '$backday'";
				
				my $backday_active = $sdb->fetchAll($sql);
				my $backday_active_record = shift @$backday_active;
				my $backday_active_num = $backday_active_record->{num};
				
				$sql = "select count(*) as num from loginplayer ll 
				inner join player pl on ll.serverid = pl.c_serverid and ll.playerid = pl.c_playerid
				where ll.theday = '$backday' and ll.times >= 600 and left(pl.c_addtime,10) = '$backday' and ll.serverid = $serverid;";
				
				my $backday_create_active = $sdb->fetchAll($sql);
				my $backday_create_active_record = shift @$backday_create_active;
				my $backday_create_active_num = $backday_create_active_record->{num};
				next if($backday_create_active_num == 0);
				$playeractivebackinfo->{$backday}->{$type}->{active} = $backday_active_num;
				$playeractivebackinfo->{$backday}->{$type}->{rate} = sprintf("%.4f", $backday_active_num / $backday_create_active_num);
			}
			
			foreach my $date (keys %$playeractivebackinfo){
				foreach my $type (keys %{$playeractivebackinfo->{$date}}){
					if($type eq 'theday'){
						my $active_num = $playeractivebackinfo->{$date}->{theday}->{active};
						my $create_active_num = $playeractivebackinfo->{$date}->{theday}->{create_active};
						my $sql_select = "select * from meta_useractiveback where theday = '$date' and serverid = $serverid";
						my $recordset = $gas->fetchAll($sql_select);
						if(@$recordset){
							my $sql_update = "update meta_useractiveback set active=$active_num, create_active=$create_active_num where theday='$theday' and serverid=$serverid";
							$gas->_execute($sql_update);
							$this->{logger}->info($sql_update);
						}else{
							my $field = "(`theday`,`serverid`,`active`,`create_active`)";
							my $row = "('$theday',$serverid,$active_num,$create_active_num)";
							my $sql_insert = "insert into meta_useractiveback $field values $row";
							$gas->_execute($sql_insert);
							$this->{logger}->info($sql_insert);
						}
					}else{
						my $backday_num = $playeractivebackinfo->{$date}->{$type}->{active};
						my $rate = $playeractivebackinfo->{$date}->{$type}->{rate};
						my $field_rete = $type.'_rate';
						my $sql_update = "update meta_useractiveback set $type = $backday_num,$field_rete = $rate where theday = '$date' and serverid=$serverid;";
						$gas->_execute($sql_update);
						$this->{logger}->info($sql_update);
					}
				}
			}
		}
	}
}

sub playeractivebacktmp{
	my($this, $theday) = @_;
	
	my $startday = $this->{startday};
	my $stopday = $this->{endday};
	my $sdb = $this->{db}->{sdb};
	my $gas = $this->{db}->{gas};
	
	#当天登录角色数
	return if(Mods::Lib::Common::ts2str(time,1) eq $theday);

	my $backdays = {
		'yester' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400,1),#昨注回头日期,
		'three' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*2,1),#三注回头日期
		'four' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*3,1),#四注回头日期
		'five' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*4,1),#五注回头日期
		'six' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*5,1),#六注回头日期
		'seven' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*6,1),#七注回头日期
		'fifteen' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*14,1),#十五注回头日期
		'thirty' => Mods::Lib::Common::ts2str(Mods::Lib::Common::str2ts($theday)-86400*29,1),#三十注回头日期
	};
	
	#之前的老角色
	# my $sql = "select pl.c_serverid,pl.c_playerid from account_prev ac inner join player pl on ac.a_id = pl.a_id";
	my $sql = "select pl.c_serverid,pl.c_playerid from account ac inner join player pl on ac.a_id = pl.a_id where ac.a_imei in (select distinct imei from imei_old)";
	my $recordset = $sdb->fetchAll($sql);
	my $playerinfo_prev = {};#当天登录角色的所有id
	foreach my $record (@$recordset){
		$playerinfo_prev->{$record->{c_serverid}}->{$record->{c_playerid}} = 1;
	}
	
	my $playerinfo = {};
	$sql = "select ll.serverid,ll.playerid from loginplayer ll where ll.theday = '$theday' and ll.times >= 600";
	$recordset = $sdb->fetchAll($sql);
	if(@$recordset){
		foreach my $record (@$recordset){
			my $serverid = $record->{serverid};
			my $playerid = $record->{playerid};
			if(!exists $playerinfo_prev->{$serverid}->{$playerid}){
				$playerinfo->{$serverid}->{playerids} .= "'".$playerid."',";
				$playerinfo->{$serverid}->{num} += 1;
			}
		}
		
		foreach my $serverid (keys %$playerinfo){
			my $active_num = $playerinfo->{$serverid}->{num};
			my $playerids = $playerinfo->{$serverid}->{playerids};
			$playerids =~ s/,$//;
			
			my $prev_players = join('\',\'',keys %{$playerinfo_prev->{$serverid}});
			
			#当天注册活跃
			$sql = "select count(*) as num from player pl where left(pl.c_addtime,10) = '$theday' and pl.c_serverid = $serverid and pl.c_playerid in ($playerids) and pl.c_playerid not in ('$prev_players')";
			my $theday_active = $sdb->fetchAll($sql);
			my $theday_active_record = shift @$theday_active;
			my $create_active_num = $theday_active_record->{num};#当天注册活跃人数
			
			my $playeractivebackinfo = {};
			$playeractivebackinfo->{$theday}->{theday}->{active} = $active_num;
			$playeractivebackinfo->{$theday}->{theday}->{create_active} = $create_active_num;
			
			foreach my $type (keys %$backdays){
				my $backday = $backdays->{$type};
				
				$sql = "select count(*) as num from loginplayer ll 
				inner join player pl on ll.serverid = pl.c_serverid and ll.playerid = pl.c_playerid
				where ll.theday = '$backday' and ll.times >= 600 and ll.playerid in ($playerids) and left(pl.c_addtime,10) = '$backday'  and pl.c_playerid not in ('$prev_players')";
				
				my $backday_active = $sdb->fetchAll($sql);
				my $backday_active_record = shift @$backday_active;
				my $backday_active_num = $backday_active_record->{num};
				
				$sql = "select count(*) as num from loginplayer ll 
				inner join player pl on ll.serverid = pl.c_serverid and ll.playerid = pl.c_playerid
				where ll.theday = '$backday' and ll.times >= 600 and left(pl.c_addtime,10) = '$backday'  and pl.c_playerid not in ('$prev_players') and ll.serverid = $serverid;";
				
				my $backday_create_active = $sdb->fetchAll($sql);
				my $backday_create_active_record = shift @$backday_create_active;
				my $backday_create_active_num = $backday_create_active_record->{num};
				next if($backday_create_active_num == 0);
				$playeractivebackinfo->{$backday}->{$type}->{active} = $backday_active_num;
				$playeractivebackinfo->{$backday}->{$type}->{rate} = sprintf("%.4f", $backday_active_num / $backday_create_active_num);
			}
			
			foreach my $date (keys %$playeractivebackinfo){
				foreach my $type (keys %{$playeractivebackinfo->{$date}}){
					if($type eq 'theday'){
						my $active_num = $playeractivebackinfo->{$date}->{theday}->{active};
						my $create_active_num = $playeractivebackinfo->{$date}->{theday}->{create_active};
						my $sql_select = "select * from meta_useractiveback_new where theday = '$date' and serverid = $serverid";
						my $recordset = $gas->fetchAll($sql_select);
						if(@$recordset){
							my $sql_update = "update meta_useractiveback_new set active=$active_num, create_active=$create_active_num where theday='$theday' and serverid=$serverid";
							$gas->_execute($sql_update);
							$this->{logger}->info($sql_update);
						}else{
							my $field = "(`theday`,`serverid`,`active`,`create_active`)";
							my $row = "('$theday',$serverid,$active_num,$create_active_num)";
							my $sql_insert = "insert into meta_useractiveback_new $field values $row";
							$gas->_execute($sql_insert);
							$this->{logger}->info($sql_insert);
						}
					}else{
						my $backday_num = $playeractivebackinfo->{$date}->{$type}->{active};
						my $rate = $playeractivebackinfo->{$date}->{$type}->{rate};
						my $field_rete = $type.'_rate';
						my $sql_update = "update meta_useractiveback_new set $type = $backday_num,$field_rete = $rate where theday = '$date' and serverid=$serverid;";
						$gas->_execute($sql_update);
						$this->{logger}->info($sql_update);
					}
				}
			}
		}
	}
}

1;
