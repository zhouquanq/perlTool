package Mods::Factory;

use strict;
use Mods::Lib::MysqlX;
use Mods::Lib::Common;
use Data::Dumper;
use Mods::Business::Account;
use Mods::Business::Lost;
use Mods::Business::Player;
use Mods::Business::Pay;
use Mods::Business::PubInfo;
use Mods::Business::UpdataInfo;
use Mods::Business::UserBack;
use Mods::Business::FirstPay;
use Mods::Business::OperationData;
use Mods::Business::UserPay;
use Mods::Business::Activity;
use Mods::Business::Level;
use Mods::Business::Mall;
use Mods::Business::Driver;

sub new{
	shift();
	my $this = shift();
	if(!$this->{startday} || !$this->{endday} || !$this->{db} || !$this->{logger}){
		die("param Invalid!");
	}
	
	$this->{mode_list} = [];
	bless $this;
	$this->Init();

	return $this;
}

sub Init{
	my ($this) = @_;
	
	push @{$this->{mode_list}},Mods::Business::UpdataInfo->new({startday => $this->{startday},endday => $this->{endday},db => $this->{db},logger => $this->{logger}});
	push @{$this->{mode_list}},Mods::Business::Account->new({startday => $this->{startday},endday => $this->{endday},db => $this->{db},logger => $this->{logger}});
	push @{$this->{mode_list}},Mods::Business::Lost->new({startday => $this->{startday},endday => $this->{endday},db => $this->{db},logger => $this->{logger}});
	push @{$this->{mode_list}},Mods::Business::Player->new({startday => $this->{startday},endday => $this->{endday},db => $this->{db},logger => $this->{logger}});
	push @{$this->{mode_list}},Mods::Business::Pay->new({startday => $this->{startday},endday => $this->{endday},db => $this->{db},logger => $this->{logger}});
	push @{$this->{mode_list}},Mods::Business::PubInfo->new({startday => $this->{startday},endday => $this->{endday},db => $this->{db},logger => $this->{logger}});
	push @{$this->{mode_list}},Mods::Business::UserBack->new({startday => $this->{startday},endday => $this->{endday},db => $this->{db},logger => $this->{logger}});
	push @{$this->{mode_list}},Mods::Business::FirstPay->new({startday => $this->{startday},endday => $this->{endday},db => $this->{db},logger => $this->{logger}});
	push @{$this->{mode_list}},Mods::Business::OperationData->new({startday => $this->{startday},endday => $this->{endday},db => $this->{db},logger => $this->{logger}});
	push @{$this->{mode_list}},Mods::Business::UserPay->new({startday => $this->{startday},endday => $this->{endday},db => $this->{db},logger => $this->{logger}});
	push @{$this->{mode_list}},Mods::Business::Activity->new({startday => $this->{startday},endday => $this->{endday},db => $this->{db},logger => $this->{logger}});
	push @{$this->{mode_list}},Mods::Business::Level->new({startday => $this->{startday},endday => $this->{endday},db => $this->{db},logger => $this->{logger}});
	push @{$this->{mode_list}},Mods::Business::Mall->new({startday => $this->{startday},endday => $this->{endday},db => $this->{db},logger => $this->{logger}});
	push @{$this->{mode_list}},Mods::Business::Driver->new({startday => $this->{startday},endday => $this->{endday},db => $this->{db},logger => $this->{logger}});
	
	# $this->{logger}->info();
}

sub getlist{
	my ($this) = @_;

	return $this->{mode_list};
}

sub destroy{
	my ($this) = @_;
	$this->{mode_list} = [];
}

1;
