
package Mods::Lib::Config;

use Data::Dumper;
sub new
{
	my $class = shift;
	my $cfg = shift;
	
	my $this = {};
	$this = bless($this, $class);
	$this->load_ini($cfg);
	return $this;
}

sub load_ini
{
	my ($this, $file) = @_;

    return $this->load_ini_from_buffer($this->readin($file));
}

sub readin
{
    my ($this, $file) = @_;

    my $len = -s $file;
	
    return "" unless $len > 0;

    my $f;
    open $f, $file;
    binmode $f;
    my $cont = "";
    sysread($f, $cont, $len);
    close $f;
    return $cont;
}

sub get_section_value
{
	my ($this, $section, $key, $default_value) = @_;

	for (@{$section->{'kvs'}}) {
		my $kv = $_;

		if (lc($kv->{'key'}) eq lc($key)) {
			if (length($kv->{'value'})>0) {
				return $kv->{'value'};
			}

			return defined($default_value)?$default_value:"";
		}
	}

	return defined($default_value)?$default_value:"";
}

sub load_ini_from_buffer
{
    my ($this, $buffer) = @_;

    my @lines = split(/\r?\n/, $buffer);

	my @ret;
	my $section_name = "";
	my $kvs;

	for(@lines)
	{
		my $line = $_;
		next if $line=~ /^\s*$/ or $line =~ /^\s*\#/;

		$line =~ s/^\s+//;
		$line =~ s/\s+$//;

		if ($line =~ /^\[([^\]]+)\]$/) {
			my $tmp_name = $1;
			$tmp_name =~ s/^\s+//;
			$tmp_name =~ s/\s+$//;

			if (length($section_name) > 0) {
				my %ini_info;
				$ini_info{'name'} = $section_name;
				$ini_info{'kvs'} = $kvs;

				push @ret, \%ini_info;
			}

			my @arKvs;
			$kvs = \@arKvs;
			$section_name = $tmp_name;
		}
		elsif ($line =~ /^([^=]+)=(.*)$/){
			my $key = $1;
			my $value = $2;

			$key =~ s/^\s+//;
			$key =~ s/\s+$//;

			$value =~ s/^\s+//;
			$value =~ s/\s+$//;

			if (length($section_name) > 0) {
				my $value_ = {};
				if ($value =~ /\s*,\s*/) {
					$value_ = {split(/\s*,\s*/, $value)};
				} else {
					die("db param error");
				}
				my %kv;
				$kv{'key'} = $key;
				$kv{'value'} = $value_;
				push @{$kvs}, \%kv;
			}
		}
	}

	if (length($section_name) > 0) {
		my %ini_info;
		$ini_info{'name'} = $section_name;
		$ini_info{'kvs'} = $kvs;

		push @ret, \%ini_info;
	}

	$this->{cfg} = \@ret;
	return $this;
}

sub getCfg{
	my ($this) = @_;
	
	return $this->{cfg};
}

return 1;