#!/usr/bin/perl
#注意: 合服时不能执行本程序,因为合服时修改serverllist表中的字段可能导致清理错误的信息
BEGIN{
	use FindBin;
	$::APPLICATION_PATH = $FindBin::Bin;
	$::PARENT_PATH = $::APPLICATION_PATH."/../";
	push( @INC, $::APPLICATION_PATH, $::PARENT_PATH);
	chdir( $::APPLICATION_PATH);
	
	$::APPLICATION_ISRUN = 1;
	
	# 防止意外关闭
	$SIG{HUP} = sub {};
	$SIG{INT} = sub { $::APPLICATION_ISRUN = 0;};
	$| = 1;
}

use strict;
use warnings;
use Data::Dumper;
use POSIX qw(strftime);
use utf8;

require 'common.pl';
use MysqlX;

my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
my $cfg_file = "$base_file.cfg";
die "cfg file: '$cfg_file' not exists!" unless -e $cfg_file;

eval {
	main();
};
warn $@ if $@;

sub main {
		my $cfg_ini = load_ini($cfg_file);
		
		foreach my $section(@{$cfg_ini}) {
			my $sdbdb = get_section_value($section, 'sdbdb', '');
			my $gasdb = get_section_value($section, 'gasdb', '');	
			my %sdbdb_hash = str2arr($sdbdb);	
			my %gasdb_hash = str2arr($gasdb);
			
			my $sdbcon = MysqlX::genConn(\%sdbdb_hash);
			my $sdbdbhd = new MysqlX($sdbcon);
			
			my $gascon = MysqlX::genConn(\%gasdb_hash);
			my $gasdbhd = new MysqlX($gascon);
			
			my $starttime1 = ts2str(time());
			clean_player($sdbdbhd, $gasdbhd);
			my $starttime2 = ts2str(time());
			clean_payrecord($sdbdbhd, $gasdbhd);
			my $stoptime = ts2str(time());
			log2("---starttime1: $starttime1");
			log2("---starttime2: $starttime2");
			log2("---stoptime: $stoptime");
		}
}

sub clean_player {
	my ($sdbdbhd, $gasdbhd) = @_;
	#步骤1:查找serverlist.servermergeto为0的服务器id(没有被合掉的服务器)
	my $sql = "SELECT s.sl_id FROM serverlist s WHERE s.servermergeto = 0";
	my $recordset = $gasdbhd->fetchAll($sql);
	my $sids_arr = [];
	foreach my $record (@$recordset) {
		push @$sids_arr, $record->{sl_id};
	}
	return unless scalar(@$sids_arr);
	my $sids_str = join(',', @$sids_arr); 
	
	
	#步骤2:删除角色表中被合掉的服务器的中间服务器(非角色初始服务器)的角色信息(当记录的serverid不在步骤1的服务器列表内,并且ismerge=1,就删除该条记录)
	$sql = "DELETE FROM `character` WHERE c_serverid NOT IN ($sids_str) AND c_ismerged = 1";
	log2("delete sql :\n $sql");
	my $result = $sdbdbhd->_execute($sql);
	log2("execute delete sql success 执行成功");
	log2("delete $result records");
	
	#此时 角色表中只有原始和最新的两条(或一条---只有新注册纪录)记录
	
	#步骤3: 将新字段c_originalsid加到sdb数据库中
	$sql = "ALTER TABLE `character` ADD COLUMN `c_originalsid` TINYINT(5) NOT NULL DEFAULT '0' AFTER `c_bserverid`";
	log2("alter sql :\n $sql");
	$sdbdbhd->_execute($sql);
	log2("execute alter sql success");
	
	#步骤4: 将原始记录的serverid写到新纪录的新字段c_originalsid中
	#查找可以更新 c_originalsid 字段的记录
	$sql = "SELECT p.c_charactername FROM `character` p WHERE p.c_serverid IN ($sids_str) AND p.c_ismerged = 1";
	$recordset = $sdbdbhd->fetchAll($sql);
	my $cnames_arr = [];
	foreach my $record (@$recordset) {
		push @$cnames_arr, $record->{c_charactername};
	}
	return unless scalar(@$cnames_arr);
	my $cnames_str = join("','", @$cnames_arr);
	$cnames_str = "'".$cnames_str."'";
	
	#查找需要更新成的内容
	$sql = "SELECT p.c_charactername, p.c_serverid FROM `character` p WHERE p.c_charactername IN ($cnames_str) AND p.c_serverid NOT IN ($sids_str)";
	$recordset = $sdbdbhd->fetchAll($sql);
	foreach my $record (@$recordset) {
		my $cname = $record->{c_charactername};
		my $originalsid = $record->{c_serverid};
		my $sql_update = "UPDATE `character` SET c_originalsid = $originalsid WHERE c_charactername = '$cname' AND c_serverid IN ($sids_str)";
		#log2("update sql1 : \n $sql_update");
		$sdbdbhd->_execute($sql_update);
	}
	log2("execute update sql1 success");
	
	#删掉原始记录
	$sql = "DELETE FROM `character` WHERE c_serverid NOT IN ($sids_str) AND c_ismerged = 0";
	log2("delete sql :\n $sql");
	$sdbdbhd->_execute($sql);
	log2("execute delete sql success");
	
	#将剩余记录中c_originalsid字段为0的置为c_serverid
	$sql = "UPDATE `character` SET c_originalsid = c_serverid WHERE c_originalsid = 0";
	log2("update sql2 :\n $sql");
	$sdbdbhd->_execute($sql);
	log2("execute update sql2 success");
}

sub clean_payrecord {
	my ($sdbdbhd, $gasdbhd) = @_;
	#步骤1:查找serverlist.servermergeto为0的服务器id
	my $sql = "SELECT s.sl_id FROM serverlist s WHERE s.servermergeto = 0";
	my $recordset = $gasdbhd->fetchAll($sql);
	my $sids_arr = [];
	foreach my $record (@$recordset) {
		push @$sids_arr, $record->{sl_id};
	}
	return unless scalar(@$sids_arr);
	my $sids_str = join(',', @$sids_arr); 
	
	#步骤2:删除充值表中被合掉的服务器的充值信息,但是保留最原始服务器的充值信息
	$sql = "DELETE FROM payrecord WHERE pr_serverid NOT IN ($sids_str) AND pr_ismerged = 1";
	log2("delete sql :\n $sql");
	my $result = $sdbdbhd->_execute($sql);
	log2("execute delete sql success");
	log2("delete $result records");
	
	#步骤3: 将新字段pr_originalsid加到sdb数据库中
	$sql = "ALTER TABLE `payrecord` ADD COLUMN `pr_originalsid` TINYINT(5) NOT NULL DEFAULT '0' AFTER `pr_pub`";
	log2("alter sql :\n $sql");
	$sdbdbhd->_execute($sql);
	log2("execute alter sql success");
	
	#步骤4:更新 pr_originalsid 字段的值
	#查找可以更新 pr_originalsid 字段的记录
	$sql = "SELECT pr.pr_orderid FROM payrecord pr WHERE pr.pr_serverid IN ($sids_str) AND pr.pr_ismerged = 1";
	$recordset = $sdbdbhd->fetchAll($sql);
	my $prorderids_arr = [];
	foreach my $record (@$recordset) {
		push @$prorderids_arr, $record->{pr_orderid};
	}
	return unless scalar(@$prorderids_arr);
	my $prorderids_str = join("','", @$prorderids_arr);
	$prorderids_str = "'".$prorderids_str."'";
	
	#查找需要更新成的内容
	$sql = "SELECT pr.pr_orderid, pr.pr_serverid FROM payrecord pr WHERE pr.pr_orderid IN ($prorderids_str) AND pr.pr_serverid NOT IN ($sids_str)";
	$recordset = $sdbdbhd->fetchAll($sql);
	foreach my $record (@$recordset) {
		my $orderid = $record->{pr_orderid};
		my $originalsid = $record->{pr_serverid};
		my $sql_update = "UPDATE payrecord SET pr_originalsid = $originalsid WHERE pr_orderid = '$orderid' AND pr_serverid IN ($sids_str)";
		#log2("update sql1 : \n $sql_update");
		$sdbdbhd->_execute($sql_update);
	}
	log2("execute update sql1 success");
	
	#删掉原始记录
	$sql = "DELETE FROM payrecord WHERE pr_serverid NOT IN ($sids_str) AND pr_ismerged = 0";
	log2("delete sql :\n $sql");
	$sdbdbhd->_execute($sql);
	log2("execute delete sql success");
	
	#将剩余记录中 pr_originalsid 字段为0的置为 pr_serverid
	$sql = "UPDATE payrecord SET pr_originalsid = pr_serverid WHERE pr_originalsid = 0";
	log2("update sql2 :\n $sql");
	$sdbdbhd->_execute($sql);
	log2("execute update sql2 success");
}

$SIG{__WARN__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);
   	
   	my $text_ = $text ? $text : "";
	log2('warn: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};

$SIG{__DIE__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);

	my $text_ = $text ? $text : "";
	log2('error: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};