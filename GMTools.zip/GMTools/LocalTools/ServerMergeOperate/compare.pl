#!/usr/bin/perl
use strict;
use warnings;
use PerlIO::encoding;
use Data::Dumper;
use File::Path;
use Time::Local;

BEGIN {
	use FindBin;
	my ($_parent_dir) = $FindBin::Bin =~ /(.*\/).*/;
	push(@INC, $FindBin::Bin, $_parent_dir);
}

use MysqlX;
require 'common.pl';

my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
my $cfg_file = "$base_file.cfg";
die "cfg file: '$cfg_file' not exists!" unless -e $cfg_file;

my $now = ts2str(time());
my $cfg_ini = load_ini($cfg_file);

foreach my $section(@{$cfg_ini}) {
	my $sectionname = $section->{'name'};
	next if ($sectionname eq "db_switch_head");
	
	log2("--------------------------------------\n");
	log2("---start section : $sectionname");
	
	my $sdb = get_section_value($section, 'sdbdb', '');
	my %sdb_hash = str2arr($sdb);	
	my $conn = MysqlX::genConn(\%sdb_hash);
	my $sdbdbcon = new MysqlX($conn);
	
	log2("character compare start");
	compare_char($sdbdbcon, $sectionname);
	log2("payrecord compare start");
	compare_payrecord($sdbdbcon, $sectionname);
	
	log2("---stop section : $sectionname");
	
	sleep 2;
}

sub compare_char {
	my ($sdbdbcon, $sectionname) = @_;
	
	#判断有没有相同的角色名 c_ismerged = 0
	my $sql = "
		select p1.c_serverid,count(*)
		from `character` p1 
		inner join serverlist sl on sl.servermergeto=p1.c_serverid
		inner join `character` p2 on sl.sl_id=p2.c_serverid and p1.c_charactername=p2.c_charactername
		where p1.c_ismerged=0
		group by p1.c_serverid
		order by p1.c_serverid asc
	";
	my $recordset = $sdbdbcon->fetchAll($sql);
	if(scalar(@$recordset)) {
		log2("same character c_ismerged eq 0:\n".Dumper($recordset));
		
		$sql = "
			update `character` p1 
			inner join serverlist sl on sl.servermergeto=p1.c_serverid
			inner join `character` p2 on sl.sl_id=p2.c_serverid and p1.c_charactername=p2.c_charactername
			set p1.c_ismerged=1
			where p1.c_ismerged=0			
		";
		my $result = $sdbdbcon->_execute($sql);
		log2("---update $result character recoreds");
	}
	
	#a1
	$sql = "
		select c.c_id, c.c_serverid, c.c_playerid, c.c_charactername
		from `character` c inner join serverlist s on c.c_serverid = s.sl_id 
		where c.c_ismerged = 0 and s.servermergeto != 0		
	";
	my $recordset_a1 = $sdbdbcon->fetchAll($sql);
	
	#b1 
	$sql = "
		select c.c_id, c.c_serverid, c.c_playerid, c.c_charactername
		from `character` c inner join serverlist s on c.c_serverid = s.sl_id 
		where c.c_ismerged = 1 and s.servermergeto = 0
	";
	my $recordset_b1 = $sdbdbcon->fetchAll($sql);
	
	my $a1_charname_hs = {};
	my $b1_charname_hs = {};
	foreach (@$recordset_a1) {
		$a1_charname_hs->{$_->{c_charactername}} = $_->{c_id};
	}
	foreach (@$recordset_b1) {
		$b1_charname_hs->{$_->{c_charactername}} = $_->{c_id};;
	}
	
	my @differ_charnames_arr;
	my @cids_ina1_notinb1;
	log2("characters in a1 but not in b1:\n");
	foreach (keys %{$a1_charname_hs}) {
		next if exists($b1_charname_hs->{$_});
		log2("c_id=".$a1_charname_hs->{$_}."\t c_charactername=".$_);
		push @cids_ina1_notinb1, $a1_charname_hs->{$_};
	}
	if(scalar(@cids_ina1_notinb1)) {
		my $cids_ina1_notinb1_str = join(",", @cids_ina1_notinb1);
		log2("cids_ina1_notinb1_str:\n".$cids_ina1_notinb1_str);
		$sql = "delete from `character` where c_id in ($cids_ina1_notinb1_str)";
		my $result = $sdbdbcon->_execute($sql);
		log2("---delete $result character recoreds");
	}
	
	log2("characters in b1 but not in a1:\n");
	foreach (keys %{$b1_charname_hs}) {
		next if exists($a1_charname_hs->{$_});
		log2("c_id=".$b1_charname_hs->{$_}."\t c_charactername=".$_);
		push @differ_charnames_arr, $_;
	}
	if(scalar(@differ_charnames_arr)) {
		my $differ_charnames_str = "'".join("','", @differ_charnames_arr)."'";
		$sql = "
			update `character` set c_ismerged = 0 where c_charactername in ($differ_charnames_str) and c_serverid in (select sl_id from serverlist where servermergeto=0)			
		";
		log2("differ_charnames_str:".$differ_charnames_str);
		my $result = $sdbdbcon->_execute($sql);
		log2("---update2 $result character recoreds");
		
		log2("++++++++++ after character update +++++++++");
		#b2
		$sql = "
			select c.c_id, c.c_serverid, c.c_playerid, c.c_charactername
			from `character` c inner join serverlist s on c.c_serverid = s.sl_id 
			where c.c_ismerged = 1 and s.servermergeto = 0		
		";
		my $recordset_b2 = $sdbdbcon->fetchAll($sql);
		my $b2_charname_hs = {};
		foreach (@$recordset_b2) {
			$b2_charname_hs->{$_->{c_charactername}} = $_->{c_serverid};
		}
		log2("characters in b2 but not in a1:\n");
		foreach (keys %{$b2_charname_hs}) {
			next if exists($a1_charname_hs->{$_});
			log2("c_serverid=".$b2_charname_hs->{$_}."\t c_charactername=".$_);
		}
	}
}

sub compare_payrecord {
	my ($sdbdbcon, $sectionname) = @_;
	
	#判断有没有相同的订单号且 c_ismerged = 0
	my $sql = "
		select p1.pr_serverid,count(*) 
		from payrecord p1 
		inner join serverlist sl on sl.servermergeto=p1.pr_serverid
		inner join payrecord p2 on sl.sl_id=p2.pr_serverid and p1.pr_orderid=p2.pr_orderid
		where p1.pr_ismerged=0
		group by p1.pr_serverid
		order by p1.pr_serverid asc
	";
	my $recordset = $sdbdbcon->fetchAll($sql);
	if(scalar(@$recordset)) {
		log2("same orderid pr_ismerged eq 0:\n".Dumper($recordset));
		
		$sql = "
			update payrecord p1 
			inner join serverlist sl on sl.servermergeto=p1.pr_serverid
			inner join payrecord p2 on sl.sl_id=p2.pr_serverid and p1.pr_orderid=p2.pr_orderid
			set p1.pr_ismerged=1
			where p1.pr_ismerged=0
		";
		my $result = $sdbdbcon->_execute($sql);
		log2("---update $result payrecord recoreds");
	}
	
	#a1
	$sql = "
		select p.pr_id ,p.pr_orderid
		from `payrecord` p inner join serverlist s on p.pr_serverid = s.sl_id 
		where p.pr_ismerged = 0 and s.servermergeto != 0 and p.pr_success = 1
	";
	my $recordset_a1 = $sdbdbcon->fetchAll($sql);
	
	#b1
	$sql = "
		select p.pr_id , p.pr_serverid, p.pr_orderid
		from `payrecord` p inner join serverlist s on p.pr_serverid = s.sl_id 
		where p.pr_ismerged = 1 and s.servermergeto = 0 and p.pr_success = 1
	";
	my $recordset_b1 = $sdbdbcon->fetchAll($sql);
	
	my $a1_charname_hs = {};
	my $b1_charname_hs = {};
	foreach (@$recordset_a1) {
		$a1_charname_hs->{$_->{pr_orderid}} = $_->{pr_id};
	}
	foreach (@$recordset_b1) {
		$b1_charname_hs->{$_->{pr_orderid}} = $_->{pr_id};
	}
	
	my @differ_prids_arr;	
	log2("orderids in a1 but not in b1:\n");
	foreach (keys %{$a1_charname_hs}) {
		next if exists($b1_charname_hs->{$_});
		log2("pr_id=".$a1_charname_hs->{$_}."\t pr_orderid=".$_);
		push @differ_prids_arr,$a1_charname_hs->{$_};		
	}
	
	log2("orderids in b1 but not in a1:\n");
	foreach (keys %{$b1_charname_hs}) {
		next if exists($a1_charname_hs->{$_});
		log2("pr_id=".$b1_charname_hs->{$_}."\t pr_orderid=".$_);
	}
	
	if(scalar(@differ_prids_arr)){
		my $differ_prids_str = join(",", @differ_prids_arr);
		$sql = "
			insert into payrecord ( pr_accountid,pr_playerid,pr_serverid,pr_money,pr_gamecoin,pr_phone,pr_paytype,pr_addtime,pr_orderid,pr_isporcess,pr_prodid,pr_prodcount,pr_payorderid,pr_telepcode,pr_success,pr_ismerged,pr_maintype,pr_pub,pr_channel ) 
			select pr_accountid,c2.c_playerid,c2.c_serverid,pr_money,pr_gamecoin,pr_phone,pr_paytype,pr_addtime,pr_orderid,pr_isporcess,pr_prodid,pr_prodcount,pr_payorderid,pr_telepcode,pr_success,1,pr_maintype,pr_pub,pr_channel from payrecord pr
			inner join `character` c1 on  pr.pr_serverid = c1.c_serverid and pr.pr_playerid = c1.c_playerid
			left join `character` c2 on c1.c_charactername=c2.c_charactername and c2.c_serverid in (select sl_id from serverlist where servermergeto=0)	where pr_success=1 and pr_id in ($differ_prids_str)		
		";
		log2("differ_prids_str:".$differ_prids_str);
		my $result = $sdbdbcon->_execute($sql);
		log2("---insert $result payrecord recoreds");
		
		
		log2("++++++++++ after payrecord insert +++++++++");
		my $b2_charname_hs = {};
		#b2
		$sql = "
			select p.pr_id , p.pr_serverid, p.pr_orderid
			from `payrecord` p inner join serverlist s on p.pr_serverid = s.sl_id 
			where p.pr_ismerged = 1 and s.servermergeto = 0 and p.pr_success = 1
		";
		my $recordset_b2 = $sdbdbcon->fetchAll($sql);
		
		foreach (@$recordset_b2) {
			$b2_charname_hs->{$_->{pr_orderid}} = $_->{pr_id};
		}
		log2("orderids in a1 but not in b2:\n");
		foreach (keys %{$a1_charname_hs}) {
			next if exists($b2_charname_hs->{$_});
			log2("pr_id=".$a1_charname_hs->{$_}."\t pr_orderid=".$_);
		}
	}
}		