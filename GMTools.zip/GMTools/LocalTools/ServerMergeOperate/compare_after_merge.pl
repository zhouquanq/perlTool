#!/usr/bin/perl
use strict;
use warnings;
use PerlIO::encoding;
use Data::Dumper;
use File::Path;
use Time::Local;

BEGIN {
	use FindBin;
	my ($_parent_dir) = $FindBin::Bin =~ /(.*\/).*/;
	push(@INC, $FindBin::Bin, $_parent_dir);
}

use MysqlX;
require 'common.pl';

my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
my $cfg_file = "$base_file.cfg";
die "cfg file: '$cfg_file' not exists!" unless -e $cfg_file;

my $now = ts2str(time());
my $cfg_ini = load_ini($cfg_file);

foreach my $section(@{$cfg_ini}) {
	my $sectionname = $section->{'name'};
	next if ($sectionname eq "db_switch_head");
	
	log2("--------------------------------------\n");
	log2("---start section : $sectionname");
	
	my $sdb = get_section_value($section, 'sdbdb', '');
	my $ga = get_section_value($section, 'gadb', '');
	my $mergesid = get_section_value($section, 'mergesid', '');
	
	my %sdb_hash = str2arr($sdb);	
	my $conn = MysqlX::genConn(\%sdb_hash);
	my $sdbdbcon = new MysqlX($conn);
	
	my %ga_hash = str2arr($ga);	
	my $gaconn = MysqlX::genConn(\%ga_hash);
	my $gadbcon = new MysqlX($gaconn);
	
	log2("character compare start");
	compare_char($sdbdbcon, $gadbcon, $sectionname, $mergesid);
	log2("payrecord compare start");
	compare_payrecord($sdbdbcon, $gadbcon, $sectionname, $mergesid);
	
	log2("---stop section : $sectionname");
	
	sleep 2;
}

sub compare_char {
	my ($sdbdbcon, $gadbcon, $sectionname, $mergesid) = @_;
	
	#sdb中合服数据
	my $sql = "
		select c_id,a_id,c_playerid,c_charactername,c_addtime,c_serverid,c_lastlogintime,c_ismerged,c_bplayerid,c_bserverid,c_originalsid  
		from player p 
		where p.c_serverid in ($mergesid)
	";
	my $recordset_sdb = $sdbdbcon->fetchAll($sql);
	
	#ga中合服数据
	$sql = "
		select c_id,a_id,c_playerid,c_charactername,c_addtime,c_serverid,c_lastlogintime,c_ismerged,c_bplayerid,c_bserverid,c_originalsid 
		from `character` p 
		where p.c_serverid in ($mergesid) 
	";
	my $recordset_ga = $gadbcon->fetchAll($sql);
	
	my $sdb_char_hs = {};
	my $ga_char_hs = {};
	foreach (@$recordset_sdb) {
		$sdb_char_hs->{$_->{c_id}} = {
			a_id	=>	$_->{a_id},
			c_playerid	=>	$_->{c_playerid},
			c_serverid	=>	$_->{c_serverid},
			c_ismerged	=>	$_->{c_ismerged},
			c_bplayerid	=>	$_->{c_bplayerid},
			c_bserverid	=>	$_->{c_bserverid},
			c_originalsid	=>	$_->{c_originalsid},
		};
	}
	foreach (@$recordset_ga) {
		$ga_char_hs->{$_->{c_id}} = {
			a_id	=>	$_->{a_id},
			c_playerid	=>	$_->{c_playerid},
			c_serverid	=>	$_->{c_serverid},
			c_ismerged	=>	$_->{c_ismerged},
			c_bplayerid	=>	$_->{c_bplayerid},
			c_bserverid	=>	$_->{c_bserverid},
			c_originalsid	=>	$_->{c_originalsid},
		};
	}
	
	my $cids_inga_notinsdb = [];
	my $cids_differ = [];
	foreach my $cid (keys %{$ga_char_hs}) {
		if(exists($sdb_char_hs->{$cid})) {
			foreach (keys %{$sdb_char_hs->{$cid}}) {
				if($sdb_char_hs->{$cid}->{$_} != $ga_char_hs->{$cid}->{$_}) {
					push @$cids_differ, $cid;
				}
			}
		} else {
			push @$cids_inga_notinsdb, $cid;
		}
	}
	log2("characters in ga but not in sdb:\n".Dumper($cids_inga_notinsdb));
	log2("cids_differ:\n".Dumper($cids_differ));
}

sub compare_payrecord {
	my ($sdbdbcon, $gadbcon, $sectionname, $mergesid) = @_;
	
		#sdb中合服数据
	my $sql = "
		select p.pr_id, p.pr_accountid, p.pr_serverid, p.pr_playerid, p.pr_ismerged, p.pr_originalsid
		from payrecord p 
		where p.pr_serverid in ($mergesid)
	";
	my $recordset_sdb = $sdbdbcon->fetchAll($sql);
	
	#ga中合服数据
	$sql = "
		select p.pr_id, p.pr_accountid, p.pr_serverid, p.pr_playerid, p.pr_ismerged, p.pr_originalsid
		from payrecord p 
		where p.pr_serverid in ($mergesid)
	";
	my $recordset_ga = $gadbcon->fetchAll($sql);
	
	my $sdb_pay_hs = {};
	my $ga_pay_hs = {};
	foreach (@$recordset_sdb) {
		$sdb_pay_hs->{$_->{pr_id}} = {
			pr_accountid	=>	$_->{pr_accountid},
			pr_serverid	=>	$_->{pr_serverid},
			pr_playerid	=>	$_->{pr_playerid},
			pr_ismerged	=>	$_->{pr_ismerged},
			pr_originalsid	=>	$_->{pr_originalsid},
		};
	}
	foreach (@$recordset_ga) {
		$ga_pay_hs->{$_->{pr_id}} = {
			pr_accountid	=>	$_->{pr_accountid},
			pr_serverid	=>	$_->{pr_serverid},
			pr_playerid	=>	$_->{pr_playerid},
			pr_ismerged	=>	$_->{pr_ismerged},
			pr_originalsid	=>	$_->{pr_originalsid},
		};
	}
	
	my $prids_inga_notinsdb = [];
	my $prids_differ = [];
	foreach my $prid (keys %{$ga_pay_hs}) {
		if(exists($sdb_pay_hs->{$prid})) {
			foreach (keys %{$sdb_pay_hs->{$prid}}) {
				if($sdb_pay_hs->{$prid}->{$_} != $ga_pay_hs->{$prid}->{$_}) {
					push @$prids_differ, $prid;
				}
			}
		} else {
			push @$prids_inga_notinsdb, $prid;
		}
	}
	log2("payrecords in ga but not in sdb:\n".Dumper($prids_inga_notinsdb));
	log2("prids_differ:\n".Dumper($prids_differ));
}