#!/usr/bin/perl
#注意: 合服时不能执行本程序,因为合服时修改serverllist表中的字段可能导致清理错误的信息
#前置准备:
#	1.停止sdb同步程序
#	2.检查serverlist表,看有无异常,将serverlist表复制一份到sdb
#	3.检查sdb角色表中有无重复角色,有的话要先处理掉
		# select p.c_id,p.c_serverid,p.c_charactername,count(*) as counts 
		# from player p 
		# where p.c_ismerged = 0 
		# group by p.c_charactername 
		# having counts > 1
#	4.执行脚本前,先判断一下条件
#		a. servermergeto != 0 and ismerged =0 的记录数量 a1;
			# select count(*) 
			# from `player` c inner join serverlist s on c.c_serverid = s.serverid 
			# where c.c_ismerged = 0 and s.servermergeto != 0;

			# select count(*) 
			# from `payrecord` p inner join serverlist s on p.pr_serverid = s.serverid 
			# where p.pr_ismerged = 0 and s.servermergeto != 0;
#		b. servermergeto = 0 and ismerged =1 的记录数量 b1;
			# select count(*) 
			# from `player` c inner join serverlist s on c.c_serverid = s.serverid 
			# where c.c_ismerged = 1 and s.servermergeto = 0;

			# select count(*) 
			# from `payrecord` p inner join serverlist s on p.pr_serverid = s.serverid 
			# where p.pr_ismerged = 1 and s.servermergeto = 0;
#		如果a1 >= b1,可以继续
#		如果a1 < b1,这可能合服有问题,需要找出原因处理
#	
#	5.判断合服后有没有 ismerged 字段没更新的情况
	# ---对payrecord表
		# select p1.pr_serverid,count(*) 
		# from payrecord p1 
		# inner join serverlist sl on sl.servermergeto=p1.pr_serverid
		# inner join payrecord p2 on sl.serverid=p2.pr_serverid and p1.pr_orderid=p2.pr_orderid
		# where p1.pr_ismerged=0
		# group by p1.pr_serverid
		# order by p1.pr_serverid asc

		# 如果结果不为空 就说明有需要改的,执行下面的语句
		# update payrecord p1 
		# inner join serverlist sl on sl.servermergeto=p1.pr_serverid
		# inner join payrecord p2 on sl.serverid=p2.pr_serverid and p1.pr_orderid=p2.pr_orderid
		# set p1.pr_ismerged=1
		# where p1.pr_ismerged=0		
		
	#---对player表
		# select p1.c_serverid,count(*)
		# from player p1 
		# inner join serverlist sl on sl.servermergeto=p1.c_serverid
		# inner join player p2 on sl.serverid=p2.c_serverid and p1.c_charactername=p2.c_charactername
		# where p1.c_ismerged=0
		# group by p1.c_serverid
		# order by p1.c_serverid asc

		# update player p1 
		# inner join serverlist sl on sl.servermergeto=p1.c_serverid
		# inner join player p2 on sl.serverid=p2.c_serverid and p1.c_charactername=p2.c_charactername
		# set p1.c_ismerged=1
		# where p1.c_ismerged=0
	
#	
#	
BEGIN{
	use FindBin;
	$::APPLICATION_PATH = $FindBin::Bin;
	$::PARENT_PATH = $::APPLICATION_PATH."/../";
	push( @INC, $::APPLICATION_PATH, $::PARENT_PATH);
	chdir( $::APPLICATION_PATH);
	
	$::APPLICATION_ISRUN = 1;
	
	# 防止意外关闭
	$SIG{HUP} = sub {};
	$SIG{INT} = sub { $::APPLICATION_ISRUN = 0;};
	$| = 1;
}

use strict;
use warnings;
use Data::Dumper;
use POSIX qw(strftime);
use utf8;

require 'common.pl';
use MysqlX;

my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
my $cfg_file = "$base_file.cfg";
die "cfg file: '$cfg_file' not exists!" unless -e $cfg_file;

eval {
	main();
};
warn $@ if $@;

sub main {
		my $cfg_ini = load_ini($cfg_file);
		
		foreach my $section(@{$cfg_ini}) {
			my $sdbdb = get_section_value($section, 'sdbdb', '');
			my %sdbdb_hash = str2arr($sdbdb);	
			
			my $sdbcon = MysqlX::genConn(\%sdbdb_hash);
			my $sdbdbhd = new MysqlX($sdbcon);
			
			my $starttime1 = ts2str(time());
			clean_player($sdbdbhd);
			my $starttime2 = ts2str(time());
			clean_payrecord($sdbdbhd);
			my $stoptime = ts2str(time());
			log2("---starttime1: $starttime1");
			log2("---starttime2: $starttime2");
			log2("---stoptime: $stoptime");
		}
}

sub clean_player {
	my ($sdbdbhd) = @_;
	#步骤1:删除角色表中被合掉的服务器的中间服务器(非角色初始服务器)的角色信息(当记录的serverid不在步骤1的服务器列表内,并且ismerge=1,就删除该条记录)
	my $sql = "DELETE FROM player WHERE c_serverid NOT IN (SELECT serverid FROM serverlist WHERE servermergeto = 0) AND c_ismerged = 1";
	log2("delete sql :\n $sql");
	my $result = $sdbdbhd->_execute($sql);
	log2("execute delete sql success 执行成功");
	log2("delete $result records");
	
	#此时 角色表中只有原始和最新的两条(或一条---只有新注册纪录)记录
	
	#步骤2: 将新字段c_originalsid加到sdb数据库中
	$sql = "ALTER TABLE `player` ADD COLUMN `c_originalsid` TINYINT(5) NOT NULL DEFAULT '0' AFTER `c_pb`";
	log2("alter sql :\n $sql");
	$sdbdbhd->_execute($sql);
	log2("execute alter sql success");
	
	#步骤3: 将原始记录的serverid写到新纪录的新字段c_originalsid中
	$sql = "update `player` c1 inner join `player` c2 on c1.c_charactername=c2.c_charactername and c2.c_ismerged=0 set c1.c_originalsid = c2.c_serverid where c1.c_serverid in (SELECT serverid FROM serverlist WHERE servermergeto = 0)";
	log2("update sql1 : \n $sql");
	$sdbdbhd->_execute($sql);
	log2("execute update sql1 success");
	
	
	#步骤4: 删掉原始记录
	$sql = "DELETE FROM player WHERE c_serverid NOT IN (SELECT serverid FROM serverlist WHERE servermergeto = 0) AND c_ismerged = 0";
	log2("delete sql :\n $sql");
	$sdbdbhd->_execute($sql);
	log2("execute delete sql success");
	
	#步骤5: 将剩余记录中c_originalsid字段为0的置为c_serverid
	$sql = "UPDATE player SET c_originalsid = c_serverid WHERE c_originalsid = 0";
	log2("update sql2 :\n $sql");
	$sdbdbhd->_execute($sql);
	log2("execute update sql2 success");
}

sub clean_payrecord {
	my ($sdbdbhd) = @_;
	#步骤1:删除充值表中被合掉的服务器的充值信息,但是保留最原始服务器的充值信息
	my $sql = "DELETE FROM payrecord WHERE pr_serverid NOT IN (SELECT serverid FROM serverlist WHERE servermergeto = 0) AND pr_ismerged = 1";
	log2("delete sql :\n $sql");
	my $result = $sdbdbhd->_execute($sql);
	log2("execute delete sql success");
	log2("delete $result records");
	
	#步骤2: 将新字段pr_originalsid加到sdb数据库中
	$sql = "ALTER TABLE `payrecord` ADD COLUMN `pr_originalsid` TINYINT(5) NOT NULL DEFAULT '0' AFTER `pr_pub`";
	log2("alter sql :\n $sql");
	$sdbdbhd->_execute($sql);
	log2("execute alter sql success");
	
	#步骤3:更新 pr_originalsid 字段的值	
	$sql = "update `payrecord` p1 inner join `payrecord` p2 on p1.pr_orderid=p2.pr_orderid and p2.pr_ismerged=0 set p1.pr_originalsid = p2.pr_serverid where p1.pr_serverid in (SELECT serverid FROM serverlist WHERE servermergeto = 0)";
	log2("update sql1 : \n $sql");
	$sdbdbhd->_execute($sql);
	log2("execute update sql1 success");
	
	
	#步骤4:删掉原始记录
	$sql = "DELETE FROM payrecord WHERE pr_serverid NOT IN (SELECT serverid FROM serverlist WHERE servermergeto = 0) AND pr_ismerged = 0";
	log2("delete sql :\n $sql");
	$sdbdbhd->_execute($sql);
	log2("execute delete sql success");
	
	#步骤5: 将剩余记录中 pr_originalsid 字段为0的置为 pr_serverid
	$sql = "UPDATE payrecord SET pr_originalsid = pr_serverid WHERE pr_originalsid = 0";
	log2("update sql2 :\n $sql");
	$sdbdbhd->_execute($sql);
	log2("execute update sql2 success");
}

$SIG{__WARN__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);
   	
   	my $text_ = $text ? $text : "";
	log2('warn: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};

$SIG{__DIE__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);

	my $text_ = $text ? $text : "";
	log2('error: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};