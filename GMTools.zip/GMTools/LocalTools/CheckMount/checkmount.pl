#!/usr/bin/perl
#功能:检查集成云盘是否挂载,否则重新启动挂载

use warnings;
use strict;
use FindBin;
require 'srv.pl';
	
my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
open LOG,">> $base_file.log";

while ($::APPLICATION_ISRUN) {
	my $cmd = "ls /GMSync/gamelog/lywm_log/gs13/2012092810.lzo";

	#如果没有挂载云盘,执行`$cmd`这条命令不会捕获任何输出,只有当挂载了云盘并且有这个文件时才会捕获到'/GMSync/gamelog/lywm_log/gs13/2012092810.lzo'
	my $return = `$cmd`;

	my $time = `/bin/date`;
	print LOG $time;
	print LOG "\n"; 
	print LOG $return;

	if($return !~ /2012092810/) {
		print LOG " ++++++++++++++++++++++++ \n";
		system("/bin/umount /mnt/dfs");
		system("/bin/bash /GMSync/mountdfs.sh");
		print LOG " ++++++++++++++++++++++++ \n";	
	}

	print LOG "-------------------------------------------------- \n";
	sleep 600;
}

close LOG;

BEGIN{
	$::APPLICATION_ISRUN = 1;
	push( @INC, $FindBin::Bin);
	# 防止意外关闭
	$SIG{HUP} = sub {};
	$SIG{INT} = sub { $::APPLICATION_ISRUN = 0;};
	$| = 1;
}
