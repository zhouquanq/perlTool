#!/usr/bin/perl
#用于同步sdb.player表的c_playerid字段
BEGIN {
	use FindBin;
	my ($_parent_dir) = $FindBin::Bin =~ /(.*\/).*/;
	push(@INC, $FindBin::Bin, $_parent_dir);
	print $_parent_dir."\n";
	$::APPLICATION_ISRUN = 1;
	
	$SIG{HUP} = sub {};
	$SIG{INT} = sub {
		$::APPLICATION_ISRUN = 0;
	};
}

use warnings;
use strict;

use MysqlX;
use Data::Dumper;

require 'srv.pl';
require 'common.pl';

main();

sub main 
{
	$| = 1;	
	my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
	my $logfile = $base_file.".log";
	my $cfg_file = "$base_file.cfg";
	
	while ($::APPLICATION_ISRUN) {
		my $cfg_ini = load_ini($cfg_file);#print Dumper($cfg_ini);
		foreach my $section (@{$cfg_ini}) {	
			my $section_name = $section->{'name'};
			my $srcdb      = get_section_value($section, 'srcdb', '');
			my $dstdb      = get_section_value($section, 'dstdb', '');	
			
			my %dstdb = str2arr($dstdb);
			my %srcdb = str2arr($srcdb);
			
			update_lines(\%srcdb, \%dstdb);
			log2($section_name." done! \n");
			#print $section_name." done! \n";
		}
		sleep 3600;
	}
}

sub update_lines {
	my ($srcdbconn, $dstdbconn) = @_;
	
	my $conn = MysqlX::genConn($srcdbconn);
	my $srcdb = new MysqlX($conn);
	
	my $conn2 = MysqlX::genConn($dstdbconn);
	my $dstdb = new MysqlX($conn2);	
	
	my $sql = "SELECT c_id FROM player WHERE c_playerid = 0";
	my $results = $dstdb->fetchAll($sql);
	my $c_ids = '';
	foreach my $result (@$results) {
		$c_ids .= $result->{'c_id'}.",";
	}
	$c_ids =~ s/(.*),$/$1/;
	#print Dumper($c_ids);
	if(@$results) {
		my $sql2 = "
			SELECT ch.c_id,ch.c_playerid 
			FROM `character` ch
			WHERE ch.c_id IN($c_ids)
		";
		my $returns = $srcdb->fetchAll($sql2);
		#print Dumper($returns);
		
		my @sql_updates;
		my $i = 0;
		foreach my $return (@$returns) {
			$sql_updates[$i++] = "UPDATE player SET c_playerid = ".$return->{'c_playerid'}." WHERE c_id = ".$return->{'c_id'}.";\n";
		}
		#print Dumper(@sql_updates);
		
		foreach my $sql_update (@sql_updates) {
			$dstdb->_execute($sql_update);
		}
	}
}

BEGIN {
	$SIG{__DIE__} = sub{
		my ($text) = @_;
		my @loc = caller(0);
		chomp($text);

		my $text_ = $text ? $text : "";
		log2('error: '. $text_); 
		
		my $index = 1;
		for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
		{
			log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
		};
		return 1;
	};
	$SIG{__WARN__} = sub{
		my ($text) = @_;
		my @loc = caller(0);
		chomp($text);

		my $text_ = $text ? $text : "";
		log2('error: '. $text_); 
		
		my $index = 1;
		for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
		{
			log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
		};
		return 1;
	};
}
