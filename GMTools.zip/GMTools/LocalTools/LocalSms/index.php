<?php

/**
 * ���Žӿ�ת������
 */


ini_set( "error_reporting", E_ALL );//& ~(E_NOTICE) & ~(E_WARNING));
ini_set( "display_errors", "ON");
//�ر�ħ������
ini_set( "magic_quotes_runtime", "Off");
defined( "APPLICATION_PATH") || define( "APPLICATION_PATH", dirname( __FILE__));

require_once 'Log.php';
require_once 'HttpClient.php';

$key = "731b2342-0b5c-2875-233e-bf54cb347ef1";
$sendurl = "http://192.168.123.2:8800/?Sender=15989345894&PhoneNumber=__PHONE__&Text=__MSG__";

$logger = Moby_Accsvr_Model_Util_Log::getInstance();

$mobiles = isset( $_POST['mobiles']) ? $_POST['mobiles'] : ( isset( $_GET['mobiles']) ? $_GET['mobiles'] : "");
$msg = isset( $_POST['msg']) ? $_POST['msg'] : ( isset( $_GET['msg']) ? $_GET['msg'] : "");
$sign = isset( $_POST['sign']) ? $_POST['sign'] : ( isset( $_GET['sign']) ? $_GET['sign'] : "");

$mobiles = urldecode( $mobiles);
$msg = urldecode( $msg);
$sign = urldecode( $sign);

$logger->record( sprintf( "[params]mobiles=%s,msg=%s,sign=%s", $mobiles, $msg, $sign));

if( !$mobiles) {
	$result = json_encode( array( "code"=>"-1", "msg"=>"mobiles is required")); 
	$logger->record( sprintf( "[output]%s", $result));
	echo $result; exit;
}

if( !$msg) {
	$result = json_encode( array( "code"=>"-2", "msg"=>"msg is required")); 
	$logger->record( sprintf( "[output]%s", $result));
	echo $result; exit;
}
 
if( !$sign) {
	$result = json_encode( array( "code"=>"-3", "msg"=>"sign is required")); 
	$logger->record( sprintf( "[output]%s", $result));
	echo $result; exit;
}

$mysign = md5( sprintf( "mobiles=%s&msg=%s&%s", $mobiles, $msg, md5( $key)));
if( $mysign != $sign) {
	$result = json_encode( array( "code"=>"-4", "msg"=>"sign valid fail")); 
	$logger->record( sprintf( "[console]sign valid fail sign:%s mysign:%s", $sign, $mysign));
	$logger->record( sprintf( "[output]%s", $result));
	echo $result; exit;
}

$mobilesArray = explode( ",", $mobiles);
$mobilesArray_ = array();
foreach( $mobilesArray as $mobile) {
	$mobileitem = trim( $mobile);
	if( !preg_match( "/^\d+$/", $mobileitem)) {
		$result = json_encode( array( "code"=>"-5", "msg"=>"mobile item must number:".$mobileitem)); 
		$logger->record( sprintf( "[output]%s", $result));
		echo $result; exit;
	}
	$mobilesArray_[] = $mobileitem;
}
$max_sms_len = 10000;
foreach( $mobilesArray_ as $mobileitem) {
	
	$sms_part = "";
	$msg_send = $msg;
	do {
		$len = $max_sms_len;
		if( strlen( $msg_send) < $len) {
			$len = strlen( $msg_send);
		}

		$sms_part = substr( $msg_send, 0, $len);
		$msg_send = substr( $msg_send, $len);

		$url_ = $sendurl;
		$url_ = str_replace( '__PHONE__', $mobileitem, $url_);
		$url_ = str_replace( '__MSG__', urlencode( $sms_part), $url_);
		$logger->record( sprintf( "[console]send msg url:%s", $url_));
		
		$bits = parse_url($url_);
        $host = $bits['host'];
        $port = isset($bits['port']) ? $bits['port'] : 80;
        $path = isset($bits['path']) ? $bits['path'] : '/';
        if (isset($bits['query'])) {
            $path .= '?'.$bits['query'];
        }
        $client = new Moby_Util_HttpClient( $host, $port);
		
		if( $client->get($path, array())) {
			$logger->record( "[console]send msg succ:".$client->getContent());
		} 
		else { 
			$logger->record( "[console]send msg error info:".$client->getError());
		}
	}
	while( strlen( $msg_send) > 0);
}

$result = json_encode( array( "code"=>"0", "msg"=>"send succ")); 
$logger->record( sprintf( "[output]%s", $result));
echo $result;
exit;
