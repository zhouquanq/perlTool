<?php
class Moby_Accsvr_Model_Util_Log {
	
	private static $_instance ;
	
	public static function getInstance() {
		if( !self::$_instance) {
			$dir = APPLICATION_PATH;
			self::$_instance = new self( $dir);
		} 
		return self::$_instance;
	}
	
	private function __construct( $dir) {
		defined( 'APP_START_TIMESTAMP')
			|| 	define( 'APP_START_TIMESTAMP', time());
		defined( 'APP_REQ_UUID') 
			|| define( 'APP_REQ_UUID', $this->uuid());

		$filename = $dir.'/'.date('Y-m-d', APP_START_TIMESTAMP).'.log';
		$this->handle = fopen( $filename, 'a');
	}
	
	public function record( $content) {
		$content = sprintf( "[%s][%s] %s\r\n", date( 'Y-m-d H:i:s', APP_START_TIMESTAMP), APP_REQ_UUID, $content);
		fputs( $this->handle, $content);
	}
	
	public function close() {
		if( $this->handle) {
			fclose( $this->handle);
		}
	}
	
	public function __destruct() {
		$this->close();
	}

	public function uuid( $prefix = '') {
	    $chars = md5(uniqid(rand()));
	    $uuid  = substr($chars,0,8) . '-';
	    $uuid .= substr($chars,8,4) . '-';
	    $uuid .= substr($chars,12,4) . '-';
	    $uuid .= substr($chars,16,4) . '-';
	    $uuid .= substr($chars,20,12);
	
	    return $prefix . $uuid;
	}
}