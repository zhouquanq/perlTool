<?php
	$cfg = array(
		"restore_info"	=>	array(
			"sdbarg"	=>	array(
				"host"	=>	"124.232.163.37",
				"port"	=>	"3306",
				"user"	=>	"root",
				"name"	=>	"db_restore_info",
				"pass"	=>	"revbHEpB9NUftrhh4Q2",
			),
		),
		"lywm"	=>	array(
			"sdbarg"	=>	array(
				"host"	=>	"183.233.224.194",
				"port"	=>	"13306",
				"user"	=>	"sdb",
				"name"	=>	"sdb_lywm",
				"pass"	=>	"qJe9esl6mE7E9N",
			),
		),
		"lyly"	=>	array(
			"sdbarg"	=>	array(
				"host"	=>	"183.233.224.194",
				"port"	=>	"13306",
				"user"	=>	"sdb",
				"name"	=>	"sdb_lyly",
				"pass"	=>	"qJe9esl6mE7E9N",
			),
		),
		"fyios"	=>	array(
			"sdbarg"	=>	array(
				"host"	=>	"124.232.163.34",
				"port"	=>	"3306",
				"user"	=>	"sdb",
				"name"	=>	"sdb_fyios",
				"pass"	=>	"qJe9esl6mE7E9N",
			),
		),
		"zs9y"	=>	array(
			"sdbarg"	=>	array(
				"host"	=>	"183.233.224.194",
				"port"	=>	"13306",
				"user"	=>	"sdb",
				"name"	=>	"sdb_zs9y",
				"pass"	=>	"qJe9esl6mE7E9N",
			),
		),
		"lyld"	=>	array(
			"sdbarg"	=>	array(
				"host"	=>	"221.181.72.65",
				"port"	=>	"3306",
				"user"	=>	"root",
				"name"	=>	"sdb_lyld",
				"pass"	=>	"j3nrM85yKGh7bidr",
			),
		),
		"lytw"	=>	array(
			"sdbarg"	=>	array(
				"host"	=>	"218.32.54.69",
				"port"	=>	"3306",
				"user"	=>	"sdb",
				"name"	=>	"sdb_lytw",
				"pass"	=>	"qJe9esl6mE7E9N",
			),
		),
		"catts"	=>	array(
			"sdbarg"	=>	array(
				"host"	=>	"192.168.123.4",
				"port"	=>	"3306",
				"user"	=>	"root",
				"name"	=>	"sdb_catts",
				"pass"	=>	"3hk8gm2yeuOOv5Kr",
			),
		),
	);
?>
