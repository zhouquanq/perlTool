<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
	</head>
	<body>
		<form name="input" action="#" method="post">
			运营商: 
			<select name='op'>
				<option value='all' <?php echo isset($_POST['op'])&&$_POST['op']=='all'?"selected='selected'":""; ?>>全部</option>
				<option value='lywm' <?php echo isset($_POST['op'])&&$_POST['op']=='lywm'?"selected='selected'":""; ?>>龙印网盟</option>
				<option value='lyly' <?php echo isset($_POST['op'])&&$_POST['op']=='lyly'?"selected='selected'":""; ?>>龙印乐易</option>
				<option value='fyios' <?php echo isset($_POST['op'])&&$_POST['op']=='fyios'?"selected='selected'":""; ?>>龙印飞娱ios</option>
				<option value='zs9y' <?php echo isset($_POST['op'])&&$_POST['op']=='zs9y'?"selected='selected'":""; ?>>宗师9游</option>
				<option value='lyld' <?php echo isset($_POST['op'])&&$_POST['op']=='lyld'?"selected='selected'":""; ?>>龙印乐逗</option>				
				<option value='lytw' <?php echo isset($_POST['op'])&&$_POST['op']=='lytw'?"selected='selected'":""; ?>>龙印台湾</option>					
				<option value='catts' <?php echo isset($_POST['op'])&&$_POST['op']=='catts'?"selected='selected'":""; ?>>寻将</option>			
			</select><br/>
			显示:
			<input type='radio' name='show' value='wrong' <?php echo isset($_POST['show'])&&$_POST['show']=='wrong'||!isset($_POST['show'])?"checked='checked'":""; ?>/>出错的
			<input type='radio' name='show' value='all' <?php echo isset($_POST['show'])&&$_POST['show']=='all'?"checked='checked'":""; ?>/>所有的
			<br/><br/>
			<input type="submit" value="Submit" />
		</form>
	</body>
</html>

<?php
	require "show_db_restore_cfg.php";
	if(isset($_POST['show'])){
		$show_value = $_POST['show'];
	} else {
		$show_value = 'wrong';
	}	
	
	if(isset($_POST['op']) && $_POST['op'] != 'all') {
		$op = $_POST['op'];
		/*
		$mysqli = new mysqli($cfg[$op]['sdbarg']['host'], $cfg[$op]['sdbarg']['user'], $cfg[$op]['sdbarg']['pass'], $cfg[$op]['sdbarg']['name'], $cfg[$op]['sdbarg']['port']);
		#print $cfg[$op]['sdbarg']['host'].", ".$cfg[$op]['sdbarg']['user'].", ".$cfg[$op]['sdbarg']['pass'].", ".$cfg[$op]['sdbarg']['name'];
		
		if ($mysqli->connect_errno) {
			printf("Connect failed: %s\n", $mysqli->connect_error);
			exit();
		}
		
		$theday = date("Y-m-d");
		$resultset_res = $mysqli->query("SELECT serverid FROM needrunserver WHERE theday = '$theday'");
		$resultset = $resultset_res->fetch_all(MYSQLI_ASSOC);
		$mysqli->close();
		*/
		#查找需要还原的服务器
		$dsn = 'mysql:dbname='.$cfg[$op]['sdbarg']['name'].";host=".$cfg[$op]['sdbarg']['host'].";port=".$cfg[$op]['sdbarg']['port'];
		try {
			$dbh = new PDO($dsn, $cfg[$op]['sdbarg']['user'], $cfg[$op]['sdbarg']['pass']);
		} catch (PDOException $e) {
			echo 'Connection'.$cfg[$op]['sdbarg']['name'].' failed: '.$e->getMessage();
		}
		$theday = date("Y-m-d");
		$sth = $dbh->prepare("SELECT serverid FROM needrunserver WHERE theday = '$theday'");
		$sth->execute();		
		$resultset = $sth->fetchAll();
		
		$db_name = array();
		array_push($db_name, $op."_db_ga");
		foreach ($resultset as $value) {
			array_push($db_name,$op."_db_gs".$value["serverid"]);
		}
		$db_name_str = implode("','", $db_name);
		$db_name_str = "'".$db_name_str."'";
		
		
		#查看服务器的还原状态
		/*
		$mysqli = new mysqli($cfg['restore_info']['sdbarg']['host'], $cfg['restore_info']['sdbarg']['user'], $cfg['restore_info']['sdbarg']['pass'], $cfg['restore_info']['sdbarg']['name'], $cfg['restore_info']['sdbarg']['port']);
		
		if ($mysqli->connect_errno) {
			printf("Connect failed: %s\n", $mysqli->connect_error);
			exit();
		}
		$sql = "SELECT * FROM restore_info WHERE db_name IN ($db_name_str) ORDER BY db_name";
		#var_dump($sql);		
		$resultset_res = $mysqli->query($sql);
		$resultset = $resultset_res->fetch_all(MYSQLI_ASSOC);
		$mysqli->close();
		*/	
		$dsn = 'mysql:dbname='.$cfg['restore_info']['sdbarg']['name'].";host=".$cfg['restore_info']['sdbarg']['host'].";port=".$cfg['restore_info']['sdbarg']['port'];
		try {
			$dbh = new PDO($dsn, $cfg['restore_info']['sdbarg']['user'], $cfg['restore_info']['sdbarg']['pass']);
		} catch (PDOException $e) {
			echo 'Connection'.$cfg['restore_info']['sdbarg']['name'].' failed: '.$e->getMessage();
		}
		$sth = $dbh->prepare("SELECT * FROM restore_info WHERE db_name IN ($db_name_str) ORDER BY db_name");
		$sth->execute();		
		$resultset = $sth->fetchAll();
		
		#var_dump($resultset);	
		echo "<table border='1' width='720'>";
			echo "<tr align='center'>";
				echo "<td width='120'>数据库</td>";
				echo "<td width='120'>能否还原</td>";
				echo "<td width='120'>最后文件时间</td>";
				echo "<td width='120'>开始还原时间</td>";
				echo "<td width='120'>结束还原时间</td>";
				echo "<td width='120'>是否过旧</td>";
			echo "</tr>";
		foreach ($resultset as $value) {
			$key = array_search($value["db_name"],$db_name);
			unset($db_name[$key]);
			#var_dump($value);
			$bgcolor = '';
			if($value["reducible"] == 0) {
				$bgcolor = 'red';
			} elseif ($value["isold"] == 1) {
				$bgcolor = 'pink';
			}
			if($bgcolor != 'red' && $bgcolor != 'pink' && $show_value == 'wrong') {
				continue;
			}
			echo "<tr align='center' bgcolor='$bgcolor'>";
				echo "<td>".$value["db_name"]."</td>";
				echo "<td>".$value["reducible"]."</td>";
				echo "<td>".$value["last_file_time"]."</td>";
				echo "<td>".$value["start_restore_time"]."</td>";
				echo "<td>".$value["end_restore_time"]."</td>";
				echo "<td>".$value["isold"]."</td>";
			echo "</tr>";
		}
		if(empty($db_name)) {
			echo "<tr><td colspan='6' bgcolor='yellow'>所有数据库都已还原</td></tr>";
		} else {
			$not_restored = implode(',<br/>', $db_name);
			echo "<tr><td colspan='6' bgcolor='pink'>$not_restored 未还原</td></tr>";
		}
		echo "</table>";
				
	} else {
		$sdb_cfg = $cfg;
		unset($sdb_cfg["restore_info"]);
		
		$db_name = array();
		foreach($sdb_cfg as $op => $op_cfg) {
			#查找需要还原的服务器
			/*
			$mysqli = new mysqli($cfg[$op]['sdbarg']['host'], $cfg[$op]['sdbarg']['user'], $cfg[$op]['sdbarg']['pass'], $cfg[$op]['sdbarg']['name'], $cfg[$op]['sdbarg']['port']);
			#print $cfg[$op]['sdbarg']['host'].", ".$cfg[$op]['sdbarg']['user'].", ".$cfg[$op]['sdbarg']['pass'].", ".$cfg[$op]['sdbarg']['name'];
			
			if ($mysqli->connect_errno) {
				printf("Connect failed: %s\n", $mysqli->connect_error);
				exit();
			}
			$theday = date("Y-m-d");
			$resultset_res = $mysqli->query("SELECT serverid FROM needrunserver WHERE theday = '$theday'");
			$resultset = $resultset_res->fetch_all(MYSQLI_ASSOC);
			$mysqli->close();
			*/
			$dsn = 'mysql:dbname='.$cfg[$op]['sdbarg']['name'].";host=".$cfg[$op]['sdbarg']['host'].";port=".$cfg[$op]['sdbarg']['port'];
			try {
				$dbh = new PDO($dsn, $cfg[$op]['sdbarg']['user'], $cfg[$op]['sdbarg']['pass']);
			} catch (PDOException $e) {
				echo 'Connection'.$cfg[$op]['sdbarg']['name'].' failed: '.$e->getMessage();
			}
			$theday = date("Y-m-d");
			$sth = $dbh->prepare("SELECT serverid FROM needrunserver WHERE theday = '$theday'");
			$sth->execute();		
			$resultset = $sth->fetchAll();
			
			array_push($db_name, $op."_db_ga");
			foreach ($resultset as $value) {
				array_push($db_name,$op."_db_gs".$value["serverid"]);
			}
		}
		$db_name_str = implode("','", $db_name);
		$db_name_str = "'".$db_name_str."'";
		#var_dump($db_name);		
		
		#查看服务器的还原状态
		/*
		$mysqli = new mysqli($cfg['restore_info']['sdbarg']['host'], $cfg['restore_info']['sdbarg']['user'], $cfg['restore_info']['sdbarg']['pass'], $cfg['restore_info']['sdbarg']['name'], $cfg['restore_info']['sdbarg']['port']);
		
		if ($mysqli->connect_errno) {
			printf("Connect failed: %s\n", $mysqli->connect_error);
			exit();
		}
		$sql = "SELECT * FROM restore_info WHERE db_name IN ($db_name_str) ORDER BY db_name";
		$resultset_res = $mysqli->query($sql);
		$resultset = $resultset_res->fetch_all(MYSQLI_ASSOC);
		$mysqli->close();
		*/
		$dsn = 'mysql:dbname='.$cfg['restore_info']['sdbarg']['name'].";host=".$cfg['restore_info']['sdbarg']['host'].";port=".$cfg['restore_info']['sdbarg']['port'];
		try {
			$dbh = new PDO($dsn, $cfg['restore_info']['sdbarg']['user'], $cfg['restore_info']['sdbarg']['pass']);
		} catch (PDOException $e) {
			echo 'Connection'.$cfg['restore_info']['sdbarg']['name'].' failed: '.$e->getMessage();
		}
		$sth = $dbh->prepare("SELECT * FROM restore_info WHERE db_name IN ($db_name_str) ORDER BY db_name");
		$sth->execute();		
		$resultset = $sth->fetchAll();
		
		#var_dump($resultset);	
		echo "<table border='1' width='720'>";
			echo "<tr align='center'>";
				echo "<td width='120'>数据库</td>";
				echo "<td width='120'>能否还原</td>";
				echo "<td width='120'>最后文件时间</td>";
				echo "<td width='120'>开始还原时间</td>";
				echo "<td width='120'>结束还原时间</td>";
				echo "<td width='120'>是否过旧</td>";
			echo "</tr>";
		foreach ($resultset as $value) {
			$key = array_search($value["db_name"],$db_name);
			unset($db_name[$key]);
			
			#var_dump($value);
			$bgcolor = '';
			if($value["reducible"] == 0) {
				$bgcolor = 'red';
			} elseif ($value["isold"] == 1) {
				$bgcolor = 'pink';
			}			
			if($bgcolor != 'red' && $bgcolor != 'pink' && $show_value == 'wrong') {
				continue;
			}
			echo "<tr align='center' bgcolor='$bgcolor'>";
				echo "<td>".$value["db_name"]."</td>";
				echo "<td>".$value["reducible"]."</td>";
				echo "<td>".$value["last_file_time"]."</td>";
				echo "<td>".$value["start_restore_time"]."</td>";
				echo "<td>".$value["end_restore_time"]."</td>";
				echo "<td>".$value["isold"]."</td>";
			echo "</tr>";
		}
		if(empty($db_name)) {
			echo "<tr><td colspan='6' bgcolor='yellow'>所有数据库都已还原</td></tr>";
		} else {
			$not_restored = implode(',<br/>', $db_name);
			echo "<tr><td colspan='6' bgcolor='pink'>$not_restored 未还原</td></tr>";
		}
		echo "</table>";
	}
?>
