#!/usr/bin/perl
#功能:检查程序是否在运行,如果是在运行,就跳过,否则重新启动该程序
#说明:该程序是用在计划任务中的,所以没有做成死循环! 如果有多个服务需要检查,又不想做成计划任务,可以做成死循环

use warnings;
use strict;

my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
open LOG,">> $base_file.log";

#在此处定义需要检查的服务名
my @processes = ('GM_DataPig','GM_LogPig');

foreach my $process (@processes) {
	my $time = `date`;
	my $sta = `/etc/init.d/$process status`;

	print LOG $time;
	print LOG "\n"; 
	print LOG $sta;

	if($sta =~ /(is running)|(正在執行)|(正在执行)/) {
	
	} else {
		print LOG " ++++++++++++++++++++++++ \n";
		my $res = `/etc/init.d/$process restart`;
		print LOG $res;
		print LOG " ++++++++++++++++++++++++ \n";
	}
}	
print LOG "-------------------------------------------------- \n";
close LOG;
