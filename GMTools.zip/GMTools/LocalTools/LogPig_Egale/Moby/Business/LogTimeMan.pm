use strict;
use warnings;
use utf8;

#############################################################
#
# 敏感字,用户修改游戏服务器敏感字库
#############################################################
package Moby::Business::LogTimeMan;

use POSIX qw{strftime};

sub new
{
	shift;
	my $this = bless {@_};
	$this->init();
	return $this;
}

sub init{
	my ( $this, $nowstr) = @_;
	if( !$nowstr) {
		$nowstr = '1970-01-01 00:00:00';
	}
	$this->{nowstr} = $nowstr;
	$this->{now} = Date::Parse::str2time( $nowstr);
	return $this;
}

sub setLogger{
	my ( $this, $logger) = @_;
	$this->{logger} = $logger;
	return $this;
}

sub runTick{
	my ( $this) = @_;
}

sub setTime {
	my ( $this, $sTime) = @_;
	$this->init( $sTime);
}

sub shut{
}

1;