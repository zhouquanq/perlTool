use strict;
use warnings;

#########################
#
# 读取日志工具类
#
#########################

package Moby::Business::Service::Item;

use Moby::Lib::Common::Common;
use Date::Parse qw{str2time};
use POSIX qw{strftime};
use Moby::Lib::Common::MysqlX;
use Moby::Lib::Common::Common;

sub new{
	shift();
	my $this = bless {@_};
	if( !$this->{timeMan} || !$this->{logger}) {
		warn( "illegal param");
	}
	$this->init();
	return $this;
}

sub init {
	my ($this ) = @_;
	$this->{data} = {
		item => {},
	};	
}

sub Insert{
	my( $this, $hDataPackage, $aDataSet, $params_notify) = @_;
	my $sLSN 		= $hDataPackage->{lsn};
	my $sDateTime 	= $hDataPackage->{datetime};
	my $hData 		= $hDataPackage->{data};
	
	my $item_match = [];
	my $gas = $params_notify->{dstdb};
	my $record = $gas->fetchAll("SELECT mim.protocol, mim.pids FROM meta_item_match mim where mim.status = 1 and mim.type = '物品增加改变'");
	foreach my $item (@$record){
		my $type = $item->{type};
		push @{$item_match}, $item;
	}
	
	my $type = '物品增加改变';
	my $proto = $hData->{protocol};
	my $pid = $hData->{pid};
	my $quality = $hData->{quality};
	my $count = $hData->{change};
	
	foreach my $item (@{$item_match}){
		my $protocol = $item->{protocol};
		my $pids = $item->{pids};
		if($protocol =~ /$proto/ && $pids =~ /$pid/){
			$this->{data}->{item}->{$type}->{$proto}->{$pid}->{insert} += $count;
		}
	}
}

sub Remove{
	my( $this, $hDataPackage, $aDataSet, $params_notify) = @_;
	my $sLSN 		= $hDataPackage->{lsn};
	my $sDateTime 	= $hDataPackage->{datetime};
	my $hData 		= $hDataPackage->{data};
	
	my $item_match = [];
	my $gas = $params_notify->{dstdb};
	my $record = $gas->fetchAll("SELECT mim.protocol, mim.pids FROM meta_item_match mim where mim.status = 1 and mim.type = '物品移除改变'");
	foreach my $item (@$record){
		push @{$item_match}, $item;
	}
	
	my $type = '物品移除改变';
	my $proto = $hData->{protocol};
	my $pid = $hData->{pid};
	my $count = $hData->{change};
	
	foreach my $item (@{$item_match}){
		my $protocol = $item->{protocol};
		my $pids = $item->{pids};
		if($protocol =~ /$proto/ && $pids =~ /$pid/){
			$this->{data}->{item}->{$type}->{$proto}->{$pid}->{remove} += $count;
		}
	}
}

sub Numeric{
	my( $this, $hDataPackage, $aDataSet, $params_notify) = @_;
	my $sLSN 		= $hDataPackage->{lsn};
	my $sDateTime 	= $hDataPackage->{datetime};
	my $hData 		= $hDataPackage->{data};
	
	my $item_match = [];
	my $gas = $params_notify->{dstdb};
	my $record = $gas->fetchAll("SELECT mim.protocol, mim.pids FROM meta_item_match mim where mim.status = 1 and mim.type = '数值类改变'");
	foreach my $item (@$record){
		push @{$item_match}, $item;
	}
	
	my $type = '数值类改变';
	my $proto = $hData->{protocol};
	my $pid = $hData->{type};
	my $count = $hData->{value};
	foreach my $item (@{$item_match}){
		my $protocol = $item->{protocol};
		my $pids = $item->{pids};
		if($protocol =~ /$proto/ && $pids =~ /$pid/){
			if ($count > 0){
				$this->{data}->{item}->{$type}->{$proto}->{$pid}->{insert} += $count;
			}else{
				$this->{data}->{item}->{$type}->{$proto}->{$pid}->{remove} += $count;
			}
		}
	}
}

sub runHour {
	my ($this, $params) = @_;
		
	#插入数据表 meta_jewel
	return unless $params->{logDayTime};
	return unless $this->{data};
	
	my $theday	 =$params->{logDayTime};
	my $serverid =$params->{sid};

	my ($row_item_insert, $row_item_remove, $row_num_insert, $row_num_remove) = (undef, undef, undef, undef);
	foreach my $type(keys %{$this->{data}->{item}}){
		foreach my $proto (keys %{$this->{data}->{item}->{$type}}){
			foreach my $pid (keys %{$this->{data}->{item}->{$type}->{$proto}}){
				if($type eq '数值类改变'){
					if(exists $this->{data}->{item}->{$type}->{$proto}->{$pid}->{insert}){
						my $count = $this->{data}->{item}->{$type}->{$proto}->{$pid}->{insert};
						$row_num_insert .= "('$theday', $serverid, '$proto', $pid, $count),"
					}
					if(exists $this->{data}->{item}->{$type}->{$proto}->{$pid}->{remove}){
						my $count = $this->{data}->{item}->{$type}->{$proto}->{$pid}->{remove};
						$row_num_remove .= "('$theday', $serverid, '$proto', $pid, $count),"
					}
				}else{
					if(exists $this->{data}->{item}->{$type}->{$proto}->{$pid}->{insert}){
						my $count = $this->{data}->{item}->{$type}->{$proto}->{$pid}->{insert};
						$row_item_insert .= "('$theday', $serverid, '$proto', $pid, $count),"
					}
					if(exists $this->{data}->{item}->{$type}->{$proto}->{$pid}->{remove}){
						my $count = $this->{data}->{item}->{$type}->{$proto}->{$pid}->{remove};
						$row_item_remove .= "('$theday', $serverid, '$proto', $pid, $count),"
					}
				}
			}
		}
	}
	
	my $field = "(`theday`,`serverid`,`proto`,`pid`,`num`)";
	if($row_item_insert && $row_item_insert =~ s/,$//){
		#$params->{dstdb}->_execute("delete from meta_item_insert where theday = '$theday' and serverid = $serverid");
		$params->{dstdb}->_execute("INSERT INTO meta_item_insert $field VALUES $row_item_insert");
	}
	if($row_item_remove && $row_item_remove =~ s/,$//){
		#$params->{dstdb}->_execute("delete from meta_item_remove where theday = '$theday' and serverid = $serverid");
		$params->{dstdb}->_execute("INSERT INTO meta_item_remove $field VALUES $row_item_remove");
	}
	if($row_num_insert && $row_num_insert =~ s/,$//){
		#$params->{dstdb}->_execute("delete from meta_num_insert where theday = '$theday' and serverid = $serverid");
		$params->{dstdb}->_execute("INSERT INTO meta_num_insert $field VALUES $row_num_insert");
	}
	if($row_num_remove && $row_num_remove =~ s/,$//){
		#$params->{dstdb}->_execute("delete from meta_num_remove where theday = '$theday' and serverid = $serverid");
		$params->{dstdb}->_execute("INSERT INTO meta_num_remove $field VALUES $row_num_remove");
	}
	
	$this->{data}->{item} = {};
}

sub runDay {
	my( $this) = @_;
}

sub runWeek{
	my( $this) = @_;
}

sub runMonth{
	my( $this) = @_;
}

sub shut{
	my( $this) = @_;
	$this->runDay();
}

1;