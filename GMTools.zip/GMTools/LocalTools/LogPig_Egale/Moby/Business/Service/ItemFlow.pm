use strict;
use warnings;

#########################
#
# 读取日志工具类
#
#########################

package Moby::Business::Service::ItemFlow;

use Moby::Lib::Common::Common;
use Date::Parse qw{str2time};
use POSIX qw{strftime};
use Moby::Lib::Common::MysqlX;
use Moby::Lib::Common::Common;

sub new{
	shift();
	my $this = bless {@_};
	if( !$this->{timeMan} || !$this->{logger}) {
		warn( "illegal param");
	}
	$this->init();
	return $this;
}

sub init {
	my ($this ) = @_;
	$this->{data} = {
		itemflow => {},
	};	
}
#item insert cid={{000104C800000047}};chr={{钟寻菡}};itemname={{巨象护腕}};pid={{10004207}};iid={{001104C8000008C6}};count={{1}};container={{1}};slot={{0}};quality={{2}};enhance={{0}}binding={{0}};change={{1}};create={{1}};needlevel={{46}};protocol={{killelite}};
sub Itemflow{
	my( $this, $hDataPackage, $aDataSet, $params_notify) = @_;

	my $sLSN 		= $hDataPackage->{lsn};
	my $sDateTime 	= $hDataPackage->{datetime};
	my $hData 		= $hDataPackage->{data};
	my $maincmd 		= $hDataPackage->{maincmd};
	my $subcmd 		= $hDataPackage->{subcmd};
	
	my $cid = $hDataPackage->{data}->{cid};
	my $chr = $hDataPackage->{data}->{chr};
	my $itemname = $hDataPackage->{data}->{itemname};
	my $pid = $hDataPackage->{data}->{pid};
	my $iid = $hDataPackage->{data}->{iid};
	my $quality = $hDataPackage->{data}->{quality};
	my $count = $hDataPackage->{data}->{change};
	my $flowtype = 0;
	if($subcmd eq 'insert'){
		$flowtype = 1;
	}
	my $proto = $hDataPackage->{data}->{protocol};
	my $destroy = $hDataPackage->{data}->{destroy}?$hDataPackage->{data}->{destroy}:0;
	my $binding = $hDataPackage->{data}->{binding};

	$this->{data}->{itemflow}->{$cid}->{$sDateTime}->{$flowtype}->{itemname} = $itemname;
	$this->{data}->{itemflow}->{$cid}->{$sDateTime}->{$flowtype}->{chr} = $chr;
	$this->{data}->{itemflow}->{$cid}->{$sDateTime}->{$flowtype}->{pid} = $pid;
	$this->{data}->{itemflow}->{$cid}->{$sDateTime}->{$flowtype}->{iid} = $iid;
	$this->{data}->{itemflow}->{$cid}->{$sDateTime}->{$flowtype}->{quality} = $quality;
	$this->{data}->{itemflow}->{$cid}->{$sDateTime}->{$flowtype}->{count} = $count;
	$this->{data}->{itemflow}->{$cid}->{$sDateTime}->{$flowtype}->{proto} = $proto;
	$this->{data}->{itemflow}->{$cid}->{$sDateTime}->{$flowtype}->{destroy} = $destroy;
	$this->{data}->{itemflow}->{$cid}->{$sDateTime}->{$flowtype}->{binding} = $binding;
}

sub runHour {
	my ($this, $params) = @_;
		
	
	# return unless $params->{logDayTime};
	# return unless $this->{data};
	
	my $sdb = $params->{srcdb};
	my $gas = $params->{dstdb};
	my $serverid = $params->{sid};
	my $theday = $params->{logDayTime};
	my $row = undef;
	foreach my $cid (keys %{$this->{data}->{itemflow}}){
		foreach my $datetime (keys %{$this->{data}->{itemflow}->{$cid}}){
			foreach my $flowtype (keys %{$this->{data}->{itemflow}->{$cid}->{$datetime}}){
				my $itemname = $this->{data}->{itemflow}->{$cid}->{$datetime}->{$flowtype}->{itemname};
				my $chr = $this->{data}->{itemflow}->{$cid}->{$datetime}->{$flowtype}->{chr};
				my $pid = $this->{data}->{itemflow}->{$cid}->{$datetime}->{$flowtype}->{pid};
				my $iid = $this->{data}->{itemflow}->{$cid}->{$datetime}->{$flowtype}->{iid};
				my $quality = $this->{data}->{itemflow}->{$cid}->{$datetime}->{$flowtype}->{quality};
				my $count = $this->{data}->{itemflow}->{$cid}->{$datetime}->{$flowtype}->{count};
				my $proto = $this->{data}->{itemflow}->{$cid}->{$datetime}->{$flowtype}->{proto};
				my $destroy = $this->{data}->{itemflow}->{$cid}->{$datetime}->{$flowtype}->{destroy};
				my $binding = $this->{data}->{itemflow}->{$cid}->{$datetime}->{$flowtype}->{binding};
				
				$row .= "('$datetime',$serverid,'$cid','$chr','$pid','$iid',$quality,$count,'$itemname',$flowtype,'$proto',$destroy,$binding),";
			}
		}
	}
	
	my $field = "(`theday`,`serverid`,`playerid`,`chr`,`pid`,`iid`,`quality`,`count`,`itemname`,`flowtype`,`proto`,`destroy`,`binding`)";
		
	if($row && $row =~ s/,$//){
		#$sdb->_execute("delete from itemflow where left(theday,10) = '$theday'");
		$sdb->_execute("INSERT INTO itemflow $field VALUES $row");
	}
	
	$this->{data}->{itemflow} = {};
}

sub runDay {
	my( $this) = @_;
}

sub runWeek{
	my( $this) = @_;
}

sub runMonth{
	my( $this) = @_;
}

sub shut{
	my( $this) = @_;
	# $this->runDay();
}

1;