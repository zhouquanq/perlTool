use strict;
use warnings;
use utf8;

#########################
#
# 读取日志工具类
#
#########################

package Moby::Business::Service::Factory;

use IO::File;
use IO::Handle;
use POSIX qw{strftime};
use File::Path qw(mkpath);
use Data::Dumper qw(Dumper);
use Date::Parse qw{str2time};

use Moby::Lib::Common::Common;

use Moby::Business::Service::Online;
use Moby::Business::Service::Camp;
use Moby::Business::Service::ItemFlow;
use Moby::Business::Service::Money;
use Moby::Business::Service::Item;
use Moby::Business::Service::Task;
use Moby::Business::Service::Operation;
use Moby::Business::Service::Activity;

sub new{
	shift();
	my $this = bless {@_};
	if( !$this->{logger} || !$this->{timeMan} || !$this->{logTimeMan}) {
		warn( "illegal param");
	}
	
	$Data::Dumper::Terse = 1;
	
	$this->{services} = {};
	
	$this->getOnline();
	$this->getCamp();
	$this->getTask();
	$this->getItem();
	$this->getMoney();
	$this->getItemflow();
	$this->getOperation();
	$this->getActivity();
	# $this->getSystem();
	return $this;
}

sub getOnline{
	my( $this) = @_;
	if( !$this->{services}->{online}) {
		$this->{logger}->info( "create Moby::Business::Service::Online");
		$this->{services}->{online} = Moby::Business::Service::Online->new( 
			timeMan=>$this->{timeMan},
			logger=>$this->{logger},
			logTimeMan=>$this->{logTimeMan},
		);
	}
	return $this->{services}->{online};
}

sub getCamp {
	my( $this) = @_;
	if( !$this->{services}->{camp}) {
		$this->{logger}->info( "create Moby::Business::Service::Camp");
		$this->{services}->{camp} = Moby::Business::Service::Camp->new( 
			timeMan=>$this->{timeMan},
			logger=>$this->{logger},
			logTimeMan=>$this->{logTimeMan},
		);
	}
	return $this->{services}->{camp};
}

sub getTask {
	my( $this) = @_;
	if( !$this->{services}->{task}) {
		$this->{logger}->info( "create Moby::Business::Service::Task");
		$this->{services}->{task} = Moby::Business::Service::Task->new( 
			timeMan=>$this->{timeMan},
			logger=>$this->{logger},
			logTimeMan=>$this->{logTimeMan},
		);
	}
	return $this->{services}->{task};
}

sub getSystem {
	my( $this) = @_;
	if( !$this->{services}->{'system'}) {
		$this->{logger}->info( "create Moby::Business::Service::System");
		$this->{services}->{'system'} = Moby::Business::Service::System->new( 
			timeMan=>$this->{timeMan},
			logger=>$this->{logger},
			logTimeMan=>$this->{logTimeMan},
		);
	}
	return $this->{services}->{'system'};
}

sub getItem {
	my( $this) = @_;
	if( !$this->{services}->{'item'}) {
		$this->{logger}->info( "create Moby::Business::Service::Item");
		$this->{services}->{'item'} = Moby::Business::Service::Item->new( 
			timeMan=>$this->{timeMan},
			logger=>$this->{logger},
			logTimeMan=>$this->{logTimeMan},
		);
	}
	return $this->{services}->{'item'};	
}

sub getMoney{
	my( $this) = @_;
	if( !$this->{services}->{'money'}) {
		$this->{logger}->info( "create Moby::Business::Service::Money");
		$this->{services}->{'money'} = Moby::Business::Service::Money->new( 
			timeMan=>$this->{timeMan},
			logger=>$this->{logger},
			logTimeMan=>$this->{logTimeMan},
		);
	}
	return $this->{services}->{'money'};	
}

sub getItemflow{
	my( $this) = @_;
	if( !$this->{services}->{'Itemflow'}) {
		$this->{logger}->info( "create Moby::Business::Service::ItemFlow");
		$this->{services}->{'Itemflow'} = Moby::Business::Service::ItemFlow->new( 
			timeMan=>$this->{timeMan},
			logger=>$this->{logger},
			logTimeMan=>$this->{logTimeMan},
		);
	}
	return $this->{services}->{'Itemflow'};	
}

sub getOperation{
	my( $this) = @_;
	if( !$this->{services}->{'Operation'}) {
		$this->{logger}->info( "create Moby::Business::Service::Operation");
		$this->{services}->{'Operation'} = Moby::Business::Service::Operation->new( 
			timeMan=>$this->{timeMan},
			logger=>$this->{logger},
			logTimeMan=>$this->{logTimeMan},
		);
	}
	return $this->{services}->{'Operation'};	
}

sub getActivity{
	my( $this) = @_;
	if( !$this->{services}->{'Activity'}) {
		$this->{logger}->info( "create Moby::Business::Service::Activity");
		$this->{services}->{'Activity'} = Moby::Business::Service::Activity->new( 
			timeMan=>$this->{timeMan},
			logger=>$this->{logger},
			logTimeMan=>$this->{logTimeMan},
		);
	}
	return $this->{services}->{'Activity'};	
}


# sub getHero {
	# my( $this) = @_;
	# if( !$this->{services}->{'hero'}) {
		# $this->{logger}->info( "create Moby::Business::Service::Hero");
		# $this->{services}->{'hero'} = Moby::Business::Service::Hero->new( 
			# timeMan=>$this->{timeMan},
			# logger=>$this->{logger},
			# logTimeMan=>$this->{logTimeMan},
		# );
	# }
	# return $this->{services}->{'hero'};
# }

sub runTickLoad {
	my ( $this, $loadFile) = @_;
	my $tmpData;
	if(defined($loadFile)){	
		my $fh = new IO::File( $loadFile, "r");
		
		my $filecontent = "";
		while(1) {
			my $sFileBuf;
			my $iReturnSize = sysread( $fh, $sFileBuf, 4096000);
			if( !$iReturnSize || !$sFileBuf) {
				last;
			}
			$filecontent = $filecontent ? sprintf( "%s%s", $filecontent, $sFileBuf) : $sFileBuf;
		}
	    $fh->close;
	    $tmpData = eval( $filecontent);
	    $this->{logger}->info( "load file length:".length( $filecontent).", name:".$loadFile.", hash:".$tmpData);
	    #$this->{logger}->info( "load file content:". $filecontent);
	}
	foreach my $sSvrName( keys %{$this->{services}}) {
		if( $this->{services}->{$sSvrName}) {
			if($tmpData) {
				$this->{services}->{$sSvrName}->{data} = $tmpData->{$sSvrName};	
				$this->{logger}->info("+loadData: ".$sSvrName."\n");
			} else {
				$this->{services}->{$sSvrName}->init();
			}
		}
	}
}

sub runTickSave {
	my ( $this, $params) = @_;
	my $data = {};	
	return unless $params->{hourtime}; 
	foreach my $sSvrName( keys %{$this->{services}}) {
		if( $this->{services}->{$sSvrName}) {
			if($params->{if_insert} == 1) {
				$this->{logger}->info("----insert into db- service:".$sSvrName." day:".$params->{logDayTime}." sid:".$params->{sid}."\n");
				$this->{services}->{$sSvrName}->runDay($params);
				
				#周
				my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(str2time($params->{logDayTime}) + 86400);
				if($wday == 1){
					$this->{logger}->info("----insert into db- week service:".$sSvrName." day:".$params->{logDayTime}." sid:".$params->{sid}."\n");
					$this->{services}->{$sSvrName}->runWeek($params);
				}
				#月
				if($mday == 1){
					$this->{logger}->info("----insert into db- month service:".$sSvrName." day:".$params->{logDayTime}." sid:".$params->{sid}."\n");
					$this->{services}->{$sSvrName}->runMonth($params);
				}
			}
			if($sSvrName eq 'item'){
				$this->{logger}->info("----insert into db- hour service:".$sSvrName." day:".$params->{logDayTime}." sid:".$params->{sid}."\n");
				$this->{services}->{$sSvrName}->runHour($params);
			}
			if($sSvrName eq 'money'){
				$this->{logger}->info("----insert into db- hour service:".$sSvrName." day:".$params->{logDayTime}." sid:".$params->{sid}."\n");
				$this->{services}->{$sSvrName}->runHour($params);
			}
			if($sSvrName eq 'Itemflow'){
				$this->{logger}->info("----insert into db- hour service:".$sSvrName." day:".$params->{logDayTime}." sid:".$params->{sid}."\n");
				$this->{services}->{$sSvrName}->runHour($params);
			}
			if($sSvrName eq 'Operation'){
				$this->{logger}->info("----insert into db- hour service:".$sSvrName." day:".$params->{logDayTime}." sid:".$params->{sid}."\n");
				$this->{services}->{$sSvrName}->runHour($params);
			}
			if($sSvrName eq 'Activity'){
				$this->{logger}->info("----insert into db- hour service:".$sSvrName." day:".$params->{logDayTime}." sid:".$params->{sid}."\n");
				$this->{services}->{$sSvrName}->runHour($params);
			}
			$data->{$sSvrName} = $this->{services}->{$sSvrName}->{data};
		}
	}
	my $tmpdatadir = $params->{tmpdatadir};
	my $tmpdatafile = $tmpdatadir."/".$params->{spb}."_".$params->{sid}."_".$params->{hourtime}.".pl";
	my $tmp_data = Dumper($data);
	my $tmp_data_len = length($tmp_data);

	{
		my $fh = new IO::File( $tmpdatafile, "w");
		my $io = new IO::Handle;
	    if( !defined( $fh)) {
	    	$this->{logger}->info("open file error:$tmpdatafile");
	    	die( $!);
	    }
	    if( !$io->fdopen( fileno( $fh),"w")) {
	    	$this->{logger}->info("open io error:$tmpdatafile");
	    	die( $!);
	    }
	    $io->print( $tmp_data);
	    $io->flush();
	    $io->sync();
	    $io->close();
	    $fh->close;
	}
	
	$this->{logger}->info("----saveData: ".$tmpdatafile." data length: $tmp_data_len\n");
	
	#记入日志分析进度表
	my $row = {
		sid		=>	$params->{sid},
		lastfile	=>	$params->{hourtime}."\.lzo",
		iscomplete	=>	$params->{is_complete},
	};
	$this->{logger}->info("\nlogana_ruler\.sid:".$params->{sid}."\nlogana_ruler\.lastfile:".$params->{hourtime}."\.lzo\nlogana_ruler\.iscomplete:".$params->{is_complete}."\n\n");
	Moby::Lib::Common::Common::write_into_metable6('logana_ruler', $row, ['sid'], $params->{dstdb});
	return $tmpdatafile;
}

sub shut{
	my( $this) = @_;
	foreach my $sSvrName( keys %{$this->{services}}) {
		if( $this->{services}->{$sSvrName}) {
			$this->{services}->{$sSvrName}->shut();
		}
		delete $this->{services}->{$sSvrName};
	}
}

1;