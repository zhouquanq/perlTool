use strict;
use warnings;

#########################
#
# 
#
#########################

package Moby::Business::Service::Operation;

use Moby::Lib::Common::Common;
use Date::Parse qw{str2time};
use POSIX qw{strftime};
use Moby::Lib::Common::MysqlX;
use Moby::Lib::Common::Common;

sub new{
	shift();
	my $this = bless {@_};
	if( !$this->{timeMan} || !$this->{logger}) {
		warn( "illegal param");
	}
	$this->init();
	return $this;
}

sub init {
	my ($this ) = @_;
	$this->{data} = {
		Operation => {},
	};	
}

sub Operation{
	my( $this, $aDataSet, $params_notify) = @_;

	foreach my $hDataPackageAll (@{$aDataSet}){
		my $sDateTime 	= $hDataPackageAll->{datetime};
		my $hData 		= $hDataPackageAll->{data};
		next if ($hData =~ /keeplife/);
		if($hData =~ /onRemoteInput:.*playerId=(.*) data=\d+ (\w+)(.*)/){
			my ($playerid, $operation, $data) = ($1,$2,$3);
			$data =~ s/^\s*//;
			$data =~ s/\)//g;
			$data =~ s/\(//g;
			$data =~ s/,//g;
			$data =~ s/\<//g;
			$data =~ s/\>//g;
			$data =~ s/\[//g;
			$data =~ s/\]//g;
			$data =~ s/;//g;
			$data =~ s/'//g;
			$data =~ s/\///g;
			$data =~ s/\\//g;
			
			$this->{data}->{Operation}->{$playerid}->{$sDateTime}->{proto} = $operation;
			$this->{data}->{Operation}->{$playerid}->{$sDateTime}->{data} = $data;
			
		}elsif($hData =~ /onRemoteInput:.*entergame (.*)/){
			my ($playerid) = ($1);
			$this->{data}->{Operation}->{$playerid}->{$sDateTime}->{proto} = 'entergame';
		}
	}
}

sub runHour {
	my ($this, $params) = @_;
		
	
	# return unless $params->{logDayTime};
	# return unless $this->{data};
	
	my $sdb = $params->{srcdb};
	my $gas = $params->{dstdb};
	my $serverid = $params->{sid};
	my $theday = $params->{logDayTime};
	my $row = undef;
	foreach my $cid (keys %{$this->{data}->{Operation}}){
		foreach my $datetime (keys %{$this->{data}->{Operation}->{$cid}}){
			my $proto = $this->{data}->{Operation}->{$cid}->{$datetime}->{proto};
			my $data = $this->{data}->{Operation}->{$cid}->{$datetime}->{data}?$this->{data}->{Operation}->{$cid}->{$datetime}->{data}:'';
			$row .= "('$datetime',$serverid,'$cid','$proto','$data'),";
		}
	}
	
	my $field = "(`theday`,`serverid`,`playerid`,`proto`,`data`)";
		
	if($row && $row =~ s/,$//){
		$gas->_execute("INSERT INTO onRemoteInput $field VALUES $row");
	}
	
	$this->{data}->{Operation} = {};
}

sub runDay {
	my( $this) = @_;
}

sub runWeek{
	my( $this) = @_;
}

sub runMonth{
	my( $this) = @_;
}

sub shut{
	my( $this) = @_;
	# $this->runDay();
}

1;