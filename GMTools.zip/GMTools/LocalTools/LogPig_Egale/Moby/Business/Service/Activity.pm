use strict;
use warnings;

#########################
#
# 读取日志工具类
#
#########################

package Moby::Business::Service::Activity;

use Moby::Lib::Common::Common;
use Date::Parse qw{str2time};
use POSIX qw{strftime};
use Moby::Lib::Common::MysqlX;
use Moby::Lib::Common::Common;

sub new{
	shift();
	my $this = bless {@_};
	if( !$this->{timeMan} || !$this->{logger}) {
		warn( "illegal param");
	}
	$this->init();
	return $this;
}

sub init {
	my ($this ) = @_;
	$this->{data} = {
		Activity => {},
	};	
}
#item insert cid={{000104C800000047}};chr={{钟寻菡}};itemname={{巨象护腕}};pid={{10004207}};iid={{001104C8000008C6}};count={{1}};container={{1}};slot={{0}};quality={{2}};enhance={{0}}binding={{0}};change={{1}};create={{1}};needlevel={{46}};protocol={{killelite}};
sub Activity{
	my( $this, $hDataPackage, $aDataSet, $params_notify) = @_;

	my $sLSN 		= $hDataPackage->{lsn};
	my $sDateTime 	= $hDataPackage->{datetime};
	my $hData 		= $hDataPackage->{data};
	my $maincmd 		= $hDataPackage->{maincmd};
	my $subcmd 		= $hDataPackage->{subcmd};
	
	my $cid = $hDataPackage->{data}->{cid};
	my $chr = $hDataPackage->{data}->{chr};
	my $subid = $hDataPackage->{data}->{subid}?$hDataPackage->{data}->{subid}:0;
# 满足条件奖励(细分)    activity taketargetedbonuses cid={{}};chr={{}};activityid={{}};subid={{}};
# 1.装备强化  2.装备洗练  2.屠龙积分  3.抽侠客  4.勇夺百胜  5.世界boss  6.日常  7.装备魂铸  8.VIP福利  9.武功突破

# 充值返利 (细分)       activity takerechargerebatebonuses cid={{}};chr={{}};activityid={{}};subid={{}};
# 1.累计充值  2.单笔   3.循环

# 积分排行活动(细分)    activity scoreranktakebonuses cid={{}};chr={{}};activityid={{}};subid={{}};
# 1.充值排行  2.消费排行  3.积分换侠客

# 禁地兑换              activity exchangegoods cid={{}};chr={{}};activityid={{}};subid={{}};
# 奇缘抽奖活动          activity enhantedlottery cid={{}};chr={{}};activityid={{}};subid={{}};
# 道具兑换活动          activity exchangeitemexchange cid={{}};chr={{}};activityid={{}};subid={{}};
# 投资返利活动          activity takeinvestmentbonuses cid={{}};chr={{}};activityid={{}};subid={{}};


	$this->{data}->{Activity}->{taketargetedbonuses}->{"$cid\t$chr"}->{$subid} += 1 if($subcmd eq 'taketargetedbonuses');
	$this->{data}->{Activity}->{scoreranktakebonuses}->{"$cid\t$chr"}->{$subid} += 1 if($subcmd eq 'scoreranktakebonuses');
	$this->{data}->{Activity}->{exchangegoods}->{"$cid\t$chr"}->{$subid} += 1 if($subcmd eq 'exchangegoods');
	$this->{data}->{Activity}->{enhantedlottery}->{"$cid\t$chr"}->{$subid} += 1 if($subcmd eq 'enhantedlottery');
	$this->{data}->{Activity}->{exchangeitemexchange}->{"$cid\t$chr"}->{$subid} += 1 if($subcmd eq 'exchangeitemexchange');
	$this->{data}->{Activity}->{takeinvestmentbonuses}->{"$cid\t$chr"}->{$subid} += 1 if($subcmd eq 'takeinvestmentbonuses');
	$this->{data}->{Activity}->{takerechargerebatebonuses}->{"$cid\t$chr"}->{$subid} += 1 if($subcmd eq 'takerechargerebatebonuses');
	$this->{data}->{Activity}->{usewishingwell}->{"$cid\t$chr"}->{$subid} += 1 if($subcmd eq 'usewishingwell');
	$this->{data}->{Activity}->{userebateturntable}->{"$cid\t$chr"}->{$subid} += 1 if($subcmd eq 'userebateturntable');
}

sub runHour {
	my ($this, $params) = @_;
		
	
	# return unless $params->{logDayTime};
	# return unless $this->{data};
	
	my $sdb = $params->{srcdb};
	my $gas = $params->{dstdb};
	my $serverid = $params->{sid};
	my $theday = $params->{logDayTime};
	my $row = undef;
	foreach my $type (keys %{$this->{data}->{Activity}}){
		foreach my $user (keys %{$this->{data}->{Activity}->{$type}}){
			my ($cid,$chr) = $user =~ /(.*)\t(.*)/;
			foreach my $subid (keys %{$this->{data}->{Activity}->{$type}->{$user}}){
				my $count = $this->{data}->{Activity}->{$type}->{$user}->{$subid};
				$row .= "('$theday',$serverid,'$cid','$chr','$type',$subid,$count),";
			}
		}
	}
	
	my $field = "(`theday`,`serverid`,`playerid`,`chr`,`activity`,`subid`,`num`)";
		
	if($row && $row =~ s/,$//){
		#$sdb->_execute("delete from itemflow where left(theday,10) = '$theday'");
		$gas->_execute("INSERT INTO activity $field VALUES $row");
	}
	
	$this->{data}->{Activity} = {};
}

sub runDay {
	my( $this) = @_;
}

sub runWeek{
	my( $this) = @_;
}

sub runMonth{
	my( $this) = @_;
}

sub shut{
	my( $this) = @_;
	# $this->runDay();
}

1;