use strict;
use warnings;
use utf8;

#########################
#
# 读取日志工具类
#
#########################

package Moby::Business::Service::Camp;

use Date::Parse qw{str2time};
use POSIX qw{strftime};
use Data::Dumper;

sub new{
	shift();
	my $this = bless {@_};
	if( !$this->{timeMan} || !$this->{logger}) {
		warn( "illegal param");
	}
	$this->init();
	return $this;
}

sub init {
	my ($this ) = @_;
}

sub rebelcamp {
	my( $this, $hDataPackage, $aDataSet, $params_notify) = @_;
	
	# my $sdb = $params_notify->{srcdb};
	my $conn = Moby::Lib::Common::MysqlX::genConn($params_notify->{srcdbarg});
	my $sdb = new Moby::Lib::Common::MysqlX($conn);
	
	my $cid = $hDataPackage->{data}->{cid};
	my $new_campid = $hDataPackage->{data}->{betrayid};
	
	#更新sdb数据库中的角色阵营;
	my $row = {
		c_serverid	=>	$params_notify->{sid},
		c_playerid	=>	$cid,
		char_campid	=>	$new_campid,
	};
	
	Moby::Lib::Common::Common::update_into_metable6( 'player', $row, ['c_serverid','c_playerid'], $sdb);
}

sub runDay {
	my ($this, $params) = @_;
	
	my $sdb = $params->{srcdb};
	my $gas = $params->{dstdb};
	# my $dstdbarg = $params->{dstdbarg};
	# my $srcdbarg = $params->{srcdbarg};
		
}

sub runWeek{
	my( $this) = @_;
}

sub runMonth{
	my( $this) = @_;
}

sub shut{
	my( $this) = @_;
	$this->runDay();
}

1;