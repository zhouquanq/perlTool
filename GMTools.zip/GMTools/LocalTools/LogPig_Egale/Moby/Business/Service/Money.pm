use strict;
use warnings;

#########################
#
# 读取日志工具类
#
#########################

package Moby::Business::Service::Money;

use Moby::Lib::Common::Common;
use Date::Parse qw{str2time};
use POSIX qw{strftime};
use Moby::Lib::Common::MysqlX;
use Moby::Lib::Common::Common;

sub new{
	shift();
	my $this = bless {@_};
	if( !$this->{timeMan} || !$this->{logger}) {
		warn( "illegal param");
	}
	$this->init();
	return $this;
}

sub init {
	my ($this ) = @_;
	$this->{data} = {
		money => {},
	};	
}

sub Change{
	my( $this, $hDataPackage, $aDataSet, $params_notify) = @_;
	my $sLSN 		= $hDataPackage->{lsn};
	my $sDateTime 	= $hDataPackage->{datetime};
	my $hData 		= $hDataPackage->{data};
	
	#numeric change cid={{000104C80000000B}};chr={{容正信}};type={{5}};value={{725}};protocol={{takehookbonuse}};
	# 绑定金 2,元宝 3
	my $cid = $hDataPackage->{data}->{cid};
	my $type = $hDataPackage->{data}->{type};
	my $value = $hDataPackage->{data}->{value};
	my $protocol = $hDataPackage->{data}->{protocol};
	my $pids = undef;
	my $iids = undef;
	my $itemcount = undef;
	
	if($type == 3 || $type == 2){
		foreach my $line (@{$aDataSet}){
			my $maincmd	= $line->{maincmd};
			my $subcmd	= $line->{subcmd};
			if("$maincmd $subcmd" eq 'item insert' || "$maincmd $subcmd" eq 'item remove'){
				my $pid = $line->{data}->{pid};
				my $iid = $line->{data}->{iid};
				my $change = $line->{data}->{change};
				if(defined $pids){
					$pids = "$pids,$pid";
				}else{
					$pids = $pid;
				}
				
				if(defined $iids){
					$iids = "$iids,$iid";
				}else{
					$iids = $iid;
				}
				if(defined $itemcount){
					$itemcount = "$itemcount,$change";
				}else{
					$itemcount = $change;
				}
			}
		}
		
		$this->{data}->{money}->{$cid}->{$type}->{$sDateTime}->{value} = $value;
		$this->{data}->{money}->{$cid}->{$type}->{$sDateTime}->{protocol} = $protocol;
		$this->{data}->{money}->{$cid}->{$type}->{$sDateTime}->{pids} = $pids?$pids:'0';
		$this->{data}->{money}->{$cid}->{$type}->{$sDateTime}->{iids} = $iids?$iids:'0';
		$this->{data}->{money}->{$cid}->{$type}->{$sDateTime}->{itemcount} = $itemcount?$itemcount:'0';
	}
}

sub runHour {
	my ($this, $params) = @_;
		
	
	# return unless $params->{logDayTime};
	# return unless $this->{data};
	
	my $sdb = $params->{srcdb};
	my $gas = $params->{dstdb};
	my $serverid = $params->{sid};
	my $theday = $params->{logDayTime};

	my $field = "(`serverid`,`time`,`playerid`,`pid`,`iid`,`itemcount`,`money`,`type`,`proto_type`)";
	my $row = undef;
	foreach my $cid (keys %{$this->{data}->{money}}){
		foreach my $type (keys %{$this->{data}->{money}->{$cid}}){
			foreach my $datetime (keys %{$this->{data}->{money}->{$cid}->{$type}}){
				my $value = $this->{data}->{money}->{$cid}->{$type}->{$datetime}->{value};
				my $protocol = $this->{data}->{money}->{$cid}->{$type}->{$datetime}->{protocol};
				my $pids = $this->{data}->{money}->{$cid}->{$type}->{$datetime}->{pids};
				my $iids = $this->{data}->{money}->{$cid}->{$type}->{$datetime}->{iids};
				my $itemcount = $this->{data}->{money}->{$cid}->{$type}->{$datetime}->{itemcount};
				$row .= "($serverid,'$datetime','$cid','$pids','$iids','$itemcount',$value,$type,'$protocol'),";
			}
		}
	}
	
	if($row && $row =~ s/,$//){
		#$sdb->_execute("delete from moneybuyrecord where left(time,10) = '$theday'");
		$sdb->_execute("INSERT INTO moneybuyrecord $field VALUES $row");
	}
	
	$this->{data}->{money} = {};
}

sub runDay {
	my( $this) = @_;
}

sub runWeek{
	my( $this) = @_;
}

sub runMonth{
	my( $this) = @_;
}

sub shut{
	my( $this) = @_;
	# $this->runDay();
}

1;