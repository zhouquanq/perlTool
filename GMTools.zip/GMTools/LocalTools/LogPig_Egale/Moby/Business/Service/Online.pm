use strict;
use warnings;
use utf8;

#########################
#
# 读取日志工具类
#
#########################

package Moby::Business::Service::Online;

use Date::Parse qw{str2time};
use POSIX qw{strftime};
use Data::Dumper;

use Moby::Lib::Common::MysqlX;

sub new{
	shift();
	my $this = bless {@_};
	if( !$this->{timeMan} || !$this->{logger} || !$this->{logTimeMan}) {
		warn( "illegal param");
	}

	$this->init();
	return $this;
}

sub init {
	my ($this ) = @_;
	$this->{data} = {
		enterchar => {},
		exitchar => {},
		logininfo => {},

		#---online nowonlinecount
		hour_online_count =>{ 
			'max' => [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
			'min' => [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
		},
		# online_count => {
			# 'max' => 0,
			# 'min' => 0,
		# },
	};	
}

sub login{ 
	my( $this, $hDataPackage, $aDataSet, $params_notify) = @_;
	
	my $aid = $hDataPackage->{data}->{aid};
	$this->{data}->{loginacc_count}->{$aid}++;
}

#进入游戏
sub entergame{
	my( $this, $hDataPackage, $aDataSet, $params_notify) = @_;

	my $cid = $hDataPackage->{data}->{cid};
	$this->{data}->{enterchar}->{$cid}->{entertime} = $hDataPackage->{datetime};
	$this->{data}->{enterchar}->{$cid}->{sex} = $hDataPackage->{data}->{sex};
	$this->{data}->{enterchar}->{$cid}->{campid} = $hDataPackage->{data}->{campid};
	$this->{data}->{enterchar}->{$cid}->{sceneid} = $hDataPackage->{data}->{sceneid};
	$this->{data}->{enterchar}->{$cid}->{level} = $hDataPackage->{data}->{level};
	
	$this->{data}->{logininfo}->{$cid}->{logincount} += 1;
	$this->{data}->{logininfo}->{$cid}->{sceneid} = $hDataPackage->{data}->{sceneid};
	$this->{data}->{logininfo}->{$cid}->{campid} = $hDataPackage->{data}->{campid};
	$this->{data}->{logininfo}->{$cid}->{sex} = $hDataPackage->{data}->{sex};
	$this->{data}->{logininfo}->{$cid}->{times} += 0;
	$this->{data}->{logininfo}->{$cid}->{timelong} += 0;
	$this->{data}->{logininfo}->{$cid}->{level} = $hDataPackage->{data}->{level};
}

sub exitgame{
	my( $this, $hDataPackage, $aDataSet, $params_notify) = @_;

	my $exit_sec = str2time($hDataPackage->{datetime});

	my $cid = $hDataPackage->{data}->{cid};
	my $sceneid = $hDataPackage->{data}->{sceneid};
	my $sex = $hDataPackage->{data}->{sex};
	my $campid = $hDataPackage->{data}->{campid};
	my $level = $hDataPackage->{data}->{level};
	
	if(exists $this->{data}->{enterchar}->{$cid}){
		my $enter_sec = str2time($this->{data}->{enterchar}->{$cid}->{entertime});
		my $times = $this->{data}->{logininfo}->{$cid}->{times}?$this->{data}->{logininfo}->{$cid}->{times}:0;
		my $timelong = $exit_sec - $enter_sec;
		
		if($times < $timelong){
			$this->{data}->{logininfo}->{$cid}->{times} = $timelong;
		}
		
		$this->{data}->{logininfo}->{$cid}->{timelong} += $timelong;
		$this->{data}->{logininfo}->{$cid}->{sceneid} = $hDataPackage->{data}->{sceneid};
		$this->{data}->{logininfo}->{$cid}->{level} = $hDataPackage->{data}->{level};
		
		delete $this->{data}->{enterchar}->{$cid};
	}else{
		my ($date) = $hDataPackage->{datetime} =~ /(\d{4}-\d{2}-\d{2})/;
		my $enter_sec = str2time("$date 00:00:00");
		my $timelong = $exit_sec - $enter_sec;
		$this->{data}->{logininfo}->{$cid}->{times} = $timelong;
		
		$this->{data}->{logininfo}->{$cid}->{timelong} += $timelong;
		$this->{data}->{logininfo}->{$cid}->{sceneid} = $sceneid;
		$this->{data}->{logininfo}->{$cid}->{logincount} += 1;
		$this->{data}->{logininfo}->{$cid}->{campid} = $campid;
		$this->{data}->{logininfo}->{$cid}->{sex} = $sex;
		$this->{data}->{logininfo}->{$cid}->{level} = $level;
	}
}

sub charlevel{
	my( $this, $hDataPackage, $aDataSet, $params_notify) = @_;
	my $cid = $hDataPackage->{data}->{cid};
	my $alevel = $hDataPackage->{data}->{alevel};
	if(exists $this->{data}->{enterchar}->{$cid}){
		$this->{data}->{logininfo}->{$cid}->{level} = $alevel;
	}
}

sub nowonlinecount{ 
	my( $this, $hDataPackage, $aDataSet, $params_notify) = @_;

	my $nowonlinecount = $hDataPackage->{data}->{count};
	
	my $iHour = $this->getHour(str2time($hDataPackage->{datetime}));
	
	$this->{data}->{hour_online_count}->{max}->[$iHour] = $nowonlinecount if $nowonlinecount > $this->{data}->{hour_online_count}->{max}->[$iHour];
	$this->{data}->{hour_online_count}->{min}->[$iHour] = $nowonlinecount if $nowonlinecount < $this->{data}->{hour_online_count}->{min}->[$iHour];
	# if($nowonlinecount > $this->{data}->{max_online_count}){
		# $this->{data}->{online_count}->{max}->{count} = $nowonlinecount;
		# $this->{data}->{online_count}->{max}->{datetime} = $hDataPackage->{datetime};
	# }
	# if($nowonlinecount < $this->{data}->{min_online_count}){
		# $this->{data}->{online_count}->{min}->{count} = $nowonlinecount;
		# $this->{data}->{online_count}->{min}->{datetime} = $hDataPackage->{datetime};
	# }
}

sub runDay{
	my( $this, $params) = @_;	
	
	my $sdb = $params->{srcdb};
	my $gas = $params->{dstdb};
	my $serverid = $params->{sid};
	my $theday = $params->{logDayTime};
	
	return unless $this->{data};
		
	my $insert_sql = undef;
	my $delete_sql = undef;
	my $filed = undef;
	my $row = undef;
	
	#一天结束时 未退出游戏的处理
	foreach my $cid (keys %{$this->{data}->{enterchar}}){
		my $sceneid = $this->{data}->{enterchar}->{$cid}->{sceneid};
		my $campid = $this->{data}->{enterchar}->{$cid}->{campid};
		my $sex = $this->{data}->{enterchar}->{$cid}->{sex};
		my $times = $this->{data}->{enterchar}->{$cid}->{times};
		my $timelong = $this->{data}->{enterchar}->{$cid}->{timelong};
		my $entertime = $this->{data}->{enterchar}->{$cid}->{entertime};
		my $level = $this->{data}->{enterchar}->{$cid}->{level};
		$entertime =~ /(\d{4}-\d{2}-\d{2})/;

		my $exit_sec = str2time("$1 23:59:59");
		my $enter_sec = str2time($entertime);
		my $timelong_tmp = $exit_sec - $enter_sec;
		
		if(exists $this->{data}->{logininfo}->{$cid}){
			my $times = $this->{data}->{logininfo}->{$cid}->{times}?$this->{data}->{logininfo}->{$cid}->{times}:0;
			if($times < $exit_sec - $enter_sec){
				$this->{data}->{logininfo}->{$cid}->{times} = $timelong_tmp;
			}
			
			$this->{data}->{logininfo}->{$cid}->{timelong} += $timelong_tmp;
			$this->{data}->{logininfo}->{$cid}->{sceneid} = $sceneid;
		}else{
			$this->{data}->{logininfo}->{$cid}->{times} = $timelong_tmp;
		
			$this->{data}->{logininfo}->{$cid}->{timelong} += $timelong_tmp;
			$this->{data}->{logininfo}->{$cid}->{sceneid} = $sceneid;
			$this->{data}->{logininfo}->{$cid}->{logincount} += 1;
			$this->{data}->{logininfo}->{$cid}->{campid} = $campid;
			$this->{data}->{logininfo}->{$cid}->{sex} = $sex;
			$this->{data}->{logininfo}->{$cid}->{level} = $level;
		}
	}

	foreach my $cid (keys %{$this->{data}->{logininfo}}){
		my $times = $this->{data}->{logininfo}->{$cid}->{times};
		my $timelong = $this->{data}->{logininfo}->{$cid}->{timelong};
		my $sceneid = $this->{data}->{logininfo}->{$cid}->{sceneid};
		my $logincount = $this->{data}->{logininfo}->{$cid}->{logincount};
		my $campid = $this->{data}->{logininfo}->{$cid}->{campid};
		my $sex = $this->{data}->{logininfo}->{$cid}->{sex};
		my $level = $this->{data}->{logininfo}->{$cid}->{level};

		$row .= "('$theday',$serverid,'$cid',$times,$timelong,$logincount,$sceneid,$campid,$sex,$level),";
	}
	
	my $field = "(`theday`,`serverid`,`playerid`,`times`,`timelong`,`logincount`,`sceneid`,`campid`,`sex`,`level`)";
	if($row && $row =~ s/,$//){
		$delete_sql = "delete from loginplayer where serverid = $serverid and theday = '$theday'";
		$sdb->_execute($delete_sql);
		$insert_sql = "insert into loginplayer $field values $row";
		$sdb->_execute($insert_sql);
	}
	
	
	#`theday`，`serverid`，`top_char`，`low_char`
	my ($max,$min) = (undef,undef);	
	$min = join(',', @{$this->{data}->{hour_online_count}->{min}});
	$max = join(',', @{$this->{data}->{hour_online_count}->{max}});
	$row = {
		theday		=> $theday,
		serverid	=> $serverid,
		
		top_char => $max,
		low_char => $min,
	};
	Moby::Lib::Common::Common::write_into_metable6('meta_onlinebyhour', $row, ['theday', 'serverid'], $gas);
}

sub runWeek{
	my( $this, $params) = @_;	
	
	my $sdb = $params->{srcdb};
	my $gas = $params->{dstdb};
}

sub runMonth{
	my( $this, $params) = @_;	
	
	my $sdb = $params->{srcdb};
	my $gas = $params->{dstdb};
}

sub shut{
	my( $this) = @_;
	# $this->runDay();
}

sub getHour{
	my($this, $timestr) = @_;
	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) =	localtime($timestr);
	return $hour;
}

1;