use strict;
use warnings;
use utf8;


#########################
#
# 读取日志工具类
#
#########################

package Moby::Business::Service::Task;

use Date::Parse qw{str2time};
use POSIX qw{strftime};
use Data::Dumper;
use Moby::Lib::Common::Common;

sub new{
	shift();
	my $this = bless {@_};
	if( !$this->{timeMan} || !$this->{logger}) {
		warn( "illegal param");
	}
	$this->init();
	return $this;
}

sub init {
	my ($this ) = @_;
	$this->{data} = {
		firsttask => {},                #玩家第一个任务
	};	
}

sub Submit {
	my( $this, $hDataPackage, $aDataSet, $params_notify) = @_;
	
	my $cid = $hDataPackage->{data}->{cid};
	my $chr = $hDataPackage->{data}->{chr};
	my $tid = $hDataPackage->{data}->{tid};
	
	if($tid == 100010){#用来记录玩家强制新手引导时第一个任务
		$this->{data}->{firsttask}->{$cid} = 1;
	}
}

sub runDay {
	my ($this, $params) = @_;
	
	my $sdb = $params->{srcdb};
	my $gas = $params->{dstdb};
	my $serverid = $params->{sid};
	my $theday = $params->{logDayTime};
	
	#更新player表里 第一个任务 情况
	foreach my $cid (keys %{$this->{data}->{firsttask}}){
		my $row = {
			c_serverid	=>	$serverid,
			c_playerid	=>	$cid,
			c_firsttask	=>	1,
		};
		
		Moby::Lib::Common::Common::update_into_metable6( 'player', $row, ['c_serverid','c_playerid'], $sdb);
	}
}

sub runWeek{
	my( $this) = @_;
}

sub runMonth{
	my( $this) = @_;
}

sub shut{
	my( $this) = @_;
	$this->runDay();
}

1;