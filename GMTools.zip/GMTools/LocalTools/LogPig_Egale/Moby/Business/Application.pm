use strict;
use warnings;

#########################
#
# 读取日志工具类
#
#########################

package Moby::Business::Application;

use Moby::Business::TimeMan;
use Moby::Business::LoggerMan;
use Moby::Business::LogTimeMan;

use Moby::Business::Service::Factory;
use Moby::Business::Listener::Factory;

sub new{
	shift();
	my $this = bless {@_};
	if( !$this->{cmdparam} || !$this->{apppath}) {
		warn( "illegal param");
	}
	
	$this->init();
	return $this;
}

sub init{
	my ( $this) = @_;
	$this->{manage}->{logtimer} = Moby::Business::LogTimeMan->new();
	$this->{manage}->{timer} = Moby::Business::TimeMan->new();
	$this->{manage}->{logger} = Moby::Business::LoggerMan->new(
		apppath=>$this->{apppath}, 
		timeMan=>$this->{manage}->{timer}
	);
	$this->{logger} = $this->{manage}->{logger}->getLogger();
	$this->{manage}->{timer}->setLogger( $this->{logger});
	
}

sub getServiceFactory{
	my ( $this) = @_;
	if( !$this->{faction}->{service}) {
		$this->{logger}->info( "create Moby::Business::Service::Factory");
		$this->{faction}->{service} = Moby::Business::Service::Factory->new(
			logger=>$this->{logger},
			timeMan=>$this->{manage}->{timer},
			logTimeMan=>$this->{manage}->{logtimer},
		);
	}
	return $this->{faction}->{service};
}

sub getListenerFactory{
	my ( $this) = @_;
	if( !$this->{faction}->{listen}) {
		$this->{logger}->info( "create Moby::Business::Listener::Factory");
		$this->{faction}->{listen} = Moby::Business::Listener::Factory->new(
			servicefactory=>$this->getServiceFactory(),
		);
	}
	return $this->{faction}->{listen};
}

sub getLogger {
	my ( $this) = @_;
	return $this->{logger};
}

sub getTimeMan{
	my ( $this) = @_;
	return $this->{manage}->{timer};
}

sub getLogTimeMan{
	my ( $this) = @_;
	return $this->{manage}->{logtimer};
}

sub runTick{
	my ( $this) = @_;
	foreach my $sManName( keys %{$this->{manage}}) {
		if( $this->{manage}->{$sManName}) {
			$this->{manage}->{$sManName}->runTick();
		}
	}
}

sub runTickLoad {
	my ( $this, $loadFile) = @_;
	foreach my $sFacName( keys %{$this->{faction}}) {
		if( $this->{faction}->{$sFacName}) {
			$this->{faction}->{$sFacName}->runTickLoad($loadFile);
		}
	}	
}

sub runTickSave {
	my ( $this, $params) = @_;
	foreach my $sFacName( keys %{$this->{faction}}) {
		if( $this->{faction}->{$sFacName} && 'service' eq $sFacName) {
			return $this->{faction}->{$sFacName}->runTickSave($params);
		}
	}	
}

sub shut{
	my ( $this) = @_;
	foreach my $sManName( keys %{$this->{manage}}) {
		if( $this->{manage}->{$sManName}) {
			$this->{manage}->{$sManName}->shut();
		}
		delete $this->{manage}->{$sManName};
	}
	foreach my $sFacName( keys %{$this->{faction}}) {
		if( $this->{faction}->{$sFacName}) {
			$this->{faction}->{$sFacName}->shut();
		}
		delete $this->{faction}->{$sFacName};
	}
}

1;