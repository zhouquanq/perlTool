use strict;
use warnings;
use utf8;

#########################
#
# 读取日志工具类
#
#########################

package Moby::Business::Listener::OnRemoteInput::Operation;

use base qw{Moby::Lib::Listener};

sub new{
	shift();
	my $this = bless Moby::Lib::Listener->new(@_);
	if( !$this->{servicefactory}) {
		warn( "illegal param");
	}
	return $this;
}

sub notify{
	my( $this, $aDataSet, $params_notify) = @_;
	$this->{servicefactory}->getOperation()->Operation( $aDataSet, $params_notify);
}

sub shut{
	my( $this) = @_;
	$this->{servicefactory} = undef;
}

1;