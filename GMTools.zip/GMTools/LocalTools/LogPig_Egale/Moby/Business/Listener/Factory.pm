use strict;
use warnings;
use utf8;

#########################
#
# 读取日志工具类
#
#########################

package Moby::Business::Listener::Factory;

use Moby::Lib::LogFormatListenerMan;

# use Moby::Business::Listener::General::Login;
use Moby::Business::Listener::General::Entergame;
use Moby::Business::Listener::General::Exitgame;
use Moby::Business::Listener::General::Nowonlinecount;
use Moby::Business::Listener::General::Charlevel;
use Moby::Business::Listener::Camp::Campbetray;
use Moby::Business::Listener::Task::Submit;
use Moby::Business::Listener::Item::Remove;
use Moby::Business::Listener::Item::Insert;
use Moby::Business::Listener::Numeric::Change;
# use Moby::Business::Listener::Hero::Heropump;
use Moby::Business::Listener::OnRemoteInput::Operation;
use Moby::Business::Listener::Activity::Taketargetedbonuses;
use Moby::Business::Listener::Activity::Takerechargerebatebonuses;
use Moby::Business::Listener::Activity::Scoreranktakebonuses;
use Moby::Business::Listener::Activity::Exchangegoods;
use Moby::Business::Listener::Activity::Enhantedlottery;
use Moby::Business::Listener::Activity::Exchangeitemexchange;
use Moby::Business::Listener::Activity::Takeinvestmentbonuses;
use Moby::Business::Listener::Activity::Usewishingwell;
use Moby::Business::Listener::Activity::Userebateturntable;
	
sub new{
	shift();
	my $this = bless {@_};
	if( !$this->{servicefactory}) {
		warn( "illegal param");
	}
	$this->init();
	return $this;
}

sub init{
	my ($this) = @_;
	if( !$this->{listenerman}) {
		$this->{listenerman} = Moby::Lib::LogFormatListenerMan->new();
	}
	#在线人数
	$this->{listenerman}->listen(
		'online', 
		'nowonlinecount', 
		Moby::Business::Listener::General::Nowonlinecount->new(
				servicefactory=>$this->{servicefactory}
		) 
	);
	#登录账号
	# $this->{listenerman}->listen(
		# 'general', 
		# 'login', 
		# Moby::Business::Listener::General::Login->new(
				# servicefactory=>$this->{servicefactory}
		# )
	# );
	#进入游戏
	$this->{listenerman}->listen(
		'general', 
		'entergame', 
		Moby::Business::Listener::General::Entergame->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	#退出游戏
	$this->{listenerman}->listen(
		'general', 
		'exitgame', 
		Moby::Business::Listener::General::Exitgame->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	#等级变化
	$this->{listenerman}->listen(
		'levelup', 
		'charlevel', 
		Moby::Business::Listener::General::Charlevel->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	
	#阵营
	$this->{listenerman}->listen(
		'camp', 
		'campbetray', 
		Moby::Business::Listener::Camp::Campbetray->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	
	#物品改变数值类变化
	$this->{listenerman}->listen(
		'item', 
		'insert', 
		Moby::Business::Listener::Item::Insert->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	
	$this->{listenerman}->listen(
		'item', 
		'remove', 
		Moby::Business::Listener::Item::Remove->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	
	$this->{listenerman}->listen(
		'numeric', 
		'change', 
		Moby::Business::Listener::Numeric::Change->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	
	
	#--------------------------
	#运营活动统计
	#--------------------------
	# 满足条件奖励(细分)    activity taketargetedbonuses cid={{}};chr={{}};activityid={{}};subid={{}};
	# 1.装备强化  2.装备洗练  2.屠龙积分  3.抽侠客  4.勇夺百胜  5.世界boss  6.日常  7.装备魂铸  8.VIP福利  9.武功突破

	# 充值返利 (细分)       activity takerechargerebatebonuses cid={{}};chr={{}};activityid={{}};subid={{}};
	# 1.累计充值  2.单笔   3.循环

	# 积分排行活动(细分)    activity scoreranktakebonuses cid={{}};chr={{}};activityid={{}};subid={{}};
	# 1.充值排行  2.消费排行  3.积分换侠客

	# 禁地兑换              activity exchangegoods cid={{}};chr={{}};activityid={{}};subid={{}};
	# 奇缘抽奖活动          activity enhantedlottery cid={{}};chr={{}};activityid={{}};subid={{}};
	# 道具兑换活动          activity exchangeitemexchange cid={{}};chr={{}};activityid={{}};subid={{}};
	# 投资返利活动          activity takeinvestmentbonuses cid={{}};chr={{}};activityid={{}};subid={{}};
	
	$this->{listenerman}->listen(
		'activity', 
		'taketargetedbonuses', 
		Moby::Business::Listener::Activity::Taketargetedbonuses->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	$this->{listenerman}->listen(
		'activity', 
		'takerechargerebatebonuses', 
		Moby::Business::Listener::Activity::Takerechargerebatebonuses->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	$this->{listenerman}->listen(
		'activity', 
		'scoreranktakebonuses', 
		Moby::Business::Listener::Activity::Scoreranktakebonuses->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	$this->{listenerman}->listen(
		'activity', 
		'exchangegoods', 
		Moby::Business::Listener::Activity::Exchangegoods->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	$this->{listenerman}->listen(
		'activity', 
		'enhantedlottery', 
		Moby::Business::Listener::Activity::Enhantedlottery->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	$this->{listenerman}->listen(
		'activity', 
		'exchangeitemexchange', 
		Moby::Business::Listener::Activity::Exchangeitemexchange->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	$this->{listenerman}->listen(
		'activity', 
		'takeinvestmentbonuses', 
		Moby::Business::Listener::Activity::Takeinvestmentbonuses->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	#许愿池
	$this->{listenerman}->listen(
		'activity', 
		'usewishingwell', 
		Moby::Business::Listener::Activity::Usewishingwell->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	#返利转盘
	$this->{listenerman}->listen(
		'activity', 
		'userebateturntable', 
		Moby::Business::Listener::Activity::Userebateturntable->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	
	#=============== 旧日志处理 ====================
	
	$this->{listenerman}->listen(
		'', 
		'', 
		Moby::Business::Listener::OnRemoteInput::Operation->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	
	#结婚
	# $this->{listenerman}->listen(
		# 'marry', 
		# 'marrysuc', 
		# Moby::Business::Listener::Numeric::Change->new(
				# servicefactory=>$this->{servicefactory}
		# )
	# );
	
	#任务
	# $this->{listenerman}->listen(
		# 'task', 
		# 'accepttask', 
		# Moby::Business::Listener::Numeric::Change->new(
				# servicefactory=>$this->{servicefactory}
		# )
	# );
	
	$this->{listenerman}->listen(
		'task', 
		'submittask', 
		Moby::Business::Listener::Task::Submit->new(
				servicefactory=>$this->{servicefactory}
		)
	);
	
	#技能
	# $this->{listenerman}->listen(
		# 'skill', 
		# 'decomposeskill', 
		# Moby::Business::Listener::Skill::Decomposeskill->new(
				# servicefactory=>$this->{servicefactory}
		# )
	# );
	
	#侠客抽取
	# $this->{listenerman}->listen(
		# 'hero', 
		# 'heropump', 
		# Moby::Business::Listener::Hero::Heropump->new(
				# servicefactory=>$this->{servicefactory}
		# )
	# );
	
	#=============== 旧日志处理 ====================
	
	# $this->{listenerman}->listen(
		# '', 
		# '', 
		# Moby::Business::Listener::Item::ItemAdd->new(
				# servicefactory=>$this->{servicefactory}
		# )
	# );
}

sub getLogFormatListenerMan{
	my ($this) = @_;
	return $this->{listenerman};
}

sub runTick{
	my ( $this, $params, $tmp_files) = @_;
	#$this->{listenerman}->trace();
}

sub runTickLoad {
	my ( $this, $loadFile) = @_;
	#$this->{listenerman}->trace();
}

sub runTickSave {
	my ( $this, $params) = @_;
}

sub shut{
	my ($this) = @_;
	$this->{listenerman} = undef;
}

1;