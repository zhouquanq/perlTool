use strict;
use warnings;
use utf8;

#########################
#
# 读取日志工具类
#
#########################

package Moby::Business::Listener::Activity::Takerechargerebatebonuses;

use base qw{Moby::Lib::Listener};

sub new{
	shift();
	my $this = bless Moby::Lib::Listener->new(@_);
	if( !$this->{servicefactory}) {
		warn( "illegal param");
	}
	return $this;
}

sub notify{
	my( $this, $hDataPackage, $aDataSet, $params_notify) = @_;
	$this->{servicefactory}->getActivity()->Activity(  $hDataPackage, $aDataSet, $params_notify);
}

sub shut{
	my( $this) = @_;
	$this->{servicefactory} = undef;
}

1;