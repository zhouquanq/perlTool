use strict;
use warnings;

#########################
#
# 日志格式监听管理模块
#
#########################

package Moby::Lib::LogFormatListenerMan;

use Moby::Lib::ListenerMan;

sub new{
	shift();
	my $this = bless {@_};
	return $this;
}

sub listen{
	my( $this, $maincmd, $subcmd, $listener) = @_;
	
	if($maincmd eq '' && $subcmd eq ''){
		if(!defined $this->{listenmanOld}){
			$this->{listenmanOld} = Moby::Lib::ListenerMan->new();
		}
		$this->{listenmanOld}->appendOld( $listener);
	}
	
	if( !defined( $this->{listenman}->{$maincmd}->{$subcmd})) {
		$this->{listenman}->{$maincmd}->{$subcmd} = Moby::Lib::ListenerMan->new();
	}
	if( 'Moby::Lib::ListenerMan' ne ref($this->{listenman}->{$maincmd}->{$subcmd})) {
		$this->{listenman}->{$maincmd}->{$subcmd} = Moby::Lib::ListenerMan->new();
	}
	$this->{listenman}->{$maincmd}->{$subcmd}->append( $listener);
}

sub notifyList{
	my( $this, $maincmd, $subcmd, $LogType) = @_;
	
	if($LogType eq 'old'){
		if(!defined $this->{listenmanOld}){
			return [];
		}else{
			return $this->{listenmanOld}->getListenersOld();
		}
	}
	if( !defined( $this->{listenman}->{$maincmd}->{$subcmd})) {
		return [];
	}
	if( 'Moby::Lib::ListenerMan' ne ref($this->{listenman}->{$maincmd}->{$subcmd})) {
		return [];
	}
	return $this->{listenman}->{$maincmd}->{$subcmd}->getListeners();
}

sub trace{
	my( $this) = @_;
	my $result = [];
	foreach my $maincmd( keys %{$this->{listenman}}) {
		foreach my $subcmd( %{$this->{listenman}->{$maincmd}}) {
			if( $this->{listenman}->{$maincmd}->{$subcmd}) {
				my $aListeners = $this->{listenman}->{$maincmd}->{$subcmd}->getListeners();
				foreach my $listener( @{$aListeners}) {
					push( @{$result}, sprintf( "%s, %s, %s\n", $maincmd, $subcmd, ref( $listener)));
				}
			}
		}
	}
	return $result;
}

1;