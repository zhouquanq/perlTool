use strict;
use warnings;

#########################
#
# 监听这管理模块
#
#########################

package Moby::Lib::ListenerMan;

sub new{
	shift();
	my $this = bless {};
	$this->{listeners} = {};
	return $this;
}

sub append{
	my( $this, $listener) = @_;
	
	$this->{listeners}->{new}->{$listener} = $listener;
	push( @{$this->{listenersarr}}, $listener);
}

sub appendOld{
	my( $this, $listener) = @_;
	
	$this->{listeners}->{old}->{$listener} = $listener;
	push( @{$this->{listenersarr}}, $listener);
}

sub remove{
	my( $this, $listener) = @_;
	if( defined( $this->{listeners}->{new}->{$listener})) {
		delete $this->{listeners}->{new}->{$listener};
	}
	$listener;
}

sub appendList {
	my( $this, $listeners) = @_;
	if( !$listeners || 'ARRAY' ne ref( $listeners)) {
		return;
	}
	foreach my $listener( @{$listeners}) {
		$this->append( $listener);
	}
}

sub removeAll( ) {
	my( $this) = @_;
	delete $this->{listeners};
}

sub getListeners{
	my( $this) = @_;
	return [values %{$this->{listeners}->{new}}];
}

sub getListenersOld{
	my( $this) = @_;
	return [values %{$this->{listeners}->{old}}];
}

1;