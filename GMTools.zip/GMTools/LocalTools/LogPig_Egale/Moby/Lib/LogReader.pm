use strict;
use warnings;
use utf8;

#########################
#
# 读取日志工具类
#
#########################

package Moby::Lib::LogReader;
use Data::Dumper;

sub new{
	shift();
	my $this = bless {@_};
	if( $this->{sFilePath}) {
		$this->setFilePath( $this->{sFilePath});
	}
	return $this;
}

sub setFilePath{
	my( $this, $sFilePath) = @_;
	$this->{$sFilePath} = $sFilePath;
	if( $this->{fh}) {
		$this->close();
	}
	if( open( my $fhTargetLogFile, "<", $sFilePath)) {
		binmode( $fhTargetLogFile, ":encoding(utf8)");
		$this->{fh} = $fhTargetLogFile;
	}
	$this->{sFileLastLine} = "";
	$this->{hContext} = {};
	$this->{hContextAll} = {};
	$this->{sLastLSN} = "";
	$this->{eof} = 0;
	$this->{aLsn} = [];
}

sub eof{
	my( $this) = @_;
	return $this->{eof};
}

sub process{
	my( $this) = @_;
	
	#用于记录lsn的顺序
	my $sLsn_arr = $this->{aLsn};
	$this->{aLsn} = [];
	if( $this->eof()) {
		return 0;
	}
	my $fhTargetLogFile = $this->{fh};
	my $sLastLSN = $this->{sLastLSN};
	my $aa = 0;
	while( 2 > scalar( keys( %{$this->{hContext}}))) {
		if( $this->eof()) {
			last;
		}
		my $iReturnSize = sysread( $fhTargetLogFile, my $sFileBuf, 4096);
		if( !$iReturnSize || !$sFileBuf){
			$this->{eof} = 1;
			last;
		}
		my $aFileLines = [split( /(?:\r\n|\n)/, $sFileBuf)];
		###########################################
		#use Data::Dumper qw(Dumper);
		#$Data::Dumper::Terse = 1;
		#open my $aFormatLine,">> aformatlines.txt";
		#print $aFormatLine Dumper($aFileLines);
		#close $aFormatLine;
		#############################################
		if( $this->{sFileLastLine}) {
			$aFileLines->[0] = sprintf( "%s%s", $this->{sFileLastLine}, $aFileLines->[0]);
			$this->{sFileLastLine} = "";
		}
		if( !$this->eof() && $sFileBuf !~ /(?:\r\n|\n)$/) {
			$this->{sFileLastLine} = pop( @{$aFileLines});
		}
		foreach my $sFileLine( @{$aFileLines}) {
			if( $sFileLine =~ /\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\](\[\d+\.\d+\])?\[([^\]]+)\]\s*(.*)$/) {
				my $sDateTime = $1;
				my $sLSN = $3;
				$sLastLSN = $3;
				my $sRawData = $4;
				#由于武功 斗转乾坤 在输出时多了个空格 做下特殊处理
				$sRawData = "$1斗转乾坤$2" if($sRawData  =~ /(.*)斗转乾坤 (.*)/);
				#$sRawData = $1."item remove".$2.";pid".$3 if($sRawData  =~ /(.*)item remove(.*)pid(.*)/);
				my $sMainCmd;
				my $sSubCmd;
				my $hData;
				
				if(0 == scalar(@$sLsn_arr) || $sLsn_arr->[-1] ne $sLSN) {
					push @$sLsn_arr,$sLSN;
				}
				
				if( !defined( $this->{hContext}->{$sLSN})){
					$this->{hContext}->{$sLSN} = [];
				}
				
				push( @{$this->{hContextAll}->{$sLSN}}, {
					lsn		=>$sLSN,
					datetime=>$sDateTime,
					data	=>$sRawData,
				});
				
				if( $sRawData =~ /onRemoteInput/) {
					#onRemoteInput: id=5452 socket=80 playerId=90311 data=479 killmonster 996 1360
					if( $sRawData =~ /playerId=(\d+) data=(.*)$/) {
						$sMainCmd = "system";
						$sSubCmd = "onRemoteInput";
						my $sPlayerId = $1;
						my $sData = $2;
						my $aData = [split( / /, $sData)];
						if( 2 > scalar( @{$aData})) {
							next;
						}
						my $iRid = shift( @{$aData});
						my $sCmd = shift( @{$aData});
						
						$hData = {
							rid=>$iRid,
							cmd=>$sCmd,
							params=>$aData,
							cid=>$sPlayerId,
						};
					}
					else {
						next;
					}
				}
				else {
					my $aData = [split( / /, $sRawData)];
					
					if( @{$aData} != 3 && @{$aData} != 4 ) {	#针对错误的fair onsaleinfo日志格式做了兼容修改,使其能兼容; pid中的空格;
						next;
					}
					$sMainCmd = shift( @{$aData});
					if( $sMainCmd !~ /^[a-zA-Z]+$/) {
						next;
					}
					$sSubCmd = shift( @{$aData});
					# my $sData = shift( @{$aData});
					my $sData = join(' ',@{$aData});
					
					if($sMainCmd eq 'fair' && $sSubCmd eq 'onsaleinfo' && scalar(@{$aData})) {
						my $sData2 = shift( @{$aData});
						$sData .= $sData2;
					}
					
					$hData = {$sData =~ m/(\w+)=\{\{(.*?)\}\}/g};
					
				}
							
				push( @{$this->{hContext}->{$sLSN}}, {
					lsn		=>$sLSN,
					datetime=>$sDateTime,
					maincmd	=>$sMainCmd,
					subcmd	=>$sSubCmd,
					data	=>$hData,
				});
			} 
		}
	}
	
	my $aIncomplete = 0;
	if( !$this->eof()) {
		$aIncomplete = $this->{hContext}->{$sLastLSN};
		delete $this->{hContext}->{$sLastLSN};
		pop(@$sLsn_arr);
	}
	
	my $hContext_ = {};
	$hContext_->{new} = $this->{hContext};
	$hContext_->{all} = $this->{hContextAll};
	
	if( $aIncomplete) {
		$this->{hContext} = { $sLastLSN => $aIncomplete};
	} else {
		$this->{hContext} = {};
	}
	
	$this->{sLastLSN} = $sLastLSN;
	push( @{$this->{aLsn}}, $sLastLSN);
	return ($sLsn_arr, $hContext_);
}

sub close{
	my( $this) = @_;
	my $fhTargetLogFile = $this->{fh};
	close( $fhTargetLogFile);
}

1;
