use strict;
use warnings;

#########################
#
# 监听者的父类
#
#########################

package Moby::Lib::Listener;

sub new{
	shift();
	my $this = bless {@_};
	return $this;
}

sub notify{
	my( $this, $data) = @_;
	
	warn( "not implement");
}

1;