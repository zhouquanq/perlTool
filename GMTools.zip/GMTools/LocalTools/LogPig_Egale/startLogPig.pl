#!/usr/bin/perl
use strict;
use warnings;

#########################
#
# 日志分析入口
#
#########################

BEGIN
{
	use FindBin;
	use PerlIO::encoding;
	
	$::APPLICATION_PATH = scalar( $FindBin::Bin);
	chdir( $::APPLICATION_PATH);
	push( @INC, $::APPLICATION_PATH, $::APPLICATION_PATH."/../");
	
	if( 'MSWin32' eq $^O) {
		binmode( STDOUT, ':encoding(gbk)');
	} else {
		binmode( STDOUT, ':encoding(utf8)');
	}
		
	$::APPLICATION_ISRUN = 1;
	
	# 防止意外关闭
	$SIG{HUP} = sub {};
	$SIG{INT} = sub { $::APPLICATION_ISRUN = 0;};
	$| = 1; 
}

require 'srv.pl';

use Date::Parse qw{str2time};
use Data::Dumper qw(Dumper);
use File::Path qw(mkpath rmtree);

use Moby::Business::Application;
use Moby::Lib::LogReader;
use Moby::Lib::Common::Common;
use Moby::Lib::Common::MysqlX;

# 设置日志的临时目录;
my $sTargetLogPath = sprintf( "%s/%s", $::APPLICATION_PATH, "targetlogs");
my $sTempDataFilePath = sprintf( "%s/%s", $::APPLICATION_PATH, "tmpdata");
mkpath($sTempDataFilePath) unless -e $sTempDataFilePath;	

my $oApplication = Moby::Business::Application->new( cmdparam=>{@ARGV}, apppath=>$::APPLICATION_PATH);
my $oLogFormatListenerMan = $oApplication->getListenerFactory()->getLogFormatListenerMan();

my $oLogReader = Moby::Lib::LogReader->new();

use POSIX qw{strftime};

my $oTimeMan = $oApplication->getTimeMan();
my $oLogTimeMan = $oApplication->getLogTimeMan();
my $logger = $oApplication->getLogger();

$logger->info( "================= service statrt ===================");

my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
my $cfg_file = "$base_file.cfg";
die "cfg file: '$cfg_file' not exists!" unless -e $cfg_file;

BIG: while($::APPLICATION_ISRUN == 1) {
	my $cfg_ini = Moby::Lib::Common::Common::load_ini($cfg_file);
	$logger->info("----------circulating-----------\n");
	foreach my $section(@{$cfg_ini}) {
		my $pb = $section->{'name'};
		
		my $dir_base      = Moby::Lib::Common::Common::get_section_value($section, 'dir_base', '');
		my $dstdb      = Moby::Lib::Common::Common::get_section_value($section, 'dstdb', '');
		my $srcdb      = Moby::Lib::Common::Common::get_section_value($section, 'srcdb', '');
		my %dstdb = Moby::Lib::Common::Common::str2arr($dstdb);
		my %srcdb = Moby::Lib::Common::Common::str2arr($srcdb);
				
		#从数据库查询该运营商需要分析日志的服务器(一周内)
		my $last_week = Moby::Lib::Common::Common::ts2str($oTimeMan->{now} - 86400*7, 1);	
		
		my $conn = Moby::Lib::Common::MysqlX::genConn(\%srcdb);
		my $db = new Moby::Lib::Common::MysqlX($conn);
		my $sql = "
			SELECT * FROM needrunserver WHERE theday > '$last_week' GROUP BY serverid ORDER BY serverid
		";
#		my $sql = "
#			SELECT * FROM needrunserver WHERE theday > '$last_week' and serverid in (7,9,12,15) GROUP BY serverid ORDER BY serverid
#		";		
		my $run_servers = $db->fetchAll($sql);
		
		#对该运营商的每个服务器进行日志分析
		foreach (@{$run_servers}) {
			my $serverid = $_->{'serverid'};			
			
			my $logdir = $dir_base."/gs".$serverid;			
									
			#查询该服务器日志分析到哪个小时
			my $conn2 = Moby::Lib::Common::MysqlX::genConn(\%dstdb);
			my $db2 = new Moby::Lib::Common::MysqlX($conn2);
			$sql = "SELECT * FROM logana_ruler WHERE sid = $serverid";
			my $alog_ruler = $db2->fetchRow($sql);
			my $last_log;
			my $last_log_sta;
			#如果数据库中有记录
			if($alog_ruler) {
				$last_log = $alog_ruler->{'lastfile'};
				$last_log_sta = $alog_ruler->{'iscomplete'};
			} else {
				$sql = "insert into logana_ruler values ($serverid,'2000112200.lzo',1)";
				$db2->_execute($sql);
				next;
			}
			
			my ($lastYear, $lastMon, $lastDay, $lastHour) = $last_log =~ /(\d{4})(\d{2})(\d{2})(\d{2})\.lzo/;	
			
			#该运营商该服务器需要分析的下一个日志
			my $nextLogAndData = getLogAndDataFile($sTempDataFilePath, $pb, $serverid, $logdir, $last_log, $last_log_sta);	
			my $next_log = $nextLogAndData->{nextlog};
			my $tmp_data_file = $nextLogAndData->{datafile};
			next unless $next_log;
			
			#删除这个服务器十天之前的临时数据
			my $data_files = [sort(glob($sTempDataFilePath."/$pb"."_$serverid"."_*.pl"))];
			foreach my $t_file (@{$data_files}) {
				$t_file =~ /(\d{4})(\d{2})(\d{2})(\d{2})\.pl$/;
				if(str2time("$lastYear-$lastMon-$lastDay $lastHour:00:00") - str2time("$1-$2-$3 $4:00:00") > 86400*10) {
					unlink $t_file;
					$logger->info("---delete Success: $t_file");
				}
			}
			
			#删除临时日志目录之前的日志,解压新的日志				
			rmtree($sTargetLogPath) if (-e $sTargetLogPath && -d $sTargetLogPath);
			mkpath($sTargetLogPath);							
			#my $cmd = "/usr/local/bin/lzop -x -f $next_log -p$sTargetLogPath";
			my $cmd = "/usr/bin/lzop -x -f $next_log -p$sTargetLogPath";
			if(0 == Moby::Lib::Common::Common::cmd($cmd)) {
				$logger->info("unlzop Success: $cmd");
			} else {
				$logger->info("unlzop Failed: $cmd");
			}
						
			
			##############################################################################################################################
			my @aFiles = sort(glob($sTargetLogPath."/*.log"));

			my $sFileName = $aFiles[0];
			if( !$sFileName || '.' eq $sFileName || '..' eq $sFileName || $sFileName !~ /.*\.log$/) {
				next;
			}
			my ($logYear, $logMon, $logDay, $logHour) = $sFileName =~ /(\d{4})-(\d{2})-(\d{2})-(\d{2})\.log$/;						
			
			#如果last_log与next_log不在同一天,就将下面的时间存为last_log的时间
			my $logTimeLast;
			my $logDayTime;
			my $logHourTime;
			print "lasttime:$lastYear-$lastMon-$lastDay\nlogtime:$logYear-$logMon-$logDay\n";
			if(str2time("$lastYear-$lastMon-$lastDay") < str2time("$logYear-$logMon-$logDay")){
				$logTimeLast = "$lastYear-$lastMon-$lastDay $lastHour:59:59";
				$logDayTime = "$lastYear-$lastMon-$lastDay";
				$logHourTime = $lastYear.$lastMon.$lastDay.$lastHour;
			}else{							
				$logTimeLast = "$logYear-$logMon-$logDay $logHour:59:59";
				$logDayTime = "$logYear-$logMon-$logDay";
				$logHourTime = $logYear.$logMon.$logDay.$logHour;
			}						
			my $lastBlockDateTime = "$logYear-$logMon-$logDay $logHour:00:00";
			
			$logger->info(sprintf( "analysis:%s\n", $sFileName));
			$logger->info(sprintf( "tmp_data_file:%s\n", $tmp_data_file)) if $tmp_data_file;
						
			if( open( my $fhOutput, ">>", "$::APPLICATION_PATH/tmp.txt")) {
				binmode( $fhOutput, ":encoding(utf8)");			
				$oApplication->runTick();
				$oApplication->runTickLoad($tmp_data_file);							
				
				#print $fhOutput sprintf( "analysis:%s\n", $sFileName);
				$oLogReader->setFilePath( $sFileName);
				my $index = 0;
				while( !$oLogReader->eof()) {
					$logger->info( "process 40M-- $sFileName \n")if($index % 5000 == 0);
					$index++;
					#每次读取40M的数据到$hContent,每次读取的数据大小在process函数中调节
					my ($sLsn_arr, $hContent) = $oLogReader->process();
					#my @sLsn_arr = sort(keys %$hContent);
					#$logger->info( "sLsn_arr:".Dumper($sLsn_arr));
					foreach my $sLsn(@$sLsn_arr) {
						my $aDataSet = $hContent->{new}->{$sLsn};#新日志格式lsn
						my $aDataSetAll = $hContent->{all}->{$sLsn};#新老格式的lsn
						
						#根据格式化的数据块的第二行判断哪些可能没有定义新格式的日志,输出数据块第一行到文件: A,第二行没有  B,第二行为数值类变化或物品改变
#						open( my $fhNotDefineLog, ">>", "$::APPLICATION_PATH/notDefineLog.txt");
#						if (2 > scalar(@{$aDataSet})) {
#							print $fhNotDefineLog "===========================================================\n";
#							print $fhNotDefineLog Dumper($aDataSet->[0]);
#						} else {
#							my $sMainCmd_t 	= $aDataSet->[1]->{maincmd};
#							my $sSubCmd_t 	= $aDataSet->[1]->{subcmd};
#							if($sMainCmd_t eq 'numeric' || $sMainCmd_t eq 'item' || $sMainCmd_t eq 'mail' || $sMainCmd_t eq 'bussiness') {
#								print $fhNotDefineLog "===========================================================\n";
#								print $fhNotDefineLog Dumper($aDataSet->[0]);								
#							}
#						}
#						close $fhNotDefineLog;
						foreach my $hDataPackage( @{$aDataSet}) {
							my $sLSN 		= $hDataPackage->{lsn};
							my $sDateTime 	= $hDataPackage->{datetime};
							my $sMainCmd 	= $hDataPackage->{maincmd};
							my $sSubCmd 	= $hDataPackage->{subcmd};
							my $hData 		= $hDataPackage->{data};
							$lastBlockDateTime = $sDateTime;
#							print $fhOutput sprintf( "[%s] [%s] [%s] [%s] [", $sDateTime, $sLSN, $sMainCmd, $sSubCmd);
#							foreach my $sKey( keys( %{$hData})) {
#								print $fhOutput sprintf( "%s=>%s, ", $sKey, $hData->{$sKey});
#							}
#							print $fhOutput "]\n";
							
							#######################################
							#    业务逻辑在这里
							#######################################
							#将日志中的时间传入
							$oLogTimeMan->setTime( $sDateTime);
							
							#如果变成了下一个小时,就先将当前数据存入,然后初始化重新存取
							my ($tmp_year, $tmp_mon, $tmp_day, $tmp_hour, $tmp_min, $tmp_sec) = $sDateTime =~ /(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})/;
							my ($log_now_time) = "$tmp_year-$tmp_mon-$tmp_day $tmp_hour:$tmp_min:$tmp_sec";
							if(str2time($logTimeLast) < str2time($log_now_time)) {	
								#如果换天了,不仅要写临时数据,还要存入数据库
								my $if_insert = 0;
								if(str2time($logDayTime) < str2time("$tmp_year-$tmp_mon-$tmp_day")){
									$if_insert = 1;
								}
								#副本积分8点重置,要在8点处理插入副本积分
								if($tmp_hour == 8) {
									$if_insert = 2;
								}
								my $params = {
									'hourtime'	=> $logHourTime,
									'logDayTime'=> $logDayTime,
									'spb'	=>	$pb,
									'sid'	=>	$serverid,
									'dstdbarg'	=>	\%dstdb,
									'srcdbarg'	=>	\%srcdb,
									'dstdb'	=>	$db2,
									'srcdb'	=>	$db,
									'tmpdatadir'=>	$sTempDataFilePath,	
									'if_insert' =>	$if_insert,
									'is_complete' => 1,
								};
								my $tmpdatafile = $oApplication->runTickSave($params);
								if($if_insert == 1) {
									$logDayTime = "$tmp_year-$tmp_mon-$tmp_day";
									$oApplication->runTickLoad();
								} else {
									$oApplication->runTickLoad($tmpdatafile);
								}
								$logTimeLast = "$tmp_year-$tmp_mon-$tmp_day $tmp_hour:59:59";
								$logHourTime = $tmp_year.$tmp_mon.$tmp_day.$tmp_hour;
							}						
																	
							#获取监听者列表
							my $aListenerList = $oLogFormatListenerMan->notifyList( $sMainCmd, $sSubCmd, 'new');
							
							#将对应的日志传给对应的监听者
							my $params_notify = {
								'logDayTime'=>$logDayTime,
								'sid'	=>	$serverid,
								'srcdbarg'	=>	\%srcdb,
								'dstdbarg'	=>	\%dstdb,
								'dstdb'	=>	$db2,
								'srcdb'	=>	$db,
							};
							foreach my $oListener( @{$aListenerList}) {
								$oListener->notify( $hDataPackage, $aDataSet, $params_notify, $aDataSetAll);
							}
							if( !$::APPLICATION_ISRUN) {
								next BIG;
							}
						}
						
						#兼容老日志格式
						foreach my $hDataPackageAll (@{$aDataSetAll}){
							# my $sLSN 		= $hDataPackageAll->{lsn};
							my $sDateTime 	= $hDataPackageAll->{datetime};
							# my $hData 		= $hDataPackageAll->{data};
							
							$lastBlockDateTime = $sDateTime;
							#将日志中的时间传入
							$oLogTimeMan->setTime( $sDateTime);
							
							#如果变成了下一个小时,就先将当前数据存入,然后初始化重新存取
							my ($tmp_year, $tmp_mon, $tmp_day, $tmp_hour, $tmp_min, $tmp_sec) = $sDateTime =~ /(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})/;
							my ($log_now_time) = "$tmp_year-$tmp_mon-$tmp_day $tmp_hour:$tmp_min:$tmp_sec";
							if(str2time($logTimeLast) < str2time($log_now_time)) {	
								#如果换天了,不仅要写临时数据,还要存入数据库
								my $if_insert = 0;
								if(str2time($logDayTime) < str2time("$tmp_year-$tmp_mon-$tmp_day")){
									$if_insert = 1;
								}
								#副本积分8点重置,要在8点处理插入副本积分
								if($tmp_hour == 8) {
									$if_insert = 2;
								}
								my $params = {
									'hourtime'	=> $logHourTime,
									'logDayTime'=> $logDayTime,
									'spb'	=>	$pb,
									'sid'	=>	$serverid,
									'dstdbarg'	=>	\%dstdb,
									'srcdbarg'	=>	\%srcdb,
									'dstdb'	=>	$db2,
									'srcdb'	=>	$db,
									'tmpdatadir'=>	$sTempDataFilePath,	
									'if_insert' =>	$if_insert,
									'is_complete' => 1,
								};
								my $tmpdatafile = $oApplication->runTickSave($params);
								if($if_insert == 1) {
									$logDayTime = "$tmp_year-$tmp_mon-$tmp_day";
									$oApplication->runTickLoad();
								} else {
									$oApplication->runTickLoad($tmpdatafile);
								}
								$logTimeLast = "$tmp_year-$tmp_mon-$tmp_day $tmp_hour:59:59";
								$logHourTime = $tmp_year.$tmp_mon.$tmp_day.$tmp_hour;
							}
							
							#获取旧日志格式监听者列表
							my $sMainCmd = ''; 
							my $sSubCmd = '';
							my $aListenerList = $oLogFormatListenerMan->notifyList($sMainCmd,$sSubCmd,"old");
							
							#将对应的日志传给对应的监听者
							my $params_notify = {
								'logDayTime'=>$logDayTime,
								'sid'	=>	$serverid,
								'srcdbarg'	=>	\%srcdb,
								'dstdbarg'	=>	\%dstdb,
								'dstdb'	=>	$db2,
								'srcdb'	=>	$db,
							};
							foreach my $oListener( @{$aListenerList}) {
								$oListener->notify( $aDataSetAll, $params_notify);
							}
							if( !$::APPLICATION_ISRUN) {
								next BIG;
							}
							last;
						}
					}
				}
				$oLogReader->close();
				close( $fhOutput);
				
				
				#这个日志分析完了,如果最后一个数据块的时间中小时与日志名上的小时相同,说明这个小时的日志结束了
				#否则,说明是当前日志中引入了下一个小时00分00秒的日志,而且下一个小时的日志还没有分析完整
				my ($y, $m, $d ,$h) = $lastBlockDateTime =~ /(\d{4})-(\d{2})-(\d{2}) (\d{2})/;
				my $is_complete = 0;
				if(str2time("$y-$m-$d $h:00:00") == str2time("$logYear-$logMon-$logDay $logHour:00:00") && $logHourTime eq $logYear.$logMon.$logDay.$logHour){
					$is_complete = 1;
				}
				open my $tComplete,">>",$::APPLICATION_PATH."/startLogPig2.log";
				print $tComplete "spb:$pb sid:$serverid log:$next_log hourtime:$logHourTime lastBlockDateTime:$lastBlockDateTime logHour:$logHour is_complete:$is_complete\n";
				close $tComplete;
				
				my $params = {
					'hourtime'	=> $logHourTime,
					'logDayTime'=> $logDayTime,
					'spb'	=>	$pb,
					'sid'	=>	$serverid,
					'dstdbarg'	=>	\%dstdb,
					'srcdbarg'	=>	\%srcdb,
					'dstdb'	=>	$db2,
					'srcdb'	=>	$db,
					'tmpdatadir'=>	$sTempDataFilePath,	
					'if_insert' =>	0,
					'is_complete' => $is_complete,
				};
				$oApplication->runTickSave($params);							
			}
		}
	}
	system("sync && echo 3 >/proc/sys/vm/drop_caches");
	sleep 10;
}

$oApplication->shut();
$logger->info("================= service stop ===================");

$SIG{__WARN__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);
   	
   	my $text_ = $text ? $text : "";
	$logger->warn('warn: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		$logger->warn( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};

$SIG{__DIE__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);

	my $text_ = $text ? $text : "";
	$logger->warn('error: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		$logger->warn( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};

#获取要分析的下一个日志文件和临时数据文件
sub getLogAndDataFile {
	my ($sTempDataFilePath, $pb, $serverid, $logdir, $last_log, $last_log_sta) = @_;
	
	#如果日志状态为完成,就引入这个时间点的下一个日志,引入的临时数据与本时间点相同
	my $nextFile;
	my $datafile;
	my $nextFile_time;
	my ($last_log_time) = $last_log =~ /(\d{10})\.lzo$/; 
	
	my $allFiles = [sort(glob($logdir."/*.lzo"))];
	if($last_log) {	
		if($last_log_sta) {
			foreach my $file (@$allFiles) {
				my ($tmp_log_time) = $file =~ /(\d{10})\.lzo$/; 
				if($tmp_log_time > $last_log_time) {
					if (!defined($nextFile) || $nextFile_time > $tmp_log_time) {
						$nextFile = $file;	
						$nextFile_time = $tmp_log_time; 
					}		
				}
			}
		} else {
			foreach my $file (@$allFiles) {
				my ($tmp_log_time) = $file =~ /(\d{10})\.lzo$/; 
				if($tmp_log_time >= $last_log_time) {
					if (!defined($nextFile) || $nextFile_time > $tmp_log_time) {
						$nextFile = $file;	
						$nextFile_time = $tmp_log_time; 
					}		
				}
			}
		}
		$datafile = $sTempDataFilePath."/".$pb."_".$serverid."_".$last_log_time.".pl" if -e $sTempDataFilePath."/".$pb."_".$serverid."_".$last_log_time.".pl";
	} else {
		$nextFile = $allFiles->[0];
	}
	
	my $nextLogAndData = {
		nextlog		=>	$nextFile,
		datafile	=>	$datafile,
	};
	return $nextLogAndData;
}