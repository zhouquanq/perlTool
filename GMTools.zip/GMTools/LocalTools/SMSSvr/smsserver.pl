use strict;
use warnings;

use JSON;
use POSIX;
use Encode; 
use File::Copy;
use URI::Escape;
use MIME::Base64;
use LWP::UserAgent;
use HTTP::Request;
use Unicode::Map;


#############################################
# version 1.0
# 
# ������ӡ,��ʦ�����޸��������
# �����޸�����ɹ�����
# 
# ��Ҫģ��
#     ppm install Unicode::Map
#     ppm install Log::Log4perl
#
#############################################

BEGIN {
	
	use FindBin;
	use File::Path;
	use Log::Log4perl;
	use POSIX qw(strftime);
	
	chdir( $FindBin::Bin);
	our $APPLICATION_PATH = $FindBin::Bin;
	our $AppName = "smsserver";
	
	$::timeMan->{now} = time();
	
	my $logpath = sprintf( "%s/%s", $::APPLICATION_PATH, "logs");
	mkpath( $logpath);
	my $log_file = sprintf("%s/%s_%s.log", $logpath, $::AppName, strftime("%Y-%m-%d", localtime($::timeMan->{now})));
	
	my $conf = \qq{
		log4perl.category.main = INFO,Logfile
		log4perl.appender.Logfile = Log::Log4perl::Appender::File
		log4perl.appender.Logfile.filename = $log_file
		log4perl.appender.Logfile.layout = Log::Log4perl::Layout::PatternLayout
		log4perl.appender.Logfile.layout.ConversionPattern = [%d{yyyy-MM-dd HH:mm:ss}][%F(%L)] %m%n
	};
	
	#init log4perl config
	Log::Log4perl::init( $conf);
	our $logger = Log::Log4perl::get_logger( "main");
	$| = 1;
	
	
	$::continue = 1;
	$SIG{TERM} = sub { $::continue = 0 };
	
	for(@ARGV){
		next unless /^\-srv$/i;
		
		my $pid = fork();
		if ($pid < 0) {
			die "fork: $!";
		}
		elsif ($pid) {
			exit 0;
		}
	
		chdir($FindBin::Bin);
	
		open(STDIN,  "</dev/null");
		open(STDOUT, ">/dev/null");
		open(STDERR, ">&STDOUT");
		last;
	}
}

$::logger->info( "server start");
print "server start\n";

my $status_file = shift(@ARGV);
if (!defined($status_file) || length($status_file) <= 0) {
	die "perl -w smsserver.pl path_of_status_file";
}

my $AppPath = $FindBin::Bin;
my $map = new Unicode::Map("gb2312");

my $param_url = "http://gp.ta.cn/getupdpwdaddr.php";
my $sms_sendurl = "http://192.168.123.2:8800/?PhoneNumber=__PHONE__&Text=__MSG__";
my $dir = "C:\\Program Files (x86)\\NowSMS\\SMS-IN";

my %modMap = (
'COM3:' => { phone => '15914071614'},
'COM4:' => { phone => '15989345894'},
);

my $repottolog = 120;
my $lastreporttime = 0;

my $asdksetpwdurls = {
	'asdk' => 'http://account.sdk.7899.com/services.php',
	'fysdk' => 'http://119.147.224.162:8081/services.php',
};
Main();

sub update {
	$::timeMan->{now} = time();
	
	if( open( my $fhStusFl, '>', $status_file) ) {
		print $fhStusFl $::timeMan->{now};
		close( $fhStusFl);
	}
	if( $lastreporttime + $repottolog < $::timeMan->{now}) {
		$::logger->info( sprintf( "now:%s", strftime("%Y-%m-%d %H:%M:%S", localtime( $::timeMan->{now}))));
		
		$lastreporttime = $::timeMan->{now};
	}
}

sub Main 
{
	while( $::continue) {
		update();
		
		opendir(DIR, $dir) || die "can't opendir $dir: $!";
		my @files = grep { /\.SMS$/i } readdir(DIR);
		closedir DIR;
		
		for(@files) {
			my $sms_file = $_;
			my $file = $dir . "\\" . $sms_file;
			my $device = "";
			my $comNumber = "";
		
			$::logger->info( "parse $file ...");

			open(FILE, $file) || die "can't open file $file";
			my ($sender, $data, $binary, $dcs);
			$data = "";
			while(<FILE>) {
				next unless(length($_));

				my $line = $_;
				$line =~ s/^\s+//;
				$line =~ s/\s+$//;
				
				if ($line =~ /^sender=(\+?\d\d)?(\d+)$/i) {
					$line =~ s/^sender=//i;
					$line =~ s/^\+?86//i;
					$sender = $line;
				}
				elsif ($line =~ /^binary=(.+)$/i) {
					$binary = $1;
				}
				elsif ($line =~ /^data=(.+)$/i) {
					$data = $1;
				}
				elsif ($line =~ /^dcs=(.+)$/i) {
					$dcs = $1;
				}
				elsif ($line =~ /^ModemName=(.+)$/i) {
					$comNumber = $1;
					print( $1);
					$device = $modMap{uc($1)};
				}
			}
			close(FILE);
			
			if ($binary == 1) {
				if ($dcs == 8) {
					$data = DecodeData($data);
				}
				else {
					$data = "";
				}
			}

			$data =~ s/^\s+//;
			$data =~ s/\s+$//;

			$::logger->info( sprintf( "%s(%s)", $comNumber, $device->{phone}));
			printf( "timenow:%s $sender: $data \n", strftime( "%Y-%m-%d %H:%M:%S", localtime()));

			if( $data =~ m/^\s*�޸�����(\w+)@(\w+)\s+(\w+)\s+(\w+)\s*$/i) {
				my $pub = $1;
				my $project = $2;
				my $account = $3;
				my $password = $4;
				$::logger->info("    �޸����� $pub $sender $account $password " . $device->{phone});
				if( exists( $asdksetpwdurls->{$project})){
					my $asdksetpwdurl = $asdksetpwdurls->{$project};
					ProcessResetPasswordByASdk( $pub, $sender, $account, $password, $device, $asdksetpwdurl);
				}
				
				unlink($file);
			}
			elsif ($data =~ m/^\s*�޸�����(\w+)\s+(\w+)[^0-9]+([0-9]+)\s*$/i){
				my $account = $2;
				my $password = $3;
				$::logger->info("    �޸����� $1 $sender $account $password " . $device->{phone});
				ProcessResetPassword($1, $sender, $account, $password, $device);
				unlink($file);
			}
			elsif ($data =~ /�˺�\d+�Ķ�����֤��Ϊ\d+����ӡ�ͷ���/i){
				open FSMS, ">D:\\GMTools\\CheckTool\\sms\\" . $sms_file;
				print FSMS "sender:$sender recver:" . $device->{phone}. " ". $data;
				close FSMS;

				$::logger->info("    CheckTools $sender $data");
				unlink($file);
			}
			elsif ($data =~ /^\s*smspay\s*$/i){
				$::logger->info("    ���ų�ֵ���� $sender $data");
				#ProcessTestSmsPay($sender, $data, $device);
				unlink($file);
			}
			else{
				unlink($file);
				$::logger->info("    skip $sender $data");

				my $unknownDir = "$AppPath\\unknown\\";
				mkdir($unknownDir);

				my $phone_file = "$unknownDir\\";
				$phone_file .= "$sender";


				my $bExists = 0;
				my $no = "";
				do {
					if (length($no)) {
						$bExists = -e $phone_file . "_" . $no . ".txt";
					}
					else {
						$bExists = -e $phone_file . ".txt";
					}

					if ($bExists) {
						if (length($no)) {
							$no ++;
						}
						else{
							$no = 2;
						}
					}
				}
				while($bExists);

				if (length($no)) {
					$phone_file .= "_" . $no . ".txt";
				}
				else {
					$phone_file .= ".txt";
				}

				open FPHONE, ">$phone_file";
				print FPHONE "[sms]\n";
				print FPHONE "sender=$sender\n";
				print FPHONE "com=$comNumber\n";
				print FPHONE "data=$data\n";				
				close FPHONE;
			}
		}
		
		sleep(10);
	}
}

sub GetUrlByPub
{
	my ($pub) = @_;

	while(1)
	{
		my %form=(
			'pubid'=>$pub,
		);	

		my $browser    = new LWP::UserAgent;
		$browser->agent("NokiaN72/ 5.0741.4.0.1 Series60/2.8 Profile/MIDP-2.0 Configuration/CLDC-1.1");
		my $response = $browser->post($param_url, \%form, 'Content_Type' => 'application/x-www-form-urlencoded');  

		if ($response->is_success) 
		{
			my $content = $response->content; 
			$content = encode( "gb2312", decode("utf-8", $content));
			
			my $isSucc = 0;
			my $reqmsg = "";
			if ( $content =~ /^(\d+)\|(.+)$/) {
				$reqmsg = $2;
				if( $1 == 0) {
					$isSucc = 1;
					return $reqmsg;
				}
			}
			if( $isSucc) {
				$::logger->info( sprintf( "    get update pass url succ:%s by pub:%s", $reqmsg, $pub));
			} else {
				$::logger->info( sprintf( "    get update pass url fail:%s by pub:%s", $reqmsg, $pub));
			}

			return "";
		}
		else
		{
			if ($response->content)
			{
				print "error response: ", $response->content, "\n";
			}
			else
			{
				print $response->status_line, "\n";
			}
		}
	}
}

sub ProcessResetPassword
{
	my ($pub, $sender, $account, $password, $device) = @_;

	my $unisdkPub = { 
		'tacn'=>1, 
		'test'=>1,
		'leyi'=>1,
		'jiayu'=>1,
		'fyios'=>1,
		'uc'=>1,
		'uios'=>1,
		'longyin'=>1,
	};

	my $sender_q = uri_escape($sender);
	my $account_q = uri_escape($account);
	my $password_q = uri_escape($password);
	my $device_q = uri_escape($device->{phone});
	my $pub_q = uri_escape($pub);

	my $url = GetUrlByPub($pub);
	if(length($url)<=0)
	{
		return;
	}

	$url .= "?gameparam=setpwd&phone=__PHONE__&username=__ACCOUNT__&userpassword=__PASSWORD__&serverphone=__SENDTO__&op=__OP__";
	$url =~ s/__PHONE__/$sender_q/ig;
	$url =~ s/__ACCOUNT__/$account_q/ig;
	$url =~ s/__PASSWORD__/$password_q/ig;
	$url =~ s/__SENDTO__/$device_q/ig;
	$url =~ s/__OP__/$pub_q/ig;

	$::logger->info( sprintf( "    request update pass url:%s", $url));

	my $bDone = 0;
	while($bDone == 0)
	{
		my $ua = LWP::UserAgent->new;
		
		my $request = HTTP::Request->new("GET", $url);
		
		my $response = $ua->request($request);
		if ($response->is_success) 
		{
			$bDone = 1;
			my $content = $response->content; 
			my $isSucc = 0;
			my $reqmsg = "δ֪����";
			#$content = encode("gb2312", decode("utf-8", $content));
			if( $unisdkPub->{$pub}) {
				
				my $json = {};
				eval{
					$json = JSON->new->decode( $content);
				};
				if( $@) {
					$::logger->warn( sprintf( "    update pass json decode fail :%s", $@));
				}
				else {
					$::logger->info( sprintf( "    update pass json decode succ code:$json->{code}", ));
					$::logger->info( sprintf( "    update pass json decode succ msg:%s", encode( "gb2312", decode("utf-8", $json->{msg}))));
					if( "HASH" eq ref( $json) ) {
						if( $json->{code} == 0) {
							$isSucc = 1;
						}
						$reqmsg = $json->{msg};
						$reqmsg = encode( "gb2312", decode("utf-8", $reqmsg));
					}
				}
				
			}
			else {
				$content = encode("gb2312", decode("utf-8", $content));
				if( $content =~ /^(\d+)\|(.*)$/i) {
					if( $1 == 0) {
						$isSucc = 1;
					}
					$reqmsg = $2;
				}
			}
			$content = encode("gb2312", decode("utf-8", $content));
			if( $isSucc) {
				$::logger->info( sprintf( "    update pass succ from:%s account:%s msg:%s resp:%s", $sender, $account, $reqmsg, $content));
				report_sms( $sender, sprintf( "�޸ĳɹ�,������������:%s", $password));
			} else {
				$::logger->info( sprintf( "    update pass fail from:%s account:%s msg:%s resp:%s", $sender, $account, $reqmsg, $content));
			}
		}
		else
		{
			if ($response->content)
			{
				$::logger->info( sprintf( "    request url:%s error response:%s", $url, $response->content));
			}
			else
			{
				print $response->status_line, "\n";
				$::logger->info( sprintf( "    request url:%s error response(status):%s", $url, $response->status_line));
			}
		}
	}
}

sub ProcessResetPasswordByASdk
{
	my ($pub, $sender, $account, $password, $device, $url) = @_;


	my $sender_q = uri_escape($sender);
	my $account_q = uri_escape($account);
	my $password_q = uri_escape($password);
	my $device_q = uri_escape($device->{phone});
	my $pub_q = uri_escape($pub);

	if(length($url)<=0)
	{
		return;
	}

	$url .= "?gameparam=setpwd&phone=__PHONE__&username=__ACCOUNT__&userpassword=__PASSWORD__&serverphone=__SENDTO__&op=__OP__";
	$url =~ s/__PHONE__/$sender_q/ig;
	$url =~ s/__ACCOUNT__/$account_q/ig;
	$url =~ s/__PASSWORD__/$password_q/ig;
	$url =~ s/__SENDTO__/$device_q/ig;
	$url =~ s/__OP__/$pub_q/ig;

	$::logger->info( sprintf( "    request update pass url:%s", $url));

	my $bDone = 0;
	while($bDone == 0)
	{
		my $ua = LWP::UserAgent->new;
		
		my $request = HTTP::Request->new("GET", $url);
		
		my $response = $ua->request($request);
		if ($response->is_success) 
		{
			$bDone = 1;
			my $content = $response->content; 
			my $isSucc = 0;
			my $reqmsg = "δ֪����";
			#$content = encode("gb2312", decode("utf-8", $content));
			
				
			my $json = {};
			eval{
				$json = JSON->new->decode( $content);
			};
			if( $@) {
				$::logger->warn( sprintf( "    update pass json decode fail :%s", $@));
			}
			else {
				$::logger->info( sprintf( "    update pass json decode succ code:$json->{code}", ));
				$::logger->info( sprintf( "    update pass json decode succ msg:%s", encode( "gb2312", decode("utf-8", $json->{msg}))));
				if( "HASH" eq ref( $json) ) {
					if( $json->{code} == 0) {
						$isSucc = 1;
					}
					$reqmsg = $json->{msg};
					$reqmsg = encode( "gb2312", decode("utf-8", $reqmsg));
				}
			}
				
			
			$content = encode("gb2312", decode("utf-8", $content));
			if( $isSucc) {
				$::logger->info( sprintf( "    update pass succ from:%s account:%s msg:%s resp:%s", $sender, $account, $reqmsg, $content));
				report_sms( $sender, sprintf( "�޸ĳɹ�,������������:%s", $password));
			} else {
				$::logger->info( sprintf( "    update pass fail from:%s account:%s msg:%s resp:%s", $sender, $account, $reqmsg, $content));
			}
		}
		else
		{
			if ($response->content)
			{
				$::logger->info( sprintf( "    request url:%s error response:%s", $url, $response->content));
			}
			else
			{
				print $response->status_line, "\n";
				$::logger->info( sprintf( "    request url:%s error response(status):%s", $url, $response->status_line));
			}
		}
	}
}

sub logl
{
	my ($line) = @_;
	
	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);	
	$year += 1900;
	$mon ++;
	
	my $log_line = "$year-$mon-$mday $hour:$min:$sec : $line\n";
	
	open FLOG, ">>$AppPath\\ph.log";
	print FLOG $log_line;
	print $line, "\n";
	close FLOG;
}

sub DecodeData
{
	my ($data) = @_;

	if (defined $data and length($data) > 0) {
		$data =~ s/(..)/chr(hex($1))/ge;

		$data = $map->from_unicode($data);

		return $data;
	}
	else
	{
		return "";
	}
}

# ���Ͷ���
sub report_sms
{
	my ( $targetphone, $msg_) = @_;

	return unless length($msg_)>0 && defined($sms_sendurl) && length($sms_sendurl)>0;
	
	my $tmNow = time();
	my $msg = sprintf( "%s ����ʱ��:%s", $msg_, strftime("%Y-%m-%d %H:%M:%S", localtime(time)));
	
	my $phone = uri_escape( $targetphone);
	my $msg_edg = uri_escape( Encode::encode( "utf8", Encode::decode( "gb2312", $msg)));
	#my $msg_edg = $msg;
	my $url = $sms_sendurl;
	$url =~ s/__PHONE__/$phone/ig;
	$url =~ s/__MSG__/$msg_edg/ig;

	#$::logger->info( sprintf( "    send msg url:%s", $url));

	my $browser  = LWP::UserAgent->new;
	my $response = $browser->get($url);	
	
	if( $response->is_success) {
		my $rescontent = $response->content;
		$::logger->info( sprintf("    send msg:%s succ by phone:%s", $msg_, $targetphone));
	} 
	else {
		$::logger->warn( sprintf( "    send msg:%s fail:%s by phone:%s", $msg_, $!, $targetphone));
	}
}