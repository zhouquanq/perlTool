#!/usr/bin/perl
use strict;
use warnings;
use utf8;
use PerlIO::encoding;
use Data::Dumper;
use File::Path;

require 'srv.pl';

BEGIN{
	use FindBin;
	$::APPLICATION_PATH = $FindBin::Bin;
	$::PARENT_PATH = $::APPLICATION_PATH."/../";
	push( @INC, $::APPLICATION_PATH, $::PARENT_PATH);
	chdir( $::APPLICATION_PATH);
	
	$::APPLICATION_ISRUN = 1;
	
	# 防止意外关闭
	$SIG{HUP} = sub {};
	$SIG{INT} = sub { $::APPLICATION_ISRUN = 0;};
	$| = 1;
}

use Common;
use MysqlX;


Common::log2( "================= 服务器开启 ===================");

my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
my $cfg_file = "$base_file.cfg";
die "cfg file: '$cfg_file' not exists!" unless -e $cfg_file;

my $olday = '';	   
while ($::APPLICATION_ISRUN) {
	my $now = Common::ts2str(time());
	
	my ($day, $hour) = ($now =~ m/(\d{4}-\d+-\d+) (\d+):\d+:\d+/);	
	if ($olday eq $day || '03' ne $hour) {							#每天3点时段计算一次
		print "[$now] Not in time. Skip.\n";
		sleep 600;
		next;
	}
	
	Common::log2("now start: $now...\n");
	system "sync && echo 3 > /proc/sys/vm/drop_caches";
	sleep(5);
	my $cfg_ini = Common::load_ini($cfg_file);
					
	foreach my $section(@{$cfg_ini}) {
		my $start_time = Common::ts2str(time());
	
		my $node = $section->{'name'};
		
		my $log_dir      = Common::get_section_value($section, 'log_dir', '');
		my $dstdb      = Common::get_section_value($section, 'dstdb', '');
		my %dstdb = Common::str2arr($dstdb);
		
		#从数据库查询该运营商需要分析日志的服务器
		my $conn = MysqlX::genConn(\%dstdb);
		my $db = new MysqlX($conn);
		
		my $yesterday = Common::ts2str(time() - 86400, 1);			
		
		#创建临时目录
		my $tmpdir = $::APPLICATION_PATH."/temp";
		(-d $tmpdir ? rmtree($tmpdir) : unlink $tmpdir) if -e $tmpdir;
		mkdir($tmpdir);
		
		#获取lzo格式的日志		
		my @lzofiles = Common::filter_log_lzofile($yesterday,$log_dir);
		foreach my $file (@lzofiles) {
			next unless $file =~ /\.lzo$/;
			
			my $cmd = "/usr/local/bin/lzop -x -f $file -p$tmpdir";
			0 == Common::cmd($cmd) or Common::log2("Failed: $cmd");
		}
		
		#分析日志
		my @logfiles = glob("$tmpdir/*.log");
		while(<@logfiles>) {
			next unless $_ =~ /\.log/;
			open FH, "< $_";
			Common::log2("Add log file[$log_dir]: $_\n");
			while (<FH>) {
				my $line = $_;
				next unless $line =~ m/\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\].*?\[update\]\[.*?,http_moby_imei=(.*?),http_moby_sdk=(.*?),.*?http_moby_pb=(.*?),/;
				my $pa_time = $1;
				my $pa_imei = $2;
				my $pa_sdk = $3;
				my $pa_pub = $4;
				
				my $pa_ip;
				if($line =~ m/,client_ip=(\d+\.\d+\.\d+\.\d+)\]/) {
					$pa_ip = $1;
				}
				
				#分析行**********************************************************************
				my $row;
				if (defined($pa_ip)){
					$row = {
						pa_pub	=>	$pa_pub,
						pa_imei	=>	$pa_imei,
						pa_ip	=>	$pa_ip,
						pa_time	=>	$pa_time,	
						pa_sdk	=>	$pa_sdk,					
					};
				} else {
					$row = {
						pa_pub	=>	$pa_pub,
						pa_imei	=>	$pa_imei,
						pa_time	=>	$pa_time,
						pa_sdk	=>	$pa_sdk,
					};
				}
				
				#查询是否存在相同的imei
				my $sql = "
					SELECT * FROM pubsync_activate WHERE pa_imei = '$pa_imei'
				";
				my $results = $db->fetchAll($sql);
				if (scalar(@$results)) {
					next;
				} else {
					$db->insert('pubsync_activate', $row);
				}
				#print Dumper($row);
				#\/分析行**********************************************************************
				die unless $::APPLICATION_ISRUN;
			}
			close FH;
			#清理系统内存
			system "sync && echo 3 > /proc/sys/vm/drop_caches";
			sleep 1;
		}
		die unless $::APPLICATION_ISRUN;
	
		my $stop_time = Common::ts2str(time());
		Common::log2("node: $node	theday: $yesterday	start time: $start_time		stop time: $stop_time");
	}
	$olday = $day;
}

Common::log2("================= 服务器关闭 ===================");








$SIG{__WARN__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);
   	
   	my $text_ = $text ? $text : "";
	Common::log2('warn: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		Common::log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};

$SIG{__DIE__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);

	my $text_ = $text ? $text : "";
	Common::log2('error: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		Common::log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};