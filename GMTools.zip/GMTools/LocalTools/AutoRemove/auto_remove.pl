#!/usr/bin/perl
#实现文件夹之间的遍历拷贝(不覆盖),主要用于将82上的日志拷贝到集群
BEGIN{
	use FindBin;
	$::APPLICATION_PATH = $FindBin::Bin;
	$::PARENT_PATH = $::APPLICATION_PATH."/../";
	push( @INC, $::APPLICATION_PATH, $::PARENT_PATH);
	chdir( $::APPLICATION_PATH);
	
	$::APPLICATION_ISRUN = 1;
	
	# 防止意外关闭
	$SIG{HUP} = sub {};
	$SIG{INT} = sub { $::APPLICATION_ISRUN = 0;};
	$| = 1;
}
use strict;
use warnings;
use Data::Dumper;
use POSIX qw(strftime);
use File::Path qw(mkpath rmtree);

use File::Copy;

require 'common.pl';
require 'srv.pl';

#*************************要修改的***************************
my $configs = [
	 {
		 type	=>	'log',			#类型,包括 日志log和数据库备份dbbk
		 dir		=>	'/GMAutoUpload',				#扫描的目录
		 days	=>	6,				#删除该天数之前的
	 },
	# {
	#	type	=>	'dbbk',
	#	dir		=>	'/GMAutodown/lyld_db',
	#	full_count	=>	2,			#留取的全备份次数
	# },
];
#****************************************************

our $delete_count = 0;
while ($::APPLICATION_ISRUN) {
	my $start_time = strftime("%Y-%m-%d %H:%M:%S", localtime(time));
	
	$delete_count = 0;
	foreach my $hConfig (@$configs) {
		if($hConfig->{type} eq 'log') {
			traversal_dir_delete_log($hConfig->{dir}, $hConfig->{days});
		} elsif ($hConfig->{type} eq 'dbbk') {
			traversal_dir_delete_dbbk($hConfig->{dir}, $hConfig->{full_count});
		}
	}
	
	my $end_time = strftime( "%Y-%m-%d %H:%M:%S", localtime(time));

	log2("[".ts2str(time)."] Success,unlinked $delete_count files!");	
	log2("[".ts2str(time)."] start_time:".$start_time);
	log2("[".ts2str(time)."] end_time:".$end_time);
	log2("--------------------------------- ---------------------------------\n\n");
	
	sleep 86400;
}

#递归删除文件夹下的45天前的日志
sub traversal_dir_delete_log {
	my ($src_dir, $del_days) = @_;
	
	our $delete_count;
	
	my @dir_lists = glob($src_dir."/*");
	
	foreach (@dir_lists) {
		my $src_tmp = $_;
		#print $src_tmp."\n";
		
		if(-f $src_tmp) {
			next if $src_tmp !~ /(\d{10})\.lzo$/;
			my $log_str = $1;
			
			my $min_t = ts2str(time - $del_days * 86400);
			my ($min_y, $min_m, $min_d, $min_h) = $min_t =~ /(\d{4})-(\d{2})-(\d{2}) (\d{2}):\d{2}:\d{2}/;
			my $min_str = $min_y.$min_m.$min_d.$min_h;
						
			#删除大于$del_days天前的日志
			if ($min_str > $log_str) {
				unlink $src_tmp or die "unlink $src_tmp failed: $!";
				$delete_count++;
				log2("[".ts2str(time)."] unlinked file $src_tmp");
			}
		} elsif (-d $src_tmp) {
			traversal_dir_delete_log($src_tmp,$del_days);
		}
	}
}

sub traversal_dir_delete_dbbk {
	my ($src_dir, $full_remain) = @_;
		
	our $delete_count;
	
	my $dir_lists = [sort(glob($src_dir."/*"))];
	my $fullfile_lists = [sort(glob($src_dir."/*full*"))];
	my $min_ts = undef;
	if(defined($fullfile_lists) && 2 <= scalar(@$fullfile_lists)) {
		#/GMAutodown/lywm_db/gs7/1352468486_full.tar.gz
		($min_ts) = $fullfile_lists->[scalar(@$fullfile_lists) - $full_remain] =~ /(\d{10})_full\.tar\.gz$/;
	}
	
	foreach my $src_tmp (@$dir_lists) {
		#print $src_tmp."\n";
		
		if(-f $src_tmp && defined($min_ts)) {
			next if $src_tmp !~ /(\d{10})_/;
			my $log_ts = $1;
						
			#删除两个全备份前的增量
			if ($min_ts > $log_ts) {
				unlink $src_tmp or die "unlink $src_tmp failed: $!";
				$delete_count++;
				log2("[".ts2str(time)."] unlinked file $src_tmp");
			}
		} elsif (-d $src_tmp) {
			traversal_dir_delete_dbbk($src_tmp,$full_remain);
		}
	}
}

$SIG{__WARN__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);
   	
   	my $text_ = $text ? $text : "";
	log2('warn: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};

$SIG{__DIE__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);

	my $text_ = $text ? $text : "";
	log2('error: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};
