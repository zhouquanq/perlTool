#!/usr/bin/perl -w
#注:远程通过ftp同步文件夹(不覆盖)
BEGIN{
	use FindBin;
	$::APPLICATION_PATH = $FindBin::Bin;
	$::PARENT_PATH = $::APPLICATION_PATH."/../";
	push( @INC, $::APPLICATION_PATH, $::PARENT_PATH);
	chdir( $::APPLICATION_PATH);
	
	$::APPLICATION_ISRUN = 1;
	
	# 防止意外关闭
	$SIG{HUP} = sub {};
	$SIG{INT} = sub { $::APPLICATION_ISRUN = 0;};
	$| = 1;
}
use strict;
use warnings;

use File::Copy;
use File::Path;
use POSIX qw(strftime);
use Net::FTP;
use Thread;
use Archive::Zip qw( :ERROR_CODES :CONSTANTS );
use Archive::Tar;
use Data::Dumper;

require 'srv.pl';
require 'common.pl';


our $copy_count = 0;
our $makepath_count = 0;
main();
sub main 
{
	my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
	my $cfg_file = "$base_file.cfg";
	die "cfg file: '$cfg_file' not exists!" unless -e $cfg_file;
		
	BIG: while ($::APPLICATION_ISRUN) {
		my $cfg_ini = load_ini($cfg_file);
		
		foreach my $section(@{$cfg_ini}) {
			my $sectionname = $section->{'name'};			
			log2("+++++++++++++++++++++++start $sectionname+++++++++++++++++++++++");
			
			my $server = get_section_value($section, 'server', '');
			my $port = get_section_value($section, 'port', '');
			my $passive = get_section_value($section, 'passive', 1);
			my $username = get_section_value($section, 'username', '');
			my $password = get_section_value($section, 'password', '');	
			my $ext = get_section_value($section, 'ext', '');
			my $filter_ext = get_section_value($section, 'filter_ext', '0');
			my $from_base_dir = get_section_value($section, 'from_base_dir', '');
			my $to_base_dir = get_section_value($section, 'to_base_dir', '');
			
			my $start_time = strftime("%Y-%m-%d %H:%M:%S", localtime(time));
			###############################################################################
			$copy_count = 0;
			$makepath_count = 0;
						
			#扩展名trim
			my $exts;
			{
				my @tmp_exts = split(/,/, $ext);
				for (@tmp_exts)
				{
					my $e = $_;
					$e =~ s/^\s+//;
					$e =~ s/\s+$//;

					$exts->{lc($e)} = 1;
				}
			}
			
			#FTP连接
			my $ftp = 0;
			my $tryCount = 3;
			while ($tryCount--) {
				$ftp = Net::FTP->new($server, Port => $port, Debug => 0, Passive => $passive);		

				if ($ftp) {
					last;
				} else {
					sleep(10);
				}
			}				
			if (!$ftp) {
				log2("connect to ftp($sectionname) error: $@");
				return;
			}

			#ftp登录
			my $b_logined = 0;
			$tryCount = 3;
			while ($tryCount--) {		
				$b_logined = $ftp->login($username, $password);

				if ($b_logined) {
					last;
				} else {
					sleep(10);
				}
			}
			if (!$b_logined) {
				log2("login to ftp($server) error: $@");
				return;
			}
			
			#ftp切换传输模式
			if (!$ftp->binary()) {
				log2("can't change ftp($server) mode to binary: $@");
				return;
			}
			eval {
				&recursive_scan($ftp, $exts, $filter_ext, $from_base_dir, $to_base_dir);
			};
			log2("recursive_scan error: $@") if $@;
			###############################################################################
			my $end_time = strftime( "%Y-%m-%d %H:%M:%S", localtime(time));

			log2("[".ts2str(time)."] Success,made $makepath_count dir!");
			log2("[".ts2str(time)."] Success,copied $copy_count files!");
			log2("[".ts2str(time)."] start_time:".$start_time);
			log2("[".ts2str(time)."] end_time:".$end_time);
			log2("--------------------------------- ---------------------------------\n\n");
			
			$ftp->quit;
		}
		sleep 1;
	}
}

sub recursive_scan
{
	my ($ftp, $exts, $filter_ext, $ftp_path, $download_path) = @_;
	
	our $makepath_count;	
	
	if($ftp->cwd($ftp_path)) {	 #如果能切换到这个路径,说明是目录
		#去掉路径结尾/或\
		$ftp_path =~ s/[\\\/]\s*$// if $ftp_path !~ /^\s*[\/\\]\s*$/;
		$download_path =~ s/[\\\/]\s*$//;
		unless (-d $download_path) {
			mkpath($download_path);
			$makepath_count++;
			log2("+++++++++++++++++++++++\n makepath $download_path...");
		}

		#FTP列出文件
		my @items = $ftp->ls($ftp_path);
		foreach my $item (@items) {
			my $tmp_ftp_path = $item;
			my ($tmp_name) = ($item =~ /([^\/]*)$/);
			my $tmp_download_path = $download_path.'/'.$tmp_name;
			if($ftp->cwd($tmp_ftp_path)) {				
				&recursive_scan($ftp, $exts, $filter_ext, $tmp_ftp_path, $tmp_download_path);
			} else {
				&ftp_down_file($ftp, $exts, $filter_ext, $tmp_ftp_path, $tmp_download_path);
			}
			last unless $::APPLICATION_ISRUN;
		}
	} else {
		&ftp_down_file($ftp, $exts, $filter_ext, $ftp_path, $download_path);
	}
}

sub ftp_down_file {
	my ($ftp, $exts, $filter_ext, $ftp_path, $download_path) = @_;
	
	our $copy_count;
	
	$download_path =~ /\.([^\.]+)$/;
	my $file_ext = lc($1);
	$file_ext =~ s/^\s+//;
	$file_ext =~ s/\s+$//;
	if($filter_ext && !exists($exts->{$file_ext})) {
		return;		
	}
	
	my $tmpfile = $download_path.".tmp";
	my $tmpfilesize;	
	if(-e $download_path) {
		print "file $download_path exists,next...\n";
		return;
	} elsif (-e $tmpfile) {
		$tmpfilesize = -s $tmpfile;
		if ($tmpfilesize < $ftp->size($ftp_path)) {
			if (!$ftp->get($ftp_path, $tmpfile, $tmpfilesize)) {
				log2("ftp get file $ftp_path error: $@");
				return;
			}
		}
	} else {
		log2("-----------------------\nget $ftp_path...");
		if (!$ftp->get($ftp_path, $tmpfile)) {
				log2("ftp get file $ftp_path error: $@");
				return;
		}
	}

	#下载完整性检查	
	return unless -e $tmpfile;	
	$tmpfilesize = -s $tmpfile;
	unless (defined($tmpfilesize) && $tmpfilesize > 0) {
		return;
	}
	
	log2("local size:$tmpfilesize		remote size:".$ftp->size($ftp_path));
	if ($tmpfilesize == $ftp->size($ftp_path)) {
		move($tmpfile, $download_path);
		$copy_count++;
	}
	elsif ($tmpfilesize > $ftp->size($ftp_path)) {
		log2("Delete too large tmpfile: $tmpfile");
		unlink $tmpfile;
	}
}

$SIG{__WARN__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);
   	
   	my $text_ = $text ? $text : "";
	log2('warn: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};

$SIG{__DIE__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);

	my $text_ = $text ? $text : "";
	log2('error: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};