#!/usr/bin/perl
#实现集群与本地之间的遍历拷贝(不覆盖),主要用于将集群上的日志拷贝到硬盘
#/usr/bin/perl /GMTools/AutoHdfsCopy/auto_hdfs_copy.pl -srv
BEGIN{
	use FindBin;
	$::APPLICATION_PATH = $FindBin::Bin;
	$::PARENT_PATH = $::APPLICATION_PATH."/../";
	push( @INC, $::APPLICATION_PATH, $::PARENT_PATH);
	chdir( $::APPLICATION_PATH);
	
	$::APPLICATION_ISRUN = 1;
	
	# 防止意外关闭
	$SIG{HUP} = sub {};
	$SIG{INT} = sub { $::APPLICATION_ISRUN = 0;};
	$| = 1;
}
use strict;
use warnings;
use Data::Dumper;
use POSIX qw(strftime);
use File::Path qw(make_path remove_tree);

use File::Copy;

require 'common.pl';
require 'srv.pl';

#*************************要修改的***************************
# my $type = {
	# type	=>	'db',		#类型,db或log
	# start_time	=>	'2013-01-11 10:00:51',
	# end_time	=>	'2013-01-11 23:59:59',
# };

my $type = {
	type	=>	'log',		#类型,db或log
	start_time	=>	'2012091323',
	end_time	=>	'2012101500',
};

my $hdfs_dir = "/glog/lywm_log/gs13";
my $local_dir = "/home/lity/LogOneMonth/gs13";
#****************************************************


our $copy_count = 0;
our $makepath_count = 0;
our $delete_count = 0;

my $hadoop_path = "/usr/hadoop-1.0.3/bin/hadoop";
my $hdfs_base = "hdfs://csmaster:9000";

while ($::APPLICATION_ISRUN) {
	my $start_time = strftime("%Y-%m-%d %H:%M:%S", localtime(time));
	###############################################################################
	$copy_count = 0;
	$makepath_count = 0;
	$delete_count = 0;
	hdfs_to_local($hdfs_base, $hdfs_dir, $local_dir, $type);
	###############################################################################
	my $end_time = strftime( "%Y-%m-%d %H:%M:%S", localtime(time));

	log2("Success,made $makepath_count dir!");
	log2("Success,copied $copy_count files!");
	log2("Success,deleted $delete_count files!");
	log2("start_time:".$start_time);
	log2("end_time:".$end_time);
	log2("--------------------------------- ---------------------------------\n\n");
	
	sleep 6;
}

sub hdfs_to_local {
	my ($hdfs_base, $hdfs_dir, $local_dir, $type) = @_;					#$type值为db,log
	
	our $copy_count;
	our $makepath_count;
	
	my $hdfs_lists = {
		file	=>	{},
		dir		=>	{},
	};
	my $local_lists = [glob($local_dir."/*")];
	
	my $dst_lists_tmp = [split(/\n|\r\n/,`$hadoop_path fs -ls $hdfs_base$hdfs_dir`)];
	foreach (sort @{$dst_lists_tmp}) {
		next unless /([-d])[-rwxd]{9}.*?(\d+)\s+(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})\s+(.*)/;
		# print "$1,$2,$3,$4,$5\n";
		$hdfs_lists->{file}->{$5} = $2 if $1 eq '-';
		$hdfs_lists->{dir}->{$5} = 1 if $1 eq 'd';
	}
	
	foreach (sort(keys %{$hdfs_lists->{file}})) {
		my $hdfs_tmp = $_;
		$_ =~ s#$hdfs_dir#$local_dir#;
		my $local_tmp = $_;
		
		#添加后缀的过滤
		next if $hdfs_tmp =~ /\.tmp$/;
		
		#时间过滤
		if( 'db' eq $type->{type} ) {
			my ($t_ts) = $hdfs_tmp =~ /(\d{10})/;
			next unless ($t_ts >= str2ts($type->{start_time}) && $t_ts <= str2ts($type->{end_time}));
		}
		if( 'log' eq $type->{type} ) {
			my ($t_ts) = $hdfs_tmp =~ /(\d{10})/;
			next unless ($t_ts >= $type->{start_time} && $t_ts <= $type->{end_time});
		}
		
		if(-f $local_tmp) {
			my $size_local = -s $local_tmp;
			my $size_hdfs = $hdfs_lists->{file}->{$hdfs_tmp};
			if($size_hdfs == $size_local) {
				next;
			} 
			else {
				log2("$hdfs_tmp size:$size_hdfs\t$local_tmp size:$size_local");
			}
		} else {
			my $r_v = `$hadoop_path fs -get $hdfs_base$hdfs_tmp $local_tmp`;
			if('' eq $r_v) {
				$copy_count++;
				log2("copied file $hdfs_tmp");
			} else {
				log2("copy $hdfs_tmp failed");
			}
		}
	}
	
	foreach (sort(keys %{$hdfs_lists->{dir}})) {
		my $hdfs_tmp = $_;
		$_ =~ s#$hdfs_dir#$local_dir#;
		my $local_tmp = $_;
	
		if(-d $local_tmp) {
			hdfs_to_local($hdfs_base, $hdfs_tmp, $local_tmp, $type);
		} else {
			make_path($local_tmp);
			$makepath_count++;
			log2("made path $local_tmp");
			hdfs_to_local($hdfs_base, $hdfs_tmp, $local_tmp, $type);
		}
	}
}


$SIG{__WARN__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);
   	
   	my $text_ = $text ? $text : "";
	log2('warn: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};

$SIG{__DIE__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);

	my $text_ = $text ? $text : "";
	log2('error: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};