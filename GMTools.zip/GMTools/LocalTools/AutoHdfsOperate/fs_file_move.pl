#/usr/bin/perl
#��Ⱥ�ڵ���Ŀ¼Ǩ��(��һ�ڵ�)

use strict;
use warnings;

BEGIN {
	use FindBin;

	$::APPLICATION_PATH = scalar($FindBin::Bin);

	chdir($::APPLICATION_PATH);
	push(@INC, $::APPLICATION_PATH, $::APPLICATION_PATH."/../");
	
	$::APPLICATION_RUN = 1;

	$SIG{HUP} = sub {};
	$SIG{INT} = sub {$::APPLICATION_RUN = 1;};

	$| = 1;
}

use Data::Dumper qw(Dumper);

my $infile = $::APPLICATION_PATH."/block8.txt";

open my $inFileHandle, "<", $infile or die "cannot open file $infile";
open my $lostBlockHandle, ">", $::APPLICATION_PATH."/lostblock.log";

my $lostblockfile = [];
while (<$inFileHandle>) {
	next unless /(.*): CORRUPT block (blk_-?\d+)/;
	my ($logpath, $lostfile) = ($1, $2);
	push @$lostblockfile, $lostfile;
	print $lostBlockHandle "$logpath\t$lostfile\n";
}
close $inFileHandle;
close $lostBlockHandle;

print Dumper($lostblockfile);

open my $findReturn, ">", $::APPLICATION_PATH."/findreturn.log";

my $hdfs_prepath = "/hadoop/\ ";
my $hdfs_basepath1 = "/mnt/hdsecond/hadoop/var/hdfs/data1/";

my $count = 0;
foreach my $block (@$lostblockfile) {
	$block = $block."*";
	
	my $cmd_return = `find '$hdfs_prepath$hdfs_basepath1' -name $block`;
	
	print "find:\n"."find '$hdfs_prepath$hdfs_basepath1' -name $block\n";
	next unless $cmd_return;
	print $findReturn $cmd_return;
	
	my @cmd_return_lines = split('\n', $cmd_return);
	print "------------------------\n";
	print $cmd_return;
	print Dumper([@cmd_return_lines]);
	foreach my $line (@cmd_return_lines){
		my ($path1, $path2, $file) = $line =~ m#/hadoop/ ((/mnt/hdsecond/hadoop/var/hdfs/data1/current/subdir\d+/).*)(blk_.*)#;
		
		$path1 = "/hadoop/\ ".$path1;		
		print Dumper([$path1, $path2, $file]);
	
		my $cr = `cp '$path1$file' $path2$file`;
		print "cp:\n"."cp '$path1$file' $path2$file"."\n";
		print "cr:\n".$cr."\n";
	}
	$count++;
	#last if $count++ > 1;
}
print "count:".$count."\n";

#/hadoop/ /mnt/hdsecond/hadoop/var/hdfs/data1/current/subdir45/blk_7078250166518525386
#/hadoop/ /mnt/hdsecond/hadoop/var/hdfs/data1/current/subdir45/blk_3323603459444567417
#/hadoop/ /mnt/hdsecond/hadoop/var/hdfs/data1/current/subdir55/subdir63/blk_1077846731494922169
#/hadoop/ /mnt/hdsecond/hadoop/var/hdfs/data1/current/subdir63/subdir38/blk_3931294941149944373
