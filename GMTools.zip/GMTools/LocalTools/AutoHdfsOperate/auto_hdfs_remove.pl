#!/usr/bin/perl
#实现集群中跨文件夹日志和数据库备份的删除
BEGIN{
	use FindBin;
	$::APPLICATION_PATH = $FindBin::Bin;
	$::PARENT_PATH = $::APPLICATION_PATH."/../";
	push( @INC, $::APPLICATION_PATH, $::PARENT_PATH);
	chdir( $::APPLICATION_PATH);
	
	$::APPLICATION_ISRUN = 1;
	
	# 防止意外关闭
	$SIG{HUP} = sub {};
	$SIG{INT} = sub { $::APPLICATION_ISRUN = 0;};
	$| = 1;
}
use strict;
use warnings;
use Data::Dumper;
use Date::Parse qw(str2time);
use POSIX qw(strftime);
use File::Path qw(make_path remove_tree);

use File::Copy;

require 'common.pl';
require 'srv.pl';

#*************************要修改的***************************
my $configs = [
	{
		 hadoop_path	=>	'/usr/hadoop-1.0.3/bin/hadoop',
		 hdfs_base	=>	'hdfs://csmaster:9000',
		 type	=>	'log',			#类型,包括 日志log和数据库备份dbbk
		 dir		=>	'/glog',				#扫描的目录
		 days	=>	200,				#删除该天数之前的
	},
	{
		hadoop_path	=>	'/usr/hadoop-1.0.3/bin/hadoop',
		hdfs_base	=>	'hdfs://csmaster:9000',
		type	=>	'dbbk',
		dir		=>	'/gdb',
		full_count	=>	2,			#留取的全备份次数
	},
	{
		hadoop_path	=>	'/usr/hadoop-1.0.3/bin/hadoop',
		hdfs_base	=>	'hdfs://csmaster:9000',
		type	=>	'sql',
		dir		=>	'/gdb/dbback',
		remain_count	=>	2,			#留取的全备份次数
	},
	{
		hadoop_path	=>	'/usr/hadoop-1.0.3/bin/hadoop',
		hdfs_base	=>	'hdfs://csmaster:9000',
		type	=>	'webbk',
		dir		=>	'/glog/website_backup',
		remain_count	=>	2,			#留取的全备份次数
	},
];
#****************************************************

our $delete_count = 0;
while ($::APPLICATION_ISRUN) {
	my $start_time = strftime("%Y-%m-%d %H:%M:%S", localtime(time));
	
	$delete_count = 0;
	foreach my $hConfig (@$configs) {
		if($hConfig->{type} eq 'log') {
			traversal_hdfsdir_delete_log($hConfig->{hadoop_path}, $hConfig->{hdfs_base}, $hConfig->{dir}, $hConfig->{days});
		} 
		if ($hConfig->{type} eq 'dbbk') {
			traversal_hdfsdir_delete_dbbk($hConfig->{hadoop_path}, $hConfig->{hdfs_base}, $hConfig->{dir}, $hConfig->{full_count});
		}
		if ($hConfig->{type} eq 'sql') {
			traversal_hdfsdir_delete_sql($hConfig->{hadoop_path}, $hConfig->{hdfs_base}, $hConfig->{dir}, $hConfig->{remain_count});
		}
		if ($hConfig->{type} eq 'webbk') {
			traversal_hdfsdir_delete_webbk($hConfig->{hadoop_path}, $hConfig->{hdfs_base}, $hConfig->{dir}, $hConfig->{remain_count});
		}
	}
	
	my $end_time = strftime( "%Y-%m-%d %H:%M:%S", localtime(time));

	log2("Success,unlinked $delete_count files!");	
	log2("start_time:".$start_time);
	log2("end_time:".$end_time);
	log2("--------------------------------- ---------------------------------\n\n");
	
	sleep 86400;
}

sub traversal_hdfsdir_delete_log {
	my ($hadoop_path, $hdfs_base, $src_dir, $rm_days) = @_;
	
	our $delete_count;
	
	my $dir_lists_tmp = [split(/\n|\r\n/,`$hadoop_path fs -ls $hdfs_base$src_dir`)];
	
	my $dir_lists = {};
	foreach (@$dir_lists_tmp) {
		next unless m#([-d])[-rwxd]{9}.*?(\d+)\s+(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})\s+(.*)#;
		$dir_lists->{file}->{$5} = $2 if $1 eq '-';
		$dir_lists->{dir}->{$5} = 1 if $1 eq 'd';
	}
	
	#open my $dLogFile,">> deletelogfiles.txt";
	foreach my $d_file (sort(keys %{$dir_lists->{file}})) {
		next unless $d_file =~ m#(\d{4})(\d{2})(\d{2})(\d{2})\.lzo#;
		
		#删除200天之前的日志
		if(time() - 86400*$rm_days > str2time("$1-$2-$3 $4:00:00")) {
			my $r_v = `$hadoop_path fs -rm $hdfs_base$d_file`;
			if($r_v =~ /^Deleted hdfs/) {
				 log2("deleted old log file $d_file");
				 $delete_count++;
			} else {
				log2("deleted old log file $d_file failed");
			}
			#print $dLogFile $d_file."\n";
		}
	}
	#close $dLogFile;	
	
	foreach my $d_dir (sort(keys %{$dir_lists->{dir}})) {
		traversal_hdfsdir_delete_log($hadoop_path, $hdfs_base, $d_dir, $rm_days);
	}
}

sub traversal_hdfsdir_delete_dbbk {
	my ($hadoop_path, $hdfs_base, $src_dir, $full_remain) = @_;
		
	our $delete_count;
	
	my $dir_lists_tmp = [split(/\n|\r\n/,`$hadoop_path fs -ls $hdfs_base$src_dir`)];
	
	my $dir_lists = {};
	my $fullfile_lists = [];
	foreach (@$dir_lists_tmp) {
		next unless m#([-d])[-rwxd]{9}.*?(\d+)\s+(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})\s+(.*)#;
		$dir_lists->{file}->{$5} = $2 if $1 eq '-';
		$dir_lists->{dir}->{$5} = 1 if $1 eq 'd';
	}
	foreach (keys %{$dir_lists->{file}}) {
		next unless m#\d{10}_full#;
		push @$fullfile_lists,$_;
	}
	$fullfile_lists = [sort(@$fullfile_lists)];
	
	open my $mylog,">> mylog.txt";
	print $mylog "------------------- $src_dir -------------------\n";
	print $mylog "+++d:\n".Dumper([sort(keys %{$dir_lists->{dir}})]);
	print $mylog "+++f:\n".Dumper([sort(keys %{$dir_lists->{file}})]);
	print $mylog Dumper($fullfile_lists);
		
	foreach my $src_tmp (sort(keys %{$dir_lists->{dir}})) {
		traversal_hdfsdir_delete_dbbk($hadoop_path, $hdfs_base, $src_tmp, $full_remain);
	}
	
	foreach my $src_tmp (sort(keys %{$dir_lists->{file}})) {
		next unless $src_tmp =~ /(\d{10})_/;
		my $log_ts = $1;
		
		#删除23天之前的增量
		if (time() - 86400*23 > $log_ts) {
			my $r_v = `$hadoop_path fs -rm $hdfs_base$src_tmp`;
			if($r_v =~ /^Deleted hdfs/) {
				 log2("deleted old remote file $src_tmp");
				 $delete_count++;
			} else {
				log2("deleted old file $src_tmp failed");
			}
		}
	}
	
	my $min_ts = undef;
	if(defined($fullfile_lists) && 1 <= scalar(@$fullfile_lists) && scalar(@$fullfile_lists) >= $full_remain) {
		#/GMAutodown/lywm_db/gs7/1352468486_full.tar.gz
		($min_ts) = $fullfile_lists->[scalar(@$fullfile_lists) - $full_remain] =~ /(\d{10})_full\.tar\.gz$/;
	}	
	return unless defined($min_ts);
	
	print $mylog "+++t:\n".Dumper($min_ts);
	close $mylog;
	
	foreach my $src_tmp (sort(keys %{$dir_lists->{file}})) {
		next unless $src_tmp =~ /(\d{10})_/;
		my $log_ts = $1;
		
		# 删除两个全备份前的增量
		if ($min_ts > $log_ts) {
			my $r_v = `$hadoop_path fs -rm $hdfs_base$src_tmp`;
			if($r_v =~ /^Deleted hdfs/) {
				log2("deleted remote file $src_tmp");
				$delete_count++;
			} else {
				log2("deleted file $src_tmp failed");
			}
		}
	}
}

sub traversal_hdfsdir_delete_sql {
	my ($hadoop_path, $hdfs_base, $src_dir, $remain_count) = @_;
		
	our $delete_count;
	
	my $dir_lists_tmp = [split(/\n|\r\n/,`$hadoop_path fs -ls $hdfs_base$src_dir`)];
	
	my $dir_lists = {};
	
	foreach (@$dir_lists_tmp) {
		#next unless m#([-d])[-rwxd]{9}.*?(\d+)\s+(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})\s+(.*)#;
		next unless m#([-d])[-rwxd]{9}.*?(\d+)\s+(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})\s+(.*?)_(\d{10})\.sql#;
		push @{$dir_lists->{file}->{$5}},$6 if $1 eq '-';
	}
	print "---dir_lists:\n".Dumper($dir_lists);
	foreach my $tbase (keys %{$dir_lists->{file}}) {
		my @tbase_files = sort(@{$dir_lists->{file}->{$tbase}});
		next unless scalar(@tbase_files) > $remain_count;
		while(scalar(@tbase_files) > $remain_count) {
			print "$tbase tbase_files:\n".Dumper([@tbase_files]);
			my $file_time =  shift @tbase_files;
			my $d_file = $tbase."_".$file_time.".sql";
			
			my $r_v = `$hadoop_path fs -rm $hdfs_base$d_file`;
			if($r_v =~ /^Deleted hdfs/) {
				 log2("deleted remote file $d_file");
				 $delete_count++;
			} else {
				log2("deleted file $d_file failed");
			}
		}
	}
}

sub traversal_hdfsdir_delete_webbk {
	my ($hadoop_path, $hdfs_base, $src_dir, $remain_count) = @_;
		
	our $delete_count;
	
	my $dir_lists_tmp = [split(/\n|\r\n/,`$hadoop_path fs -ls $hdfs_base$src_dir`)];
	
	my $dir_lists = {};
	
	foreach (@$dir_lists_tmp) {
		next unless m#([-d])[-rwxd]{9}.*?(\d+)\s+(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})\s+(.*?)_(\d{8})\.tar\.gz#;
		push @{$dir_lists->{file}->{$5}},$6 if $1 eq '-';
	}
	print "---dir_lists:\n".Dumper($dir_lists);
	foreach my $tbase (keys %{$dir_lists->{file}}) {
		my @tbase_files = sort(@{$dir_lists->{file}->{$tbase}});
		next unless scalar(@tbase_files) > $remain_count;
		while(scalar(@tbase_files) > $remain_count) {
			print "$tbase tbase_files:\n".Dumper([@tbase_files]);
			my $file_time =  shift @tbase_files;
			my $d_file = $tbase."_".$file_time.".tar.gz";
			
			my $r_v = `$hadoop_path fs -rm $hdfs_base$d_file`;
			if($r_v =~ /^Deleted hdfs/) {
				 log2("deleted remote file $d_file");
				 $delete_count++;
			} else {
				log2("deleted file $d_file failed");
			}
		}
	}
}

$SIG{__WARN__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);
   	
   	my $text_ = $text ? $text : "";
	log2('warn: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};

$SIG{__DIE__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);

	my $text_ = $text ? $text : "";
	log2('error: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};
