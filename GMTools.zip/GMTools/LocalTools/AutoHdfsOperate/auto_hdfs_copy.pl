#!/usr/bin/perl
#实现本地与集群之间的遍历拷贝(不覆盖),主要用于将82上的日志拷贝到集群(不挂载)
#/usr/bin/perl /GMTools/AutoHdfsCopy/auto_hdfs_copy.pl -srv
BEGIN{
	use FindBin;
	$::APPLICATION_PATH = $FindBin::Bin;
	$::PARENT_PATH = $::APPLICATION_PATH."/../";
	push( @INC, $::APPLICATION_PATH, $::PARENT_PATH);
	chdir( $::APPLICATION_PATH);
	
	$::APPLICATION_ISRUN = 1;
	
	# 防止意外关闭
	$SIG{HUP} = sub {};
	$SIG{INT} = sub { $::APPLICATION_ISRUN = 0;};
	$| = 1;
}
use strict;
use warnings;
use Data::Dumper;
use POSIX qw(strftime);
use File::Path qw(make_path remove_tree);

use File::Copy;

require 'common.pl';
require 'srv.pl';

#*************************要修改的***************************
my $src_base_dir = "/GMTools/LogPig_new";
my $hadoop_path = "/usr/hadoop-1.0.3/bin/hadoop";

my $hdfs_base = "hdfs://csmaster:9000";
my $dst_dir = "/gdb/test1";
#****************************************************

our $copy_count = 0;
our $makepath_count = 0;
our $delete_count = 0;
while ($::APPLICATION_ISRUN) {
	my $start_time = strftime("%Y-%m-%d %H:%M:%S", localtime(time));
	###############################################################################
	$copy_count = 0;
	$makepath_count = 0;
	$delete_count = 0;
	local_to_hdfs($src_base_dir, $hdfs_base, $dst_dir);
	###############################################################################
	my $end_time = strftime( "%Y-%m-%d %H:%M:%S", localtime(time));

	log2("Success,made $makepath_count dir!");
	log2("Success,copied $copy_count files!");
	log2("Success,deleted $delete_count files!");
	log2("start_time:".$start_time);
	log2("end_time:".$end_time);
	log2("--------------------------------- ---------------------------------\n\n");
	
	sleep 6;
}

sub local_to_hdfs {
	my ($src_dir, $hdfs_base, $dst_dir) = @_;
	
	our $copy_count;
	our $makepath_count;
	
	my $dir_lists = [sort glob($src_dir."/*")];
	my $dst_lists = {
		file	=>	{},
		dir		=>	{},
	};
	
	my $dst_lists_tmp = [split(/\n|\r\n/,`$hadoop_path fs -ls $hdfs_base$dst_dir`)];
	foreach (@{$dst_lists_tmp}) {
		next unless /([-d])[-rwxd]{9}.*?(\d+)\s+(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})\s+(.*)/;
		# print "$1,$2,$3,$4,$5\n";
		$dst_lists->{file}->{$5} = $2 if $1 eq '-';
		$dst_lists->{dir}->{$5} = 1 if $1 eq 'd';
	}
	
	# print Dumper($dst_lists);
	# print Dumper($dir_lists);
	
	
	foreach (@{$dir_lists}) {
		my $src_tmp = $_;
		#print $src_tmp."\n";
		$_ =~ s#$src_dir#$dst_dir#;
		my $dst_tmp = $_;
		# print $dst_tmp."\n";
		
		if(-f $src_tmp) {
			#添加后缀的过滤
			next if $src_tmp =~ /\.tmp$/;
			if(grep { $_ eq $dst_tmp } keys %{$dst_lists->{file}}) {
				my $size_src = -s $src_tmp;
				my $size_dst = $dst_lists->{file}->{$dst_tmp};
				if($size_dst == $size_src) {
					next;
				} else {
					log2("$src_tmp size:$size_src\t$dst_tmp size:$size_dst");
					my $r_v = `$hadoop_path fs -rm $hdfs_base$dst_tmp`;
					if($r_v =~ /^Deleted hdfs/) {
						log2("deleted remote bad file $dst_tmp");
						$delete_count++;
					} else {
						log2("deleted file $dst_tmp failed");
					}
				}
			} else {
				my $r_v = `$hadoop_path fs -put $src_tmp $hdfs_base$dst_tmp`;
				if('' eq $r_v) {
					$copy_count++;
					log2("copied file $dst_tmp");
				} else {
					log2("copy $src_tmp failed");
				}
			}
		} elsif (-d $src_tmp) {
			if(grep { $_ eq $dst_tmp } keys %{$dst_lists->{dir}}) {
				local_to_hdfs($src_tmp, $hdfs_base, $dst_tmp);
			} else {
				my $r_v = `$hadoop_path fs -mkdir $hdfs_base$dst_tmp`;
				if('' eq $r_v) {
					$makepath_count++;
					log2("made path $dst_tmp");
					local_to_hdfs($src_tmp, $hdfs_base, $dst_tmp);
				} else {
					log2("make path $dst_tmp failed");
				}
			}
		}
	}
}

$SIG{__WARN__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);
   	
   	my $text_ = $text ? $text : "";
	log2('warn: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};

$SIG{__DIE__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);

	my $text_ = $text ? $text : "";
	log2('error: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};