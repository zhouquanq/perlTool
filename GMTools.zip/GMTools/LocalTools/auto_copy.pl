#!/usr/bin/perl
#实现本地文件夹之间的遍历拷贝(不覆盖),主要用于将82上的日志拷贝到集群
BEGIN{
	use FindBin;
	$::APPLICATION_PATH = $FindBin::Bin;
	$::PARENT_PATH = $::APPLICATION_PATH."/../";
	push( @INC, $::APPLICATION_PATH, $::PARENT_PATH);
	chdir( $::APPLICATION_PATH);
	
	$::APPLICATION_ISRUN = 1;
	
	# 防止意外关闭
	$SIG{HUP} = sub {};
	$SIG{INT} = sub { $::APPLICATION_ISRUN = 0;};
	$| = 1;
}
use strict;
use warnings;
use Data::Dumper;
use POSIX qw(strftime);
use File::Path qw(make_path remove_tree);

use File::Copy;

require 'common.pl';
require 'srv.pl';

#*************************要修改的***************************
my $src_base_dir = "";
my $dst_base_dir = "";
#****************************************************

our $copy_count = 0;
our $makepath_count = 0;
while ($::APPLICATION_ISRUN) {
	my $start_time = strftime("%Y-%m-%d %H:%M:%S", localtime(time));
	###############################################################################
	$copy_count = 0;
	$makepath_count = 0;
	traversal_dir($src_base_dir,$dst_base_dir);
	###############################################################################
	my $end_time = strftime( "%Y-%m-%d %H:%M:%S", localtime(time));

	log2("[".ts2str(time)."] Success,made $makepath_count dir!");
	log2("[".ts2str(time)."] Success,copied $copy_count files!");
	log2("[".ts2str(time)."] start_time:".$start_time);
	log2("[".ts2str(time)."] end_time:".$end_time);
	log2("--------------------------------- ---------------------------------\n\n");
	
	sleep 600;
}

sub traversal_dir {
	my ($src_dir,$dst_dir) = @_;
	
	our $copy_count;
	our $makepath_count;
	
	my @dir_lists = glob($src_dir."/*");
	my @dst_lists = glob($dst_dir."/*");
	
	foreach (@dir_lists) {
		my $src_tmp = $_;
		#print $src_tmp."\n";
		$_ =~ s#$src_dir#$dst_dir#;
		my $dst_tmp = $_;
		#print $dst_tmp."\n";
		
		if(-f $src_tmp) {
			#添加后缀的过滤
			next if $src_tmp =~ /\.tmp$/;
			if(grep { $_ eq $dst_tmp } @dst_lists) {
				
			} else {
				copy($src_tmp,$dst_tmp) or die "Copy $src_tmp failed: $!";
				$copy_count++;
				log2("[".ts2str(time)."] copied file $dst_tmp");
			}
		} elsif (-d $src_tmp) {
			if(grep { $_ eq $dst_tmp } @dst_lists) {
				traversal_dir($src_tmp,$dst_tmp);
			} else {
				make_path($dst_tmp);				
				$makepath_count++;
				log2("[".ts2str(time)."] make path $dst_tmp");
				traversal_dir($src_tmp,$dst_tmp);
			}
		}
	}	
}

$SIG{__WARN__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);
   	
   	my $text_ = $text ? $text : "";
	log2('warn: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};

$SIG{__DIE__} = sub{
	
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);

	my $text_ = $text ? $text : "";
	log2('error: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};