﻿<?php
	$cfg = array(
		"lywm"	=>	array(
			"sdbarg"	=>	array(
				"host"	=>	"183.233.224.194",
				"port"	=>	"13306",
				"user"	=>	"sdb",
				"name"	=>	"sdb_lywm",
				"pass"	=>	"qJe9esl6mE7E9N",
			),
			"gasarg"	=>	array(
				"host"	=>	"183.233.224.194",
				"port"	=>	"13306",
				"user"	=>	"gas",
				"name"	=>	"gameanalysis_lywm",
				"pass"	=>	"XSFdRGXjPO9t",
			),
		),
		"lyly"	=>	array(
			"sdbarg"	=>	array(
				"host"	=>	"183.233.224.194",
				"port"	=>	"13306",
				"user"	=>	"sdb",
				"name"	=>	"sdb_lyly",
				"pass"	=>	"qJe9esl6mE7E9N",
			),
			"gasarg"	=>	array(
				"host"	=>	"183.233.224.194",
				"port"	=>	"13306",
				"user"	=>	"gas",
				"name"	=>	"gameanalysis_lyly",
				"pass"	=>	"XSFdRGXjPO9t",
			),
		),
		"lyju"	=>	array(
			"sdbarg"	=>	array(
				"host"	=>	"124.232.163.34",
				"port"	=>	"3306",
				"user"	=>	"sdb",
				"name"	=>	"sdb_lyju",
				"pass"	=>	"qJe9esl6mE7E9N",
			),
			"gasarg"	=>	array(
				"host"	=>	"124.232.163.88",
				"port"	=>	"3306",
				"user"	=>	"gas",
				"name"	=>	"gameanalysis_lyju",
				"pass"	=>	"XSFdRGXjPO9t",
			),
		),
		"fyios"	=>	array(
			"sdbarg"	=>	array(
				"host"	=>	"124.232.163.34",
				"port"	=>	"3306",
				"user"	=>	"sdb",
				"name"	=>	"sdb_fyios",
				"pass"	=>	"qJe9esl6mE7E9N",
			),
			"gasarg"	=>	array(
				"host"	=>	"124.232.163.88",
				"port"	=>	"3306",
				"user"	=>	"gas",
				"name"	=>	"gameanalysis_fyios",
				"pass"	=>	"XSFdRGXjPO9t",
			),
		),
		"lyios"	=>	array(
			"sdbarg"	=>	array(
				"host"	=>	"183.233.224.194",
				"port"	=>	"13306",
				"user"	=>	"sdb",
				"name"	=>	"sdb_lyios",
				"pass"	=>	"qJe9esl6mE7E9N",
			),
			"gasarg"	=>	array(
				"host"	=>	"183.233.224.194",
				"port"	=>	"13306",
				"user"	=>	"gas",
				"name"	=>	"gameanalysis_lyios",
				"pass"	=>	"XSFdRGXjPO9t",
			),
		),
		"lyld"	=>	array(
			"sdbarg"	=>	array(
				"host"	=>	"221.181.72.65",
				"port"	=>	"3306",
				"user"	=>	"root",
				"name"	=>	"sdb_lyld",
				"pass"	=>	"j3nrM85yKGh7bidr",
			),
			"gasarg"	=>	array(
				"host"	=>	"221.181.72.65",
				"port"	=>	"3306",
				"user"	=>	"gas",
				"name"	=>	"gameanalysis_lyld",
				"pass"	=>	"XSFdRGXjPO9t",
			),
		),
		"lytw"	=>	array(
			"sdbarg"	=>	array(
				"host"	=>	"218.32.54.69",
				"port"	=>	"3306",
				"user"	=>	"sdb",
				"name"	=>	"sdb_lytw",
				"pass"	=>	"qJe9esl6mE7E9N",
			),
			"gasarg"	=>	array(
				"host"	=>	"218.32.54.69",
				"port"	=>	"3306",
				"user"	=>	"gas",
				"name"	=>	"gameanalysis_lytw",
				"pass"	=>	"XSFdRGXjPO9t",
			),
		),
	);
?>
