﻿<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
	</head>
	<body>
		<form name="myform" action="#" method="post">
			运营商: 
			<select name='op' onchange="myform.submit()">
				<option value='lywm' <?php echo isset($_POST['op'])&&$_POST['op']=='lywm'?"selected='selected'":""; ?>>龙印网盟</option>
				<option value='lyly' <?php echo isset($_POST['op'])&&$_POST['op']=='lyly'?"selected='selected'":""; ?>>龙印乐易</option>
				<option value='lyju' <?php echo isset($_POST['op'])&&$_POST['op']=='lyju'?"selected='selected'":""; ?>>龙印嘉誉</option>
				<option value='fyios' <?php echo isset($_POST['op'])&&$_POST['op']=='fyios'?"selected='selected'":""; ?>>龙印飞娱ios</option>
				<option value='lyios' <?php echo isset($_POST['op'])&&$_POST['op']=='lyios'?"selected='selected'":""; ?>>龙印9游ios</option>
				<option value='lyld' <?php echo isset($_POST['op'])&&$_POST['op']=='lyld'?"selected='selected'":""; ?>>龙印乐逗</option>				
				<option value='lytw' <?php echo isset($_POST['op'])&&$_POST['op']=='lytw'?"selected='selected'":""; ?>>龙印台湾</option>				
			</select><br/>
		</form>
	</body>
</html>

<?php
	require "show_logana_ruler.cfg.php";
	if(!isset($_POST['op'])) {
		$op = "lywm";
	} else {
		$op = $_POST['op'];
	}
	#查找需要显示的服务器
	$dsn = 'mysql:dbname='.$cfg[$op]['sdbarg']['name'].";host=".$cfg[$op]['sdbarg']['host'].";port=".$cfg[$op]['sdbarg']['port'];
	try {
		$dbh = new PDO($dsn, $cfg[$op]['sdbarg']['user'], $cfg[$op]['sdbarg']['pass']);
	} catch (PDOException $e) {
		echo 'Connection'.$cfg[$op]['sdbarg']['name'].' failed: '.$e->getMessage();
	}
	$theday = date("Y-m-d");
	$sth = $dbh->prepare("SELECT serverid FROM needrunserver WHERE theday = '$theday' ORDER BY serverid");
	$sth->execute();		
	$resultset = $sth->fetchAll();
	
	$sids_arr = array();
	foreach ($resultset as $value) {
		array_push($sids_arr, $value["serverid"]);
	}
	$sids_arr_str = implode(",", $sids_arr);
	#print_r($sids_arr_str);
	
	#根据服务器查找分析进度
	$sql = "SELECT l.sid,s.servername,l.lastfile,l.iscomplete FROM logana_ruler l INNER JOIN serverlist s ON l.sid = s.serverid WHERE l.sid IN ($sids_arr_str) GROUP BY l.sid ORDER BY l.sid";
	
	$dsn = "mysql:dbname=".$cfg[$op]['gasarg']['name'].";host=".$cfg[$op]['gasarg']['host'].";port=".$cfg[$op]['gasarg']['port'].";charset=utf8";
	try {
		$dbh = new PDO($dsn, $cfg[$op]['gasarg']['user'], $cfg[$op]['gasarg']['pass']);
	} catch (PDOException $e) {
		echo 'Connection'.$cfg[$op]['gasarg']['name'].' failed: '.$e->getMessage();
	}
	$sth = $dbh->prepare($sql);
	$sth->execute();		
	$resultset = $sth->fetchAll();
	
	echo "<table border='1' width='540'>";
		echo "<tr align='center'>";
			echo "<td width='100'>服务器id</td>";
			echo "<td width='200'>服务器名</td>";
			echo "<td width='120'>最后分析文件</td>";
			echo "<td width='120'>是否已分析</td>";
		echo "</tr>";
	foreach ($resultset as $row) {
		echo "<tr align='center'>";
			echo "<td>".$row['sid']."</td>";
			echo "<td>".$row['servername']."</td>";
			echo "<td>".$row['lastfile']."</td>";
			echo "<td>".($row['iscomplete']?"是":"否")."</td>";
		echo "</tr>";
	}
	echo "</table>";
?>
