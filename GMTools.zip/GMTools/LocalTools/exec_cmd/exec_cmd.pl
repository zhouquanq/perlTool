# sdb数据库位置:
# sdb_lywm			183.233.224.194:13306
# sdb_lyly			183.233.224.194:13306
# sdb_fyios			124.232.163.34
# sdb_lyld			221.181.72.65
# sdb_lytw			218.32.54.69

# user: sdb
# pswd: qJe9esl6mE7E9N

#!/usr/bin/perl
use warnings;
use strict;
use Data::Dumper;
use HTTP::Date qw(time2iso);

my $cmds = [
	# "mysql -usdb -pqJe9esl6mE7E9N sdb_lyly < /home/zm_0621/SdbDeleteSqlFile_leyi_gs10.txt",
	# "mysql -usdb -pqJe9esl6mE7E9N sdb_lyly < /home/zm_0621/SdbDeleteSqlFile_leyi_gs103.txt",
	# "mysql -usdb -pqJe9esl6mE7E9N sdb_lyly < /home/zm_0621/SdbDeleteSqlFile_leyi_gs104.txt",
	# "mysql -usdb -pqJe9esl6mE7E9N sdb_lyly < /home/zm_0621/SdbUpdateSqlFile_merge_gs106.txt",
	# "mysql -usdb -pqJe9esl6mE7E9N sdb_lyly < /home/zm_0621/SdbUpdateSqlFile_merge_gs107.txt",
	"df -h"
];

my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
my $log_file = "$base_file.log";

open LOG, ">> $log_file";
foreach my $t_cmd (@$cmds) {
	print LOG "\n\n---------------------------------------------\n";
	print LOG "[".time2iso(time())."] "."---start cmd:\n $t_cmd\n";
	my $return_content = `$t_cmd`;
	print LOG "[".time2iso(time())."] "."return info:\n $return_content\n";
}