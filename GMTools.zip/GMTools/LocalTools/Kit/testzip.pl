#!/usr/bin/perl -w
use File::Copy;
use Archive::Zip qw( :ERROR_CODES :CONSTANTS );
my ($d,$r) = @ARGV;
$r = defined($r) && ($r eq '-r') ? '1' : '0';
&testzip($d,$r);

sub testzip
{
	my ($dir, $rename) = @_;
	$dir =~ s/[\\\/]\s*$//g;
	opendir(DIR, $dir) or die "open failed!\n";
	my @filelist = readdir(DIR);
	close(DIR);

	my $printedir = 0;
	foreach my $filename(@filelist) {
		my $file = "$dir/$filename";
		next if ($filename eq '.' || $filename eq '..');

		if (-d $file) {
			&testzip($file, $rename);
		} elsif ($file =~ /\.zip$/) {
				my $zip_obj = Archive::Zip->new();
				if ($zip_obj->read($file) ne AZ_OK) {
					if ($printedir == 0) {
						print "-------------$dir-------------\n";
						$printedir = 1;
					}
					if ($r) {
						rename($file, $file.'.bad');
						print "$filename has renamed!\n";
					} else {
						print "$filename is bad!\n";
					}
				}
		} elsif ($file =~ /\.bad$/) {
			if ($printedir == 0) {
				print "-------------$dir-------------\n";
				$printedir = 1;
			}
			print "$filename was bad!\n";
		} elsif (-f $file) {
			if ($printedir == 0) {
				print "-------------$dir-------------\n";
				$printedir = 1;
			}
			print "$filename is unknown!\n";
		}
	}
}
