#!/opt/ActivePerl-5.14/bin/perl -w
use strict;
use warnings;
use Encode;
use FindBin;
use File::Path;
use File::Basename;
use Compress::Zlib;
use Archive::Zip qw( :ERROR_CODES :CONSTANTS );
BEGIN {
	use constant APPLICATION_PATH=>scalar($FindBin::Bin);
	push(@INC, $FindBin::Bin);
}
use Mysql;

my $AppPath;
my $g_continue;
my $WARN_LOCKCOUNT;

#my %dbconfig = ('host'=>'localhost', 'port'=>3306, 'name'=>'gamelog', 'user'=>'root', 'pass'=>'go2Db');
my %dbconfig = ('host'=>'192.168.1.21', 'port'=>3306, 'name'=>'gamelog', 'user'=>'root', 'pass'=>'go2Db');

my %g_charname2charid;

my $conn = Mysql::genConn(\%dbconfig);
my $db = new Mysql($conn);

my $g_current_findb;
my $g_current_dbtable;
my $g_dbimport_file;

my $g_bRecordInput;
#my @unknown_lines;
#my @unknown_owner_logs;
#my @online_players;

main();

#for(@unknown_lines) {
#	print_utf8($_,"\n");
#}

#use Data::Dump;
#Data::Dump::dump(%processed_files);
#exit;
############################################################################################
sub main 
{	
	$|=1;
	$AppPath = $FindBin::Bin;
	$g_bRecordInput = shift(@ARGV);
	$g_bRecordInput = 0 unless (defined($g_bRecordInput) && length($g_bRecordInput));

	$g_continue = 1;
	
	while($g_continue) {
		my $cfg_ini = load_ini("$AppPath/parse_log.cfg");
		for (@{$cfg_ini}) {
			my $section = $_;
			my $logdir = get_section_value($section, 'logdir', '');
			$g_current_dbtable = get_section_value($section, 'dbtable', '');
			$g_current_findb = get_section_value($section, 'findb', '');
			scan_dir($logdir);
			%g_charname2charid = ();
			undef %g_charname2charid;
		}
		unlink ("$AppPath/dbimport.txt");
		print "Sleeping...\n";
		sleep(10);
	}
	print "Done!\n";
}

sub scan_dir
{
	my ($scandir) = @_;
	print "scaning directory: $scandir ...\n" unless ("$AppPath/parse_tmp" eq $scandir);

	my %processed_files = load_processed_files("$scandir/processed.log");
	
	if (opendir(DIR_SCAN, $scandir)) {
		my @items = sort(readdir(DIR_SCAN));
		closedir DIR_SCAN;

		for(@items) {
			my $item = $_;
			
			if (-f "$scandir/$item" && $item ne 'processed.log') {		
				if (exists($processed_files{lc($item)})) {
					print "--skip proccessed: $item\n";
					next;
				} elsif ($item =~ /\.log$/i) {
					parse_log("$scandir/$item");					
				} elsif ($item =~ /\.zip$/i) {
					my $tmp_path = "$AppPath/parse_tmp";
					-d $tmp_path ? rmtree($tmp_path) : unlink $tmp_path;
					mkpath("$tmp_path");

					my $zip_obj = Archive::Zip->new();
					unless ($zip_obj->read("$scandir/$item") == AZ_OK ) {
					   print "read zip file failed $scandir/$item", "\n";
					   next;
					}
					print "--extracting: $item ...\n";
					$zip_obj->extractTree('', "$tmp_path/");
					
					scan_dir($tmp_path);					
					rmtree($tmp_path);
				}
				append_processed_files("$scandir/processed.log", lc($item));
			} #if (-f "$scandir/$item" && $item ne 'processed.log')									
		} #for(@items)
	}#if (opendir(DIR_SCAN, $scandir))
}

sub parse_log
{
	my ($file) = @_;
	my $filebasename = basename($file);
	return unless $filebasename =~ /server-(\d{4})-(\d{1,2})-\d{1,2}-\d{1,2}\.log$/i;
	print "--parsing log: $filebasename...\n";
		
	my $tbsuffix = "_$1_$2";

	my $player_name;
	my $player_id;
	
	open $g_dbimport_file, ">$AppPath/dbimport.txt";	
	open FLOG, $file;

	while(<FLOG>) {
		my $line = $_;

		next if $line =~ /^\s*$/;

		$line =~ s/^\s+//;
		$line =~ s/\s+$//;

		if ($line =~ s/^\[[^\]]+\]\[[^\]]+\]\[([^\]]+)\]\s*//) {
			my $strTime = $1;

			if ($line =~ /^onRemote/i) {
				if ($g_bRecordInput)
				{
					$line =~ /^onRemoteInput:.*? playerId=(\d+)/i or next;
					$player_id = $1;
					parse_line(1, $player_id, "", $strTime, $line, '\N', '\N', '\N', '\N');
				}
				next;
			}
			elsif ($line =~ /^onServerAccept/i){
				next;
			}
			elsif ($line =~ /^submit\[[^\]]+\]/i){
				next;
			}
			elsif ($line =~ /^currentOnlinePlayers/i){
				$line =~ /^currentOnlinePlayers:(\d+)$/ or next;  #die_utf8($line);
				#push @online_players, "$strTime, $1";
				next;
			}

			elsif ($line =~ /^buyonsaleitem/i){
				$line =~ /^buyonsaleitem: seller:(\d+) sellermail gold: (\d+) (.+)$/ or next; # die_utf8($line);
				$player_id = $1;

				parse_line(2, $player_id, "", $strTime, "buyonsaleitem: gold:$2 " .$3, '\N', '\N', '\N', '\N');
				next;
			}
			elsif ($line =~ /nowlevelup start:\d+ end:\d+$/i){
			}
			elsif ($line =~ /startitemonsale:inst:\d+ protoId:\d+$/i){
			}
			elsif ($line =~ /^onsale info:/i){
				$line =~ /^onsale info:onsaleId:\d+ (\d+), ([^,]+), (.+)$/ or next; #die_utf8($line);
				$player_name = $2;
				$player_id = $1;

				parse_line(3, $player_id, $player_name, $strTime, "onsale: " .$3, '\N', '\N', '\N', '\N');
				next;
			}
			elsif ($line =~ /^[^\s]+ \d+$/i){
			}
			elsif ($line =~ /^\=+$/i){
			}
			elsif ($line =~ /^Version: /i){
			}
			elsif ($line =~ /^impossible /i){
			}
			elsif ($line =~ / line \d+.$/i){
			}
			elsif ($line =~ /^connection not exists:/i){
			}
			elsif ($line =~ /^\-> Invalid player name/i){
			}
			elsif ($line =~ /^\-> Invalid content text/i){
			}
			elsif ($line =~ /活动更新 segment: \d+ expired: \d+$/i){
			}
			elsif ($line =~ /活动更新 campId: \d+ state: \d+ opened: \d+$/i){
			}
			elsif ($line =~ /活动更新 expired: \d+ opened: \d+$/i){
			}
			elsif ($line =~ /活动[^\(]+\(\d+\)更新 state: \d+/i){
			}
			elsif ($line =~ /进入游戏$/i){
				$line =~ /^([^\(]+)\((\d+)\)/ or next; # die_utf8($line);
				$player_name = $1;
				$player_id = $2;

				parse_line(4, $player_id, $player_name, $strTime, "进入游戏", '\N', '\N', '\N', '\N');
				next;
			}
			elsif ($line =~ /^items in container:/i){
				$line =~ /^items in container:(\d+), ([^,]+), ([a-z]+),(.+?)容器:(\d+)(.+)$/i or next; #die_utf8($line);
				$player_id = $1;
				$player_name = $2;
				my $context = $3;
				my $l = $4 . $6;
				my $container = $5;

				my %desc = (
					1 => "装备背包",
					2 => "材料背包",
					3 => "技能背包",
					4 => "装备槽",
					5 => "仓库",
					);

				parse_line(5, "", $player_name, $strTime, "物品信息($context) 在 ".$desc{$container}." ".$l, '\N', '\N', '\N', '\N');

			}
			elsif ($line =~ /退出游戏$/i){
				$line =~ /^([^\(]+)\((\d+)\)/ or next; #die_utf8($line);
				$player_name = $1;
				$player_id = $2;

				parse_line(6, $player_id, $player_name, $strTime, "退出游戏", '\N', '\N', '\N', '\N');
				next;
			}
			elsif ($line =~ /makearm: makeId:\d+ schemeIndex:\d+$/i){
			}
			elsif ($line =~ /decomposearm: decomposearm:$/i){
			}
			elsif ($line =~ /learnskillbook \d+ skillProto:SkillProto=HASH\([^\)]+\)$/i){
			}
			elsif ($line =~ /upgradeskill nextSkillProto:SkillProto=HASH\([^\)]+\)$/i){
			}
			elsif ($line =~ /^数值类改变/i)
			{
				$line =~ /^数值类改变: (\d+), ([^,]+)/ or next; #die_utf8($line);
				$player_id = $1;
				$player_name = $2;

				parse_line(7, $player_id, $player_name, $strTime, $line, '\N', '\N', '\N', '\N');
				next;
			}
			elsif ($line =~ /^移除事件消息/i)
			{
				next;
			}
			elsif ($line =~ /^物品增加改变/i)
			{
				$line =~ /^物品增加改变: (\d+), ([^,]+)/ or next; #die_utf8($line);
				$player_id = $1;
				$player_name = $2;

				parse_line(8, $player_id, $player_name, $strTime, $line, '\N', '\N', '\N', '\N');
				next;
			}
			elsif ($line =~ /^物品移除改变/i)
			{
				$line =~ /^物品移除改变: (\d+), ([^,]+)/ or next; #die_utf8($line);
				$player_id = $1;
				$player_name = $2;

				parse_line(9, $player_id, $player_name, $strTime, $line, '\N', '\N', '\N', '\N');
				next;
			}
			elsif ($line =~ /^强化物品/i)
			{
				$line =~ /^强化物品:([^ ]+) /i or next; #die_utf8($line);
				$player_name = $1;
				parse_line(10, "", $player_name, $strTime, $line, '\N', '\N', '\N', '\N');
				next;
			}
			elsif ($line =~ /^清除野外战斗记录/i)
			{
				next;
			}
			elsif ($line =~ /^清除校场战斗记录/i)
			{
				next;
			}
			elsif ($line =~ /^更新排行榜/i)
			{
				next;
			}
			elsif ($line =~ /^服务器关闭中/i)
			{
				next;
			}
			elsif ($line =~ /^服务器关闭完成/i)
			{
				next;
			}
			elsif ($line =~ /^服务器启动中/i)
			{
				next;
			}
			elsif ($line =~ /^服务器启动完成/i)
			{
				next;
			}
			elsif ($line =~ /^国战信息 /i){
			}
			elsif ($line =~ /^礼包 /i)
			{
				next;
			}
			elsif ($line =~ /挂机停止 forceStop: \d+$/i){
			}
			elsif ($line =~ /重置任务$/i){
				next;
			}
			elsif ($line =~ /重置杀精英怪次数$/i){
				next;
			}
			elsif ($line =~ /重置活动活跃度$/i){
				next;
			}
			elsif ($line =~ /更新帮派任务$/i){
				next;
			}
			elsif ($line =~ /挂机被重置$/i){
				next;
			}
			elsif ($line =~ /进入排队状态 \d+ \d+$/i){
				next;
			}
			elsif ($line =~ /进入装载状态 \d+ \d+$/i){
				next;
			}
			elsif ($line =~ /退出战斗状态$/i){
				next;
			}
			elsif ($line =~ /退出刺探状态( completed: \d+)?$/i){
				next;
			}
			elsif ($line =~ /装载完成$/i){
				next;
			}
			else
			{
				#die_utf8($line);
				next;
			}
		} #if ($line =~ s/^\[[^\]]+\]\[[^\]]+\]\[([^\]]+)\]\s*//)
		elsif ($line =~ /^\s+called by/i) {
		}
		else {
			#push @unknown_lines, $line;
		}	
	} #while(<FLOG>)
	close FLOG;
	close $g_dbimport_file;	

	$db->_execute("LOAD DATA LOCAL INFILE '$AppPath/dbimport.txt' INTO TABLE $g_current_dbtable$tbsuffix");	
}

sub parse_line
{	
	my ($logtype, $charid, $charname, $optime, $content, $reserve1, $reserve2, $reserve3, $reserve4) = @_;
	
	if (length($charid)<=0) {
		if (exists($g_charname2charid{$charname})) {
			$charid = $g_charname2charid{$charname};
		} elsif(length($charname)>0) {
			find_charid($charname);
			return unless exists($g_charname2charid{$charname});
			$charid = $g_charname2charid{$charname};
		} else {
			return;
		}
	} elsif (length($charname)>0) {
		$g_charname2charid{$charname} = $charid;
	}

	my $line = "$charid\t$charname\t$logtype\t$content\t$optime\t$reserve1\t$reserve2\t$reserve3\t$reserve4";
	print $g_dbimport_file $line."\n";		

	#push @unknown_owner_logs, "$charid, $charname, $optime, ". $content;
	#return;
	#$charid = -1;
}

sub find_charid
{
	my $charname = shift(@_);

	$g_charname2charid{$charname} = 0;
	return;

	my $sql = "
		SELECT char_id
		FROM `$g_current_findb`.`character`
		WHERE `char_name` = '$charname'
		LIMIT 1";
	my $sth = $db->_query($sql);

	my $row_p = $sth->fetchrow_arrayref();	
	$g_charname2charid{$charname} = $row_p->[0] if defined($row_p);	
	$sth->finish();	
}

sub load_processed_files
{
	my ($logfile) = @_;
	my %processed_files;

	if (open(F_PROCESS, $logfile)) {
		while(<F_PROCESS>)
		{
			my $line = $_;
			next if $line =~ /^\s*$/;

			$line =~ s/^\s+//;
			$line =~ s/\s+$//;

			$processed_files{lc($line)} = 1;
		}
		close(F_PROCESS);
	}

	return %processed_files;
}

sub append_processed_files
{
	my ($logfile, $filename) = @_;
	open(F_OUT_PROCESS, ">>$logfile") or die "can't write $logfile";
	print F_OUT_PROCESS "$filename\n";
	close F_OUT_PROCESS;
}

#sub make_tmp
#{
#	$path = shift(@_);
#	if (-e $path)
#		-d $path ? rmtree($path) : unlink $path;
#	my $dir = "$AppPath/parse_tmp";
#	if (opendir(DIR_SCAN, $dir)) {
#		my @items = readdir DIR_SCAN;
#		closedir DIR_SCAN;
#
#		for (@items) {
#			my $item = $_;
#			next if -d "$dir/$item";
#			unlink("$dir/$item");
#		}
#	}
#	mkpath("$AppPath/parse_tmp");
#	return "$AppPath/parse_tmp";
#}

sub load_ini
{
	my ($file) = @_;
    
    return load_ini_from_buffer(readin($file));
}

sub readin
{
    my ($file) = @_;
    
    my $len = -s $file;


    return "" unless $len > 0;

    my $f;
    open $f, $file;
    binmode $f;
    my $cont = "";
    sysread($f, $cont, $len);
    close $f;
    
    return $cont;
}

sub load_ini_from_buffer
{
    my ($buffer) = @_;
    
    my @lines = split(/\r?\n/, $buffer);
    
	my @ret;
	my $section_name = "";
	my $kvs;

	for(@lines)
	{
		my $line = $_;
		next if $line=~ /^\s*$/ or $line =~ /^\s*\#/;

		$line =~ s/^\s+//;
		$line =~ s/\s+$//;

		if ($line =~ /^\[([^\]]+)\]$/) {
			my $tmp_name = $1;
			$tmp_name =~ s/^\s+//;
			$tmp_name =~ s/\s+$//;

			if (length($section_name) > 0) {
				my %ini_info;
				$ini_info{'name'} = $section_name;
				$ini_info{'kvs'} = $kvs;

				push @ret, \%ini_info;
			}

			my @arKvs;
			$kvs = \@arKvs;
			$section_name = $tmp_name;
		}
		elsif ($line =~ /^([^=]+)=(.*)$/){
			my $key = $1;
			my $value = $2;

			$key =~ s/^\s+//;
			$key =~ s/\s+$//;

			$value =~ s/^\s+//;
			$value =~ s/\s+$//;

			if (length($section_name) > 0) {
				my %kv;
				$kv{'key'} = $key;
				$kv{'value'} = $value;

				push @{$kvs}, \%kv;
			}
		}
	}

	if (length($section_name) > 0) {
		my %ini_info;
		$ini_info{'name'} = $section_name;
		$ini_info{'kvs'} = $kvs;

		push @ret, \%ini_info;
	}

	return \@ret;
}

sub get_section_value
{
	my ($section, $key, $default_value) = @_;

	for (@{$section->{'kvs'}}) {
		my $kv = $_;
		
		if (lc($kv->{'key'}) eq lc($key)) {
			if (length($kv->{'value'})>0) {
				return $kv->{'value'};
			}
		
			return defined($default_value)?$default_value:"";
		}
	}

	return defined($default_value)?$default_value:"";
}

sub print_utf8
{
	my (@params) = @_;
	for(@params)
	{
		#print encode("gb2312", decode("utf-8", $_));
		print $_;
	}
}

sub die_utf8
{
	print_utf8(@_);
	die;
}


BEGIN
{        
	$WARN_LOCKCOUNT = 0;

	$SIG{TERM} = sub {
		$g_continue = 0 
	};
	
	$SIG{__WARN__} = sub {
		return if($WARN_LOCKCOUNT);
		
		my ($text) = @_;		
	    my @loc = caller(0);  
		chomp($text);
	    __log($loc[1], $loc[2], $text);
	    
		my $index = 1;
	    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index)) {
			__log($loc[1], $loc[2], "$loc[3]");
		};

	    return 1;
	};

	$SIG{__DIE__} = sub {
		my ($text) = @_;
	    my @loc = caller(0);
	   	chomp($text);
	    __log($loc[1], $loc[2], $text);

		my $index = 1;
	    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index)) {
			__log($loc[1], $loc[2], "$loc[3]");
		};

	    return 1;
	};

	sub __log
	{
		my ($file, $line, $text) = @_;
		
		my ($sec, $min, $hour, $day, $mon, $year) = localtime(time());
		$year += 1900;
		$mon += 1;

		my $time = sprintf("%04d-%02d-%02d %02d:%02d:%02d", $year, $mon, $day, $hour, $min, $sec);

		$WARN_LOCKCOUNT++;
		
		my $script_name = $0;
		$script_name =~ s/^.+[\\\/]([^\\\/]+)$/$1/;
		
		my $pathname = $FindBin::Bin . "/" . $script_name . ".log";
		if($pathname)
		{
			open LOGFILE, ">>$pathname";
			#binmode(LOGFILE, ":encoding(utf8)");
			print LOGFILE "[$file($line)][$time] $text\n";
			close LOGFILE;
		}        
		$WARN_LOCKCOUNT--;              
	}
}

BEGIN
{
	for(@ARGV)
	{
		next unless /^\-srv$/i;
		
		my $pid = fork();
		if ($pid < 0)
		{
			die "fork: $!";
		}
		elsif ($pid)
		{
			exit 0;
		}
	
		chdir($FindBin::Bin);
	
		open(STDIN,  "</dev/null");
		open(STDOUT, ">/dev/null");
		open(STDERR, ">&STDOUT");
		last;
	}
}