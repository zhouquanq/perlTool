#!/usr/bin/perl
use Archive::Zip;
use strict;

require 'common.pl';

my ($d) = @ARGV;
&scanlog($d);

sub scanlog 
{
	my ($dir) = @_;
	opendir(DIR, $dir) or die "open failed!\n";
	my @filelist = readdir(DIR);
	close(DIR);

	my $newests = 0;
	foreach my $filename(@filelist) {
		my $file = "$dir/$filename";
		next if ($filename eq '.' || $filename eq '..');

		if (-d $file) {
			&scanlog($file);;
		} 
		elsif ($file =~ /\.zip$/) {			 
				my $zip_obj = Archive::Zip->new();
				if ($zip_obj->read("$file") ne 0 ) {
					next;
				}
				my @logfiles = $zip_obj->memberNames();
				foreach my $logfile(@logfiles) {
					next unless my ($ymd, $hour) = ($logfile =~ /server-(\d{4}-\d{1,2}-\d{1,2})-(\d{2})\.log$/i);
					my $ts = str2ts("$ymd $hour:00:00");
					$newests = $ts if $ts > $newests;
				}
		}
				
	}
	print "$dir: ".ts2str($newests)."\n" if $newests > 0;		
}