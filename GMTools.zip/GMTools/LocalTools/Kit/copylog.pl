#!/usr/bin/perl -w
use FindBin;
use Time::Local;
use File::Path;
use File::Copy;
use Archive::Zip qw( :ERROR_CODES :CONSTANTS );

my ($scandir, $startime, $endtime) = @ARGV;
my ($s_year, $s_mon, $s_day, $s_hour) = ();
my ($e_year, $e_mon, $e_day, $e_hour) = ();
if(defined($startime)&&$startime =~ /(\d{4})-(\d{2})-(\d{2})-(\d{2})/) {
	($s_year, $s_mon, $s_day, $s_hour) = ($1, $2, $3, $4);
} else {
	die ('Run as: this.pl scandir startime(yyyy-mm-dd-hh) endtime');
}
if (defined($endtime)&&$endtime =~ /(\d{4})-(\d{2})-(\d{2})-(\d{2})/) {
	($e_year, $e_mon, $e_day, $e_hour) = ($1, $2, $3, $4);
} else {
	die ('Run as: this.pl scandir startime(yyyy-mm-dd-hh) endtime');
}
die ('Run as: this.pl scandir startime(yyyy-mm-dd-hh) endtime') if (!defined($scandir) || !defined($startime) || !defined($endtime));

my $app_path = $FindBin::Bin;
my $tmp_path = "$app_path/tmplog";

@t = split('-', $startime);
my $starts = timelocal(0, 0, $t[3], $t[2], $t[1] - 1, $t[0]);
@t = split('-', $endtime);
my $endts  = timelocal(59, 59, $t[3], $t[2], $t[1] - 1, $t[0]);

print "dir $scandir not exists! \n" unless -d $scandir;
if (!opendir(DIR_SCAN, $scandir)) {
	die "Open dir $scandir failed!\n";
}

-d $tmp_path ? rmtree($tmp_path) : unlink $tmp_path;
mkpath($tmp_path);

my @files = reverse(sort(readdir(DIR_SCAN)));
closedir DIR_SCAN;
for(@files) {
	my $filename = $_;
	
	#zip格式
	if ($filename =~ /(13\d{8})/i) {
		next if($1 > ($endts + 86400) || $1 < $starts);
	
		my $zip_obj = Archive::Zip->new();
		if ($zip_obj->read("$scandir/$filename") ne AZ_OK ) {
			print "read zip file failed $scandir/$filename", "\n";
			next;
		}
		@logfilenames = sort($zip_obj->memberNames());						
		$firstlog = $logfilenames[0];
		#$lastlog = $logfilenames[length(@logfilenames) - 1];
		if ($firstlog =~ /server-(\d{4})-(\d{2})-(\d{2})-(\d{2})\.log$/i){
			$logts = timelocal(0, 0, $4, $3, $2 - 1, $1);
			
			if ($starts <= $logts && $logts <= $endts) {
				print "copying $filename\n";
				copy("$scandir/$filename", "$tmp_path/$filename");
			}
		}
	} elsif ($filename =~ /server-(\d{4})-(\d{2})-(\d{2})-(\d{2})\.log$/i) {
			$logts = timelocal(0, 0, $4, $3, $2 - 1, $1);
			
			if ($starts <= $logts && $logts <= $endts) {
				print "copying $filename\n";
				copy("$scandir/$filename", "$tmp_path/$filename");
			}		
	}
	
	#lzo格式	2012092609.lzo
	if($filename =~ /(\d{10}).lzo$/) {
		if(defined($s_year)&&defined($s_mon)&&defined($s_day)&&defined($s_hour)&&defined($e_year)&&defined($e_mon)&&defined($e_day)&&defined($e_hour)) {
			next if ($1 < int($s_year.$s_mon.$s_day.$s_hour) || $1 > int($e_year.$e_mon.$e_day.$e_hour));
			copy("$scandir/$filename", "$tmp_path/$filename");
			print "copying log $scandir/$filename \n";
		}
	}
}
