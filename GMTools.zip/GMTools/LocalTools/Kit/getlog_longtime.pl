#!/usr/bin/perl -w
BEGIN {
	use FindBin;
	my ($_parent_dir) = $FindBin::Bin =~ /(.*\/).*/;
	push(@INC, $FindBin::Bin, $_parent_dir);
}
use warnings;
use strict;
use Data::Dumper;

use MysqlX;

require 'common.pl';

our $g_app_path;

my $g_dbimport_file;		#当前导入文件句柄

my %g_charname2charid;

main();
sub main
{
		$g_app_path = $FindBin::Bin;

		my ($logdir, $startday, $enday, $charid) = @ARGV;
		die ('Run as: this.pl logdir startday(yyyy-mm-dd) [enday charid]') if (!defined($logdir) || !defined($startday));

		$enday = $startday if !defined($enday);
		$charid = undef if (!defined($charid) || 0 == $charid);
		
		
		open $g_dbimport_file, "> $g_app_path/dbimport_longtime.txt";	
	
		$enday = $startday if !defined($enday);
		
		my %connarg = (host=>'127.0.0.1',
					   port=>3306,
					   name=>'gamelog',
					   user=>'root', 
					   pass=>'3hk8gm2yeuOOv5Kr');
		
		my $conn = MysqlX::genConn(\%connarg);
		my $db = new MysqlX($conn);
		

		my $tmpdir = "$g_app_path/temp_longtime";
		(-d $tmpdir ? rmtree($tmpdir) : unlink $tmpdir) if -e $tmpdir;
		mkdir($tmpdir);
		
		#获取zip格式的日志
		my @zipfiles = filter_log_zipfile($logdir, $startday, $enday);
		while (<@zipfiles>) {
				my $zip_obj = Archive::Zip->new($_);
				$zip_obj->extractTree('', "$tmpdir/");
		}
		#获取lzop格式的日志
		my @lzofiles = &filter_log_lzofile_days($startday, $enday, $logdir);
		foreach my $file (@lzofiles) {
			next unless $file =~ /\.lzo$/;
			my $zip = Archive::Zip->new();
			
			my $cmd = "/usr/local/bin/lzop -x -f $file -p$tmpdir";
			0 == cmd($cmd) or print("Failed: $cmd");
		}
		
		my @logfiles = glob("$tmpdir/*.log");
		while(<@logfiles>) {
			open FH, "< $_";
			print "Add log file: $_\n";
			while (<FH>) {
				parse_line($_,$charid);
			}
			close FH;
		}
		
		close $g_dbimport_file;
		$db->_execute('TRUNCATE TABLE charop');
		$db->_execute("LOAD DATA LOCAL INFILE '$g_app_path/dbimport_longtime.txt' INTO TABLE charop");
}

sub parse_line
{
	my ($acc_line, $findcharid) = @_;	

	if ($acc_line =~ m/^(\[ [^\]]+ \]){2}   \[ ([^\]]+) \]  \s*(.*)/x) {
		my $strTime = $2;
		my $line = $3;

		if ($line =~ /onRemote/i) {
			if ($line =~ /onRemoteInput:.*? playerId=(\d+)/i)
			{
				my $player_id = $1;
				print_line(1, $player_id, "", $strTime, $line, '\N', '\N', '\N', '\N', $findcharid);
			}
		}
		elsif ($line =~ /buyonsaleitem: seller:(\d+) sellermail gold: (\d+) (.+)$/){
			my $player_id = $1;
			print_line(2, $player_id, "", $strTime, "buyonsaleitem: gold:$2 " .$3, '\N', '\N', '\N', '\N', $findcharid);
		}
		elsif ($line =~ /onsale info:onsaleId:\d+ (\d+), ([^,]+), (.+)$/){
			my $player_name = $2;
			my $player_id = $1;
			print_line(3, $player_id, $player_name, $strTime, "onsale: " .$3, '\N', '\N', '\N', '\N', $findcharid);
		}
		elsif ($line =~ /([^\(]+)\((\d+)\) 进入游戏/i){
			my $player_name = $1;
			my $player_id = $2;
			print_line(4, $player_id, $player_name, $strTime, "进入游戏", '\N', '\N', '\N', '\N', $findcharid);
		}
		elsif ($line =~ /items in container:(\d+), ([^,]+), ([a-z]?),(.+?)容器:(\d+)(.+)$/i){
			my $player_id = $1;
			my $player_name = $2;
			my $context = $3;
			my $l = $4 . $6;
			my $container = $5;

			my %desc = (
				1 => "装备背包",
				2 => "材料背包",
				3 => "技能背包",
				4 => "装备槽",
				5 => "仓库",
				);

			print_line(5, "", $player_name, $strTime, "物品信息($context) 在 ".$desc{$container}." ".$l, '\N', '\N', '\N', '\N', $findcharid);

		}
		elsif ($line =~ /([^\(]+)\((\d+)\) 退出游戏/i){
			my $player_name = $1;
			my $player_id = $2;
			print_line(6, $player_id, $player_name, $strTime, "退出游戏", '\N', '\N', '\N', '\N', $findcharid);
		}
		elsif ($line =~ /数值类改变: (\d+), ([^,]+)/)
		{
			my $player_id = $1;
			my $player_name = $2;
			print_line(7, $player_id, $player_name, $strTime, $line, '\N', '\N', '\N', '\N', $findcharid);
		}
		elsif ($line =~ /物品增加改变: (\d+), ([^,]+)/)
		{
			my $player_id = $1;
			my $player_name = $2;
			print_line(8, $player_id, $player_name, $strTime, $line, '\N', '\N', '\N', '\N', $findcharid);
		}
		elsif ($line =~ /物品移除改变: (\d+), ([^,]+)/)
		{
			my $player_id = $1;
			my $player_name = $2;
			print_line(9, $player_id, $player_name, $strTime, $line, '\N', '\N', '\N', '\N', $findcharid);
		}
		elsif ($line =~ /强化物品:([^ ]+)/)
		{
			my $player_name = $1;
			print_line(10, "", $player_name, $strTime, $line, '\N', '\N', '\N', '\N', $findcharid);
		}
		elsif ($line =~ /mail info/i)
		{	
			if($line =~ /senderId:(\d+),/i) {
				my $player_id = $1;
				print_line(11, $player_id, "", $strTime, $line, '\N', '\N', '\N', '\N', $findcharid);
			} 
			if($line =~ /receiverId:(\d+),/i) {
				my $player_id = $1;
				print_line(12, $player_id, "", $strTime, $line, '\N', '\N', '\N', '\N', $findcharid);
			}
		}
		elsif ($line =~ /\((\d+)\) 金币: \d+ 元宝: \d+ 礼卷: \d+/i)
		{
			my $player_id = $1;
			print_line(13, $player_id, '', $strTime, $line, '\N', '\N', '\N', '\N', $findcharid);
		}
		elsif($line =~ /(\d+) \S* nowlevelup start:\d+ end:\d+/)	{
			my $player_id = $1;
			print_line(14, $player_id, '', $strTime, $line, '\N', '\N', '\N', '\N', $findcharid);
		}
	}
}

sub print_line
{	
	my ($logtype, $charid, $charname, $optime, $content, $reserve1, $reserve2, $reserve3, $reserve4, $findcharid) = @_;

	if (length($charid)<=0) {
		if (exists($g_charname2charid{$charname})) {
			$charid = $g_charname2charid{$charname};
		} elsif(length($charname)>0) {
			return unless exists($g_charname2charid{$charname});
			$charid = $g_charname2charid{$charname};
		} else {
			return;
		}
	} elsif (length($charname)>0) {
		$g_charname2charid{$charname} = $charid;
	}

	my $line = "\\N\t$charid\t$charname\t$logtype\t$content\t$optime\t$reserve1\t$reserve2\t$reserve3\t$reserve4\n";
	if (defined($findcharid)) {
		print $g_dbimport_file $line if ($charid eq $findcharid);
	} else {
		print $g_dbimport_file $line;
	}
}

sub filter_log_lzofile_days {
	my ($startday, $enday, $logdir) = @_;
	my @files;
	for(my $i=str2ts($startday);$i<=str2ts($enday);$i += 86400) {
		my ($year,$month,$day) = ts2str($i) =~ /(\d{4})-(\d{2})-(\d{2})/;
		my @tmp_files = glob("$logdir/$year"."$month"."$day*.lzo");
		push @files,@tmp_files;
	}
		
	return @files;
}