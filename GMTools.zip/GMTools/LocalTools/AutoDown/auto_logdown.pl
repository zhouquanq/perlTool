#!/usr/bin/perl -w
#注:单线程下载,从数据库读取配置
BEGIN {
	use FindBin;
	my ($_parent_dir) = $FindBin::Bin =~ /(.*\/).*/;
	push(@INC, $FindBin::Bin, $_parent_dir);
}
use strict;
use warnings;

use File::Copy;
use File::Path;
use Net::FTP;
use Thread;
use Archive::Zip qw( :ERROR_CODES :CONSTANTS );
use Archive::Tar;
use Data::Dumper;
use POSIX;

require 'srv.pl';
require 'common.pl';

our $g_app_path;

my $g_continue;
my $WARN_LOCKCOUNT;

main();
sub main 
{
	$| = 1;
	$g_app_path = $FindBin::Bin;
	$g_continue = 1;

	my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
	my $cfg_file = "$base_file.cfg";
	die "cfg file: '$cfg_file' not exists!" unless -e $cfg_file;

	my $status_file = "$base_file.sta";
	
	#定义用于存储已下载文件名的变量
	#my %frist_time_flag = ();
	our $have_down = {};
	
	while ($g_continue) {
		my $now = ts2str(time());
		print "now: $now ...\n";
				
		my $cfg_ini = load_ini($cfg_file);
		
		my @threads;
		foreach my $section(@{$cfg_ini}) {
			#修改状态文件
			open(F_STATUS, ">$status_file") or die "can't write status output file: $status_file";
			print F_STATUS time();
			close F_STATUS;
			
			my $t_sectionname = $section->{'name'};			

			my $server = get_section_value($section, 'server', '');
			my $port = get_section_value($section, 'port', '');
			my $passive = get_section_value($section, 'passive', 1);
			my $username = get_section_value($section, 'username', '');
			my $password = get_section_value($section, 'password', '');	
			my $ext = get_section_value($section, 'ext', '');
			my $srcdb = get_section_value($section, 'srcdb', '');
			my $from_base_dir = get_section_value($section, 'from_base_dir', '');
			my $to_base_dir = get_section_value($section, 'to_base_dir', '');
			my $delete = get_section_value($section, 'delete', 0);
			my $down_days = get_section_value($section, 'down_days', 5);
			
			my %srcdb = str2arr($srcdb);			
			my $lastweek = ts2str(time() - 86400*7, 1);	
			
			#从数据库查询该运营商需要分析日志的服务器
			my $conn = MysqlX::genConn(\%srcdb);
			my $db = new MysqlX($conn);
			my $sql = "
				SELECT serverid FROM needrunserver WHERE theday >= '$lastweek' GROUP BY serverid
			";
			my $run_servers = [];
			eval{
				$run_servers = $db->fetchAll($sql);
			};
			if($@){
				log2("db connect lost $@");
				$run_servers = [];
			}
			#log2("run_servers:".Dumper($run_servers));
			foreach (@{$run_servers}) {
				my $serverid = $_->{'serverid'};
				#保证每个服务器的sectionname不一样
				my $sectionname = $t_sectionname.$serverid;
				
				my $ftp_path = $from_base_dir."/gs".$serverid;
				my $download_path = $to_base_dir."/gs".$serverid;
							
				#先删除大小为0的文件
				system "/usr/bin/find $download_path  -size 0 | /usr/bin/xargs -n 1 /bin/rm -f";
				
				my @d_files = glob("$download_path/*");
				foreach my $d_file (@d_files) {
					next unless $d_file =~ /\/([^\/]+?\.[^\.]+)$/;
					$have_down->{$sectionname}->{$1} = 1;
				}
				print "$server, $port, $username, $password, $ext, $ftp_path, $download_path, $delete, $passive,$serverid,$sectionname,$have_down  \n";
			eval{
				&download($server, $port, $username, $password, $ext, $ftp_path, $download_path, $delete, $passive,$serverid,$sectionname,$have_down,$down_days);
			};
			if($@){
				log2("program exception: error is caught $@");
			}
				sleep 1;
			}
			log2("----- $t_sectionname -----");
		}
		sleep 600;	
	}
}

sub download
{
	my ($server, $port, $username, $password, $ext, $ftp_path, $download_path, $delete, $passive, $serverid, $sectionname, $have_down, $down_days) = @_;
	
	mkpath($download_path);

	#扩展名trim
	my %exts;
	{
		my @tmp_exts = split(/,/, $ext);
		for (@tmp_exts)
		{
			my $e = $_;
			$e =~ s/^\s+//;
			$e =~ s/\s+$//;

			$exts{lc($e)} = 1;
		}
	}
	
	#去掉路径结尾/或\
	$ftp_path =~ s/[\\\/]\s*$// if $ftp_path !~ /^\s*[\/\\]\s*$/;
	$download_path =~ s/[\\\/]\s*$//;
	
	#FTP连接
	my $ftp = 0;
	my $tryCount = 3;
	while ($tryCount--) {
		$ftp = Net::FTP->new($server, Port => $port, Debug => 0, Passive => $passive);		

		if ($ftp) {
			last;
		} else {
			sleep(10);
		}
	}				
	if (!$ftp) {
		log2("connect to ftp($sectionname,$serverid) error: $@");
		return;
	}

	#FTP登录
	my $b_logined = 0;
	$tryCount = 3;
	while ($tryCount--) {		
		$b_logined = $ftp->login($username, $password);

		if ($b_logined) {
			last;
		} else {
			sleep(10);
		}
	}
	if (!$b_logined) {
		log2("login to ftp($server) error: $@");
		return;
	}
	
	#FTP切换传输模式
	if (!$ftp->binary()) {
		log2("can't change ftp($server) mode to binary: $@");
		return;
	}

	#FTP列出文件
	my @items = $ftp->ls($ftp_path);

	foreach my $item(@items) {
		#扩展名检查
		next unless $item =~ /\/([^\/]+?)\.([^\.]+)$/;
		my ($date, $format) = ($1, $2);
		my $file_name = "$date.$format";
		next unless $date =~ /^\d+$/;
		my $from_file_time = strftime("%Y%m%d%H", localtime(time() - 86400*$down_days));
		#log2("from_file_time:".$from_file_time);
		next if $date < $from_file_time;

		if(defined($have_down->{$sectionname}->{$file_name})) {
			print "next:serverid-".$sectionname.'_'.$serverid."	file_name-".$file_name."\n";
			next;
		}
		my $file_ext = lc($format);
		$file_ext =~ s/^\s+//;
		$file_ext =~ s/\s+$//;
		next unless exists($exts{$file_ext});

		#续传机制
		#print "get $sectionname _ $serverid _ $item...\n";
		log2("get $sectionname _ $serverid _ $item...\n");
		my $tmpfile = $download_path."/".$file_name.".tmp";
		my $tmpfilesize;
		if (-e $tmpfile) {			
			$tmpfilesize = -s $tmpfile;
			if ($tmpfilesize < $ftp->size($item)) {
				if (!$ftp->get($item, $tmpfile, $tmpfilesize)) {
					log2("ftp get file $item on $server error: $@");
					next;
				}
			}
		} else {				
			if (!$ftp->get($item, $tmpfile)) {
					log2("ftp get file $item on $server error: $@");
					next;
			}
		}

		#下载完整性检查
		$tmpfilesize = -s $tmpfile;		
		if ($tmpfilesize == $ftp->size($item)) {
			my $downfile = "$download_path/$file_name";
			move($tmpfile, $downfile);
			$have_down->{$sectionname}->{$file_name} = 1;			
			#确认下载成功后，删除远端文件
			# if ($delete && -e $downfile) {
				# $ftp->delete($item);
			# }
		}
		elsif ($tmpfilesize > $ftp->size($item)) {
			log2("Delete too large tmpfile: $tmpfile");
			unlink $tmpfile;
		}
	}	
	$ftp->quit;
}
