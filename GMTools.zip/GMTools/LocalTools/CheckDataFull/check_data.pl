#!/usr/bin/perl
BEGIN {
	use FindBin;
	my ($_parent_dir) = $FindBin::Bin =~ /(.*\/).*/;
	push(@INC, $FindBin::Bin, $_parent_dir);
}
use warnings;
use strict;
use MysqlX;
use Data::Dumper;

require 'srv.pl';
require 'common.pl';

our $g_app_path;

my $g_continue;

main();
sub main 
{
	$| = 1;
	$g_app_path = $FindBin::Bin;
	$g_continue = 1;
	
	my ($base_file) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
	my $cfg_file = "$base_file.cfg";
	die "cfg file: '$cfg_file' not exists!" unless -e $cfg_file;

	my $status_file = "$base_file.sta";
		
	while ($g_continue) {
		my $now = ts2str(time());
		print "now: $now ...\n";

		open LOST_DATA, ">> lost_data.txt";
		print LOST_DATA "\n+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n";
		close LOST_DATA;		
		
		my $cfg_ini = load_ini($cfg_file);
				
		foreach my $section(@{$cfg_ini}) {	
			#修改状态文件
			open(F_STATUS, ">$status_file") or die "can't write status output file: $status_file";
			print F_STATUS time();
			close F_STATUS;
			
			my $headname = $section->{'name'};
			my $srcdb = get_section_value($section, 'srcdb', '');
			my $dstdb = get_section_value($section, 'dstdb', '');		
			my %dstdb = str2arr($dstdb);
			my %srcdb = str2arr($srcdb);
				
			print "Start to check whether the [$headname] data is full!\n";
			my $startday = ts2str(time() - 86400, 1);
			check_data(\%srcdb, \%dstdb, $headname, $startday);		
			open LOST_DATA, ">> lost_data.txt";
			print LOST_DATA "\n---------------------------------------------------------------------------------------\n";
			close LOST_DATA;	
		}
		print "Done! \n";
		sleep(3600);													#数据完整性检查间隔时间----1小时
	}
}

############################################################################################################################################
sub check_data {
	my ($srcdbconn, $dstdbconn, $headname, $startday) = @_;		

	my $conn = MysqlX::genConn($srcdbconn);
	my $srcdb = new MysqlX($conn);
	
	my $conn2 = MysqlX::genConn($dstdbconn);
	my $tgdb = new MysqlX($conn2);

	my $sql;
	my $recordset;
	my $row;
	
	#从数据库查询该运营商需要分析日志的服务器
	$sql = "
		SELECT * FROM needrunserver WHERE theday = '$startday' ORDER BY serverid
	";
	my $run_servers = $srcdb->fetchAll($sql);
	
	#根据meta_onlinebyhour数据是否完整 分析数据是否完整
	$sql = "select mo.theday,mo.serverid,mo.sum_char from meta_onlinebyhour mo where mo.theday = '$startday'";
	$recordset = $tgdb->fetchAll($sql);
	my $tips = "[".ts2str(time())."] [$headname]"."Data uncompleted,< $startday >,";
	my $flag = 0;
	my %sid = ();
	if(@$run_servers && !@$recordset) {
		$flag++;
	} 
	foreach (@{$recordset}) {
		my $serverid = $_->{"serverid"};
		my $sum_char = $_->{"sum_char"};
		$sid{$serverid} = 1;
		
		my @sum_char = split(',',$sum_char);
		
		my $flag2 = 0;
		for(my $i=0;$i<24;$i++) {
			if(0 == $sum_char[$i]) {
				if(0 == $flag2) {
					$tips .= "\n sid:$serverid hour:$i ";
				} else {
					$tips .= ",$i ";
				}
				$flag++;
				$flag2++;
			}
		}
	}
	
	my $flag3 = 0;
	foreach (@{$run_servers}) {
		my $serverid = $_->{'serverid'};
		if(!exists($sid{$serverid})) {
			if(0 == $flag3++) {
				$tips .= "\n no data for server sid:$_->{serverid} ";
			} else {
				$tips .= ",sid:$_->{serverid} "
			}
		}
	}
	
	#根据sdb.account表中数据的最后同步时间 分析同步程序是否正常同步
	#如果超过一个小时没有更新,自动发送报警邮件
	$sql = "SELECT a.a_id,a.a_addtime FROM account a ORDER BY a.a_addtime DESC LIMIT 1";
	$recordset = $srcdb->fetchAll($sql);	
	if( time() - str2ts($recordset->[0]->{a_addtime}) > 3600) {
		$tips .= "sdb.account ,the last update time is $recordset->[0]->{a_addtime}";
		$flag++;
	}
	
	$tips .= ";";	
	
	open LOST_DATA, ">> lost_data.txt";
	if(0 < $flag || 0 < $flag3) {
		print LOST_DATA $tips."\n"; 
		my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
		if($hour >= 13 && $hour <= 22){	
			system("/usr/local/bin/sendEmail -s smtp.163.com -f hbzhangmao\@163.com -t hbzhangmao\@qq.com -u data_uncomplete -m '$tips' -xu hbzhangmao -xp zm15527078191 -o tls=auto");
			system("/usr/local/bin/sendEmail -s smtp.163.com -f hbzhangmao\@163.com -t hbzhangmao\@163.com -u data_uncomplete -m '$tips' -xu hbzhangmao -xp zm15527078191 -o tls=auto");
		}
	} else {
		print LOST_DATA "[".ts2str(time())."] [$headname]"."Congratulations,< $startday >,all data is ok! \n";
	}
	close LOST_DATA;	
}
