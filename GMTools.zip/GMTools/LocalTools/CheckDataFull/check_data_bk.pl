#!/usr/bin/perl
BEGIN {
	use FindBin;
	my ($_parent_dir) = $FindBin::Bin =~ /(.*\/).*/;
	push(@INC, $FindBin::Bin, $_parent_dir);
}
use warnings;
use strict;
use MysqlX;
use Data::Dumper;

require 'common.pl';

our $g_app_path;

$SIG{HUP} = sub {};
$SIG{__DIE__} = sub{
	my ($text) = @_;
    my @loc = caller(0);
   	chomp($text);

	my $text_ = $text ? $text : "";
	log2('error: '. $text_); 
	
	my $index = 1;
    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
	{
		log2( sprintf( " callby %s(%s) %s", $loc[1], $loc[2], "$loc[3]")); 
	};
    return 1;
};

main();
sub main 
{
	$| = 1;
	$g_app_path = $FindBin::Bin;

	my ($base_name) = ($0 =~ /(.*?)(\.[^\.]*)?$/);
	my $cfg_file = "$base_name.cfg";
	die "cfg file: '$cfg_file' not exists!" unless -e $cfg_file;		
	
	my ($startday,$endday) = @ARGV;
	$endday = $startday if defined($startday) && !defined($endday);
	die("Run as: $base_name.pl startday(yyyy-mm-dd) endday(yyyy-mm-dd)") if (!defined($startday) || !defined($endday));	

	my $cfg_ini = load_ini($cfg_file);

	foreach my $section(@{$cfg_ini}) {
		my $headname = $section->{'name'};
		my $srcdb      = get_section_value($section, 'srcdb', '');
		my $dstdb      = get_section_value($section, 'dstdb', '');		
		my %dstdb = str2arr($dstdb);
		my %srcdb = str2arr($srcdb);
			
		print "Start to check whether the [$headname] data is full!\n";
		for(my $i = str2ts($startday);$i <= str2ts($endday); $i += 86400) {
			my $check_day = ts2str($i,1);
			check_data(\%srcdb, \%dstdb, $headname, $check_day);
		}
		open LOST_DATA, ">> lost_data.txt";
		print LOST_DATA "\n---------------------------------------------------------------------------------------\n";
		close LOST_DATA;
	}

	print "Done!\n";
}

############################################################################################################################################
############################################################################################################################################
sub check_data {
	my ($srcdbconn, $dstdbconn, $headname, $startday) = @_;		

	my $conn = MysqlX::genConn($srcdbconn);
	my $srcdb = new MysqlX($conn);
	
	my $conn2 = MysqlX::genConn($dstdbconn);
	my $tgdb = new MysqlX($conn2);

	my $sql;
	my $recordset;
	my $row;
	
	#从数据库查询该运营商需要分析日志的服务器
	$sql = "
		SELECT * FROM needrunserver WHERE theday = '$startday' ORDER BY serverid
	";
	my $run_servers = $srcdb->fetchAll($sql);
	
	#根据meta_onlinebyhour数据是否完整 分析数据是否完整
	$sql = "select mo.theday,mo.serverid,mo.sum_char from meta_onlinebyhour mo where mo.theday = '$startday'";
	$recordset = $tgdb->fetchAll($sql);
	my $tips = "[".ts2str(time())."] [$headname]"."Data uncompleted,< $startday >,";
	my $flag = 0;
	my %sid = ();
	if(@$run_servers && !@$recordset) {
		$flag++;
	} 
	foreach (@{$recordset}) {
		my $serverid = $_->{"serverid"};
		my $sum_char = $_->{"sum_char"};
		$sid{$serverid} = 1;
		
		my @sum_char = split(',',$sum_char);
		
		my $flag2 = 0;
		for(my $i=0;$i<24;$i++) {
			if(0 == $sum_char[$i]) {
				if(0 == $flag2) {
					$tips .= "\n ++sid:$serverid hour:$i ";
				} else {
					$tips .= ",$i ";
				}
				$flag++;
				$flag2++;
			}
		}
	}
	my $flag3 = 0;
	foreach (@{$run_servers}) {
		my $serverid = $_->{'serverid'};
		if(!exists($sid{$serverid})) {
			if(0 == $flag3++) {
				$tips .= "\n no data for server sid:$_->{serverid} ";
			} else {
				$tips .= ",sid:$_->{serverid} "
			}
		}
	}
	$tips .= ";";	
	
	open LOST_DATA, ">> lost_data.txt";
	if(0 < $flag || 0 < $flag3) {
		print LOST_DATA $tips."\n"; 
		print $tips."\n";
	} else {
		print LOST_DATA "[".ts2str(time())."] [$headname]"."Congratulations,< $startday >,all data is ok! \n";
	}
	close LOST_DATA;	
}