#!/usr/bin/perl
use strict;
use warnings;
use FindBin;
use Encode; 

my $AppPath = $FindBin::Bin;

my $status_file = shift(@ARGV);
if (!defined($status_file) || length($status_file) <= 0) {
	die "perl -w auto_clean.pl path_of_status_file";
}

my $continue = 1;
my $WARN_LOCKCOUNT = 0;
BEGIN
{
    $WARN_LOCKCOUNT = 0;
    
	$SIG{TERM} = sub { $continue = 0 };
	
	sub __log
	{
        my ($file, $line, $text) = @_;
		
        my ($sec, $min, $hour, $day, $mon, $year) = localtime(time());
        $year += 1900;
        $mon += 1;

        my $time = sprintf("%04d-%02d-%02d %02d:%02d:%02d", $year, $mon, $day, $hour, $min, $sec);

		$WARN_LOCKCOUNT++;
        
		my $script_name = $0;
		$script_name =~ s/^.+[\\\/]([^\\\/]+)$/$1/;
        
        my $pathname = $AppPath . "/" . $script_name . ".log";
        if($pathname)
        {
            open LOGFILE, ">>$pathname";
            binmode(LOGFILE, ":encoding(utf8)");
			print LOGFILE "[$file($line)][$time] $text\n";
            close LOGFILE;
        }
        
		$WARN_LOCKCOUNT--;
        
        
	}

	$SIG{__WARN__} = sub
	{
		return if($WARN_LOCKCOUNT);
		
		my ($text) = @_;
	    my @loc = caller(0);
	   	chomp($text);

	    __log($loc[1], $loc[2], $text);
	    
		my $index = 1;
	    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
		{
			__log($loc[1], $loc[2], "$loc[3]");
		};

	    return 1;
	};

	$SIG{__DIE__} = sub
	{
		my ($text) = @_;
	    my @loc = caller(0);
	   	chomp($text);

	    __log($loc[1], $loc[2], $text);

		my $index = 1;
	    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
		{
			__log($loc[1], $loc[2], "$loc[3]");
		};

	    return 1;
	};
}

$SIG{TERM} = sub { $continue = 0 };
BEGIN
{
	use FindBin;

	for(@ARGV)
	{
		next unless /^\-srv$/i;
		
		my $pid = fork();
		if ($pid < 0)
		{
			die "fork: $!";
		}
		elsif ($pid)
		{
			exit 0;
		}
	
		chdir($FindBin::Bin);
	
		open(STDIN,  "</dev/null");
		open(STDOUT, ">/dev/null");
		open(STDERR, ">&STDOUT");
		last;
	}
}

$|=1;
while($continue)
{
	run();
	sleep(30);
}

sub run
{
	my $cfg_ini = load_ini($AppPath . "/auto_clean.cfg");

	my ($sqlserver, $username, $password, $time);
	$sqlserver = "";
	$username = "";
	$password = "";
	$time = 0;

	my $bDoSql = 0;
	my $tmNow = time;

	for (@{$cfg_ini})
	{
		my $section = $_;

		my $name = $section->{'name'};

		my $root = get_section_value($section, "root", "");
		my $ext = get_section_value($section, "ext", "");
		my $time = get_section_value($section, "time");

		process($name, $root, $ext, $time);
	}

	open(F_STATUS, ">$status_file") or die "can't write status output file: $status_file";
	print F_STATUS time();
	close F_STATUS;
}

sub process
{
	my ($name, $root, $ext, $time) = @_;

	my %exts;
	{
		my @tmp_exts = split(/,/, $ext);
		for(@tmp_exts)
		{
			my $e = $_;
			$e =~ s/^\s+//;
			$e =~ s/\s+$//;

			$exts{lc($e)} = 1;
		}
	}

	my $tmNow = time();
	print "now: ", format_time($tmNow),"\n";

	$root =~ s/[\\\/]\s*$//;

	my @dirs;
	push @dirs, $root;


	my @bak_files;
	while(@dirs>0)
	{
		my $dir = shift @dirs;

		my @items;
		opendir(DIR_SCAN, $dir) or next;
		@items = readdir(DIR_SCAN);
		closedir DIR_SCAN;

		for(@items)
		{
			my $item = $_;
			next if $item =~ /^\.\.?$/;

			my $full_path = $dir . "/" . $item;
			if (-d $full_path) {
				push @dirs, $full_path;
				next;
			}

			next unless -f $full_path;

			next unless $full_path =~ /\.([^\.]+)$/;
			my $file_ext = lc($1);
			$file_ext =~ s/^\s+//;
			$file_ext =~ s/\s+$//;

			next unless exists($exts{$file_ext});

			my ($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$atime,$mtime,$ctime,$blksize,$blocks) = stat($full_path);
			
			if ($tmNow-$mtime>$time) {
				print "$full_path	",format_time($mtime),"\n";

				push @bak_files, $full_path;
			}
		}
	}

	for(@bak_files)
	{
		unlink($_);
	}
}

sub calc_md5
{
	my ($file) = @_;
	
	my $ctx = Digest::MD5->new;
	open(FILE_MD5, $file) or die "can't open file for calc md5: $file";
	$ctx->addfile(*FILE_MD5);

	my $md5 = $ctx->hexdigest;
	close(FILE_MD5);

	return $md5;
}

sub readin
{
    my ($file) = @_;
    
    my $len = -s $file;
    return "" unless $len>0;

    my $f;
    open $f, $file;
    binmode $f;
    my $cont = "";
    sysread($f, $cont, $len);
    close $f;
    
    return $cont;
}


sub load_ini_from_buffer
{
    my ($buffer) = @_;
    
    my @lines = split(/\r?\n/, $buffer);
    
	my @ret;
	my $section_name = "";
	my $kvs;
	my $text = "";

	for(@lines)
	{
		my $line = $_;
		my $raw_line = $_;
		next if $line=~ /^\s*$/ or $line =~ /^\s*\#/;

		$line =~ s/^\s+//;
		$line =~ s/\s+$//;
		$raw_line =~ s/\r?\n//g;

		if ($line =~ /^\[([^\]]+)\]$/) {
			my $tmp_name = $1;
			$tmp_name =~ s/^\s+//;
			$tmp_name =~ s/\s+$//;

			if (length($section_name) > 0) {
				my %ini_info;
				$ini_info{'name'} = $section_name;
				$ini_info{'text'} = $text;
				$ini_info{'kvs'} = $kvs;

				push @ret, \%ini_info;
			}

			my @arKvs;
			$kvs = \@arKvs;
			$section_name = $tmp_name;
			$text = "";
		}
		elsif ($line =~ /^([^=]+)=(.*)$/){
			my $key = $1;
			my $value = $2;

			$key =~ s/^\s+//;
			$key =~ s/\s+$//;

			$value =~ s/^\s+//;
			$value =~ s/\s+$//;

			if (length($section_name) > 0) {
				my %kv;
				$kv{'key'} = $key;
				$kv{'value'} = $value;

				push @{$kvs}, \%kv;
			}
			$text .= $raw_line."\n";
		}
		else{
			$text .= $raw_line."\n";
		}
	}

	if (length($section_name) > 0) {
		my %ini_info;
		$ini_info{'name'} = $section_name;
		$ini_info{'text'} = $text;
		$ini_info{'kvs'} = $kvs;


		push @ret, \%ini_info;
	}

	return \@ret;
}


sub load_ini
{
	my ($file) = @_;
    
    return load_ini_from_buffer(readin($file));
}

sub get_section_value
{
	my ($section, $key, $default_value) = @_;

	for (@{$section->{'kvs'}}) {
		my $kv = $_;
		
		if (lc($kv->{'key'}) eq lc($key)) {
			if (length($kv->{'value'})>0) {
				return $kv->{'value'};
			}
		
			return defined($default_value)?$default_value:"";
		}
	}

	return defined($default_value)?$default_value:"";
}

sub format_time
{
	my ($time) = @_;

	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);
	$mon++;
	$year += 1900;

	return "$year-$mon-$mday $hour:$min:$sec";
}
