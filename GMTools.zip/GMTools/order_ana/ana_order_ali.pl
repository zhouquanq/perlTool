#!/usr/bin/perl
use strict;
use warnings;
use PerlIO::encoding;
use Data::Dumper;
use File::Path;
use Time::Local;
use FindBin;

use MysqlX;
require 'common.pl';

$::APPLICATION_PATH = scalar( $FindBin::Bin);

my $orderfile = $::APPLICATION_PATH.'/20889015378218310156_2013_09_1.csv';

my $hash_order = {};
my $hash_order_db = {};

open FH, "< $orderfile";

while (<FH>) {
	next unless $_ =~ /游戏充值/;
	unless($_ =~ /(\d+_\d+_\d+_\d+).*?,.*?,.*?,.*?,((\d+)|(\d+\.\d+)),\s*?((-?\d+)|(-\d+\.\d+))\s*?,/) {
		print $_."\n";
		next ;
	}
	if($2 > 0 && $5 == 0) {
		$hash_order->{$1}->{"income"} = $2;
	} elsif ($2 == 0 && $5 < 0) {
		$hash_order->{$1}->{"expense"} = $5;
	} else {
		die($1."\n",$2."\n",$5."\n",$_);
	}
}
close FH;

#print Dumper($hash_order);
my $ali_order_sum = 0;
foreach my $record (keys %$hash_order) {
	$ali_order_sum += $hash_order->{$record}->{"income"};
}
print "ali_order_num:".scalar(keys %$hash_order)."\n";
print "ali_order_sum:".$ali_order_sum."\n\n";


#wm
my $dbconfig_wm = "host,183.233.224.194, port,13306, user,sdb, name,sdb_lywm,  pass,qJe9esl6mE7E9N";
my %srcdb_wm = str2arr($dbconfig_wm);
my $conn_wm = MysqlX::genConn(\%srcdb_wm);
my $srcdb_wm = new MysqlX($conn_wm);
my $sql_wm = "
	select p.pr_orderid,p.pr_money 
	from payrecord p
	where left(p.pr_addtime,7) = '2013-09' and p.pr_maintype = 'alipay' and p.pr_success = 1 and p.pr_channel in ('longyin','molon')
	order by p.pr_addtime asc
";
my $recordset_wm = $srcdb_wm->fetchAll($sql_wm);

#ly
my $dbconfig_ly = "host,183.233.224.194, port,13306, user,sdb, name,sdb_lyly,  pass,qJe9esl6mE7E9N";
my %srcdb_ly = str2arr($dbconfig_ly);
my $conn_ly = MysqlX::genConn(\%srcdb_ly);
my $srcdb_ly = new MysqlX($conn_ly);
my $sql_ly = "
	select p.pr_orderid,p.pr_money,p.pr_addtime
	from payrecord p
	where left(p.pr_addtime,7) = '2013-09' and p.pr_maintype = 'alipay' and p.pr_success = 1 and p.pr_channel = 'leyi'
	order by p.pr_addtime asc
";
my $recordset_ly = $srcdb_ly->fetchAll($sql_ly);

#综合订单
foreach my $record (@$recordset_wm) {
	$hash_order_db->{$record->{pr_orderid}}->{money} = $record->{pr_money};
	$hash_order_db->{$record->{pr_orderid}}->{t} = $record->{pr_addtime};
}
foreach my $record (@$recordset_ly) {
	$hash_order_db->{$record->{pr_orderid}}->{money} = $record->{pr_money};
	$hash_order_db->{$record->{pr_orderid}}->{t} = $record->{pr_addtime};
}

#print Dumper($hash_order_db);
my $feiyu_order_sum = 0;
foreach my $record (keys %$hash_order_db) {
	$feiyu_order_sum += $hash_order_db->{$record}->{money};
}
print "feiyu_order_num:".scalar(keys %$hash_order_db)."\n";
print "feiyu_order_sum:".$feiyu_order_sum."\n";


#print Dumper(keys %$hash_order_db);
print "\n\n  orders in ali but not in feiyu:\n";
print "[\n";
my $count = 0;
my $msum = 0;
my $msum_out = 0;
foreach my $od (keys %$hash_order) {
	if(exists($hash_order_db->{$od})) {
		next;
	} else {
		print "od:$od\n";
		print Dumper($hash_order_db->{$od});
	}
	$count ++;
	$msum += $hash_order->{$od}->{"income"};
	$msum_out += $hash_order->{$od}->{"expense"};
	print $od."\t\t".$hash_order->{$od}->{"income"}."\n";
}
print "\ncount:$count\n";
print "\nmsum:$msum\n";
print "\nmsum_out:$msum_out\n";
print "]\n";

print "\n\n  orders in feiyu but not in ali:\n";
print "[\n";
$count = 0;
$msum = 0;
foreach my $od (keys %$hash_order_db) {
	next if exists($hash_order->{$od});
	$count ++;
	$msum += $hash_order_db->{$od}->{money};
	print $od."\t\t".$hash_order_db->{$od}->{t}."\t\t".$hash_order_db->{$od}->{money}."\n";
}
print "\ncount:$count\n";
print "\nmsum:$msum\n";
print "]\n";


sub str2ts
{
	my $str = shift(@_);
	
	if ($str !~ /\d{4}-\d+-\d+(\s+\d+:\d+:\d+)?/) {
		die ("Illegal datetime str($str).\n");
	}

	$str =~ s/(\d+)-(\d+)-(\d+)//;
	my ($year, $month, $day) = ($1, $2, $3);

	my ($hour, $minute, $second);
	if ($str =~ /(\d+):(\d+):(\d+)/) {
		($hour, $minute, $second) = split(':', $str);
	} else {
		($hour, $minute, $second) = (0, 0, 0);
	}
	
	my $timestamp = timelocal($second, $minute, $hour, $day, $month - 1, $year);

	return $timestamp;
}

sub ts2str
{
	my ($ts, $only_date) = @_;

	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($ts);
	$mon++;
	$year += 1900;
	
	$mon = '0'.$mon if $mon < 10;
	$mday = '0'.$mday if $mday < 10;
	$hour = '0'.$hour if $hour < 10;
	$min = '0'.$min if $min < 10;
	$sec = '0'.$sec if $sec < 10;
	
	if (defined($only_date) && 1 == $only_date) {
		return "$year-$mon-$mday";
	} else {
		return "$year-$mon-$mday $hour:$min:$sec";
	}
}