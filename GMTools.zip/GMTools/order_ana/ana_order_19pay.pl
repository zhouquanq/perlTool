#!/usr/bin/perl
use strict;
use warnings;
use PerlIO::encoding;
use Data::Dumper;
use File::Path;
use Time::Local;
use FindBin;

use MysqlX;
require 'common.pl';

$::APPLICATION_PATH = scalar( $FindBin::Bin);

my $orderfile = $::APPLICATION_PATH.'/201301_yeshuxi@z-le.com/19pay.txt';

my $hash_order = {};
my $hash_order_db = {};

open FH, "< $orderfile";

while (<FH>) {
	next unless $_ =~ /(\d+_\d+_\d+_\d+)/;
	$hash_order->{$1} = 1;
}
close FH;

#print Dumper($hash_order);

print "yeepay_order_num:".scalar(keys %$hash_order)."\n";

#my $dbconfig_wm = "host,124.232.163.93, port,3306, user,sdb, name,sdb_lywm,  pass,qJe9esl6mE7E9N";
my $dbconfig_ly = "host,124.232.163.98, port,3306, user,sdb, name,sdb_lyly,  pass,qJe9esl6mE7E9N";
my %srcdb = str2arr($dbconfig_ly);


my $conn = MysqlX::genConn(\%srcdb);
my $srcdb = new MysqlX($conn);
my $sql = "
	select p.pr_orderid, p.pr_money
	from payrecord p
	where p.pr_addtime between '2013-01-01 00:00:00' and '2013-02-01 00:00:00' and p.pr_maintype = '19pay-card' and p.pr_success = 1 and p.pr_ismerged = 0
	order by p.pr_addtime asc
";
my $recordset = $srcdb->fetchAll($sql);
my $money_sum =  0;
foreach my $record (@$recordset) {
	$hash_order_db->{$record->{pr_orderid}} = 1;
	$money_sum += $record->{pr_money};
}

#print Dumper($hash_order_db);
print "feiyu_order_num:".scalar(keys %$hash_order_db)."\n";
print "money_sum:".$money_sum."\n";


print "\n\n  orders in 19pay but not in feiyu:\n";
foreach my $od (keys %$hash_order) {
	next if exists($hash_order_db->{$od});
	print $od."\n";
}

print "\n\n  orders in feiyu but not in 19pay:\n";
foreach my $od (keys %$hash_order_db) {
	next if exists($hash_order->{$od});
	print $od."\n";
}


sub str2ts
{
	my $str = shift(@_);
	
	if ($str !~ /\d{4}-\d+-\d+(\s+\d+:\d+:\d+)?/) {
		die ("Illegal datetime str($str).\n");
	}

	$str =~ s/(\d+)-(\d+)-(\d+)//;
	my ($year, $month, $day) = ($1, $2, $3);

	my ($hour, $minute, $second);
	if ($str =~ /(\d+):(\d+):(\d+)/) {
		($hour, $minute, $second) = split(':', $str);
	} else {
		($hour, $minute, $second) = (0, 0, 0);
	}
	
	my $timestamp = timelocal($second, $minute, $hour, $day, $month - 1, $year);

	return $timestamp;
}

sub ts2str
{
	my ($ts, $only_date) = @_;

	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($ts);
	$mon++;
	$year += 1900;
	
	$mon = '0'.$mon if $mon < 10;
	$mday = '0'.$mday if $mday < 10;
	$hour = '0'.$hour if $hour < 10;
	$min = '0'.$min if $min < 10;
	$sec = '0'.$sec if $sec < 10;
	
	if (defined($only_date) && 1 == $only_date) {
		return "$year-$mon-$mday";
	} else {
		return "$year-$mon-$mday $hour:$min:$sec";
	}
}