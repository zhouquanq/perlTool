<?php

require_once 'Moby/Http.php';

class Moby_Http_Custom extends Moby_Http {
	
	private static $_instance = null;
	
	public static function getInstance()
    {
        if (null === self::$_instance) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    
    /**
	 * 将模块,控制器,动作,url参数 编码成url,并未URL Encode
	 * @param string $mobule 模块名称
	 * @param string $control 控制器名称
	 * @param stirng $action 动作名称
	 * @param array $params 参数(参数名=>参数值)
	 * 
	 * @return string 编码后的url
	 */
	public function encode( $action, $controlle=null, $model=null, array $params=null) {
		$result = array();
		$result[] = $this->filterControlName( 'model', $model);
		$result[] = $this->filterControlName( 'controller', $controlle);
		$result[] = $this->filterControlName( 'action', $action);
		
		if( !empty( $params)) {
			foreach( $params as $key=>$value) {
				if( !is_string( $key) && !is_numeric( $key)) {
					throw new Exception( 'illegal url param name '.var_export( $key, true));
				}
				
				if( is_numeric( $value)) {
					$result[] = $key;
					$result[] = urlencode( $value);
				} 
				else if( is_string( $value)) {
					$result[] = $key;
					$result[] = urlencode( $value);
				} 
				else if( strlen( $key) > 2 && '[]' == substr( $key, -2) && is_array( $value)) {
					$result[] = $key;
					foreach( $value as $itemkey=>$itemvalue) {
						$value[$itemkey] = urlencode( $itemvalue);
					}
					$result[] = implode( ',', $value);
				} 
				else if( strlen( $key) > 2 && '{}' == substr( $key, -2) && is_array( $value)) {
					$key_ = substr( $key, 0, strlen( $key) - 2);
					foreach( $value as $itemkey=>$itemvalue) {
						$result[] = sprintf( "%s[%s]", $key_, $itemkey);
						$result[] = urlencode( $itemvalue);
					}
				} 
				else if( is_object( $value)) {
					$vars = get_object_vars( $value);
					foreach( $vars as $attrname=>$attrvalue) {
						$result[] = sprintf( "%s.%s", $key, $attrname);
						$result[] = urlencode( $attrvalue);
					}
				} 
				else {
					//throw new Exception( 'illegal url param value '.$key.':'.var_export( $value, true));
				}
			}
		}
		$phpself = $_SERVER["PHP_SELF"];
		return $phpself.'?'.implode( parent::URL_SEPARATE, $result);
	}
	
	/**
	 * 将请求url解码成参数数组,合并到$_GET[]中，已经URL Decode
	 * @param string $url 需要解码的url
	 * 
	 * @return array 解码后得到的(模块,控制器,动作,参数列表)
	 */
	public function decode( $url=null) {
		if( empty( $url)) {
			return array();
		}
		
		/*IMPORTANT :改动2011-09-02， 让合并到$_GET[]中的URL自动URL Decode */ 
        //$url = key($_GET);

		if( false !== strpos( $url, '?')) {
			$url = substr( $url, strpos( $url, '?')+1);
		} else {
			$url = '';
		}

		
		$result = array();
		
		$modelName = 'index';
		$controllerName = 'index';
		$actionName = 'index';
		
		if( 0 === strpos( $url, '/')) {
		 	$url = substr( $url, 1);
		}
		if( false !== strpos( $url, '/')) {
			 
			$params = explode( '/', $url);
			
			$modelName = array_shift( $params);
			$modelName = empty( $modelName) ? 'index' : $modelName;
			$controllerName = array_shift( $params);
			$controllerName = empty( $controllerName) ? 'index' : $controllerName;
			$actionName = empty( $params) ? 'index' : array_shift( $params);
			$actionName = empty( $actionName) ? 'index' : $actionName;
			//键key/值value循环解析
			//$key = false;
			while( count( $params)) {
				$key = array_shift( $params);
				$value = array_shift( $params);
				
				if( false != strpos( $key, '.')) {
					$pos = strrpos( $key, '.');
					$firstkey = substr( $key, 0, $pos);
					$attrname = substr( $key, $pos+1, strlen( $key) - $pos);
					$result[$firstkey] = isset( $result[$firstkey]) && is_object( $result[$firstkey]) ? $result[$firstkey] : new stdClass();
					$result[$firstkey]->$attrname = urldecode( $value);
				} 
				else if( strlen( $key) > 2 && '[]' == substr( $key, -2)) {
					$realkey = substr( $key, 0, strlen( $key) - 2);
					$aTmpValue = explode( ',', $value);
					foreach( $aTmpValue as $k=>$v) {
						$aTmpValue[ $k ] = urldecode( $v );
					}
					$result[$realkey] = $aTmpValue;
				}
				else if( preg_match( "/^(\w+)\[(\w+)]$/", $key, $matchs)) {
					$firstkey = $matchs[1];
					$attrname = $matchs[2];
					$result[$firstkey] = isset( $result[$firstkey]) && is_array( $result[$firstkey]) ? $result[$firstkey] : array();
					$result[$firstkey][$attrname] = urldecode( $value);
				}
				else {
					if( false !== strpos( $value, ',')) {
						$aTmpValue = explode( ',', $value);
						foreach( $aTmpValue as $k=>$v) {
							$aTmpValue[ $k ] = urldecode( $v );
						}
						$value = $aTmpValue;
					} else {
						/*IMPORTANT :改动2011-09-05， 让合并到$_GET[]中的URL自动URL Decode */ 
						$value = urldecode($value);
					}
					$result[$key] = $value;
				}
			}
			/*foreach( $params as $value) {
				
				if( empty( $key)) {
					$key = $value;
				} else {
					if( false !== strpos( $value, ',')) {
						$aTmpValue = explode( ',', $value);
						foreach( $aTmpValue as $k=>$v) {
							$aTmpValue[ $k ] = urldecode( $v );
						}
						/*IMPORTANT :改动2011-09-05， 让合并到$_GET[]中的URL自动URL Decode 
						$result[$key] = $aTmpValue;
					} else if( false !== strpos( $value, ',')) {
						
					} else {
						/*IMPORTANT :改动2011-09-05， 让合并到$_GET[]中的URL自动URL Decode *
						$result[$key] = urldecode($value);
					}
					$key = false;
				}
			}
			if ( !empty( $key)){
				$result[$key] = 0;
			}*/
		} else if( !empty( $url)) {
			$modelName = $this->filterControlName( 'model', $url);
		}
		$this->setModel( $modelName);
		$this->setController( $controllerName);
		$this->setAction( $actionName);
		
		return $result;
	}
}