<?php
require 'Zend/Loader/Autoloader/Interface.php';
class Moby_Autoloader implements Zend_Loader_Autoloader_Interface {
	
	protected $_namespace = '';
	protected $_dirs;
	public function __construct( $namespace, $dirs) {
		$this->_namespace = $namespace;
		$this->_dirs = $dirs;
	}
	
	public function autoload( $class) {
		
		if( 0 !== strpos( $class, $this->_namespace)) {
			throw new Exception( 'not match the class name and namespace');
		}
		$className = ltrim($class, '\\');
		$className = str_replace( $this->_namespace, '', $className);
		$file = str_replace( '_', DIRECTORY_SEPARATOR, $className) . '.php';
		return Zend_Loader::loadFile( $file, $this->_dirs);	
	}
}