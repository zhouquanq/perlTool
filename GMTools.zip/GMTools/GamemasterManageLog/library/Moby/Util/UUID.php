<?php
class Moby_Util_UUID {
	
	/**
	  * Generates an UUID
	  *
	  * @author     Anis uddin Ahmad
	  * @param      string  an optional prefix
	  * @return     string  the formatted uuid
	  */
	public static function gen( $prefix = '') {
	    $chars = md5(uniqid(rand()));
	    $uuid  = substr($chars,0,8) . '-';
	    $uuid .= substr($chars,8,4) . '-';
	    $uuid .= substr($chars,12,4) . '-';
	    $uuid .= substr($chars,16,4) . '-';
	    $uuid .= substr($chars,20,12);
	
	    return $prefix . $uuid;
	}
}