<?php

abstract class Moby_Http {
	
	
	
	/**
     * Scheme for http
     *
     */
    const SCHEME_HTTP  = 'http';

    /**
     * Scheme for https
     *
     */
    const SCHEME_HTTPS = 'https';

    /**
	 * url分隔符
	 * @var string
	 */
	const URL_SEPARATE = '/'; 
    
    protected $_requestUri = '';
    
    /**
     * Allowed parameter sources
     * @var array
     */
    protected $_paramSources = array('_GET', '_POST');
	
	protected $model = '';
	protected $controller = '';
	protected $action = '';
	
	protected $controllerName = array( 'model', 'controller', 'action');
		
	private static $_instance = null;
	
	protected $_params = array();
	
	public static function getInstance()
    {
        if (null === self::$_instance) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    /**
	 * 构造函数
	 * @param string $currUrl;
	 */
    public function __construct( $currUrl='') {
    	$this->init();
    	
    	if( empty( $currUrl)) {
    		
			$currUrl = $this->getRequestUri();
		}
		//从请求地址解码参数，已经URL Decode
		$this->_params = $this->decode( $currUrl);
    }
    
    /**
     * 获取并设置requestUri
     */
    public function init() {
    	$requestUri = '';
    	if (isset($_SERVER['HTTP_X_REWRITE_URL'])) { // check this first so IIS will catch
        	$requestUri = $_SERVER['HTTP_X_REWRITE_URL'];
        } elseif (
                // IIS7 with URL Rewrite: make sure we get the unencoded url (double slash problem)
                isset($_SERVER['IIS_WasUrlRewritten'])
                && $_SERVER['IIS_WasUrlRewritten'] == '1'
                && isset($_SERVER['UNENCODED_URL'])
                && $_SERVER['UNENCODED_URL'] != ''
                ) {
                $requestUri = $_SERVER['UNENCODED_URL'];
		} elseif (isset($_SERVER['REQUEST_URI'])) {
			$requestUri = $_SERVER['REQUEST_URI'];
            // Http proxy reqs setup request uri with scheme and host [and port] + the url path, only use url path
            $schemeAndHttpHost = $this->getScheme() . '://' . $this->getHttpHost();
            if (strpos($requestUri, $schemeAndHttpHost) === 0) {
                $requestUri = substr($requestUri, strlen($schemeAndHttpHost));
            }
        } elseif (isset($_SERVER['ORIG_PATH_INFO'])) { // IIS 5.0, PHP as CGI
            $requestUri = $_SERVER['ORIG_PATH_INFO'];
            if (!empty($_SERVER['QUERY_STRING'])) {
                $requestUri .= '?' . $_SERVER['QUERY_STRING'];
            }
        }
        $this->_requestUri = $requestUri;
        return $this;
    }
    
	/**
	 * 过滤控制器名称(模块名,控制器名,动作名)
	 * @param string $type array( 'model', 'controller', 'action');
	 * @param string $name
	 * @throws Exception
	 * @return string controller;
	 */
	public function filterControlName( $type, $name=null) {
		if( !in_array( $type, $this->controllerName)) {
			throw new Exception( 'illegal controller type '.$type);
		}
		
		$result = 'index';
		if( !empty( $name)) {
			if( !preg_match( '/[\w]+/', $name)) {
				throw new Exception( 'illegal controller name '.$name);
			}
			$result = $name;
		} else {
			$result = $this->$type;
		}
		return $result;
	}
    
    /**
	 * 将模块,控制器,动作,url参数编码成url
	 * @param string $mobule 模块名称
	 * @param string $control 控制器名称
	 * @param stirng $action 动作名称
	 * @param array $params 参数(参数名=>参数值)
	 * 
	 * @return string 编码后的url
	 */
	abstract public function encode( $action, $controlle=null, $model=null, array $params=null);
	
	/**
	 * 将url解码成参数数组
	 * @param string $url 需要解码的url
	 * 
	 * @return array 解码后得到的(模块,控制器,动作,参数列表)
	 */
	abstract public function decode( $url=null);
    
	public function setModel( $modelName) {
		$this->model = $modelName;
	}
	
	public function getModel() {
		return $this->model;
	}
	
	public function setController( $controllerName) {
		$this->controller = $controllerName;
	}
	
	public function getController() {
		return $this->controller;
	}
	
	public function setAction( $actionName) {
		$this->action = $actionName;
	}
	
	public function getAction() {
		return $this->action;
	}
	
	/**
     * Get the request URI scheme
     *
     * @return string
     */
    public function getScheme()
    {
        return ($this->getServer('HTTPS') == 'on') ? self::SCHEME_HTTPS : self::SCHEME_HTTP;
    }
	
    /**
     * Get the HTTP host.
     *
     * "Host" ":" host [ ":" port ] ; Section 3.2.2
     * Note the HTTP Host header is not the same as the URI host.
     * It includes the port while the URI host doesn't.
     *
     * @return string
     */
	public function getHttpHost()
    {
        $host = $this->getServer('HTTP_HOST');
        if (!empty($host)) {
            return $host;
        }

        $scheme = $this->getScheme();
        $name   = $this->getServer('SERVER_NAME');
        $port   = $this->getServer('SERVER_PORT');

        if (($scheme == self::SCHEME_HTTP && $port == 80) || ($scheme == self::SCHEME_HTTPS && $port == 443)) {
            return $name;
        } else {
            return $name . ':' . $port;
        }
    }

    /**
     * Get the client's IP addres
     *
     * @param  boolean $checkProxy
     * @return string
     */
    public function getClientIp( $checkProxy = true)
    {
        if ($checkProxy && $this->getServer('HTTP_CLIENT_IP') != null) {
            $ip = $this->getServer('HTTP_CLIENT_IP');
        } else if ($checkProxy && $this->getServer('HTTP_X_FORWARDED_FOR') != null) {
            $ip = $this->getServer('HTTP_X_FORWARDED_FOR');
        } else {
            $ip = $this->getServer('REMOTE_ADDR');
        }

        return $ip;
    }
    
	/**
     * Retrieve a member of the $_SERVER superglobal
     *
     * If no $key is passed, returns the entire $_SERVER array.
     *
     * @param string $key
     * @param mixed $default Default value to use if key not found
     * @return mixed Returns null if key does not exist
     */
    public function getServer($key = null, $default = null)
    {
        if (null === $key) {
            return $_SERVER;
        }

        return (isset($_SERVER[$key])) ? $_SERVER[$key] : $default;
    }
    
	/**
     * Retrieve a member of the $_POST superglobal
     *
     * If no $key is passed, returns the entire $_POST array.
     *
     * @param string $key
     * @param mixed $default Default value to use if key not found
     * @return mixed Returns null if key does not exist
     */
    public function getPost($key = null, $default = null)
    {
        if (null === $key) {
            return $_POST;
        }

        return (isset($_POST[$key])) ? $_POST[$key] : $default;
    }
    
	/**
     * Retrieve a member of the $_COOKIE superglobal
     *
     * If no $key is passed, returns the entire $_COOKIE array.
     *
     * @param string $key
     * @param mixed $default Default value to use if key not found
     * @return mixed Returns null if key does not exist
     */
    public function getCookie($key = null, $default = null)
    {
        if (null === $key) {
            return $_COOKIE;
        }

        return (isset($_COOKIE[$key])) ? $_COOKIE[$key] : $default;
    }
    
	/**
     * Returns the REQUEST_URI taking into account
     * platform differences between Apache and IIS
     *
     * @return string
     */
    public function getRequestUri()
    {
        if (empty($this->_requestUri)) {
            $this->setRequestUri();
        }

        return $this->_requestUri;
    }
    
	/**
     * Retrieve a parameter
     *
     * Retrieves a parameter from the instance. Priority is in the order of
     * userland parameters (see {@link setParam()}), $_GET, $_POST. If a
     * parameter matching the $key is not found, null is returned.
     *
     * If the $key is an alias, the actual key aliased will be used.
     *
     * @param mixed $key
     * @param mixed $default Default value to use if key not found
     * @return mixed
     */
    public function getParam($key, $default = null)
    {
        //$keyName = (null !== ($alias = $this->getAlias($key))) ? $alias : $key;
		$keyName = $key;
		
        //获取参数来源array('_GET', '_POST'..)
		$paramSources = $this->getParamSources();
		
		//自定义参数
        if (isset($this->_params[$keyName])) {
        	
            return $this->_params[$keyName];
            
        //全局$_GET已经被解析加入module/controller/action之后的各个参数键名和值
        } elseif (in_array('_GET', $paramSources) && (isset($_GET[$keyName]))) {
            return $_GET[$keyName];
            
        //全局$_GET  
        } elseif (in_array('_POST', $paramSources) && (isset($_POST[$keyName]))) {
            return $_POST[$keyName];
        }

        return $default;
    }
    
    public function setParam( $key, $value) {
    	$this->_params[$key] = $value;
    }
    
	/**
     * Retrieve an array of parameters
     *
     * Retrieves a merged array of parameters, with precedence of userland
     * params (see {@link setParam()}), $_GET, $_POST (i.e., values in the
     * userland params will take precedence over all others).
     *
     * @return array
     */
    public function getParams()
    {
        $return       = $this->_params;
        $paramSources = $this->getParamSources();
        if (in_array('_GET', $paramSources)
            && isset($_GET)
            && is_array($_GET)
        ) {
            $return += $_GET;
        }
        if (in_array('_POST', $paramSources)
            && isset($_POST)
            && is_array($_POST)
        ) {
            $return += $_POST;
        }
        return $return;
    }
    
	/**
     * Return the method by which the request was made
     *
     * @return string
     */
    public function getMethod()
    {
        return $this->getServer('REQUEST_METHOD');
    }
    
	/**
     * Was the request made by POST?
     *
     * @return boolean
     */
    public function isPost()
    {
        if ('POST' == $this->getMethod()) {
            return true;
        }

        return false;
    }

    /**
     * Was the request made by GET?
     *
     * @return boolean
     */
    public function isGet()
    {
        if ('GET' == $this->getMethod()) {
            return true;
        }

        return false;
    }
    
	/**
     * Return the value of the given HTTP header. Pass the header name as the
     * plain, HTTP-specified header name. Ex.: Ask for 'Accept' to get the
     * Accept header, 'Accept-Encoding' to get the Accept-Encoding header.
     *
     * @param string $header HTTP header name
     * @return string|false HTTP header value, or false if not found
     * @throws Exception
     */
    public function getHeader($header)
    {
        if (empty($header)) {
            require_once 'Zend/Controller/Request/Exception.php';
            throw new Exception('An HTTP header name is required');
        }

        // Try to get it from the $_SERVER array first
        $temp = 'HTTP_' . strtoupper(str_replace('-', '_', $header));
        if (!empty($_SERVER[$temp])) {
            return $_SERVER[$temp];
        }

        // This seems to be the only way to get the Authorization header on
        // Apache
        if (function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            if (!empty($headers[$header])) {
                return $headers[$header];
            }
        }

        return false;
    }
    
	/**
     * Get list of allowed parameter sources
     *
     * @return array
     */
    public function getParamSources()
    {
        return $this->_paramSources;
    }
    
    /**
     * 设置响应头信息
     * @param string $key 头信息键
     * @param string $value 头信息值
     */
    public function setRespHeader( $key, $value) {
    	header( "$key: $value");
    }
    
}