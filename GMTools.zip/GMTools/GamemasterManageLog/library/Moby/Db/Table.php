<?php

/**
 * 所有数据库表的基类
 */
class Moby_Db_Table {
	
	const LOG_SQLSTATEMENT = true;
	
	public $conn = null;
	private $sql = null;
	
	/**
	 * 表名
	 * @var string
	 */
	protected $table = null;
	
	/**
	 * 主键名
	 * @var string
	 */
	protected $primarykey = null;
	
	/**
	 * 构造函数
	 */
	public function __construct( $conn=null) {
		if( !empty( $conn)) {
			$this->setConn($conn);
		}
	}
	
	/**
	 * 设置连接
	 */
	public function setConn( $conn) {
		$this->conn = $conn;
		$this->_execute( 'set names utf8');
	}
	
	/**
	 * 生成pdo对象
	 */
	public static function genConn( $cfg) {
		if( empty( $cfg['host']) || empty( $cfg['port']) || empty( $cfg['dbname']) || empty( $cfg['user']) || empty( $cfg['port'])) {
			throw new Exception( 'illegal db config '.var_export( $cfg, true));
		}
		$dsn = "mysql:host={$cfg['host']};port={$cfg['port']};dbname={$cfg['dbname']}";
		
		return new PDO( $dsn, $cfg['user'], $cfg['pass']);
	}
	
	/**
	 * 根据主键查询记录
	 * 
	 * @param int|string $id
	 */
	public function findById( $id) {
		return $this->fetchRowByCond( array( $this->primarykey.'=?'=>$id));
	}
	
	/**
	 * 根据条件查询结集，获取首行
	 * 
	 * @param unknown_type $id
	 */
	public function fetchRowByCond( array $where=null, $fetch_style = PDO::FETCH_BOTH) {
		$sWhere = $this->getStrWhere( $where);
		if( $sWhere) {
			$sWhere = ' where '.$sWhere;
		}
		
		$sql = "select * from `{$this->table}` {$sWhere} limit 1";
		
		return $this->fetchRow( $sql, $fetch_style);
	}
	
	/**
	 * 根据提供条件查询结果集，使用默认表
	 * @param array $where 条件数组
	 */
	public function fetchAllByCond( array $where=null, $fetch_style = PDO::FETCH_BOTH, array $orderby=null, $limit=null) {
		$sWhere = $this->getStrWhere( $where);
		if( $sWhere) {
			$sWhere = ' where '.$sWhere;
		}
		
		$_orderby = $this->getStrOrderby( $orderby);
		$_limit = "";
		if( $limit) {
			$_limit = " limit {$limit}";
		}
		$sql = "select * from `{$this->table}` {$sWhere} {$_orderby} {$_limit}";
		
		return $this->fetchAll( $sql, $fetch_style);
	}
	
	/**
	 * 根据提供条件查询结果集，使用默认表
	 * @param array $where 条件数组
	 */
	public function fetchAllByJoin( $field='*', array $join=null, array $where=null, $fetch_style = PDO::FETCH_BOTH, array $orderby=null, $limit=null) {
		$sJoin = $this->getStrJoin($join);
		
		$sWhere = $this->getStrWhere( $where);
		if( $sWhere) {
			$sWhere = ' where '.$sWhere;
		}
		
		$_orderby = $this->getStrOrderby( $orderby);
		$_limit = "";
		if( $limit) {
			$_limit = " limit {$limit}";
		}
		$sql = "select $field from `{$this->table}` $sJoin {$sWhere} {$_orderby} {$_limit}";
		
		return $this->fetchAll( $sql, $fetch_style);
	}
	
	/**
	 * 根据条件查询结果集，只取指定列，使用默认表
	 * @param string $colname
	 * @param where $where
	 */
	public function fetchColByCond( $colname, array $where=null) {
		if ( empty( $colname)) {
			throw new Exception();
		}
		$sWhere = $this->getStrWhere( $where);
		if( $sWhere) {
			$sWhere = ' where '.$sWhere;
		}
		
		$sql = "select {$colname} from `{$this->table}` {$sWhere}";
		$stm = $this->_query( $sql);
		
		$result = array();
		while( $col = $stm->fetchColumn()) {
			$result[] = $col;
		}
		return $result;
	}
	
	/**
	 * 根据条件查询结果集，只取指定列，使用默认表
	 * @param array $colname
	 * @param where $where
	 */
	public function fetchColsByCond( $colname, array $where=null) {
		if ( empty( $colname)) {
			throw new Exception();
		}
		$colname = implode(',',$colname);
		$sWhere = $this->getStrWhere( $where);
		if( $sWhere) {
			$sWhere = ' where '.$sWhere;
		}
		
		$sql = "select {$colname} from `{$this->table}` {$sWhere}";
		$stm = $this->_query( $sql);
		
		$result = $stm->fetchAll(PDO::FETCH_ASSOC);
		return $result;
	}
	
	/**
	 * 返回关联数组
	 * 
	 * @param string $filedkey 用作结果关联数组键的字段名
	 * @param string $filedvalue 用作关联数组值的字段名(如果没有则使用整个行的数组作为值)
	 * @param array $where 条件数组
	 * 
	 * @throws Exception
	 */
	public function fetchHashByCond( ) {
		//func_get_args()这个函数返回的是包含当前函数所有参数的一个数组(如果调用这个函数应该是fetchHashByCond(1,2,3)这样的格式)
		
		$args = func_get_args();
		if( !is_array( $args) || empty( $args)) {
			throw new Exception( 'illegal argument '.var_export( $args, true));
		}
		
		$fieldkey = array_shift( $args);
		$fieldvalue = null;
		$where = null;
		if( count( $args) == 1) {
			$tmpArg = array_shift( $args);
			if( is_array( $tmpArg)) {
				$where = $tmpArg;
			} else {
				$fieldvalue = $tmpArg;
			}
		} else {
			$fieldvalue = array_shift( $args);
			$where = array_shift( $args);
		}
		
		if( $fieldvalue) {
			$fields = implode( ",", array( $fieldkey, $fieldvalue));
		} else {
			$fields = "*";
		}
		
		$sWhere = $this->getStrWhere( $where);
		if( $sWhere) {
			$sWhere = ' where '.$sWhere;
		}
		
		$sql = "select {$fields} from `{$this->table}` {$sWhere}";
		$stm = $this->_query( $sql);
		
		$result = array();
		if( $fieldvalue) {
			while( $row = $stm->fetch()) {
				$result[$row[$fieldkey]] = $row[$fieldvalue];
			}
		} else {
			while( $row = $stm->fetch()) {
				$result[$row[$fieldkey]] = $row;
			}
		}
		return $result;
	}
	
	/**
	 * 查询结果集
	 * @param string $sql
	 * @param const $fetch_style default:PDO::FETCH_BOTH
	 */
	public function fetchAll($sql, $fetch_style = PDO::FETCH_BOTH) {
		$stm = $this->_query($sql);
		return $stm->fetchAll($fetch_style);
	}
	
	/**
	 * 查询结果集中,获取首行
	 * @param string $sql
	 */
	public function fetchRow($sql, $fetch_style = PDO::FETCH_BOTH) {
		$stm = $this->_query($sql);
		return $stm->fetch($fetch_style);
	}
	
	/**
	 * 添加记录
	 * 
	 * @param array $data 插入的数据
	 */
	public function insert( $data) {
		if( empty( $data)) {
			return 0;
		}
		
		$aFields = array();
		$aValues = array();
		
		foreach( $data as $key=>$value) {
			$aFields[] = $key;
			$aValues[] = $this->quote( $value);
		}
		$sFields = implode( ',', $aFields);
		$sValues = implode( ',', $aValues);
		
		$sql = "insert into `{$this->table}`( {$sFields}) values( {$sValues})";
		
		return $this->_execute( $sql);
	}
	
	/**
	 * 批量添加记录
	 * 
	 * @param array $data 插入的数据
	 */
	public function batchinsert( $value) {
		if( empty( $value)) {
			return 0;
		}
		$arr_value = array();
		$field = array();
		$firstrow = array_shift( $value);
		$rowValue = array();
		foreach ($firstrow as $key=>$val) {
			$field[] = $key;
			$rowValue[] = $this->quote( $val);
		}
		$arr_value[] = implode( ',',$rowValue);
		foreach ($value as $row) {
			$arr_temp = array();
			foreach ($row as $key=>$val) {
				$arr_temp[] = $this->quote( $val);
			}
			$str_value = implode( ',',$arr_temp);
			$arr_value[] = $str_value;
			unset($arr_temp);
		}
		$sFields = implode( ',', $field);
		$sValues = implode( '),(', $arr_value);
		$sql = "insert into `{$this->table}`( {$sFields}) values( {$sValues})";
		return $this->_execute( $sql);
	}
	
	/**
	 * 修改
	 * 
	 * @param array $data 要修改的数据,列名为键名，列值为键值
	 * @param array $where 修改条件
	 * @param array $bind 条件绑定数据
	 */
	public function update( array $data, array $where=null) {
		if( empty( $data)) {
			return 0;
		}
		
		$sets = array();
		foreach( $data as $key=>$value) {
			$sets[] = $key . '=' . $this->quote( $value);
		}
		$sets = implode( ",", $sets);
		
		$sWhere = $this->getStrWhere( $where);
		if( $sWhere) {
			$sWhere = ' where '.$sWhere;
		}
		
		$sql = "update `{$this->table}` set {$sets} {$sWhere}";
		
		return $this->_execute( $sql);
	}
	
	/**
	 * 删除
	 * @param string $conditon 删除条件
	 */
	public function delete( array $where=null) {
		$sWhere = $this->getStrWhere( $where);
		if( $sWhere) {
			$sWhere = ' where '.$sWhere;
		}
		
		$sql = "delete from `{$this->table}` {$sWhere}";
		
		return $this->_execute( $sql);
	}
	
	/**
	 * 批量删除
	 * @param string $where 删除条件
	 * @example $where = array(0=>array('id'=>1,'serverid'=>3),1=>array('id'=>2,'serverid'=>5))
	 */
	public function batchdelete( array $where=null) {
		$sWhere = array();
		foreach ($where as $value) {
			$sWhere[] = $this->getStrWhere( $value);
		}
		if( !empty($sWhere)) {
			$sWhere = ' where ('.implode(') or (',$sWhere).')';
		}
		
		$sql = "delete from `{$this->table}` {$sWhere}";
		
		return $this->_execute( $sql);
	}
	
	/**
	 * 执行sql语句
	 * @param string $sql
	 */
	public function _query( $sql) {
		$this->sql = $sql;
		try {
			$this->logsql( $sql);
			
			$stm = $this->conn->prepare( $sql);
			if( empty( $stm)) {
				$code = $this->conn->errorCode();
				//判断sql语句是否预编译成功
				if ( !empty( $code) && '00000' != $code){
					
					$errorInfo = $this->conn->errorInfo();
					throw new PDOException( $errorInfo[2]);
				}
			}
			$stm->execute();
			
			$code = $stm->errorCode();
			//判断sql语句是否执行成功
			if ( !empty( $code) && '00000' != $code){
				$errorInfo = $stm->errorInfo();
				throw new PDOException( $errorInfo[2]);
			}
			return $stm;
		} catch ( PDOException $e) {
			throw new PDOException( $e);
		}
	}
	
	/**
	 * 执行sql语句
	 * @param string $sql
	 */
	public function _execute( $sql) {
		$this->sql = $sql;
		try {
			$this->logsql( $sql);
			$stm = $this->conn->prepare( $sql);
			$result = $stm->execute();
			
			$code = $stm->errorCode();
			if ( !empty( $code) && '00000' != $code){
				$errorInfo = $stm->errorInfo();
				throw new PDOException( $errorInfo[2]);
			}
			
			return $result;
		} catch ( PDOException $e) {
			throw new PDOException( $e);
		}
	}
	
	public function logsql( $sql) {
		echo $sql;
		echo "\n";
	}
	
	/**
	 * 析构函数
	 * 
	 */
	public function __destruct() {
		$this->conn = null;
	}
	
	/**
	 * 获取最后一条插入数据自增id
	 * 
	 * @return int|boolean 如果存在则返回最后插入自增id,否则返回false
	 */
	public function lastInsertId() {
		return $this->conn->lastInsertId();
	}
	
	/**
	 * 根据分页生成sql语句
	 * @param int $pageindex
	 * @param int $pagecount
	 * @param array $where
	 */
	public function _genStatementByPage( $pageIndex, $pageSize, array $where=null, $fields=null, array $orderby=null) {
		$sWhere = $this->getStrWhere( $where);
		$sAndWhere = '';
		if( $sWhere) {
			$sAndWhere = ' and '.$sWhere;
			$sWhere = ' where ' . $sWhere;
		}
		
		if( empty( $fields)) {
			$fields = '*';
		}
		
		$startindex = ($pageIndex-1)*$pageSize;
		
		$_orderby = $this->getStrOrderby( $orderby);
		
		if( $pageIndex == 1) {
			$sql = "select {$fields} from `{$this->table}` {$sWhere} {$_orderby} limit {$pageSize}";
		} else {
			$sql = "select {$fields} from `{$this->table}` {$sWhere} {$_orderby} limit {$startindex},{$pageSize}";
		}
		return $sql;
	}
	
	/**
	 * 分页查询管理员列表列表
	 * @param int $pageindex 当前页
	 * @param int $pagecount 每页数量
	 * @param array $where 条件语句
	 * @param string $fields 选择的列(字符串)
	 * @param array $orderby 排序列
	 * @param fetch_style      
	 * @return array 返回查询结果
	 */
	public function fetchAllByPage( $pageIndex, $pageSize, array $where=null, $fields=null, array $orderby=null, $fetch_style = PDO::FETCH_BOTH) {
		if( $pageIndex<=0 || $pageSize<=0) {
			return false;
		}
		//更加条件生成一条sql语句
		$sql = $this->_genStatementByPage( $pageIndex, $pageSize, $where, $fields, $orderby);
		return $this->fetchAll( $sql, $fetch_style);
	}
	
	/**
	 * 生成sql语句
	 * @param int $pagecount
	 * @param array $where
	 */
	public function _genStatement( array $where=null, $fields=null, array $orderby=null) {
		$sWhere = $this->getStrWhere( $where);
		$sAndWhere = '';
		if( $sWhere) {
			$sAndWhere = ' and '.$sWhere;
			$sWhere = ' where ' . $sWhere;
		}
		
		if( empty( $fields)) {
			$fields = '*';
		}
		
		$_orderby = $this->getStrOrderby( $orderby);
		
		$sql = "select {$fields} from `{$this->table}` {$sWhere} {$_orderby}";
		return $sql;
	}
	
	/**
	 * 查询列表
	 * @param array $where 条件语句
	 * @param string $fields 选择的列(字符串)
	 * @param array $orderby 排序列
	 * @param fetch_style      
	 * @return array 返回查询结果
	 */
	public function fetchAllByfields( array $where=null, $fields=null, array $orderby=null, $fetch_style = PDO::FETCH_BOTH) {
		//根据条件生成一条sql语句
		$sql = $this->_genStatement($where, $fields, $orderby);
		return $this->fetchAll( $sql, $fetch_style);
	}
	
	/**
	 * 返回表的行数
	 * @param array $where 条件
	 */
	public function rowCount(array $where=null) {
		$sWhere = $this->getStrWhere( $where);
		if($sWhere) {
			$sWhere = ' where '.$sWhere;
		}
		
		$sql = "select count(*) as row_count from `{$this->table}` {$sWhere}";
		$result = $this->fetchRow( $sql);
		return empty( $result) ? 0 : intval( $result['row_count']);
	}
	
	/**
	 * 生成join 语句
	 * @param array $join 数组  
	 * ps有可能是这种形式
	 * 				
	 * 				array('left'=>array('t2',array(array('t1.id','t2.id'),array('t1.name','t2.name'))));
	 * 	
	 * 				array('right'=>array('t2',array(array('t1.id','t2.id'),array('t1.name','t2.name'))),	
	 * 					  'inner'=>array('t3',array(array('t1.id','t3.id'),array('t1.name','t3.name'))));	
	 * 
	 * @return string 生成联接表达式
	 */
	public function getStrJoin( array $join=null) {
		$sJoin = '';
		if (!empty( $join)) {			
			$aJoin = array(); 
			if (count($join) == 1) {
				$join = array($join);
			}
			foreach ( $join as $item) {  
				foreach( $item as $key=>$value) {
					if (!in_array($key,array('left','right','inner'))) {	//联接类型
						continue;
					}
					$table = $value[0];		//表名
					$temp = array();
					foreach( $value[1] as $subkey=>$subvalue) {		//on条件处理
						$temp[$subkey] = implode('=',$subvalue);
					}
					$svalue = implode( ' and ', $temp);	//on条件整合
					$aJoin[] = $key.' join `'.$table.'` on '. $svalue;		//生成语句
				}
			}
			
			//最后用空格连接
			$sJoin = implode( ' ', $aJoin);
		}
		return $sJoin;
	}
	
	/**
	 * 生成where 条件语句
	 * @param array $where 条件数组  
	 * ps有可能是这种形式
	 * 				
	 * 				array( 'n_id in(?)'=>$id)
	 * 				array('id=1','sid=2');
	 * 				array('n_id in (?)'=>array('$id_1','$id_2'));	
	 * 
	 * @return string 生成条件表达式
	 */
	public function getStrWhere( array $where=null) {
		$sWhere = '';
		if (!empty( $where)) {			
			$aWhere = array();   //一个合法条件表达式
			foreach( $where as $key=>$value) {
				
				//当没有键名或键名为数字时，直接使用键值
				if( empty( $key) || is_numeric( $key)) {
					$aWhere[] = '('.$value.')';
					//略过!
					continue;
				}
				
				$svalue = $value;
				//处理是数组的键值，用于in条件等
				if(is_array( $value)) {
					foreach( $value as $subkey=>$subvalue) {
						$value[$subkey] = $this->quote( $subvalue);
					}
					$svalue = implode( ',', $value);
					$aWhere[] = '(' . str_replace( '?', $svalue, $key) . ')';
				} else {
					$aWhere[] = '(' . str_replace( '?', $this->quote($svalue), $key) . ')';
				}
			}
			
			//最后用and连接
			$sWhere = implode( ' and ', $aWhere);
		}
		return $sWhere;
	}
	/**
	 * 生产order by 语句
	 * @param Array $orderby 排序条件数组(数组有可能是这种形式 array("id","sex"=>"desc"))
	 * @return string $_orderby 生成条件表达式
	 */
	public function getStrOrderby( array $orderby=null) {
		if( empty( $orderby)) {
			if( !isset( $this->primarykey)) {
				return '';
			}
			//默认以主键升序排列
			$orderby = array( $this->primarykey=>'asc');
		}
		
		$_orderby = array();
		foreach( $orderby as $key=>$value) {
			if( is_numeric( $key)) {
				$_orderby[] = $value;
			} else {
				$_orderby[] = $key.' '.$value;
			}
		}
		$_orderby = implode( ',', $_orderby);
		if( $_orderby) {
			$_orderby = ' order by '.$_orderby;
		}
		return $_orderby;
	}
	
	/**
	 * sql 防注入,过滤所有的sql语句中的值
	 */
	public function quote( $value) { 
		if (is_int($value)) {
            return "'" . $value . "'";
        } elseif (is_float($value)) {
            return "'" . sprintf('%F', $value) . "'";
        } elseif( is_array( $value)) {
        	throw new Exception( 'db table quote fail: the value can not be array');
        }
        return "'" . addslashes ( $value ) . "'";
	}
	
	public function getLastSql( ) {
		return $this->sql;
	}
	
	public function found_rows () {
		$sql = "SELECT FOUND_ROWS() as num";
		$stm = $this->_query( $sql);
		
		$result = $stm->fetchAll(PDO::FETCH_ASSOC);
		return $result[0]['num'];
	}
}