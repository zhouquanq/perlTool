<?php

abstract class Moby_Controller {
	
	protected $_http = null;
	protected $var = array();
	
	public function __construct( $http) {
		$this->_http = $http;
	}

	/**
	 * 跳转页面
	 * @param string $model 模块
	 * @param string $controller 控制器
	 * @param string $action 动作
	 * @param array $params 参数
	 * 
	 */
	public function _redirect( $action, $controller=null, $model=null, array $params=null) {
    	$url = $this->_http->encode($action, $controller, $model, $params);
    	
    	header("location:".$url);
    	exit;
    }
    
    /**
     * 载入模板 
     * @param string $tplpath
     */
    public function display( $tplpath) {
    	require $tplpath;
    }
    
    /**
     * 设置变量
     * @param string $name 变量名称
     * @param string $value 变量值
     */
    public function assign( $name, $value) {
    	if( empty( $name) || !is_string( $name)) {
    		throw new Exception( '变量名必须为非空的字符串');
    	}
    	$this->var[$name] = $value;  
    }
    
    /**
     * 在模板中获取变量
     * @param string $name 变量名
     * 
     * @return string 如果存在则返回其值否则返回空字符串
     */
    public function get( $name, $default='') {
    	return empty( $this->var[$name]) ? $default : $this->var[$name];
    }   
}