<?php

/**
 * 应用
 *
 */
class Moby_Application {
	
	protected $controllerConfig = null;
	
	public function __construct( $ctlConfig) {
		if( empty( $ctlConfig) || !is_array( $ctlConfig)) {
			throw new Exception( 'illegal controller config ');
		}
		
		Zend_Registry::set( 'controllerConfig', $ctlConfig);
		$this->controllerConfig = $ctlConfig;
	}
	
	public function run() {
		session_start();
		
		//构造HTTP请求对象
		$http = new Moby_Http_Custom();
		
		Zend_Registry::set('MobyHttp', $http);
		
		$model = $http->getModel();
		$controller = $http->getController();
		$action = $http->getAction();

		if( empty( $this->controllerConfig[$model][$controller])) {
			throw new Exception( 'not found the controller '.$model.'/'.$controller);
		}
		
		//控制器路由数组
		$controllerClass = $this->controllerConfig[$model][$controller];
		Zend_Loader_Autoloader::autoload($controllerClass);
		
		$controllerObject = new $controllerClass($http);
		
		//方法
		$action = strtolower($action).'Action';
		if( !method_exists($controllerObject, $action)) {
			throw new Exception( 'not found the action '.$action.' in '.$controllerClass);
		}
		
		$controllerObject->$action();
	}
}