$(document).ready(function(){
	init_checkbox();
});

function init_checkbox()
{
	$('#checkAll').click(function() {
			$('.item-chkbox').attr('checked', $('#checkAll').get(0).checked);
	})
	
	$('.item-chkbox').click(function() {
			if (true == $(this).get(0).checked) {
				//所有已勾选				
				if (0 == $(".item-chkbox").size() - $(".item-chkbox:checked").size())	
					$('#checkAll').attr('checked', true);
			}
			else {
				$('#checkAll').attr('checked', false);
			}
	});
	
	//服务器全选框
	$(".chk-all-server").click (function() {
		   $sub_chkbox = $(this).nextAll("label").children(":checkbox");
				   
		   $sub_chkbox.attr("checked", $(this).get(0).checked);			   
	       if (true == $(this).get(0).checked) {	           
	           $sub_chkbox.attr("disabled", "disabled");
	       } else {
	           $sub_chkbox.attr("disabled", false);
	       }
	});
	
	//渠道全选框
	$(".chk-all-pub").click (function() {
		   $sub_chkbox = $("#publist").children("label").children(":checkbox");
		   
		   $sub_chkbox.attr("checked", $(this).get(0).checked);
	       if (true == $(this).get(0).checked) {	           
	           $sub_chkbox.attr("disabled", "disabled");
	       } else {			
	           $sub_chkbox.attr("disabled", false);
	       }
	});	
	
//	$("label :checkbox").click(function() {
//			if (true == $(this).attr('checked')) {
//			    chkbox = $(this).parents("span").children("label").children(":checkbox");
//			    chkbox_checked = $(this).parents("span").children("label").children(":checked");
//			    
//                //所有已勾选
//                if (chkbox.size() == chkbox_checked.size())
//                    $(this).parent().prevAll(".chk-all-server").attr("checked", true);
//			}
//			else {
//				$(this).parent().prevAll(".chk-all-server").attr("checked", false);
//			}	
//	});
}
