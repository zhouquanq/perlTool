//	通用js获取服务器数据
function Ajax_instance(){
		var xmlHttp;
		try {
		        // FireFox, Opera 8.0 +, Safari
		        xmlHttp = new XMLHttpRequest();
		}catch (e) {
		   try {
		        // IE 6.0 +
		        xmlHttp = new ActiveXObject('MSXML2.XMLHTTP');
		    }catch (e) {
		        try {
		                // IE 5.5 +
		           xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
		        }catch (e) {
		                alert('程序出现兼容性问题，建议使用Firefox浏览器，或联系开发人员');
		                return false;
		            }
		        }
		    }
	    return xmlHttp;	
}

/**
 * 通过Ajax获取服务器数据
 * @param model
 * @param controller
 * @param action
 * @param args	形式为array：{ "类似：username": value }
 * @param w 方式
 * @returns {String}
 */
function getInfo( m , c , a , args , w , f ){
	var		info	=	'';
	var		url		=	'http://'+location.url+'/index.php?';
	//	如果model、controller和action其中有一个为空则返回空值
	if( m || c || a ){
		return info;
	}
	url		+= m +'/'+c+'/'+a+'/';
	var	Ajax	=	Ajax_instance();
	if( typeof( args ) == object && args == null ){
	if( w == 'get' || w=='GET' ){
		//		判断对象
		
		for( var i in args ){
			url		+= i + '/' + args[i];
		}
		Ajax.open( 'GET' , url  );
		Ajax.send();
		if( Ajax.status	== 200 ){
			info	=	eval( '(' + Ajax.responseText + ')' );
		}
	}else{
		var post_url;
		for( var i in args  ){
			if( args[i]	==	object ){
				for( var x in args[i]){
					post_url	+= 	i[x]+"="+args[i][x]+"&";
				}
			}else{
				post_url	+= 	i+"="+args[i]+"&";
			}
		}
		Ajax.open( 'POST' , url  );
		Ajax.send(  );
	}
	
	
//	Ajax.onreadystatechange	=	function(){
//		if(  )
//	}
	}
	return info;
	}
	