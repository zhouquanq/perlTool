<?php

//暂时显示全部错误信息
ini_set( "error_reporting", E_ALL );//& ~(E_NOTICE) & ~(E_WARNING));
ini_set( "display_errors", "ON");
//set_magic_quotes_runtime( 0);
//关闭魔术引号
ini_set( "magic_quotes_runtime", "Off");

// 定义项目路径
defined( 'APPLICATION_PATH')
    || define( 'APPLICATION_PATH', realpath( dirname(__FILE__) . '/../application'));

// 设置项目默认命名空间
defined( 'APP_NAMESPACE') 
	|| define( 'APP_NAMESPACE', 'Moby_Mgrsvr_');
	
// 设置include_path
set_include_path( implode( PATH_SEPARATOR, array(
    realpath( APPLICATION_PATH . '/../library'),
    APPLICATION_PATH,
    get_include_path(),
)));

// 设置默认时区
date_default_timezone_set('PRC');

// 类自动加载
require 'Zend/Loader/Autoloader.php';
Zend_Loader_Autoloader::getInstance()
	->setFallbackAutoloader( true)
	->pushAutoloader( new Moby_Autoloader( APP_NAMESPACE, APPLICATION_PATH . '/application'), APP_NAMESPACE);

// 设置请求uuid
defined( 'APP_REQ_UUID') 
	|| define( 'APP_REQ_UUID', Moby_Util_UUID::gen());
	
// 设置请求uuid
defined( 'APP_REQ_SARTTIME') 
	|| define( 'APP_REQ_SARTTIME', time());
	
//路由表配置

$aa = new stdClass();
$aa->aa = "aa";
$aa->bb = "bb";

$http = new Moby_Http_Custom();
$url = $http->encode( 'index', 'index', 'index', array( 'ee{}'=>array('ee1'=>123, 'ee2'=>456), 'aa'=>$aa, 'bb[]'=>array('1',2,3,4), 'cc[]'=>'adsfa', 'dd'=>array('1',2,3,4)));
var_dump( $url);
$result = $http->decode( $url);
var_dump( $result);