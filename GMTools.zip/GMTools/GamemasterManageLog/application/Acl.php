<?php
class Acl {
	/**
	 * 当控制器动作被调用时过滤其行为或重新设置动作
	 * 
	 * @param unknown_type $http
	 */
	public function preDispatch( $http) {
		if( $http->getController() != 'index' || $http->getModel() != 'index') {
			if( !isset( $_SESSION['accountid']) || $_SESSION['accountid'] < 0) {
				$http->setModel( 'index');
				$http->setController( 'index');
				$http->setAction( 'login');
				$http->setParam( 'msg', ( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_ACL_LOGINFIRST')));
				return true;
			}
			//accountid账号是否有权限进入到这个模块 
			if( $_SESSION['accountid'] != 1 && ($http->getController() != 'main' || $http->getModel() != 'index')) {
				$modelAdmin = Moby_Mgrsvr_Index_Model_Admin::getInstance();
				try {
					$modelAdmin->isAllowController( 
						$_SESSION['accountid'], 
						$http->getAction(), 
						$http->getController(), 
						$http->getModel(), 
						$http->getParam( 'serverid', null)
					);
					
				} catch( Exception $e) {
					$message = $e->getMessage();
					$http->setModel( 'index');
					$http->setController( 'main');
					$http->setAction( 'welcome');
					$http->setParam( 'msg', ( $message));
				}
			}
		} 
		return true;
	}
}