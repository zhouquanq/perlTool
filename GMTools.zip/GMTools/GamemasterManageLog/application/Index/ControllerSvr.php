<?php
/**
 * 服务控制器基类
 */
class Moby_Mgrsvr_Index_ControllerSvr extends Moby_Mgrsvr_Index_Controller {
}