<?php
/**
 * 所有控制器的基类
 * @var $ispower 是否是权限控制该控制器是否出现在权限列表里面
 * @var @deprecated 定义控制器依赖关系
 */
abstract class Moby_Mgrsvr_Index_Controller extends Moby_Controller {

	/**
	 * 定义是否出现在权限列表中 
	 * @var int
	 */
	public $ispower = 1;
	
	/**
	 * 定义操作依赖关系
	 * @var array
	 */
	public $dependent;
	private $lang = null;
	protected $msg = null;
	
	public function __construct( $http) {
		parent::__construct( $http);

		$this->msg = $this->_http->getParam( 'msg');
		
		$this->assign('msg', $this->msg);
		$this->lang = new Moby_Mgrsvr_Index_Model_Lang();
	}

	public function getLang() {
		return $this->lang;
	}

	public function encodeToDb($value) {
		return Moby_Mgrsvr_Index_Model_Util::encodeToDb( $value);
	}

	public function decodeToDb($value) {
		return Moby_Mgrsvr_Index_Model_Util::decodeToDb( $value);
	}

    /**
     * 对参数URL Encode
     * @param mixed $param  数组或者简单变量
     */
    public function urlencode($param) {
        /*
        if (is_array($param)) {
            foreach ($param as &$val)
              $val = urlencode($val);
            unset($val);
        }
        else {
            $param = urlencode($param);
        }*/

        return $param;
    }

    /**
     * 对参数URL Decode
     * @param mixed &$param  数组或者简单变量
     */
    public function urldecode(&$param) {
        /*
    	if (is_array($param)) {
            foreach ($param as &$val)
              $val = urldecode($val);
            unset($val);
        }
        else {
            $param = urldecode($param);
        }
		*/
        return $param;
    }

	/**
	 * 通过参数名批量获取附加的url对应的参数值
	 * @param mixed $params 预获取的参数名
	 *                          组成的数组,例:array ('param1', 'param2')|
	 *                          逗号分隔的字符串|
	 *                          单个字符串,
	 * @return array 数组,参数名为键名,参数值为键值
	 *               例array('param1'=>1, 'param2' => 'abc')
	 *               PS:如果没有找到指定参数将不会有键名|
	 *
	 */
	public function getUrlParams($params) {
		if(empty( $params)) {
			return array();
		}

		if (is_string($params)) {
			$params = explode(',', $params);
		}

		$result = array();
		foreach( $params as $param) {
			$param = trim($param);
			//调用http对象的getParam完成
			$param_value = $this->_http->getParam($param, null);
			if((null !== $param_value) && ('' !== $param_value)) {
				$result[$param] = $param_value;
			}
		}
		return $result;
	}

	public function getParam( $param, $default = NULL) {
		return $this->_http->getParam($param, $default);
	}

	public function setParam( $param, $value) {
		$this->_http->setParam( $param, $value);
	}

   	/**
   	 * 获取单个URL参数值
   	 * @param string $param
   	 * @param mixed $default 默认值
   	 */
   	public function getUrlParam($param, $default = NULL) {
        if(empty($param)) {
            return $default;
        }
   	   	return $this->getParam($param, $default);
   	}

	public function httpquote( $value) {
		return htmlspecialchars( $value);
	}

	/**
	 * 导出调试日志
	 */
	public function dumplog($dumpinfo) {
		Moby_Mgrsvr_Index_Model_Util_Log::getInstance('debug')->record($dumpinfo);
	}
	
    /**
     * 设置分页助手
     * @param $page         当前页
     * @param string        需要附加的URL参数列表,逗号分隔 
     * @param $total_page   总记录条数     
     * @param $append_url   用逗号隔开的一系列键值
     */
    protected function setPageAssistant($page, $total_item, $append_url, $pagesize = 0) {
            $pagesize = $pagesize ? $pagesize : Moby_Mgrsvr_Index_Model_Util::$defaultPageSize;
                        
            $append_url = $this->getUrlParams($append_url);
            $page_assitant = Moby_Mgrsvr_Index_Model_Util::genPage($page, $total_item, $pagesize);                     
            $this->assign('pages', $page_assitant);
            $this->assign('urlParams', $append_url);
    }
    
    public function json( $var) {
    	return json_encode( $var);
    }
}