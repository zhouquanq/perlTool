<?php
/**
 * 服务控制器基类
 */
class Moby_Mgrsvr_Index_ControllerData extends Moby_Mgrsvr_Index_Controller {
}