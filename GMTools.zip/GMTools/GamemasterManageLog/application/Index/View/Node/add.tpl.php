<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_ADD_Welcome'); ?></title>
<link href="/css/moby.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.form.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.table.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="/js/jquery.js"></script>
<?php $this->display( 'Index/View/Public/moby.notice.php'); ?>
</head>
<body>
<form action="<?php echo $this->_http->encode( 'add', 'node'); ?>" method="post">
<table width="680" border="0" align="center" cellpadding="2" cellspacing="1" class="table">
    <tr>
      <th class="bg_tr" align="center" colspan="2" height="25"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_NODE_ADD_Create'); ?></th>
    </tr>
    
    <tr>
      <td width="30%" align="right"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_NODE_ADD_Name'); ?>:</td>
      <td><input name="name" type="text" class="text" id="name"size="32" /></td>
    </tr>
    <tr>
      <td align="right"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_NODE_ADD_Father'); ?>:</td>
      <td><label>
        <select name="parentid" id="parentid">
        	<option value="0" selected="selected"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_NODE_ADD_Top'); ?></option>
            <?php foreach( $this->get( 'notApexList') as $item) { ?>
            <option value="<?php echo $item['id']; ?>"><?php echo $this->decodeToDb( $item['name']); ?></option>
            <?php } ?>
        </select>
      </label></td>
    </tr>
    <tr>
      <td align="right"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_NODE_ADD_Power'); ?>:</td>
      <td><label>
        <select name="powerid" id="powerid">
        	<option value="0" selected="selected"><?php echo $this->getLang()->get( 'APP_INDEX_CONTROLLER_ADDEXP_HaveNone'); ?></option>
            <?php foreach( $this->get( 'powerlist') as $item) { ?>
            <option value="<?php echo $item['id']; ?>"><?php echo $this->decodeToDb( $item['name']); ?></option>
            <?php } ?>
        </select>
      </label></td>
    </tr>
    <tr>
      <td align="right"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_ADD_5'); ?>:</td>
      <td><label><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_ADD_6'); ?>
          <input name="enable" type="radio" id="enable" value="1" checked="checked" />
      </label>
        <label><?php echo $this->getLang()->get( 'Forbidden'); ?>
        <input type="radio" name="enable" value="0" id="enable" />
      </label></td>
    </tr>
    <tr>
      <td  colspan="2" align="center">
      <input type="submit" name="submit" class="button" value="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_LIST_3'); ?>" />
      <input type="reset" name="reset" class="button" value="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADDEXP_VERIFY_Cancel'); ?>" /></td>
    </tr>
</table>
</form>
</body>
</html>
