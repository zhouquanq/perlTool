<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_NODE_LIST_Msg'); ?></title>
<link href="/css/moby.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.form.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.table.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="/js/jquery.js"></script>
<?php $this->display( 'Index/View/Public/moby.notice.php'); ?>
</head>
<body>

<table width="680" border="0" align="center" cellpadding="2" cellspacing="1" class="table">
    <tr>
      <th class="bg_tr" align="center" colspan="6" height="25"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_NODE_LIST_Msg'); ?></th>
    </tr>
    <tr>
      <td colspan="6">
        <form id="form1" method="post" action="<?php echo $this->_http->encode( 'index');?>">
          <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_NODE_LIST_Search'); ?>:</td>
              <td><input name="name" type="text" class="text" id="name" value="<?php echo $this->httpquote( $this->_http->getParam('name'));?>" size="32" maxlength="32" /></td>
              <td><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_ADD_6'); ?>:
                <label><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_ADD_6'); ?>
                <input type="radio" name="enable" id="enable" value="1"  />
              </label>
                <label><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_ADD_7'); ?>
                <input type="radio" name="enable" id="enable" value="0" />
              </label></td>
              <td><input type="submit" name="button" id="button" value="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADDINGOT_LIST_Search'); ?>" class="button" /></td>
            </tr>
          </table>
        </form>    
      
      </tr>
    <tr>
      <td colspan="6">
    <a href="<?php echo $this->_http->encode( 'add', 'node', 'index');?>"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_LIST_3'); ?></a>    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GFTPKFGR_LIST_Name'); ?></td>
      <td><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_NODE_ADD_Father'); ?></td>
      <td><?php echo $this->getLang()->get( 'Authority'); ?>id</td>
      <td><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_ADD_5'); ?></td>
      <td><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_LIST_Operate'); ?></td>
    </tr>
    <?php if( $this->get( 'result')) { ?>
    <?php $is_odd = false; ?>
    <?php foreach( $this->get( 'result') as $item) { ?>
    <tr class="<?php echo $is_odd ? 'odd' : 'even'; $is_odd = $is_odd ? false : true;?>">
      <td height="23"><input type="checkbox" name="nodeid" value="<?php echo $item['id']; ?>" /></td>
      <td><?php echo $this->decodeToDb( $item['name']);?></td>
      <td><?php echo $this->getNameById( $item['parentid']);?></td>
      <td><?php echo $this->getPowerById( $item['powerid']);?></td>
      <td><?php echo $item['enable'] ? $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_ADD_6') : $this->getLang()->get( 'HaveBeenForbidden');?></td>
      <td>
          <a href="<?php echo $this->_http->encode( 'modify', null, null, array( 'nodeid'=>$item['id']));?>"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_LIST_Modify'); ?></a>|
          <?php if( !$item['enable']) { ?>
          <a href="<?php echo $this->_http->encode( 'unlock', null, null, array( 'nodeid'=>$item['id']));?>"><?php echo $this->getLang()->get( 'Unforbidden'); ?></a>      
          <?php } else { ?>
          <a href="<?php echo $this->_http->encode( 'lockout', null, null, array( 'nodeid'=>$item['id']));?>"><?php echo $this->getLang()->get( 'Forbidden'); ?></a>      
          <?php } ?>      </td>
    </tr>
    <?php } ?>
    <?php } else { ?>
    <tr>
      <td height="23" colspan="6"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_NODE_LIST_NOWNOTHAVENODE'); ?></td>
  </tr>
    <?php } ?>
    <tr>
      <td  colspan="6" align="right"><?php $this->display( 'Index/View/Public/page.tpl.php')?></td>
    </tr>
</table>

</body>
</html>
