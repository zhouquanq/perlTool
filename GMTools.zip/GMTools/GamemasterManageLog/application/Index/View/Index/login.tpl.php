<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_INDEX_LOGIN_1'); ?></title>

<link type="text/css" href="css/moby.css" rel="stylesheet" />
<link type="text/css" href="css/moby.form.css" rel="stylesheet" />
<link type="text/css" href="css/start/jquery-ui-1.8.20.custom.css" rel="stylesheet" />

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui-custom.min.js"></script>
<?php $this->display( 'Index/View/Public/moby.main.js.php'); ?>
<script type="text/javascript">
	$(document).ready( function() {
		if(top!=self){
		   top.location.href = self.location.href;
		}
	});
</script>
<?php $this->display( 'Index/View/Public/moby.notice.php'); ?>
</head>
<body style="background-color: #9CDCF9;" scroll="no">

<table width="681" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:120px">
  <tr>
    <td width="353" height="259" align="center" valign="bottom" style="background:url(/Images/index/login_1.gif)"></td>
    <td width="195" background="Images/index/login_2.gif">
    <form method="post" action="<?php echo $this->_http->encode( 'login'); ?>">
    <table width="190" height="106" border="0" align="center" cellpadding="2" cellspacing="0">
      
            <tr>
              <td height="50" colspan="2" align="left">&nbsp;</td>
            </tr>
            <tr>
              <td width="60" height="30" align="left"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_INDEX_LOGIN_2'); ?></td>
              <td><input name="account" type="text" class="text" id="UserName"size="14"></td>
            </tr>
            <tr>
              <td height="30" align="left"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_INDEX_LOGIN_3'); ?></td>
              <td><input name="password" type="password" class="text" id="Password" size="16"></td>
            </tr>
            <tr>
              <td height="30"> <?php echo $this->getLang()->get( 'APP_INDEX_VIEW_INDEX_LOGIN_4'); ?> </td>
			  <td><input name="code" type="text" id="Code" size="4" class="text" maxlength="4">
			  <img src="<?php echo $this->_http->encode( 'code')?>" width="50" height="24" onClick="javascript:this.src=this.src" />
		      </td>
            </tr>
            <tr>
              <td height="40" colspan="2" align="center"><img src="/Images/index/tip.gif" width="16" height="16"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_INDEX_LOGIN_5'); ?></td>
          <tr>
              <td colspan="2" align="center">
              <input type="submit" name="submit" class="button" value="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_INDEX_LOGIN_6'); ?>"> 
			  <input type="reset" name="reset" class="button" value="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADDEXP_VERIFY_Cancel'); ?>">
			</td>
          <tr>
              <td height="5" colspan="2"></td>
        
    </table>
    </form>
    </td>
    <td width="133" style="background:url(/Images/index/login_3.gif)">&nbsp;</td>
  </tr>
  <tr>
    <td height="161" colspan="3" style="background:url(/Images/index/login_4.gif)"></td>
  </tr>
</table>

</body>
</html>