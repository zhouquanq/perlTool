<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_ADD_Welcome'); ?></title>
    <link href="/css/moby.css" rel="stylesheet" type="text/css" />
	<link href="/css/moby.form.css" rel="stylesheet" type="text/css" />
	<link href="/css/moby.table.css" rel="stylesheet" type="text/css" />
    
    <script type="text/javascript" src="/js/jquery.js"></script>
    <?php $this->display( 'Index/View/Public/moby.notice.php'); ?>
</head>
<body>

<table width="680" border="0" align="center" cellpadding="2" cellspacing="1" class="table">
    <tr>
      <th class="bg_tr" align="center" colspan="10" height="25"><?php echo $this->getLang()->get( 'APP_INDEX_ControllerAuth_ChooseServer'); ?></th>
  </tr>
    </table>
<form action="<?php echo $this->get( 'requesturl', '') ?>" method="post" >
<?php $this->display( 'Index/View/Public/serverlist.tpl.php'); ?>
<table width="680" border="0" align="center" cellpadding="2" cellspacing="1" class="table">
    <tr>
		<td colspan="2" align="center">
			<input type="submit" name="button" id="button" value="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_REMOVELIST_Submit'); ?>" class="button" />
      		<input type="reset" name="button2" id="button2" value="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADDEXP_VERIFY_Cancel'); ?>" class="button" />
		</td>
	</tr>
</table>
</form>
</body>
</html>