<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_ADD_Welcome'); ?></title>
<link href="/css/moby.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.form.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.table.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="/js/jquery.js"></script>
<?php $this->display( 'Index/View/Public/moby.notice.php'); ?>
</head>
<body>
<form action="<?php echo $this->_http->encode( 'setpass');?>" method="post" >
<table class="table" cellspacing="1" cellpadding="2" width="680" align="center" border="0">
<tr>
      <th height="25" colspan="2" align="left" class="bg_tr"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_MAIN_INDEX_4'); ?></th>
  </tr>
    <tr>
      <td width="30%" height="23" align="right"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_MAIN_SETPASS_1'); ?>:<span class="TableRow2"></span><span class="TableRow1"></span></td>
      <td><input name="oldpasswd" type="password" class="text" size="32" /></td>
    </tr>
    <tr>
      <td height="23" align="right"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_MAIN_SETPASS_2'); ?>:</td>
      <td><input name="newpasswd" type="password" class="text" size="32" /></td>
    </tr>
    <tr>
      <td height="23" align="right"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_SETPASS_ConfPwd'); ?>:</td>
      <td><input name="confirmpw" type="password" class="text" size="32" /></td>
    </tr>
    <tr>
      <td height="23" colspan="2" align="center">
      <input type="submit" name="submit" class="button" value="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_REMOVELIST_Submit'); ?>" />
      <input type="reset" name="reset" class="button" value="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADDINGOT_BATCH_Reset'); ?>" />
      </td>
    </tr>
</table>
</form>
</body>
</html>
