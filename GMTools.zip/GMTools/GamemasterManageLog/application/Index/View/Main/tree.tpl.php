<?php if( $nodelist) { ?>
<?php foreach( $nodelist as $value) { ?>
	<li>
	<?php if ( !empty( $value['sublist'])) { ?>
		<span class="folder"><?php echo $this->decodeToDb( $value['name'] ); ?></span>
		<ul>
		<?php 
			if( !empty( $nodelist)) {
				array_push( $treeStack, $nodelist);
			} else {
				array_push( $treeStack, array());
			}
			//array_push( $treeStack, $value['sublist']);
			$nodelist = $value['sublist'];
			require 'Index/View/Main/tree.tpl.php';
		?>
		</ul>
	<?php } else { ?>
		<?php 
		if ( !empty( $value['powerid']) && !empty( $value['model']) && !empty( $value['controller']) && !empty( $value['action'])) {
				
			$model = empty( $value['model']) ? null : $value['model'];
			$controller = empty( $value['controller']) ? null : $value['controller'];
			$action = empty( $value['action']) ? null : $value['action']; ?>
			<?php $path = $this->_http->encode( $action, $controller, $model); ?>
			<a target="main" href="<?php echo $path; ?>"><span class="file"><?php echo $this->decodeToDb( $value['name']); ?></span></a>
		<?php } else { ?>
			<span class="folder"> <?php echo $this->decodeToDb( $value['name']); ?></span>
		<?php } ?>
	<?php } ?>
	</li>
<?php } ?>
<?php //$notelist = array_pop( $treeStack);?>
<?php } ?>