<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_ADD_Welcome'); ?></title>
    <link href="/css/moby.css" rel="stylesheet" type="text/css" />
	<link href="/css/moby.form.css" rel="stylesheet" type="text/css" />
	<link href="/css/moby.table.css" rel="stylesheet" type="text/css" />
    
    <script type="text/javascript" src="/js/jquery.js"></script>
    <?php $this->display( 'Index/View/Public/moby.notice.php'); ?>
</head>
<body>
<table class="table" cellspacing="1" cellpadding="2" width="680" align="center" border="0">
<tr>
      <th class="bg_tr" align="left" height="25"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_ADD_Welcome'); ?><?php echo $this->get( 'account');?></th>
    </tr>
    <tr>
      <td height="23"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_MAIN_WELCOME_1'); ?>:<span class="TableRow2"><?php echo $this->get( 'lasttime');?></span></td>
    </tr>
</table>
</body>
</html>
