<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_MAIN_INDEX_1'); ?></title>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
	<link type="text/css" href="css/moby.css" rel="stylesheet" />
	<link type="text/css" href="css/moby.table.css" rel="stylesheet" />
	<link type="text/css" href="css/top_css.css" rel="stylesheet" />
	<link type="text/css" href="css/start/jquery-ui-1.8.20.custom.css" rel="stylesheet" />
	
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/jquery-ui-custom.min.js"></script>
	<script type="text/javascript" src="js/jquery.bgiframe-2.1.2.js"></script>
	<?php $this->display( 'Index/View/Public/moby.main.js.php'); ?>
	<script type="text/javascript">
		//定时更新高度
		$(document).ready( function() {
			var mainwidth = $('#mainframe').width();
			var leftwidth = (mainwidth*25/100);
			var rightwidth = (mainwidth*75/100);
			var $leftd = $('#lefttd');
			var $rightd = $('#rightd');
			
			$leftd.css( 'width', leftwidth);
			$rightd.css( 'width', rightwidth);
			$('#closeleft').bind('click', function() {
				if( $leftd.css( 'display') != 'none') {
					$leftd.css( 'display', 'none');
					$leftd.css( 'width', leftwidth);
					$rightd.css( 'width', rightwidth);
				} else {
					$leftd.css( 'display', 'block');
					$leftd.css( 'width', leftwidth);
					$rightd.css( 'width', rightwidth);
				}
			});
			
			$(window).resize( function($event) {
				var diffLeftRight = 0;
				var windowDiffHeifht = $(window).height() - $(document.body).height();
				var main_left_height = $("#leftframe").height();
				var main_right_height = $("#main").height();
				
				if( main_left_height + windowDiffHeifht < 0) {
					return false;
				}
				if( main_right_height + diffLeftRight < 10 && windowDiffHeifht < 0) {
					return false;
				}
				
				if( main_left_height - diffLeftRight + windowDiffHeifht < 0) {
					return false;
				}
				
				$("#leftframe").height( main_left_height - diffLeftRight + windowDiffHeifht);
				$("#main").height( main_left_height + windowDiffHeifht);
		
			});
			$(window).resize();
		});
	</script>
	
</head>
<body>
<iframe id="template" src="<?php echo $this->_http->encode( 'template', 'index');?>" style="display:none"></iframe>
<table width="955" border="0" align="center" cellpadding="0" cellspacing="0" style=" background-color:#03A8F6">
  <tr>
    <td width="194" height="60" align="center" background="/Images/index/top_logo.jpg"></td>
    <td width="761" align="left" style="background:url(/Images/index/top_bg.jpg) no-repeat; ">
    <table cellspacing="0" cellpadding="0" border="0" width="705" height="33">
        <tr>
          <td width="13%" align="left">
          	<img height="15" alt="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_MAIN_INDEX_2'); ?>" title="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_MAIN_INDEX_2'); ?>" src="/Images/index/on-of.gif" width="15" border="0" id="closeleft" /></td>
          <td width="50%" align="left">
            <a class="title" href="<?php echo $this->_http->encode('logout', 'index');?>" ><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_MAIN_INDEX_3'); ?></a>
            <span class="top_link">┆</span> 
            <a class="title" href="<?php echo $this->_http->encode('setpass', 'main');?>" target="main"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_MAIN_INDEX_4'); ?></a>
            <span class="top_link">┆</span> 
            <a class="title" href="<?php echo $this->_http->encode('flushcache');?>" target="main"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_MAIN_INDEX_FLUSHCACHE'); ?></a>
            <?php if( $this->accountid == 1) { ?>
            <span class="top_link">┆</span>
            <a class="title" href="<?php echo $this->_http->encode('refreshpower');?>" target="main"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_MAIN_INDEX_RELOADPOWER'); ?></a>
        	<?php } ?>
          </td>  	
          <td align="right">
          	<span id=date_time></span>
          	<?php $this->display( 'Index/View/Public/datetime.js.php'); ?>
          </td>
        </tr>
    </table>
    </td>
  </tr>
  <tr height="6">
    <td bgcolor="#1F3A65" background="/Images/index/top_bg.jpg"></td>
  </tr>
</table>

<table width="955"  border="0" align="center" cellpadding="0" cellspacing="0" id="mainframe">
  <tr>
    <td valign="top" id="lefttd">
    	<iframe id="leftframe" src="<?php echo $this->_http->encode('left', 'main');?>" name="leftFrame" 
        	marginwidth="0" marginheight="0" frameborder="0" scrolling="auto" style="width:100%; " ></iframe></td>
    <td valign="top" id="rightd">
    	<iframe id="main" name="main" src="<?php echo $this->_http->encode('welcome', 'main');?>"  
    		marginwidth="0" marginheight="0" frameborder="0" scrolling="auto" style="width:100%;" ></iframe>
    </td>
  </tr>
</table>

</body>
</html>