<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
	<title><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_MAIN_LEFT_1'); ?></title>
	<link rel="stylesheet" href="/css/jquery.treeview.css" />
    <link rel="stylesheet" href="/css/red-treeview.css" />
	
	
	<script type="text/javascript" src="/js/jquery.js" ></script>
	<script type="text/javascript" src="/js/jquery.treeview.js" ></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$("#browser").treeview();
		});
	</script>
</head>
<body>
	<div>
		<ul id="browser" class="filetree">
			<?php 
			$treeStack = array( $this->get('nodelist'));
			$nodelist = $this->get('nodelist');
			require 'Index/View/Main/tree.tpl.php';?>
		</ul>
	</div> 
</body>
</html>