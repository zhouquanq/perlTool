<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GOODS_LIST3_1'); ?></title>
</head>
<body>
	<div id="_templateGoodsSelectShowInfo">
		<div id="widget_goodsselectshowinfo">
			<div style="float:left;" name="titlediv">
				<table align="center" cellpadding="2" cellspacing="1" class="table" width="100%">
					<tr><td>
						<a href="javascript:void(0)" name="selectgoodstype" type="" class="title"></a>
					</td></tr>
				</table>
			</div>
			<div name="datadiv" style="overflow-y:scroll; float:left;">
				<table name="datatable" cellpadding="2" cellspacing="1" align="center" width="100%" class="table">
					<tr>
						<td>
							<label>
								<input type="radio" name="goodsprotoid" value="" goodname="" />
								<a href="javascript:void(0);" id=""></a><div style="display:none"></div>
							</label>
						</td>
						<td>
							<label>
								<input type="radio" name="goodsprotoid" value="" goodname="" />
								<a href="javascript:void(0);" id=""></a><div style="display:none"></div>
							</label>
						</td>
						<td>
							<label>
								<input type="radio" name="goodsprotoid" value="" goodname="" />
								<a href="javascript:void(0);" id=""></a><div style="display:none"></div>
							</label>
						</td>
						<td>
							<label>
								<input type="radio" name="goodsprotoid" value="" goodname="" />
								<a href="javascript:void(0);" id=""></a><div style="display:none"></div>
							</label>
						</td>
						<td>
							<label>
								<input type="radio" name="goodsprotoid" value="" goodname="" />
								<a href="javascript:void(0);" id=""></a><div style="display:none"></div>
							</label>
						</td>
						<td>
							<label>
								<input type="radio" name="goodsprotoid" value="" goodname="" />
								<a href="javascript:void(0);" id=""></a><div style="display:none"></div>
							</label>
						</td>
					</tr>
				</table>
			</div>
		</div>
	</div>
	
	<div id="_templateCardsSelectShowInfo">
		<div id="widget_cardsselectshowinfo">
			<div name="datadiv" style="overflow-y:scroll; float:left;">
				<table name="datatable" cellpadding="2" cellspacing="1" align="center" width="100%" class="table">
					<tr>
						<td>
							<label>
								<input type="radio" name="goodsprotoid" value="" goodname="" />
								<a href="javascript:void(0);" id=""></a><div style="display:none"></div>
							</label>
						</td>
						<td>
							<label>
								<input type="radio" name="goodsprotoid" value="" goodname="" />
								<a href="javascript:void(0);" id=""></a><div style="display:none"></div>
							</label>
						</td>
						<td>
							<label>
								<input type="radio" name="goodsprotoid" value="" goodname="" />
								<a href="javascript:void(0);" id=""></a><div style="display:none"></div>
							</label>
						</td>
						<td>
							<label>
								<input type="radio" name="goodsprotoid" value="" goodname="" />
								<a href="javascript:void(0);" id=""></a><div style="display:none"></div>
							</label>
						</td>
						<td>
							<label>
								<input type="radio" name="goodsprotoid" value="" goodname="" />
								<a href="javascript:void(0);" id=""></a><div style="display:none"></div>
							</label>
						</td>
						<td>
							<label>
								<input type="radio" name="goodsprotoid" value="" goodname="" />
								<a href="javascript:void(0);" id=""></a><div style="display:none"></div>
							</label>
						</td>
					</tr>
				</table>
			</div>
		</div>
	</div>
	
	<div id="_templateSendSysMailInfo">
		<div id="widget_sendsysmailinfo">
			<div name="datadiv" style="overflow-y:scroll; float:left;">
				<table name="datatable" cellpadding="2" cellspacing="1" align="center" width="100%" class="table">
					<tr>
						<td width="30%" name="name" align="right"></td>
						<td name="data"></td>
					</tr>
				</table>
			</div>
		</div>
	</div>
</body>
</html>
