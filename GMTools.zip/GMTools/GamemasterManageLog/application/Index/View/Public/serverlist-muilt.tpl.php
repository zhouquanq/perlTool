<?php 
	$facadelist = Moby_Mgrsvr_Index_Model_Game::getSvrAndFac(); 
?>
<script type="text/javascript">
	
	function serverlist_muilt_select(){
		$('[name="serverids[]"]').each( function() {
			if( $('[name="serveridall"]').attr( 'checked')) {
				$(this).attr( 'checked', 'checked');
			} 
			else {
				$(this).removeAttr( 'checked');
			}
		});
	}
</script>
<table width="680" border="0" align="center" cellpadding="2" cellspacing="1" class="table">
	<?php if( $facadelist) { ?>
    <tr>
      <td width="30%" align="right">
    <label><input type="checkbox" name="serveridall" value="" onclick="serverlist_muilt_select()" /><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADDEXP_VERIFY_Server'); ?></label>:</td>
      <td align="left">
      	<?php $serverids = $this->_http->getParam( 'serverids', array()); ?>
      	<?php $serverids = is_array($serverids)?$serverids:array($serverids);?>
          <?php foreach( $facadelist as $svrid=>$item) { ?>
	          <?php if( is_array( $serverids) && in_array( $svrid, $serverids)) { ?>
	          	<label><input type="checkbox" name="serverids[]" value="<?php echo $svrid; ?>" checked="checked" /><?php echo $item['fullname']; ?></label><br />
	      	  <?php } else { ?>
	      	  	<label><input type="checkbox" name="serverids[]" value="<?php echo $svrid; ?>" /><?php echo $item['fullname']; ?></label><br />
	      	  <?php } ?>
          <?php } ?>
      </td>
    </tr>
	<?php } else { ?>
	<tr>
		<td colspan="2" align="center">
			<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_NOTICE_NOSERVER'); ?>
		</td>
	</tr>
	<?php } ?>
</table>