<?php 
	$facadelist = Moby_Mgrsvr_Index_Model_Game::getSvrAndFac(); 
?>
<table width="680" border="0" align="center" cellpadding="2" cellspacing="1" class="table">
	<?php if( $facadelist) { ?>
    <tr>
      <td width="30%" align="right"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADDEXP_VERIFY_Server'); ?>:</td>
      <td align="left">
      	<?php $serverid = $this->_http->getParam( 'serverid'); ?>
          <?php foreach( $facadelist as $svrid=>$item) { ?>
	          <?php if( $serverid && $serverid == $svrid) { ?>
	          	<label><input type="radio" name="serverid" value="<?php echo $svrid; ?>" checked="checked" /><?php echo $item['fullname']; ?></label><br />
	      	  <?php } else { ?>
	      	  	<label><input type="radio" name="serverid" value="<?php echo $svrid; ?>" /><?php echo $item['fullname']; ?></label><br />
	      	  <?php } ?>
          <?php } ?>
      </td>
    </tr>
	<?php } else { ?>
	<tr>
		<td colspan="2" align="center">
			<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_NOTICE_NOSERVER'); ?>
		</td>
	</tr>
	<?php } ?>
</table>