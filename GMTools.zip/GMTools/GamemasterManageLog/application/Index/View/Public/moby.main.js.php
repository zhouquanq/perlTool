<script type="text/javascript">
	
	$(document).ready( function(){
		
		var MobyMgrSvrApp = {
			msg:{
				show: function( msg) {
					if( msg) {
						var $dialogmsg = $( '<div>'+msg+'</div>');
						$dialogmsg.dialog({
							autoOpen: false,
							draggable: false,
							resizable: false,
							width: 400,
							show: { effect: 'drop'} ,
							hide: { effect: 'drop'},
							buttons: { "Ok": function() {
									$(this).dialog("close");
							}},
							open: function( event, ui) { window.setTimeout( function() {
									$dialogmsg.dialog("close");
							}, 3000 );}
						});
						
						$dialogmsg.dialog("open");
					}
				}
			},
			template:{
				getById: function( id, cb) {
					if( !id) {
						return "";
					}
					return $("#template").contents().find( "#"+id).html() || "";
				}
			},
			goods:{
				getNameById: function( protoid, cb) {
					var url	= 'http://'+location.host+'/index.php?data/goods/getGoodSimpleInfoById/id/'+protoid;
					if( cb) {
						$.getJSON( url, function( data){ cb( data);});
					}
				},
				selectitem: function( cb) {
					var $this = $(this);
					var url	= 'http://'+location.host+'/index.php?data/goods/typelist';
					
					$.getJSON( url, function( data){
						var goodstypelist = data;
						var _templateGoodsSelectShowInfo = top.MobyMgrSvrApp.template.getById( '_templateGoodsSelectShowInfo');
						var $showinfo = $( _templateGoodsSelectShowInfo);
						var $titlecol = $showinfo.find("a[name='selectgoodstype']").parent();
						var _templateTitleItem = $showinfo.find("a[name='selectgoodstype']").parent().html();
						var _timelateDataTableRow = $showinfo.find( "table[name='datatable']").html();
						$titlecol.empty();
						for( var itemtype in goodstypelist) {
							var $item = $( _templateTitleItem);
							$item.attr( "type", itemtype);
							$item.text( '['+goodstypelist[itemtype]+']');
							$titlecol.append($item);
						}
						
						$showinfo.find( "div[name='titlediv']").width( 840);
						$showinfo.find( "div[name='datadiv']").width( 840);
						$showinfo.find( "div[name='datadiv']").height( 345);
						
						$showinfo.dialog({
							modal: true,
							autoOpen: false,
							draggable: false,
							resizable: false,
							width: 900,
							height: 500,
							zIndex: 50,
							show: { effect: 'drop', direction: "up" } ,
							hide: { effect: 'drop', direction: "down" },
							buttons: { "Ok": function() {
								//获取物品名称和id
					  			var selectgood;
					  			$showinfo.find("input[type='radio']").each( function() {
					  				if($(this).attr('checked')) {
					  					selectgood = {
					  						"id":$(this).val(),
					  						"name":$(this).attr("goodname")
					  					};
					  				}
					  			});
					  			if( selectgood && cb) {
						  			cb( selectgood);
						  		}
								$showinfo.dialog("close");
							}}
					  	});
					  	
					  	//选择物品类型
				  		$showinfo.find("[name='selectgoodstype']").bind( 'click', function() {
				  			var $this = $(this);
				  			var type = $this.attr('type');
				  			var url	= 'http://'+location.host+'/index.php?data/goods/listbytp/type/'+type;	
				  			
				  			$.getJSON( url, function( data){
				  				var goodslist = data;
				  				var $table = $showinfo.find( "table[name='datatable']");
								var i=0;
								var $row = $( _timelateDataTableRow);
								var columncount = $row.find('td').size();
								$table.empty();
								
								var rowcount = 0;
						  		for( var item in goodslist) {
					  				if( i % columncount == 0 && i != 0) {
					  					$table.append( $row);
						  				$row = $( _timelateDataTableRow);
						  				i = 0;
						  				rowcount++;
						  			}
						  			var desc = typeof goodslist[item].showinfo === 'object' 
						  				? goodslist[item].showinfo.join( '<br />\n')
						  				: goodslist[item].showinfo;
						  			var $col = $($row.find('td').get(i));
						  			$col.find('input[name="goodsprotoid"]')
						  				.val( goodslist[item].id)
						  				.attr( 'goodname', goodslist[item].descname);
						  			$col.find('a')
						  				.attr( 'id', goodslist[item].id).
						  				text( goodslist[item].descname);
						  			$col.find('div').html( desc);
						  			++i;
						  		}
						  		if( rowcount > 0 || i > 0) {
						  			for( var coli = i; coli < columncount; coli++) {
						  				$($row.find('td').get(coli)).text( "--");
						  			}
								  	$table.append( $row);
								}
							  	$table.find( "a").bind( {
							  		"mouseover": function() {
							  			var $this = $(this);
								  		var id = $(this).attr("id");
								  		var result = $this.next().html();
										MobyMgrSvrApp.widget.showinfo.show( 
											'showgoodsiteminfo', 
											result, 
											{
												left: $this.offset().left, 
												top: $this.offset().top,
												width: $this.width(),
												height: $this.height()
											},
											document
										);
							  		},
							  		"mouseout": function() {
							  			MobyMgrSvrApp.widget.showinfo.remove( 'showgoodsiteminfo', document);
							  		}
							  	});
							  	
						  		$showinfo.find("div[name='data']").append( $table);
						  		$showinfo.dialog( "open");
						  	});
				  		});
				  		$showinfo.find("[name='selectgoodstype']").get(2).click();
				  	});
				},
				bindSelect: function( event) {
					top.MobyMgrSvrApp.goods.selectitem( event.data.cb);
				}
			},
			cards:{
				getNameById: function( protoid, cb) {
					var url	= 'http://'+location.host+'/index.php?data/cards/getCardSimpleInfoById/id/'+protoid;
					if( cb) {
						$.getJSON( url, function( data){ cb( data);});
					}
				},
				selectitem: function( cb) {
					
					var _templateGoodsSelectShowInfo = top.MobyMgrSvrApp.template.getById( '_templateCardsSelectShowInfo');
					var $showinfo = $( _templateGoodsSelectShowInfo);
					
					var _timelateDataTableRow = $showinfo.find( "table[name='datatable']").html();
					
					$showinfo.find( "div[name='datadiv']").width( 840);
					$showinfo.find( "div[name='datadiv']").height( 345);
					
					$showinfo.dialog({
						modal: true,
						autoOpen: false,
						draggable: false,
						resizable: false,
						width: 900,
						height: 500,
						zIndex: 50,
						show: { effect: 'drop', direction: "up" } ,
						hide: { effect: 'drop', direction: "down" },
						buttons: { "Ok": function() {
							//获取物品名称和id
				  			var selectgood;
				  			$showinfo.find("input[type='radio']").each( function() {
				  				if($(this).attr('checked')) {
				  					selectgood = {
				  						"id":$(this).val(),
				  						"name":$(this).attr("goodname")
				  					};
				  				}
				  			});
				  			if( selectgood && cb) {
					  			cb( selectgood);
					  		}
							$showinfo.dialog("close");
						}}
				  	});
				  	
				  	
		  			var url	= 'http://'+location.host+'/index.php?data/cards/list';	
		  			
		  			$.getJSON( url, function( data){
		  				var goodslist = data;
		  				var $table = $showinfo.find( "table[name='datatable']");
						var i=0;
						var $row = $( _timelateDataTableRow);
						var columncount = $row.find('td').size();
						$table.empty();
						
						var rowcount = 0;
				  		for( var item in goodslist) {
			  				if( i % columncount == 0 && i != 0) {
			  					$table.append( $row);
				  				$row = $( _timelateDataTableRow);
				  				i = 0;
				  				rowcount++;
				  			}
				  			var desc = typeof goodslist[item].showinfo === 'object' 
				  				? goodslist[item].showinfo.join( '<br />\n')
				  				: goodslist[item].showinfo;
				  			var $col = $($row.find('td').get(i));
				  			$col.find('input[name="goodsprotoid"]')
				  				.val( goodslist[item].id)
				  				.attr( 'goodname', goodslist[item].descname);
				  			$col.find('a')
				  				.attr( 'id', goodslist[item].id).
				  				text( goodslist[item].descname);
				  			$col.find('div').html( desc);
				  			++i;
				  		}
				  		if( rowcount > 0 || i > 0) {
				  			for( var coli = i; coli < columncount; coli++) {
				  				$($row.find('td').get(coli)).text( "--");
				  			}
						  	$table.append( $row);
						}
					  	$table.find( "a").bind( {
					  		"mouseover": function() {
					  			var $this = $(this);
						  		var id = $(this).attr("id");
						  		var result = $this.next().html();
								MobyMgrSvrApp.widget.showinfo.show( 
									'showgoodsiteminfo', 
									result, 
									{
										left: $this.offset().left, 
										top: $this.offset().top,
										width: $this.width(),
										height: $this.height()
									},
									document
								);
					  		},
					  		"mouseout": function() {
					  			MobyMgrSvrApp.widget.showinfo.remove( 'showgoodsiteminfo', document);
					  		}
					  	});
					  	
				  		$showinfo.find("div[name='data']").append( $table);
				  		$showinfo.dialog( "open");
				  	});
				},
				bindSelect: function( event) {
					top.MobyMgrSvrApp.cards.selectitem( event.data.cb);
				}
			},
			sendmail:{
				desc:function( info) {
					var _templateGoodsSelectShowInfo = top.MobyMgrSvrApp.template.getById( '_templateSendSysMailInfo');
					var $showinfo = $( _templateGoodsSelectShowInfo);
					$showinfo.find( "div[name='datadiv']").width( 470);
					$showinfo.find( "div[name='datadiv']").height( 305);
					$showinfo.dialog({
						modal: true,
						autoOpen: false,
						draggable: false,
						resizable: false,
						width: 500,
						zIndex: 50,
						show: { effect: 'drop', direction: "up" } ,
						hide: { effect: 'drop', direction: "down" },
						buttons: { "Ok": function() {
							$showinfo.dialog( 'close');
						}}
					});
					var $table = $showinfo.find( "table[name='datatable']");
					var rowhtml = $table.html();
					$table.empty();
					
					for( var i in info) {
						var $row = $(rowhtml);
						var rowTmp = info[i];
						if( rowTmp['key']) {
							$row.find( "[name='name']").html( rowTmp['key']);
							$row.find( "[name='data']").html( rowTmp['value']);
						}
						else {
							$row.find( "[name='data']").html( rowTmp['value']);
						}
						$table.append( $row);
					}
					$showinfo.dialog('open');
				}
			},
			widget:{
				showinfo: {
					show:function( id, html, elementattr, document_) {
						MobyMgrSvrApp.widget.showinfo.remove( id);
						if( !id || !html) {
							return;
						}
						id = 'widget_'+id;
						var $showgoodsiteminfo = $( '<div name="'+id+'"></div>');
						$showgoodsiteminfo.css( {
							'line-height':'22px',
							'padding':'5px'
						});
				  		$showgoodsiteminfo.html( html);
				  		$showgoodsiteminfo.hide();
				  		$(document_).find('body').append( $showgoodsiteminfo);
				  		if( $showgoodsiteminfo.width() > 300) {
				  			$showgoodsiteminfo.css( {
				  				"width":300
				  			});
				  		}
				  		var x = 0;
				  		if( elementattr.left < $showgoodsiteminfo.width() + elementattr.width + 10) {
					  		x = elementattr.left;
					  	} 
					  	else {
					  		x = elementattr.left - $showgoodsiteminfo.width() + elementattr.width;
					  	}
				  		var y = 0;
				  		if( top < $showgoodsiteminfo.height() + 10) {
				  			y = elementattr.top + height + 10;
				  		} 
				  		else {
				  			y = elementattr.top - $showgoodsiteminfo.height() - 10;
				  		}
				  		$showgoodsiteminfo.css({
				  			"top":y,"left":x, 
				  			"z-index":9901, 
				  			"position":"absolute", 
				  			"background-color":"#FFFFFF", 
				  			"border":"1px solid #000000"
				  		}); 
				  		var $iframe = $('<iframe name="'+id+'iframe" src="javascript:false;" scrolling="no" frameborder="0" ></iframe>');
				  		$iframe.css({
				  			"top":y,"left":x, 
				  			"z-index":9900, 
				  			"position":"absolute", 
				  			"background-color":"#FFFFFF", 
				  			"border":"0px",
				  			"width":$showgoodsiteminfo.width(),
				  			"height":$showgoodsiteminfo.height()
				  		});
				  		$(document_).find('body').append( $iframe);
				  		$showgoodsiteminfo.show();
					},
					remove: function( id, document_) {
						if( !id) {
							return;
						}
						id = 'widget_'+id;
						if( $(document_).find("div[name='"+id+"']").size()) {
							$(document_).find("div[name='"+id+"']").remove();
						}
						if( $(document_).find("iframe[name='"+id+"iframe']").size()) {
							$(document_).find("iframe[name='"+id+"iframe']").remove();
						}
					}
				}
			}
		};
		window["MobyMgrSvrApp"] = MobyMgrSvrApp;
	});
</script>