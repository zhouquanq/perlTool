<?php 
/* page->count:总页数
 * page->curr:当前页号
 * page->next:下页号,0代表无
 * page->prev:上页号,0代表无
 * page->last:尾页号
 * 
 * page->list: 超链接数字页号列表
 * page->listmin:最小超链接数字页号
 * page->listmax:最大超链接数字页号
 */
$pages = $this->get('pages');

if($pages && $pages->last > 1) {
	
	//获取本页的请求参数
	$urlParam = $this->get('urlParams');
	
	echo '('.$this->getLang()->get( 'APP_INDEX_VIEW_PUBLIC_PAGE_1').$pages->curr.'/'.$this->getLang()->get( 'APP_INDEX_VIEW_PUBLIC_PAGE_2').$pages->last.')';
	
	//前翻
	if( $pages->prev) {		
		$urlParam['page']=1;
		$path = $this->_http->encode( null, null, null, $urlParam);
		echo '<a href="'.$path.'">['.$this->getLang()->get( 'APP_INDEX_VIEW_PUBLIC_PAGE_3').']</a>';
		
		$urlParam['page']=$pages->prev;
		$path = $this->_http->encode( null, null, null, $urlParam);
		echo '<a href="'.$path.'">['.$this->getLang()->get( 'APP_INDEX_VIEW_PUBLIC_PAGE_4').']</a>';
	} else {
		echo '['.$this->getLang()->get( 'APP_INDEX_VIEW_PUBLIC_PAGE_3').']';
		echo '['.$this->getLang()->get( 'APP_INDEX_VIEW_PUBLIC_PAGE_4').']';
	}
	
	//中间数字超链接列表
	if (count( $pages->list) > 0) {		
		foreach( $pages->list as $pageItem) {
			if( $pageItem == $pages->curr) {
				echo '[ <b>'.$pageItem.'</b> ]';
			} else {
				
				$urlParam['page']=$pageItem;
				$path = $this->_http->encode( null, null, null, $urlParam);
				echo '<a href="'.$path.'">[ '.$pageItem.' ]</a>';
			}
		}
	}
	
	//后翻
	if( $pages->next) {		
		$urlParam['page']=$pages->next;
		$path = $this->_http->encode( null, null, null, $urlParam);
		echo '<a href="'.$path.'">['.$this->getLang()->get( 'APP_INDEX_VIEW_PUBLIC_PAGE_5').']</a>';
		
		$urlParam['page']=$pages->last;
		$path = $this->_http->encode( null, null, null, $urlParam);
		echo '<a href="'.$path.'">['.$this->getLang()->get( 'APP_INDEX_VIEW_PUBLIC_PAGE_6').']</a>';
	} else {
		echo '['.$this->getLang()->get( 'APP_INDEX_VIEW_PUBLIC_PAGE_5').']';
		echo '['.$this->getLang()->get( 'APP_INDEX_VIEW_PUBLIC_PAGE_6').']';
	}
	
	//下拉列表框
	unset($urlParam['page']);
	$path = $this->_http->encode( null);	
	echo '<form action="'.$path.'" method="post" style="display:inline;">';
	foreach( $urlParam as $paramkey=>$paramvalue) {
		echo '<input type="hidden" name="'.$paramkey.'" value="'.$paramvalue.'" />';
	}
	
	echo '<select name="page" >';
	
	for( $i=1; $i<=$pages->last; $i++) {
		if( $pages->curr == $i) {
			echo '<option value="'.$i.'" selected="selected">'.$i.'</option>';
		} else {
			echo '<option value="'.$i.'">'.$i.'</option>';
		}
	}
	
	echo '</select>';
	echo '<input type="submit" value='.$this->getLang()->get( 'APP_INDEX_VIEW_PUBLIC_PAGE_7').' class="button"/>';
	echo '</form>';
}