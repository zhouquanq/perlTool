<script type="text/javascript">
	
	$(document).ready(function(){
		var msg = "<?php echo str_replace( array( "\\", "\r\n", "\n"),  array( "/", "<br />", "<br />"), $this->get('msg'));?>";
		
		top.MobyMgrSvrApp.msg.show( msg);
	}); 

</script>