<script type="text/javascript">
	
	$(document).ready(function(){
		var $body = $(document.body);
		$body.find('>table').css( 'width', $body.width())
		$body.find('>form>table').css( 'width', $body.width());
	}); 

</script>