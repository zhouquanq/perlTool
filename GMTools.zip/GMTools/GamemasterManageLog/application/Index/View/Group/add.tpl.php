<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_ADD_Welcome'); ?>
</title>
<link href="/css/moby.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.form.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.table.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="/js/jquery.js"></script>
<script type="text/javascript" src="/js/checkbox.js"></script>
<?php $this->display( 'Index/View/Public/moby.notice.php'); ?>
</head>
<body>
<form action="<?php echo $this->_http->encode( null); ?>" method="post">
<table width="680" border="0" align="center" cellpadding="2" cellspacing="1" class="table">
    <tr>
      	<th class="bg_tr" align="center" colspan="3" height="25">
      		<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_ADD_1'); ?>
		</th>
    </tr>
    <tr>
      	<td width="30%" align="right">
      		<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_ADD_2'); ?>:
		</td>
      	<td width="40%">
      		<input name="name" type="text" class="text" id="name"size="32" maxlength="32" />
      	</td>
      	<td>&nbsp;</td>
    </tr>
    <tr>
      	<td align="right">
      		<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_ADD_3'); ?>:
      	</td>
      	<td align="left">
      	<?php
			$format = array();
			$treeStack = array( $this->get( 'powerTree'));
			while( $powerTree = array_pop( $treeStack)) {
				if( count( $treeStack) == 1) {
					array_push( $format, '---');
				}
				while( $power = array_shift( $powerTree)) {
					array_push( $format, '---');
					echo implode( '', $format); 
					if (!empty( $power['sublist'])) {
						echo '<span>';
						
						echo '<label><input type="checkbox" name="powerids['.$power['id'].'][]" value="1" />';
						echo $this->decodeToDb( $power['name']);
						echo '</label>';
						
						echo '</span>';
						echo "<br />\n";
						// 如果有子子节点则继续调用自身方法进行循环。
						if( !empty( $powerTree)) {
							array_push( $treeStack, $powerTree);
						}
						array_push( $treeStack, $power['sublist']);
						array_shift( $format);
						break;
					} else {
						echo '<span>';
						
						echo '<label><input type="checkbox" name="powerids['.$power['id'].'][]" value="1" />';
						echo $this->decodeToDb( $power['name']);
						echo '</label>';
						
						echo "</span>\n";
						echo "<br />\n";
						array_shift( $format);
					}
				}
				if( count( $treeStack) == 1) {
					array_shift( $format);				
				}
			}
		?>
		</td>
      	<td align="left">
      		<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_ADD_4'); ?>
		</td>
    </tr>
    <tr>
      	<td align="right">
      		<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_ADD_5'); ?>:
      	</td>
      	<td align="left">
	      	<label>
	      		<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_ADD_6'); ?>
				<input name="islock" type="radio" id="islock" value="0" checked="checked" />
	      	</label>
	      	<label>
	      		<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_ADD_7'); ?>
				<input type="radio" name="islock" id="islock" value="1" />
	      	</label>
      	</td>
      	<td align="left">&nbsp;</td>
    </tr>
    <tr>
      <td  colspan="3" align="center">
	      <input type="submit" name="submit" class="button" value="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_LIST_3'); ?>" />
	      <input type="reset" name="reset" class="button" value="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADDEXP_VERIFY_Cancel'); ?>" />
      </td>
    </tr>
</table>
</form>
</body>
</html>
