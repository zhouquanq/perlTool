<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_LIST_1'); ?>
</title>
<link href="/css/moby.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.form.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.table.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="/js/jquery.js"></script>
<?php $this->display( 'Index/View/Public/moby.notice.php'); ?>
</head>
<body>

<table width="680" border="0" align="center" cellpadding="2" cellspacing="1" class="table">
    <tr>
      <th class="bg_tr" align="center" colspan="8" height="25"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_LIST_1'); ?>
</th>
    </tr>
</table>
<form action="<?php echo $this->_http->encode( null); ?>" method="post">
<table width="680" border="0" align="center" cellpadding="2" cellspacing="1" class="table">
    <tr>
      <td width="30%" align="right"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_LIST_2'); ?>
:</td>
      <td width="40%"><input name="name" type="text" id="name" value="<?php echo $this->httpquote( $this->_http->getParam('name')); ?>" size="32" maxlength="32" class="text" /></td>
      <td><input type="submit" name="button" id="button" value="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_REMOVELIST_Submit'); ?>
" class="button" /></td>
    </tr>
</table>
</form>
<table width="680" border="0" align="center" cellpadding="2" cellspacing="1" class="table">
    <tr>
      <td colspan="4">
    <a href="<?php echo $this->_http->encode( 'add');?>"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_LIST_3'); ?>
</a>    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="center"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_LIST_2'); ?>
</td>
      <td align="center"><?php echo $this->getLang()->get( 'APP_INDEX_CONTROLLER_PAYRECORD_Array7'); ?>
</td>
      <td align="center"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_LIST_Operate'); ?>
</td>
    </tr>
    <?php if( $this->get( 'result')) { ?>
    <?php $is_odd = false; ?>
    <?php foreach( $this->get( 'result') as $item) { ?>
    <tr class="<?php echo $is_odd ? 'odd' : 'even'; $is_odd = $is_odd ? false : true;?>">
      <td height="23"><input name="groupid" type="checkbox" id="groupid" value="<?php echo $item['ag_id']; ?>" /></td>
      <td><?php echo $item['ag_name']; ?></td>
      <td><?php echo $item['ag_islock'] ? $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_LIST_Unlock') : $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_LIST_4');?></td>
      <td>
          <a href="<?php echo $this->_http->encode( 'modify', null, null, array( 'groupid'=>$item['ag_id']));?>"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_LIST_Modify'); ?>
</a></td>
    </tr>
    <?php } ?>
    <?php } else { ?>
    <tr>
      <td height="23" colspan="4"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_LIST_NoGroup'); ?>
</td>
    </tr>
    <?php } ?>
    <tr>
      <td  colspan="4" align="right"><?php $this->display( 'Index/View/Public/page.tpl.php')?></td>
    </tr>
</table>

</body>
</html>
