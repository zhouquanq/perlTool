<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_LIST_AdminList'); ?></title>
<link href="/css/moby.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.form.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.table.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="/js/jquery.js"></script>
<?php $this->display( 'Index/View/Public/moby.notice.php'); ?>
</head>
<body>

<table width="680" border="0" align="center" cellpadding="2" cellspacing="1" class="table">
    <tr>
      <th class="bg_tr" align="center" colspan="8" height="25"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_LIST_AdminList'); ?></th>
    </tr>
</table>
<form action="<?php echo $this->_http->encode( null); ?>" method="post">
<table width="680" border="0" align="center" cellpadding="2" cellspacing="1" class="table">
    <tr>
      <td width="30%" align="right"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_LIST_ID'); ?>:</td>
      <td><input name="account" type="text" id="account" value="<?php echo $this->httpquote( $this->_http->getParam('account')); ?>" size="32" maxlength="32" class="text" /></td>
    </tr>
    <tr>
      <td align="right"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_ADD_UserGroup'); ?>:</td>
      <td>
      	<?php $grouplist = $this->get('grouplist'); ?>
      	<?php if( $grouplist) {?>
      	<select name="groupid">
      		<?php foreach( $grouplist as $item) { ?>
      			<option value="0"><?php echo $this->getLang()->get( 'APP_INDEX_CONTROLLER_ADDEXP_HaveNone'); ?></option>
      			<?php if( $item['ag_id'] == $this->_http->getParam('groupid')) {?>
      				<option value="<?php echo $item['ag_id'];?>" selected="selected"><?php echo $item['ag_name']; ?></option>
      			<?php } else { ?>
      				<option value="<?php echo $item['ag_id'];?>"><?php echo $item['ag_name']; ?></option>
      			<?php }?>
      		<?php }	?>
      	</select>
      	<?php } else {?>
      		<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_LIST_NoGroup'); ?>
      	<?php } ?>
      </td>
    </tr>
    <tr>
      <td colspan="2" align="center"><input type="submit" name="button" id="button" value="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_REMOVELIST_Submit'); ?>" class="button" /></td>
    </tr>
</table>
</form>
<table width="680" border="0" align="center" cellpadding="2" cellspacing="1" class="table">
    <tr>
      <td colspan="8">
    <a href="<?php echo $this->_http->encode( 'add', 'admin', 'index');?>"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_LIST_3'); ?></a></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_LIST_ID'); ?></td>
      <td><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_LIST_Remark'); ?></td>
      <td><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_LIST_LastTime'); ?></td>
      <td><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_LIST_LastIP'); ?></td>
      <td><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_LIST_CreateTime'); ?></td>
      <td><?php echo $this->getLang()->get( 'APP_INDEX_CONTROLLER_PAYRECORD_Array7'); ?></td>
      <td><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_LIST_Operate'); ?></td>
    </tr>
    <?php if( $this->get( 'result')) { ?>
    <?php $is_odd = false; ?>
    <?php foreach( $this->get( 'result') as $entityAdminItem) { ?>
    <tr class="<?php echo $is_odd ? 'odd' : 'even'; $is_odd = $is_odd ? false : true;?>">
      <td height="23"><input type="checkbox" name="accountid" value="<?php echo $entityAdminItem->getAccountid(); ?>" /></td>
      <td><?php echo $entityAdminItem->getAccount(); ?></td>
      <td><?php echo $entityAdminItem->getRealName(); ?></td>
      <td><?php echo date( 'Y-m-d H:i:s', $entityAdminItem->getLastLoginTime()); ?></td>
      <td><?php echo $entityAdminItem->getLastip(); ?></td>
      <td><?php echo date( 'Y-m-d H:i:s', $entityAdminItem->getRegTime()); ?></td>
      <td><?php echo $entityAdminItem->getLock() ? $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_LIST_Unlock'): $this->getLang()->get( 'APP_INDEX_VIEW_GROUP_LIST_4'); ?></td>
      <td>
          <a href="<?php echo $this->_http->encode( 'modify', 'admin', 'index', array( 'accountid'=>$entityAdminItem->getAccountid()));?>"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_LIST_Modify'); ?></a>|
          <?php if( $entityAdminItem->getLock()) { ?>
          <a href="<?php echo $this->_http->encode( 'unlock', 'admin', 'index', array( 'accountid'=>$entityAdminItem->getAccountid()));?>"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_LIST_Lock'); ?></a>      
          <?php } else { ?>
          <a href="<?php echo $this->_http->encode( 'lockout', 'admin', 'index', array( 'accountid'=>$entityAdminItem->getAccountid()));?>"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_LIST_Unlock'); ?></a>      
          <?php } ?>
      </td>
    </tr>
    <?php } ?>
    <?php } else { ?>
    <tr>
      <td height="23" colspan="8"><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_LIST_NoAdmin'); ?></td>
    </tr>
    <?php } ?>
    <tr>
      <td  colspan="8" align="right"><?php $this->display( 'Index/View/Public/page.tpl.php')?></td>
    </tr>
</table>

</body>
</html>
