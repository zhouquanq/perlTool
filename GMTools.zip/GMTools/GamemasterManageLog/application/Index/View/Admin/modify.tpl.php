<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_ADD_Welcome'); ?></title>
<link href="/css/moby.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.form.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.table.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="/js/jquery.js"></script>
<script type="text/javascript" src="/js/checkbox.js"></script>
<?php $this->display( 'Index/View/Public/moby.notice.php'); ?>
</head>
<body>
<form action="<?php echo $this->_http->encode( 'modify', 'admin'); ?>" method="post">
<?php $entityAdmin = $this->get('entityAdmin'); ?>
<table width="680" border="0" align="center" cellpadding="2" cellspacing="1" class="table">
    <tr>
      <th class="bg_tr" align="center" colspan="2" height="25">
<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_MODIFY_Msg'); ?></th>
    </tr>
    <tr>
      <td align="right">
<?php echo $this->getLang()->get( 'APP_CONF_POWERS_ACCOUNT__NAME'); ?>:</td>
      <td><?php echo $entityAdmin->getAccount(); ?><input type="hidden" name="accountid" id="accountid" value="<?php echo $entityAdmin->getAccountid(); ?>" /></td>
    </tr>
    <tr>
      <td width="30%" align="right">      
<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_SETPASS_UserPwd'); ?>:</td>
      <td><input name="passwd" type="password" class="text" size="32" /></td>
    </tr>
    <tr>
      <td align="right">
<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_SETPASS_ConfPwd'); ?>:</td>
      <td><input name="confirmwd" type="password" class="text" size="32" /></td>
    </tr>
    <tr>
      <td align="right">
<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_ADD_TrueName'); ?>:</td>
      <td><input name="realname" type="text" class="text" size="32" value="<?php echo $this->httpquote( $entityAdmin->getRealName()); ?>" /></td>
    </tr>
    <tr>
      <td align="right"></td>
      <td align="left"></td>
    </tr>
    <tr>
    	<td align="right">
        	<input type="checkbox" name="grouplist[]" value="all" class="chk-all-pub" />
			<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_ADD_UserGroup'); ?>:
        </td>
    	<td align="left">
        	<?php
        	$grouplist = $this->get('grouplist');
        	$usrgroupidlist = $this->get('usrgroupidlist');
        	if( $grouplist) {
        		if( $usrgroupidlist) {
					foreach ( $grouplist as $item) { ?>
						<label>
							<?php if( in_array( $item['ag_id'], $usrgroupidlist)) { ?>
								<input type="checkbox" name="grouplist[]" value="<?php echo $item['ag_id'] ?>" checked="checked" />
							<?php } else { ?>
								<input type="checkbox" name="grouplist[]" value="<?php echo $item['ag_id'] ?>" />
							<?php } ?>
							<?php echo $this->decodeToDB( $item['ag_name']); ?>
						</label>
					<?php }
        		} else {
        			foreach ( $grouplist as $item) { ?>
						<label>
							<input type="checkbox" name="grouplist[]" value="<?php echo $item['ag_id'] ?>" />
							<?php echo $this->decodeToDB( $item['ag_name']); ?>
						</label>
					<?php }
        		}
        	} else { ?>
        		(<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADMIN_ADD_AddGroup'); ?>)
        	<?php } ?>
        </td>
    </tr>
    <tr>
      <td  colspan="2" align="center">
      <input type="submit" name="submit" class="button" value="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ACCOUNT_LIST_Modify'); ?>" />
      <input type="reset" name="reset" class="button" value="<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ADDEXP_VERIFY_Cancel'); ?>" /></td>
    </tr>
</table>
</form>
</body>
</html>
