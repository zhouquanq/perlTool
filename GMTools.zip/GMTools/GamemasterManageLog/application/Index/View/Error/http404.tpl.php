<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>
<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ERROR_HTTP404_Title'); ?></title>
<link href="/css/moby.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.form.css" rel="stylesheet" type="text/css" />
<link href="/css/moby.table.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="/js/jquery.js"></script>
<?php $this->display( 'Index/View/Public/moby.notice.php'); ?>
</head>
<body style="vertical-align:middle;">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="500">
    <table width="300" border="0" align="center" cellpadding="0" cellspacing="0" >
      <tr>
        <td align="center"  style="color:#B8D3F1;"><font style="font-weight:900; font-size:25px; ">
<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ERROR_HTTP404_NoPage'); ?></font></td>
      </tr>
      <tr>
        <td align="center"  style="color:#B8D3F1;"><font style="font-weight:900; font-size:100px; ">404</font></td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</body>
</html>
