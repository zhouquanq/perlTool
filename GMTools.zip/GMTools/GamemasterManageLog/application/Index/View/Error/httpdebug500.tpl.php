<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>
<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_SYSMSG_VERIFYLIST_1'); ?></title>

</head>
<body>
<?php $exception = $this->get('exception');?>

<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ERROR_HTTP500_Wrong'); ?>:<?php echo $exception->getMessage();?>&nbsp;<?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ERROR_HTTP500_Code'); ?>:<?php echo $exception->getCode();?><br /><?php echo $this->getLang()->get( 'APP_INDEX_VIEW_ERROR_HTTP500_Wrong'); ?>
<?php 
	foreach( $exception->getTrace() as $key=>$value) {
		$args = array();
		foreach( $value['args'] as $arg) {
			$args[] = var_export( $arg, true);
		}
		if( isset( $value['class'])) {
			printf( "#%s %s(%s) %s::%s(%s)<br />", $key, $value['file'], $value['line'], $value['class'], $value['function'], implode( ", ", $args));
		} else {
			printf( "#%s %s(%s) %s(%s)<br />", $key, $value['file'], $value['line'], $value['function'], implode( ", ", $args));
		}
	}
?>
</body>
</html>
