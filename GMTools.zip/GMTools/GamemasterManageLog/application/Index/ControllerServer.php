<?php

class Moby_Mgrsvr_Index_ControllerServer extends Moby_Mgrsvr_Index_ControllerPermValid {

	
	protected $serverid = null;
	
	public function __construct( $http) {
		parent::__construct( $http);
		
		$serverlist = Moby_Mgrsvr_Index_Model_Game::getSvrCfg();
		
		$serverid = $this->_http->getParam( 'serverid', null);
		if( is_null( $serverid) || !array_key_exists( $serverid, $serverlist)) {
			$message = $this->getLang()->get( 'APP_INDEX_ControllerServer_ChooseServer2');
			$this->assign( "requesturl", 
				$this->_http->encode( 
					$this->_http->getAction(), 
					$this->_http->getController(), 
					$this->_http->getModel(), 
					$this->_http->getParams()
				)
			);
			$this->display( 'Index/View/Main/serverlist.tpl.php');
			exit;
		}
		
		$this->serverid = $serverid;
	}
	
	/**
	 * 重定向时给游戏服务器加上server_id
	 * @param unknown_type $action
	 * @param unknown_type $controller
	 * @param unknown_type $model
	 * @param array $params
	 */
	public function _redirect( $action, $controller=null, $model=null, array $params=null) {
		if( empty($params)) {
			$params = array();
		}
		$params['serverid'] = $this->serverid;
		
		parent::_redirect( $action, $controller, $model, $params);
	}
	
}