<?php

class Moby_Mgrsvr_Index_ControllerPermValid extends Moby_Mgrsvr_Index_ControllerAuth {

	protected $msg = null;
	protected $accountid = 0;
	protected $accountInfo = null;
	protected $serverid = 0;
	
	public function __construct( $http) {
		parent::__construct( $http);
		
		if( $this->accountid != 1) {
			$modelAdmin = Moby_Mgrsvr_Index_Model_Admin::getInstance();
			try {
				$modelAdmin->isAllowController( 
					$this->accountid, 
					$http->getAction(), 
					$http->getController(), 
					$http->getModel()
				);
				
			} 
			catch( Exception $e) {
				$msg = $e->getMessage();
				
				$this->_redirect( 'welcome', 'main', 'index', array( 'msg'=>$msg));
			}
		}
	}
}