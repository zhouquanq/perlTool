<?php

class Moby_Mgrsvr_Index_Model_Admin {

	private static $_instance = null;

	public static function getInstance() {
		if( null === self::$_instance) {
			self::$_instance = new self( );
		}
		return self::$_instance;
	}

	public function __construct() {
		$this->adminaccount = new Moby_Mgrsvr_Index_Model_DbTable_Admin_Account();
	}

	/**
	 * 创建账号
	 * @param string $account 账号
	 * @param string $passwd 密码(加密前)
	 * @param string $realname 真实姓名
	 * @param array $powers 权限列表
	 *
	 * @return int|boolean 如果成功则返回刚刚创建的账号的id,否则返回false
	 */
	public function reg( $entityAdmin) {
		$accountInfo = $this->adminaccount->getByAccount( $entityAdmin->getAccount());
		if( !empty( $accountInfo)) {
			throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_ADMIN_IDExist'));
		}

		$data = array(
			'a_account'=>$entityAdmin->getAccount(),
			'a_password'=>$entityAdmin->getSavepass(),
			'a_realname'=>$entityAdmin->getRealName(),
			'a_lasttime'=>$entityAdmin->getLastLoginTime(),
			'a_addtime'=>$entityAdmin->getRegTime(),
			'a_lastip'=>$entityAdmin->getLastip(),
			'a_islock'=>$entityAdmin->getLock(),
			'a_powers'=>'',
			'a_session'=>$entityAdmin->getSessionid(),
		);

		$accountid = 0;
		try {
			$this->adminaccount->insert( $data);
			$accountid = $this->adminaccount->lastInsertId();
			$entityAdmin->setAccountid( $accountid);
			
			$this->setPowers( $entityAdmin);
			$this->setGroups( $entityAdmin);
		} catch( Exception $e) {
			throw new Exception( $e);
		}
		return $entityAdmin;
	}

	/**
	 * 账号登陆
	 * @param string $account 账号
	 * @param string $passwd 密码
	 *
	 * @return array 如果登陆成功返回用户信息,否则返回跑出异常
	 */
	public function login( $entityAdmin) {
		if( !$entityAdmin->getAccount() || !$entityAdmin->getSavepass()) {
			throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_ADMIN_IDPwdNotNull'));
		}

		$entityAdminQuery = $this->getEntityByAccount( $entityAdmin->getAccount());
		if( empty( $entityAdminQuery)) {
			throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_ADMIN_UserNameNotExist'));
		}

		if( $entityAdminQuery->getLock() > 0) {
			throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_ADMIN_IDIsLocked'));
		}

		if( $entityAdminQuery->getSavepass() != $entityAdmin->getSavepass()) {
			throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_ADMIN_PwdWrong'));
		}

		$entityAdmin->setAccountid( $entityAdminQuery->getAccountid());
		$this->modifyLogin( $entityAdmin);
		$entityAdminQuery->setLastLoginTime( $entityAdmin->getLastLoginTime())
						 ->setLastip( $entityAdmin->getLastip())
						 ->setSessionid( $entityAdmin->getSessionid());
		return $entityAdminQuery;
	}

	/**
	 * 更新登录信息
	 * @param int $id
	 * @param string $ip
	 */
	public function modifyLogin( $entityAdmin) {
		$data = array(
			'a_lasttime'=>$entityAdmin->getLastLoginTime(),
			'a_lastip'=>$entityAdmin->getLastip(),
			'a_session'=>$entityAdmin->getSessionid(),
		);
		return $this->adminaccount->modifyById( $entityAdmin->getAccountid(), $data);
	}

	/**
	 * 设置用户信息
	 * @param int $id
	 * @param string $entityAdmin 管理员实体
	 *
	 * @return boolean 返回是否修改成功
	 */
	public function setInfo( $entityAdmin) {
		$data = array();
		if( $entityAdmin->getSavepass()) {
			$data['a_password'] = $entityAdmin->getSavepass();
		}
		if( $entityAdmin->getRealName()) {
			$data['a_realname'] = $entityAdmin->getRealName();
		}

		try {
			$this->adminaccount->update( $data, array( 'a_id=?'=>$entityAdmin->getAccountid()));
			$this->setPowers( $entityAdmin);
			$this->setGroups( $entityAdmin);
			
		} catch( Exception $e) {
			throw new Exception( $e);
		}
		return true;
	}

	public function setPowers( $entityAdmin) {
		if( $entityAdmin->getPowerIds()) {
			$AdminAccountPower = new Moby_Mgrsvr_Index_Model_DbTable_Admin_AccountPower();
			//先删除
			$AdminAccountPower->delete( array( 'a_id=?'=>$entityAdmin->getAccountid()));
			//后重新插入
			$AdminAccountPower->addPower( $entityAdmin->getAccountid(), $entityAdmin->getPowerIds());
		}
	}
	
	public function setGroups( $entityAdmin) {
		if( $entityAdmin->getGroupIds()) {
			//用户组
			$dbTableAccGrp = new Moby_Mgrsvr_Index_Model_DbTable_Admin_AccountGroup();
			$dbTableAccGrp->remove( $entityAdmin->getAccountid());
			foreach( $entityAdmin->getGroupIds() as $groupid) {
				$dbTableAccGrp->add( $entityAdmin->getAccountid(), $groupid);
			}
		}
	}

	/**
	 * 查询用户信息根据id
	 * @param int $id 用户账号id
	 *
	 * @return array|boolean 如果用户才能在则返回用户信息,否则返回false
	 */
	public function getById( $id) {
		return $this->adminaccount->findById( $id);
	}


	/**
	 * 查询管理员列表(分页)
	 * @param string $pageindex 当前页
	 * @param string $pagecount 每页记录条数
	 * @param string $account 账号
	 */
	public function getList( $page, $account=null, $groupid=0) {
		$where = null;
		if( !empty( $account)) {
			$where['a_account like ?'] = "%$account%";
		}
		if( !empty( $groupid)) {
			$dbTableAccGrp = new Moby_Mgrsvr_Index_Model_DbTable_Admin_AccountGroup();
			$accountidlist = $dbTableAccGrp->getActList( $groupid);
			if( $accountidlist) {
				$where['a_id in( ?)']=$accountidlist;
			} else {
				$where['a_id = ?']=-1;
			}
		}
		$rowCount = $this->adminaccount->rowCount( $where);
		
		$resultlist = null; 
		$pages = null;
		if( $rowCount > 0) {
			$pages = Moby_Mgrsvr_Index_Model_Util::genPage( $page, $rowCount);
			$resultlist = $this->adminaccount->fetchAllByPage( $pages->curr, Moby_Mgrsvr_Index_Model_Util::$defaultPageSize, $where);
		} else {
			$pages = null;
			$resultlist = array();
		}
		$resultlist = new Moby_Mgrsvr_Index_Model_EntIter_Admin( $resultlist);
		return new Moby_Mgrsvr_Index_Model_DbTable_RecordSet( $rowCount, $resultlist, $pages);
	}

	/**
	 * 禁用管理员
	 * @param int $accountid
	 */
	public function lockout( $accountid) {
		if( empty( $accountid)) {
			throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_ADMIN_IDNotNull'));
		}
		return $this->adminaccount->update( array( 'a_islock'=>1), array( 'a_id=?'=>$accountid));
	}

	/**
	 * 解禁管理员
	 * @param int $accountid
	 */
	public function unlock( $accountid) {
		if( empty( $accountid)) {
			throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_ADMIN_IDNotNull'));
		}
		return $this->adminaccount->update( array( 'a_islock'=>0), array( 'a_id=?'=>$accountid));
	}

	/**
	 * 获取用户权限列表
	 * @param int $accountid
	 */
	public function getPowerList( $accountid) {
		$result = array();
		$AccountPower = new Moby_Mgrsvr_Index_Model_DbTable_Admin_AccountPower();
		$accountPoweridList = $AccountPower->getListByAccid( $accountid);
		foreach( $accountPoweridList as $powerid) {
			$result[$powerid] = 1;
		}
		return $result;
	}

	/**
	 * 获取左边的菜单栏根据用户的权限
	 * @param int $accountid
	 */
	public function getLeftMenuList( $accountid) {
		$AccountPower = new Moby_Mgrsvr_Index_Model_DbTable_Admin_AccountPower();
		$modelAdmGrp = new Moby_Mgrsvr_Index_Model_AdminGroup();
		$dbTableGrpPwr = new Moby_Mgrsvr_Index_Model_DbTable_Admin_GroupPower();
		$ModelNode = new Moby_Mgrsvr_Index_Model_Node();
		
		$result = array();
		$tmppowerlist = array();
		$powerlist = array();
		
		if( 1 == $accountid) {
			$powerlist = $ModelNode->getAvaiPweList();
		} else {
			$poweridlist = $AccountPower->getListByAccid( $accountid);
			$groupidList = $modelAdmGrp->getListidByAccid( $accountid);
			$grouppwerlist = $dbTableGrpPwr->getListByGroupids( $groupidList);
	
			$poweridlist = array_merge( $poweridlist, $grouppwerlist);
			if( !empty( $poweridlist)) {
				$powerlist = $ModelNode->getListByPowerIds( $poweridlist, 1);
			}
		}

		$ModelPower = Moby_Mgrsvr_Index_Model_Power::getInstance();
		//可用服务器列表
//		$enableServerList = Moby_Mgrsvr_Index_Model_Game::getEnableServer();
		$pwerInfoList = $ModelPower->findAll();
		
		$maxCircleCount = 10;
		while( $powerlist || $maxCircleCount <= 0) {
			$maxCircleCount--;
			foreach( $powerlist as $power) {
				$item = array( 
					'id'=>$power['id'],
					'name'=>$power['name'],
					'powerid'=>$power['powerid'],
					'parentid'=>$power['parentid'],
				);

				if( $item['powerid']) {
					if( is_array( $pwerInfoList) && array_key_exists( $item['powerid'], $pwerInfoList)) {
						$powerInfo = $pwerInfoList[$item['powerid']];
						$item['action'] = $powerInfo['action'];
						$item['controller'] = $powerInfo['controller'];
						$item['model'] = $powerInfo['model'];
					} else {
						$item['action'] = "";
						$item['controller'] = "";
						$item['model'] = "";
					}
				}

				if( isset( $tmppowerlist[$item['id']])) {
					$item['sublist'] = $tmppowerlist[$item['id']];
					unset( $tmppowerlist[$item['id']]);
				}

				if( empty( $power['parentid'])) {
					if( isset( $result[$item['id']])) {
						if( !isset( $result[$item['id']]['sublist'])) {
							$result[$item['id']]['sublist'] = array();
						}
						if( isset( $item['sublist']) && $item['sublist'] && is_array( $item['sublist'])) {
							$result[$item['id']]['sublist'] = array_merge( $result[$item['id']]['sublist'], $item['sublist']);
						}
					} else {
						$result[$item['id']] = $item;
					}
					continue;
				}

				if( !isset( $tmppowerlist[$item['parentid']])){
					$tmppowerlist[$item['parentid']] = array();
				}

				$tmppowerlist[$item['parentid']][$item['id']] = $item;

			}

			//$powerlist = $DbTableAdminNode->fecthAllByCond( array( 'p_id in(?)'=>array_keys( $tmppowerlist)));
			$noteidlist = array_keys( $tmppowerlist);
			if( empty( $noteidlist)) {
				break;
			}
			$powerlist = $ModelNode->getListByIds( array_keys( $tmppowerlist), 1);
		}

		return $result;
	}

	/**
	 * 验证控制器的存在性和权限，包括服务器权限
	 */
	public function isAllowController( $accountid, $action, $controller, $model) {
		$AdminPower = Moby_Mgrsvr_Index_Model_Power::getInstance();
		$powerInfo = $AdminPower->findByC( $model, $controller, $action);
		if( empty( $powerInfo)) {
			throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_ADMIN_ControllerNotExist'));
		}

		$currreqpid = $powerInfo['id'];
		$AdminAccountPower = Moby_Mgrsvr_Index_Model_DbTable_Admin_AccountPower::getInstance();
		$accountPowerInfo = $AdminAccountPower->fetchRowByCond( array( 'p_id=?'=>$currreqpid, 'a_id=?'=>$accountid));
		if( empty( $accountPowerInfo)) {
			$modelAdmGrp = new Moby_Mgrsvr_Index_Model_AdminGroup();
			$groupidList = $modelAdmGrp->getListidByAccid( $accountid);
	
			$dbTableGrpPwr = new Moby_Mgrsvr_Index_Model_DbTable_Admin_GroupPower();
			$grouppwerlist = $dbTableGrpPwr->getListByGroupids( $groupidList);
			if( !in_array( $currreqpid, $grouppwerlist)) {
				throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_ADMIN_PowerNotEnough'));
			}
		}
		return true;
	}
	
	public function getEntityByAccount( $account) {
		$info = $this->adminaccount->getByAccount( $account);
		return $this->_fillAccount( $info);
	}
	
	public function getEntityByAccountid( $accountid) {
		$info = $this->adminaccount->findById( $accountid);
		return $this->_fillAccount( $info);
	}
	
	public function _fillAccount( $info) {
		if( empty( $info)) {
			return false;
		}
		$entityAdmin = new Moby_Mgrsvr_Index_Model_Entity_Admin();
		$entityAdmin->setAccountid( $info['a_id'])
					->setAccount( $info['a_account'])
					->setRealName( $info['a_realname'])
					->setSavepass( $info['a_password'])
					->setRegTime( $info['a_addtime'])
					->setLock( $info['a_islock'])
					->setLastip( $info['a_lastip'])
					->setLastLoginTime( $info['a_lasttime'])
					->setSessionid( $info['a_session']);
		return $entityAdmin;
	}
}