<?php

class Moby_Mgrsvr_Index_Model_Power {
	
	
	private static $_instance = null;
	
	public static function getInstance(){
		if( null === self::$_instance) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	
	protected $adminpower = null;
	
	public function __construct() {
		$this->adminpower = Moby_Mgrsvr_Index_Model_DbTable_Virtual_Power::getInstance();
	}
	/**
	 * 得到顶级节点的权限信息
	 * 
	 * 
	 */
	public function getTopList() {
		return $this->adminpower->getTopList();
	}
	/**
	 * 
	 * 得到指定$id的权限信息
	 * @param unknown_type $id
	 */
	public function getById( $id) {
		return $this->adminpower->findById( $id);
	}
	
	private function _getPowerItemArr($controllerName,$controllerStr){
	
		if( is_subclass_of($controllerName,'Moby_Mgrsvr_Index_Controller') ){
			
			//获取controller类中所有的属性
			$vars = get_class_vars($controllerName);
			//获取controller类中所有的方法
			$methods = get_class_methods($controllerName);

		}
	
		$langkey = 'APP_CONF_POWERS_'.strtoupper($controllerStr)."__NAME";

		//power数组下面的元素
		$poweritem['name'] = Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( $langkey );
		$poweritem['ispower'] = isset($vars['ispower'])?$vars['ispower']:0;
		$poweritem['isreqsvrid'] = 0;
		$poweritem['dependent'] = isset($vars['dependent'])?$vars['dependent']:array();
		
		//获取controller文件中不作为权限的Action
		$excludes = isset($vars['excludes'])?$vars['excludes']:array();

		if(!empty($methods)){

			foreach($methods as $method){
				if(strpos($method,'Action')){
					$actionStr = str_replace('Action','',$method);
					//排除controller文件中不作为权限的Action
					if(in_array($actionStr, $excludes))
						continue;
					$langkey = 'APP_CONF_POWERS_'.strtoupper($controllerStr).'__OPERALIST__'.strtoupper($actionStr);
					$poweritem['operalist'][$actionStr] = Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( $langkey );
				}
			}
		}
		return $poweritem;
	}

	public function getPowerArr(){
		//打开/Index/Controller/ 目录
		if ($dh = opendir(APPLICATION_PATH.'/Index/Controller/')) {
		
			//遍历该目录
			while ( ($file = readdir($dh)) !== false ) {
				$parts = pathinfo($file);
				
				//获取文件名
				$controllerStr = $parts['filename'];
				if( isset( $parts['extension']) && $parts['extension'] == 'php'  ){
					
					$controllerName = 'Moby_Mgrsvr_Index_Controller_'.$controllerStr;

					$power['index'][strtolower($controllerStr)] = $this->_getPowerItemArr($controllerName,$controllerStr);	
				}
			}
			unset($power['index']['error'],$power['index']['main'],$power['index']['index']);
			closedir($dh);
		}
		
		return $power;
	}
	
	public function reset() {
		//得到一个配置信息的数组
		$configPower = $this->getPowerArr();
		
		$result = array();
		//不是model，是module?
		foreach( $configPower as $model=>$controllers) {
			foreach( $controllers as $controller=>$item) {
				$tmpitem = $item;
				if( $tmpitem['ispower'] && $tmpitem['operalist']) {
					$isreqsvrid = empty( $tmpitem['isreqsvrid']) ? 0 : $tmpitem['isreqsvrid'];
					$stackPower = array();
					
					if( isset( $tmpitem['dependent'])) {
						$tmpres = array();
						$toplist = array_diff_key( $tmpitem['operalist'], $tmpitem['dependent']);
						foreach( $toplist as $topkey=>$topaction) {
							$operaname = $tmpitem['operalist'][$topkey];
							
							$subopera = array(
								'name'=>$operaname,
								'model'=>$model,
								'controller'=>$controller,
								'action'=>$topkey,
								'isreqsvrid'=>$isreqsvrid,
								'dependent'=>array(),
							);
							$result[] = $subopera;
							unset( $tmpitem['operalist'][$topkey]);
							$tmpres[$topkey] = $operaname;
						}
						
						while ( $tmpitem['operalist']) {
							foreach( $tmpitem['dependent'] as $depkey=>$depval) {
								if( isset( $tmpres[$depval]) && isset( $tmpitem['operalist'][$depkey])) {
									$operaname = $tmpitem['operalist'][$depkey];
									
									$subopera = array(
										'name'=>$operaname,
										'model'=>$model,
										'controller'=>$controller,
										'action'=>$depkey,
										'isreqsvrid'=>$isreqsvrid,
										'dependent'=>array(
											$model,$controller,$depval
										),
									);
									$result[] = $subopera;
									unset( $tmpitem['operalist'][$depkey]);
									$tmpres[$depkey] = $operaname;
								}
							}
							
						}
					} else {
						foreach( $tmpitem['operalist'] as $topkey=>$topaction) {
							$operaname = $tmpitem['operalist'][$topkey];
							
							$subopera = array(
								'name'=>$operaname,
								'model'=>$model,
								'controller'=>$controller,
								'action'=>$topkey,
								'dependent'=>array(),
								'isreqsvrid'=>$isreqsvrid,
							);
							$result[] = $subopera;
						}
					}
				}
			}
		}
		
		$powerIds = array();
		$saveall = array();
		foreach( $result as $item) {
			$depid = 0;
			if( !empty( $item['dependent'])) {
				$depkey = implode( '_', $item['dependent']);
				if( isset( $powerIds[$depkey])) {
					$depid = $powerIds[$depkey];
				} else {
					continue;
				}
			}
			
			$poweridkey = $item['model']."_".$item['controller']."_".$item['action'];
			$id = $this->adminpower->genId( $item['model'], $item['controller'], $item['action']);
			/*
			$powerInfo = $this->adminpower->findByC( $item['model'], $item['controller'], $item['action']);
			if( !empty( $powerInfo)) {
				$powerIds[$poweridkey] = $powerInfo['id'];
				print 1;
				print "<br />\n";
				continue;
			}
			echo "<pre>";
			print_r($item) ;
			print "<br />\n";
			$powerIds[$poweridkey] = $this->adminpower->add( Moby_Mgrsvr_Index_Model_Util::encodeToDb( $item['name']), $item['model'], $item['controller'], $item['action'], $depid, $item['isreqsvrid']);
			*/
			
			$powerIds[$poweridkey] = $id;
			echo "<pre>";
			print_r($item) ;
			print "<br />\n";
			
			$saveall[$id] = array(
				'id'=>$id,
				'name'=> $item['name'],
				'model'=>$item['model'],
				'controller'=>$item['controller'],
				'action'=>$item['action'],
				'depid'=>$depid,
				'reqsvrid'=>$item['isreqsvrid'],
			);
		}
		$this->adminpower->saveAll( $saveall);
	}
	
	/**
	 * 获取梳妆结构的权限
	 * @param int $parentid
	 */
	public function getTree( ) {
		$result = $this->getTreeById( 0);
		return $result;
	}
	
	private function getTreeById( $parentid=0) {
		$topPowerList = $this->adminpower->getSubList( $parentid);
		##Moby_Mgrsvr_Index_Model_Util_Log::getInstance( 'debug')->record( var_export( $topPowerList, true));
		$result = array();
		if( $topPowerList) {
			foreach( $topPowerList as $item) {
				$result[$item['id']] = array(
					'id'=>$item['id'],
					'name'=>$item['name'],
					'isreqsvrid'=>$item['reqsvrid'],
					'sublist'=>$this->getTreeById( $item['id']),
				);
				
			}
		}
		return $result;
	}
	
	/**
	 * 根据权限的依赖关系强制用户拥有子权限必须拥有父权限
	 * @param array $powerids[$powerid]
	 */
	public function format( array $powerlists=null) {
		if( empty( $powerlists)) {
			return $powerlists;
		}
		$powerids = array_keys( $powerlists);
		$parentids = $this->adminpower->getDepList( $powerids);
		if( empty( $parentids) || empty( $powerids)) {
			return $powerlists;
		}
		
		while( $diff = array_diff_key( $parentids, $powerlists)) {

			foreach( $diff as $depid=>$powerid) {
				if( !isset( $powerlists[$depid])) {
					$powerlists[$depid] = $powerlists[$powerid];
				}
			}
			
			$powerids = array_keys( $powerlists);
			$parentids = $this->adminpower->getDepList( $powerids);
		}

		return $powerlists;
	}
	
	public function findAll() {
		return $this->adminpower->findAll( );
	}
	
	public function findByC( $model, $action, $controller) {
		return $this->adminpower->findByC( $model, $action, $controller);
	}
}