<?php

class Moby_Mgrsvr_Index_Model_Config {

	/**
	 * 元宝消费类型
	 */
	public static function getUseIngotType() {
		if( !Zend_Registry::isRegistered( 'ConfigSystemIngotUseType')) {
			$ibr_type = array();
			$temp = Moby_Mgrsvr_Index_Model_Util_Xml::load( 'Ibrtype');
			foreach ($temp['childrenlist'] as $value) {
				$ibr_type[$value['type']] = $value['name'];
			}
			Zend_Registry::set( 'ConfigSystemIngotUseType', $ibr_type);
		}
		return Zend_Registry::get( 'ConfigSystemIngotUseType');
	}

	/**
	 * 点卷消费类型
	 */
	public static function getUseTicketType() {
		if( !Zend_Registry::isRegistered( 'ConfigSystemTicketUseType')) {
			Zend_Registry::set( 'ConfigSystemTicketUseType', array(
				'giftPack'=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_18'),
				'item'=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_21'),
				'addticket'=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_23'),
			));
		}
		return Zend_Registry::get( 'ConfigSystemTicketUseType');
	}

	public static function getSysMsgVerifyType() {
		if( !Zend_Registry::isRegistered( 'ConfigSysMsgVerifyType')) {
			Zend_Registry::set( 'ConfigSysMsgVerifyType', array(
				'1'=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_25'),
				'2'=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_26'),
				'3'=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_27'),
			));
		}
		return Zend_Registry::get( 'ConfigSysMsgVerifyType');
	}

	public static function getPayType(){
		if( !Zend_Registry::isRegistered( 'ConfigPayforType')) {
			Zend_Registry::set( 'ConfigPayforType', array(
				1=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_28'),
				2=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_29'),
				3=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_30'),
				4=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_31'),
				5=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_32'),
				6=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_33'),
				7=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_34'),
				8=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_35'),
				9=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_36')
			));
		}
		return Zend_Registry::get( 'ConfigPayforType');
	}
	
	public static function getGoodsNameList() {

		$result = array();
		$regKey = "CacheGoodsNameList";
		if( !Zend_Registry::isRegistered( $regKey)) {
			if( !Moby_Mgrsvr_Index_Model_Util_Cache::isExists( $regKey)) {
				$result = Moby_Mgrsvr_Index_Model_GoodsProtos::getInstance()->getSimpleList();
				Moby_Mgrsvr_Index_Model_Util_Cache::save( $regKey, $result);
			}
			//$result = require $file;
			$result = Moby_Mgrsvr_Index_Model_Util_Cache::load( $regKey);
			Zend_Registry::set( $regKey, $result);
		}
		$result = Zend_Registry::get( $regKey);

		return $result;
	}
	
	public static function getCardsNameList() {

		$result = array();
		$regKey = "CacheCardsNameList";
		if( !Zend_Registry::isRegistered( $regKey)) {
			if( !Moby_Mgrsvr_Index_Model_Util_Cache::isExists( $regKey)) {
				$result = Moby_Mgrsvr_Index_Model_Xml_CardProtos::getInstance()->getSimpleList();
				Moby_Mgrsvr_Index_Model_Util_Cache::save( $regKey, $result);
			}
			//$result = require $file;
			$result = Moby_Mgrsvr_Index_Model_Util_Cache::load( $regKey);
			Zend_Registry::set( $regKey, $result);
		}
		$result = Zend_Registry::get( $regKey);

		return $result;
	}
	
	public static function getGoodsAllInfoList() {

		$result = array();
		$regKey = "CacheGoodsAllInfoList";
		if( !Zend_Registry::isRegistered( $regKey)) {
			if( !Moby_Mgrsvr_Index_Model_Util_Cache::isExists( $regKey)) {
				$result = Moby_Mgrsvr_Index_Model_GoodsProtos::getInstance()->getList();
				Moby_Mgrsvr_Index_Model_Util_Cache::save( $regKey, $result);
			}
			//$result = require $file;
			$result = Moby_Mgrsvr_Index_Model_Util_Cache::load( $regKey);
			Zend_Registry::set( $regKey, $result);
		}
		$result = Zend_Registry::get( $regKey);

		return $result;
	}
	
	public static function getGoodsAllInfoListToJson() {
		return json_encode( self::getGoodsAllInfoList());
	}

	
	/**
	 * 获取应用配置
	 */
	public static function getApplicationConfig() {
		if( !Zend_Registry::isRegistered( 'ConfigApplication')) {
			$pubconvert = new Zend_Config_Ini( APPLICATION_PATH.'/Config/application.ini');

			Zend_Registry::set( 'ConfigApplication', $pubconvert);
		}
		return Zend_Registry::get( 'ConfigApplication');
	}
	
	/**
	 * 角色权限
	 */
	public static function getPlayerPowerList() {
		if( !Zend_Registry::isRegistered( 'ConfigPlayerPowerList')) {
			Zend_Registry::set( 'ConfigPlayerPowerList', array(
				1=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_39'),
			));
		}
		return Zend_Registry::get( 'ConfigPlayerPowerList');
	}
	
	/**
	 * 礼包领取类型
	 * Enter description here ...
	 */
	public static function getGiftTakeTypeList() {
		$regkey = 'ConfigGiftTakeType';
		if( !Zend_Registry::isRegistered( $regkey)) {
			Zend_Registry::set( $regkey, array(
				1=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_40'),
				2=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_41'),
				3=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_42'),
			));
		}
		return Zend_Registry::get( $regkey);
	}
	
	/**
	 * 获取机型信息
	 */
	public static function getMachineList( ) {
		$regkey = 'ConfigMachineList';
		if( !Zend_Registry::isRegistered( $regkey)) {
			Zend_Registry::set( $regkey, array(
				's60_3rd', 's60_5th', 'android', 'iphone', 'winphone'
			));
		}
		return Zend_Registry::get( $regkey);
	}
	
	/**
	 * 获取邮件类型
	 * 
	 */
	public static function getGameMailType() {
		$regkey = 'ConfigGameMailTypeList';
		if( !Zend_Registry::isRegistered( $regkey)) {
			Zend_Registry::set( $regkey, array(
				1=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_GAMEMAIL_TYPE_USER'),
				2=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_CONFIG_GAMEMAIL_TYPE_SYS'),
			));
		}
		return Zend_Registry::get( $regkey);
	}
	
	/**
	 * 获取商城类型
	 * 
	 */
	public static function getMallType() {
		$regkey = 'ConfigMallTypeList';
		if( !Zend_Registry::isRegistered( $regkey)) {
			Zend_Registry::set( $regkey, array(
				1=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_MALLMANAGE_FORM_TYPEITEM'),
				2=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_MALLMANAGE_FORM_TYPEBOX'),
				3=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_MALLMANAGE_FORM_TYPEACT'),
				4=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_MALLMANAGE_FORM_TYPECARD'),
			));
		}
		return Zend_Registry::get( $regkey);
	}
	
	/**
	 * 获取命令类型
	 * 
	 */
	public static function getCMDType() {
		$regkey = 'ConfigCMDTypeList';
		if( !Zend_Registry::isRegistered( $regkey)) {
			Zend_Registry::set( $regkey, array(
				1 =>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_GET_SENSWORD'),
				2 =>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_SET_SENSWORD'),
				3 =>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_SEND_SYSMSG'),
				4 =>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_SEND_SYSMAIL'),
				5 =>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_PAYFORINGOT'),
				6 =>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_FORBID_SPEAK'),
				7 =>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_UNFORBID_SPEAK'),
				8 =>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_KICKOFFLINE'),
				9 =>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_UNKICKOFFLINE'),
				10=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_GIVEEXP'),
				13=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_SET_PLAYER_RIGHT'),
				18=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_PAYMENT'),
				20=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_ADD_ACTIVITY'),
				21=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_DEL_ACTIVITY'),
				22=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_SORT_ACTIVITY'),
				23=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_QUERY_ACTIVITY'),
				25=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_MODIFY_ACTIVITY_STATUS'),
				26=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_ADDINGOT'),
				51=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_INSERTMALLITEM'),
				52=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_SETMALLITEM'),
				53=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ADMINCOMMAND_CONF_REMOVEMALLITEM'),
			));
		}
		return Zend_Registry::get( $regkey);
	}
	
	/**
	 * 获取帮派职位列表
	 *
	 */
	public static function getFactionJob() {
		
		$regKey = "XMLFactionList";
		if( !Zend_Registry::isRegistered( $regKey)) {
			if( !Moby_Mgrsvr_Index_Model_Util_Cache::isExists( $regKey)) {
				$result = array();
				$factions = Moby_Mgrsvr_Index_Model_Util_Xml::load('Faction');
				if ( isset( $factions['childrenlist'][3]['childrenlist'])) {
					foreach ( $factions['childrenlist'][3]['childrenlist'] as $item) {
						$result[$item['type']] = $item['name'];
					}
				}
				
				Moby_Mgrsvr_Index_Model_Util_Cache::save( $regKey, $result);
			}
			$result = Moby_Mgrsvr_Index_Model_Util_Cache::load( $regKey);
			Zend_Registry::set( $regKey, $result);
		}
		return Zend_Registry::get( $regKey);
	}
	
	public static function getStoreElement() {
		$regKey = "XMLStoreElement";
		if( !Zend_Registry::isRegistered( $regKey)) {
			$result = array();
			if( !Moby_Mgrsvr_Index_Model_Util_Cache::isExists( $regKey)) {
				$result = Moby_Mgrsvr_Index_Model_Xml_Scenes::getInstance()->getStoreElement();
				Moby_Mgrsvr_Index_Model_Util_Cache::save( $regKey, $result);
			}
			$result = Moby_Mgrsvr_Index_Model_Util_Cache::load( $regKey);
			Zend_Registry::set( $regKey, $result);
			
		}
		return Zend_Registry::get( $regKey);
	}
	
	public static function getSkillConfig() {
		$regKey = "XMLSkillConfig";
		if( !Zend_Registry::isRegistered( $regKey)) {
			$result = array();
			if( !Moby_Mgrsvr_Index_Model_Util_Cache::isExists( $regKey)) {
				$camps = Moby_Mgrsvr_Index_Model_Util_Xml::load( 'ItemConfig');
				foreach( $camps['childrenlist'] as $key=>$value) {
					$result[$key] = $value;
				}
				Moby_Mgrsvr_Index_Model_Util_Cache::save( $regKey, $result);
			}
			$result = Moby_Mgrsvr_Index_Model_Util_Cache::load( $regKey);
			Zend_Registry::set( $regKey, $result);
		}
		return Zend_Registry::get( $regKey);
	}
	
	public static function getActivityConfig() {
		$regKey = "ActivityTypeList";
		if( !Zend_Registry::isRegistered( $regKey)) {
			$result = array();
			if( !Moby_Mgrsvr_Index_Model_Util_Cache::isExists( $regKey)) {
				$result = array(
					"1000000"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACTIVITY_DYNAMICDEMO'),
		        	"1000001"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACTIVITY_EXCHANGEITEM'),
		        	"1000002"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACTIVITY_SCOREEXCHANGE'),
		        	"1000003"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACTIVITY_SHOOTSUN'),      	
		        	"1000004"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACTIVITY_EXCHANGELOTTERY'),
		        	"1000005"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACTIVITY_LOGINEVERYDAY'),
					"1000006"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACTIVITY_SCORERANK'),
		        	"1000007"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACTIVITY_RECHARGERABATE'),
					"1000008"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACTIVITY_NOTICE'),
					"1000009"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACTIVITY_ANNOUNCEMENT'),
				);
				Moby_Mgrsvr_Index_Model_Util_Cache::save( $regKey, $result);
			}
			$result = Moby_Mgrsvr_Index_Model_Util_Cache::load( $regKey);
			Zend_Registry::set( $regKey, $result);
			
		}
		
		return Zend_Registry::get( $regKey);
		
		
	}
	
	public static function getSpecilVerifyConfig() {
		$regKey = "SpecilVerifyTypeList";
		if( !Zend_Registry::isRegistered( $regKey)) {
			$result = array();
			if( !Moby_Mgrsvr_Index_Model_Util_Cache::isExists( $regKey)) {
				$result = array(
		        	"AutoUpdate"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_SPECILVERIFY_LIST_AUTOUPDATE'),
		        	"Version"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_SPECILVERIFY_LIST_VERSION'),
				);
				Moby_Mgrsvr_Index_Model_Util_Cache::save( $regKey, $result);
			}
			$result = Moby_Mgrsvr_Index_Model_Util_Cache::load( $regKey);
			Zend_Registry::set( $regKey, $result);
			
		}
		
		return Zend_Registry::get( $regKey);
		
	}
	
	public static function getChannelConfig() {
		$regKey = "ChannelList";
		if( !Zend_Registry::isRegistered( $regKey)) {
			$result = array();
			if( !Moby_Mgrsvr_Index_Model_Util_Cache::isExists( $regKey)) {
				$result = array();
				$result = array(
		        	"moby"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACCOUNT_MOBY'),
					"tacn"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACCOUNT_TACN'),
					"test"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACCOUNT_TEST'),
					"longyin"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACCOUNT_LONGYIN'),
					"leyi"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACCOUNT_LEYI'),
					"jiayu"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACCOUNT_JIAYU'),
					"fyios"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACCOUNT_FYIOS'),
					"uios"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACCOUNT_UIOS'),
					"uc"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACCOUNT_UC'),
					"tencetest"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACCOUNT_TENCETEST'),
					"ledou"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACCOUNT_LEDOU'),
					"sina"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACCOUNT_SINA'),
					"twly"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACCOUNT_TWLY'),
					"9game"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACCOUNT_9GAME'),
					"asdk"=>Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_VIEW_ACCOUNT_ASDK'),
				);
				
				Moby_Mgrsvr_Index_Model_Util_Cache::save( $regKey, $result);
			}
			$result = Moby_Mgrsvr_Index_Model_Util_Cache::load( $regKey);
			Zend_Registry::set( $regKey, $result);
			
		}
		
		return Zend_Registry::get( $regKey);
		
	}
}