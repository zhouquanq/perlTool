<?php

class Moby_Mgrsvr_Index_Model_DbTable_Admin_Pub extends Moby_Mgrsvr_Index_Model_DbTable_Account {
	
	private static $_instance = null;
	
	public static function getInstance(){
		if( null === self::$_instance) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	
	protected $table = 'admin_pub';
	protected $primarykey = 'ap_id';
	
	public function getAll() {
		return $this->fetchAllByCond();
	}
	
	public function getByKey( $pubkey) {
		return $this->fetchRowByCond( array( 'ap_key=?'=>$pubkey));
	}
	
	public function getListDiff( $publist){
		$where = array();
		if( !empty( $publist)) {
			$where['ap_key not in(?)']=$publist;
		}
		return $this->fetchAllByCond( $where);
	}
}