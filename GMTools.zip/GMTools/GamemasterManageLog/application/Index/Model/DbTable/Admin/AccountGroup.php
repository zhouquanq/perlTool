<?php
class Moby_Mgrsvr_Index_Model_DbTable_Admin_AccountGroup extends Moby_Mgrsvr_Index_Model_DbTable_Admin {
	protected $table = "admin_account_group";
	protected $primarykey = "aag_id";
	
	/**
	 * 根据用户id查询用户所属的用户组id数组
	 * @param int $accountid
	 * @return array $groupids
	 */
	public function getGroupList( $accountid, $lockGroupids=null, $isid=true) {
		$where = array( 
			'aag_accountid=?'=>$accountid
		);
		if( $lockGroupids) {
			$where['aag_groupid not in(?)'] = $lockGroupids;
		}
		if( $isid) {
			return $this->fetchColByCond( 'aag_groupid', $where);
		} else {
			return $this->fetchAllByCond( $where);
		}
	}
	
	public function add( $accountid, $groupid) {
		$data = array( 
			'aag_accountid'=>$accountid,
			'aag_groupid'=>$groupid,
		);
		return $this->insert( $data);
	}
	
	/**
	 * 根据用户组id查询用户id列表
	 * @param int $accountid
	 * @return array $groupids
	 */
	public function getActList( $groupid, $isid = true) {
		if( $isid) {
			return $this->fetchColByCond( 'aag_accountid', array( 'aag_groupid=?'=>$groupid));
		} else {
			return $this->fetchAllByCond( array( 'aag_groupid=?'=>$groupid));
		}
	}
	
	public function remove( $accountid) {
		return $this->delete( array( 'aag_accountid=?'=>$accountid));
	}
}