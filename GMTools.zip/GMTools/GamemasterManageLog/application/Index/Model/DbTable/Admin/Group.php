<?php
class Moby_Mgrsvr_Index_Model_DbTable_Admin_Group extends Moby_Mgrsvr_Index_Model_DbTable_Admin {
	
	private static $_instance = NULL;

	public static function getInstance() {
        if(NULL == self::$_instance) {
            self::$_instance = new self();
        }
        return self::$_instance;
	}
	
	protected $table = 'admin_group';
	protected $primarykey = 'ag_id';
	
	/**
	 * 查询用户组列表(分页)
	 * @param int $pageindex 当前页
	 * @param int $pagecount 每页记录条数
	 * @param string $account 账号
	 */
	public function getList( $pageIndex, $pageSize, $name=null) {
		$where = null;
		if( !empty( $name)) {
			$where = array( 'ap_name like ?'=>"%$name%");
		}
		return $this->fetchAllByPage( $pageIndex, $pageSize, $where);
	}

	/**
	 * 查询用户组数量
	 * @param string $account 账号
	 */
	public function getCount( $name=null) {
		$where = null;
		if( !empty( $name)) {
			$where = array( 'ap_name like ?'=>"%$name%");
		}
		return $this->rowCount( $where);
	}
	
	/**
	 * 添加用户组 
	 * @param string $name
	 * @param boolean $islock
	 */
	public function add( $name, $islock) {
		$data = array(
			'ag_name'=>$name,
			'ag_islock'=>$islock,
		);
		return $this->insert( $data);
	} 
	
	/**
	 * 修改用户组
	 * @param int $groupid
	 * @param string $name
	 * @param boolean $islock
	 */
	public function modify( $groupid, $name, $islock) {
		$data = array(
			'ag_name'=>$name,
			'ag_islock'=>$islock,
		);
		return $this->update( $data, array( 'ag_id=?'=>$groupid));
	}
	
	/**
	 * 查询已锁定的组
	 */
	public function getLock() {
		return $this->fetchColByCond( 'ag_id', array( 'ag_islock=?'=>1));
	}
}