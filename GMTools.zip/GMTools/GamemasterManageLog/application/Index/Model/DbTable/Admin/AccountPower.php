<?php
class Moby_Mgrsvr_Index_Model_DbTable_Admin_AccountPower extends Moby_Mgrsvr_Index_Model_DbTable_Account {
	
	private static $_instance = null;
	
	public static function getInstance() {
		if( null === self::$_instance) {
			self::$_instance = new self( );
		}
		return self::$_instance;
	}
	
	protected $table = "admin_account_power";
	protected $primarykey = "ap_id";
	
	public function addPower( $accountid, array $powerids) {
		$this->conn->beginTransaction();
		try {
			foreach( $powerids as $powerid=>$serveridlist) {
				$serverids = implode( ',', $serveridlist);
				$data = array(
					'a_id'=>$accountid,
					'p_id'=>$powerid,
					'ap_serverids'=>$serverids,
				);
				$this->insert( $data);
			}
		} catch( Exception $e) {
			$this->conn->rollBack();
			throw new Exception( $e);
		}
		$this->conn->commit();
		return true;
	}
	
	public function getListByAccid( $accountid) {
		return $this->fetchColByCond( 'p_id', array( 'a_id=?'=>$accountid));
	}
}