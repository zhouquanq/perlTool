<?php
class Moby_Mgrsvr_Index_Model_DbTable_Admin_GroupPower extends Moby_Mgrsvr_Index_Model_DbTable_Admin {
	
	private static $_instance = NULL;

	public static function getInstance() {
        if(NULL == self::$_instance) {
            self::$_instance = new self();
        }
        return self::$_instance;
	}
	
	protected $table = 'admin_group_power';
	protected $primarykey = 'agp_id';
	
	/**
	 * 为某个用户组添加权限
	 * @param int $groupid
	 * @param array $powerids
	 * @throws Exception
	 */
	public function addPower( $groupid, array $powerids) {
		if( empty( $powerids)) {
			return false;
		}
		
		$this->conn->beginTransaction();
		try {
			foreach( $powerids as $powerid) {
				$data = array(
					'agp_groupid'=>$groupid,
					'agp_powerid'=>$powerid,
				);
				$this->insert( $data);
			}
		} catch( Exception $e) {
			$this->conn->rollBack();
			throw new Exception( $e);
		}
		$this->conn->commit();
		return true;
	}
	
	/**
	 * 删除一个组的所有权限(当$powerids为空时),或者删除一个用户组的部分权限
	 * @param int $groupid
	 * @param array $powerids
	 */
	public function remove( $groupid, array $powerids=null) {
		if( empty( $groupid) || !is_numeric( $groupid)) {
			return false;
		}
		
		$where = array(
			'agp_groupid=?'=>$groupid
		);
		
		if( !empty( $powerids)) {
			$where['agp_powerid in(?)']=$powerids;
		}
		
		return $this->delete( $where);
	}
	
	public function getListByGroupids( $groupid) {
		if( empty( $groupid)) {
			return array();
		}
		if( is_array( $groupid)) {
			$where = array( 'agp_groupid in(?)'=>$groupid);
		} else {
			$where = array( 'agp_groupid=?'=>$groupid);
		}
		return $this->fetchColByCond( 'agp_powerid', $where);
	}
}