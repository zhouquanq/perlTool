<?php
/**
 * 后台管理员账号表
 * @author Administrator
 *
 */
class Moby_Mgrsvr_Index_Model_DbTable_Admin_Account extends Moby_Mgrsvr_Index_Model_DbTable_Admin {
	protected $table = 'admin_account';
	protected $primarykey = 'a_id';
	
	/**
	 * 根据账号查询用户信息
	 * @param stirng $account
	 * 
	 * @return array 返回用户账号信息
	 */
	public function getByAccount( $account) {
		return $this->fetchRowByCond( array( 'a_account=?'=>$account));
	}
	
	/**
	 * 根据账号id修改账号信息
	 * @param int $id
	 * @param array $data
	 * 
	 * @return int 返回影响行数
	 */
	public function modifyById( $id, $data) {
		return $this->update( $data, array( 'a_id=?'=>$id));
	}
	
}