<?php
class Moby_Mgrsvr_Index_Model_DbTable_Admin extends Moby_Mgrsvr_Index_Model_DbTable_Base{

	/*
	 * 为服务器配置生成连接
	 */
	public function __construct( ) {
		$configKey = 'ConfigDbTableAdmin';
		$connKey = 'DbTableAdmin';
		
		//已经有注册的连接
		if( Zend_Registry::isRegistered( $connKey)) {
			$conn = Zend_Registry::get( $connKey);
		} else {
			//已经有注册的配置
			if( Zend_Registry::isRegistered( $configKey)) {
				$configs = Zend_Registry::get( $configKey);
			} else {
				$appConfig = Moby_Mgrsvr_Index_Model_Config::getApplicationConfig();
				
				$configs = $appConfig->dbconfig->account->toArray();
				Zend_Registry::set( $configKey, $configs);
			}
			$conn = parent::genConn( $configs);
			Zend_Registry::set( $connKey, $conn);
		}
		parent::__construct( $conn);
	}
}