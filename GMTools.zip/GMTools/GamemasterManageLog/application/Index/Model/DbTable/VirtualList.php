<?php
/**
 * 虚拟数据库的默认实现(php文件)
 * @author Administrator
 *
 */
class Moby_Mgrsvr_Index_Model_DbTable_VirtualList extends Moby_Mgrsvr_Index_Model_DbTable_Virtual {
	
	protected static $fileext = ".php";
	
	public function __construct() {
		$this->init();
	}
	
	/**
	 * 获取虚拟数据库文件名
	 * @param int|string $id
	 */
	public function getfilename() {
		return sprintf( "%s/list%s", $this->_virtualdbtablepath, self::$fileext);
	}
	
	public function findAll() {
		$recordpath = $this->getfilename();
		if( !file_exists( $recordpath)) {
			return array();
		}
		return require $recordpath;
	}
	
	/* (non-PHPdoc)
	 * @see Moby_Accsvr_Model_DbTable_Virtual::findById()
	 */
	public function findById($id) {
		$list = $this->findAll();
		return (!empty( $list) && array_key_exists( $id, $list)) ? $list[$id] : array();
	}

	/**
	 * 增加多个元素
	 */
	public function appendList( $list) {
		$recordpath = $this->getfilename();
		$listAll = $this->findAll();
		$listAll = array_merge( $listAll, $list);
		return $this->saveAll( $listAll);;
	}

	/* (non-PHPdoc)
	 * @see Moby_Accsvr_Model_DbTable_Virtual::save()
	 */
	public function save( $data, $id) {
		$recordpath = $this->getfilename();
		$listAll = $this->findAll();
		if( empty( $listAll[$id]) || !is_array( $listAll[$id])) {
			$listAll[$id] = $data;
		} else {
			$listAll[$id] = array_merge( $listAll[$id], $data);
		}
		return $this->saveAll( $listAll);
	}

	/* (non-PHPdoc)
	 * @see Moby_Accsvr_Model_DbTable_Virtual::delete()
	 */
	public function delete( $id) {
		$listAll = $this->findAll();
		if( array_key_exists( $id, $listAll)) {
			unset( $listAll[$id]);
			$recordpath = $this->getfilename();
			return $this->saveAll( $listAll);
		}
		return 0;
	}
	
	public function removeAll() {
		$recordpath = $this->getfilename();
		if( file_exists( $recordpath)) {
			return unlink( $recordpath);
		}
		return 0;
	}
	
	public function saveAll( $data) {
		$recordpath = $this->getfilename();
		return file_put_contents( $recordpath, '<?php '.PHP_EOL.'return '.var_export( $data, true).';');
	}
}