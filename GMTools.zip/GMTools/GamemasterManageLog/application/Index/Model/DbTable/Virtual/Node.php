<?php

class Moby_Mgrsvr_Index_Model_DbTable_Virtual_Node extends Moby_Mgrsvr_Index_Model_DbTable_VirtualList {
	
	private static $_instance = null;
	
	public static function getInstance() {
		if( null === self::$_instance) {
			self::$_instance = new self( );
		}
		return self::$_instance;
	}
	
	private static $_list = null;
	
	protected $table = "node";
	protected $primarykey = "id";
	
	public function findAll() {
		if( empty( self::$_list)) {
			self::$_list = parent::findAll();
		}
		return self::$_list;
	}
	
	public function genId( ) {
		return Moby_Util_UUID::gen();
	}
	
	public function remove( $id) {
		$this->delete( $id);
	}
	
	/**
	 * 查询节点列表根据节点id列表
	 * @param array|string $nodeids
	 * @param int 是否可用(1可用,2不可用,如果忽略则查询所有)
	 * 
	 * @return array 节点列表
	 */
	public function getListByIds( $nodeids, $enable=null) {
		$listAll = $this->findAll();
		$result = array();
		foreach( $listAll as $value) {
			if( isset( $enable)) {
				if( in_array( $value['id'], $nodeids) && $value['enable'] == $enable) {
					$result[$value['id']] = $value;
				}
			} else {
				if( in_array( $value['id'], $nodeids)) {
					$result[$value['id']] = $value;
				}
			}
		}
		return $result;
	}
	
	public function getListByPowerIds( $powerids, $enable) {
		$listAll = $this->findAll();
		$result = array();
		foreach( $listAll as $value) {
			if( !is_null( $enable)) {
				if( (in_array( $value['powerid'], $powerids)) && $value['enable'] == $enable) {
					$result[$value['id']] = $value;
				}
			} else {
				if( ( in_array( $value['powerid'], $powerids))) {
					$result[$value['id']] = $value;
				}
			}
		}
		return $result;
	}
	
	public function getListByNotApex( ) {
		$listAll = $this->findAll();
		$result = array();
		foreach( $listAll as $value) {
			if( sprintf( '%s', $value['powerid']) === '0' && $value['enable'] == 1) {
				$result[$value['id']] = $value;
			}
		}
		return $result;
	}
	
	/**
	 * 查询管理员列表(分页)
	 * @param string $pageindex 当前页
	 * @param string $pagecount 每页记录条数
	 * @param string $account 账号
	 */
	public function getList( $name=null) {
		$listAll = $this->findAll();
		$result = array();
		foreach( $listAll as $value) {
			
			if( !empty( $name) && false === strpos( $value['name'], $name)) {
				continue;
			}
			$result[$value['id']] = $value;
		}
		return $result;
	}
	
	/**
	 * 查询管理员列表(分页)
	 * @param string $pageindex 当前页
	 * @param string $pagecount 每页记录条数
	 * @param string $account 账号
	 */
	public function getAvaiPweList() {
		$listAll = $this->findAll();
		$result = array();
		foreach( $listAll as $value) {
			if( empty( $value['enable']) || empty($value['powerid'])) {
				continue;
			}
			$result[$value['id']] = $value;
		}
		return $result;
	}
	
	/**
	 * 添加节点
	 * @param stting $name 节点名称
	 * @param stting $parentid 父节点id
	 * @param int $powerid 权限id
	 * @param int $enable 是否可用(1可用,0不可用)
	 * 
	 * @return int|boolean 如果成佛那个返回插入数据的自增id,否则返回false
	 */
	public function add( $name, $parentid=0, $powerid=0, $enable=1) {
		$id = $this->genId();
		$data = array( 
			'id'=>$id,
			'name'=>$name,
			'parentid'=>$parentid,
			'powerid'=>$powerid,
			'enable'=>$enable,
		);
		
		$this->save( $data, $id);
		return $id; 
	}
	
	/**
	 * 修改节点
	 * @param int $id 节点id
	 * @param stting $name 节点名称
	 * @param stting $parentid 父节点id
	 * @param int $powerid 权限id
	 
	 * 
	 * @return int|boolean 如果成佛那个返回插入数据的自增id,否则返回false
	 */
	public function modify( $id, $name=null, $parentid=null, $powerid=null, $enable=null) {
		
		$data = array();
		if( !empty( $name)) {
			$data['name']=$name;
		}
		
		if( null !== $parentid) {
			$data['parentid']= $parentid;
		}
		
		if( null !== $powerid) {
			$data['powerid']= $powerid;
		}
		
		if( null !== $enable) {
			$data['enable']= $enable;
		}
		
		if( empty( $data)) {
			throw new Exception(Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_CONTROLLER_BULLETIN_ModifyFailed'));
		}
		
		return $this->save( $data, $id);
	}
	
	/**
	 * 禁用节点
	 * @param int $id
	 */
	public function lockout( $id) {
		$data = array( 'enable'=>0);
		return $this->save( $data, $id);
	}
	
	/**
	 * 解禁节点
	 * @param int $id
	 */
	public function unlock( $id) {
		$data = array( 'enable'=>1);
		return $this->save( $data, $id);
	}
}