<?php

class Moby_Mgrsvr_Index_Model_DbTable_Virtual_Power extends Moby_Mgrsvr_Index_Model_DbTable_VirtualList {
	
	private static $_instance = null;
	
	public static function getInstance() {
		if( null === self::$_instance) {
			self::$_instance = new self( );
		}
		return self::$_instance;
	}
	
	private static $_list = null;
	
	protected $table = "power";
	protected $primarykey = "id";
	
	public function findAll() {
		if( empty( self::$_list)) {
			self::$_list = parent::findAll();
		}
		return self::$_list;
	}
	
	public function genId( $model, $controller, $action) {
		return md5( sprintf( '%s_%s_%s', $model, $controller, $action));
	}
	
	/**
	 * 根据控制器名获取权限信息
	 *
	 */
	public function findByC( $model, $controller, $action) {
		$id = $this->genId( $model, $controller, $action);
		return $this->findById( $id);
	}
	
	public function saveAll( $list) {
		$result = array();
		foreach( $list as $value) {
			$id = $this->genId( $value['model'], $value['controller'], $value['action']);
			$value['id'] = $id;
			$result[$id] = $value;
		}
		$this->removeAll();
		return parent::saveAll( $result);
	}
	
	/**
	 * 添加节点
	 * @param string $name
	 * @param string $model
	 * @param string $controller
	 * @param string $action
	 * @param int $depid 
	 * @param int $reqsvrid 是否需要服务id
	 */
	public function add( $name, $model, $controller, $action, $depid, $reqsvrid) {
		$id = $this->genId( $model, $controller, $action);
		$data = array( 
			'id'=>$id,
			'name'=>$name,
			'model'=>$model,
			'controller'=>$controller,
			'action'=>$action,
			'depid'=>$depid,
			'reqsvrid'=>$reqsvrid,
		);
		
		$this->save( $data, $id);
		return $id;
	}
	
	public function getTopList() {
		return $this->getSubList( 0);
	}
	
	public function getSubList( $id) {
		$list = $this->findAll();
		$result = array();
		foreach( $list as $key=>$value) {
			if( $id === $value['depid']) {
				$result[$key] = $value;
			} else {
			}
		}
		
		return $result;
	}
	
	public function getDepList( array $powerids) {
		$list = $this->findAll();
		$result = array();
		foreach( $list as $key=>$value) {
			if( is_array( $powerids)) {
				if( in_array( $value['id'], $powerids) && $value['depid'] != '0') {
					$result[$value['depid']] = $value['id'];
				}
			} else {
				if( $value['id'] == $powerids && $value['depid'] != '0') {
					$result[$value['depid']] = $value['id'];
				}
			}
		}
		return $result;
	}
}