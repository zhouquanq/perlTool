<?php

/**
 * 
 * 虚拟数据库,用于加快某些属于账号数据的读写速度
 * @author Administrator
 *
 */
abstract class Moby_Mgrsvr_Index_Model_DbTable_Virtual {
	
	protected $_virtualdatapath = "";
	protected $_virtualdbtablepath = "";
	protected $table = "";
	protected $primarykey = "";
	
	public function init() {
		if( empty( $this->table) || !preg_match( '/^\w+$/', $this->table)) {
			throw new Exception( 'illegal virtual table name '.$this->table);
		}
		$this->table = strtolower( $this->table);
		$this->_virtualdatapath = APPLICATION_PATH."/../virtualdb";
		$this->_virtualdbtablepath = $this->_virtualdatapath."/".$this->table;
		
		if( !file_exists( $this->_virtualdbtablepath)) {
			if( !file_exists( $this->_virtualdatapath)) {
				mkdir( $this->_virtualdatapath, 0755);
			}
			mkdir( $this->_virtualdbtablepath, 0755);
		}
	}
	
	/**
	 * 根据id获取数据
	 * @param int $id
	 */
	abstract public function findById( $id);
	
	/**
	 * 插入一条记录
	 * @param array $data
	 */
	abstract public function save( $data, $id);
	
	/**
	 * 删除一条记录
	 * @param int|string $id
	 */
	abstract public function delete( $id);
}