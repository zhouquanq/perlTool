<?php
/**
 * 虚拟数据库的默认实现(php文件)
 * @author Administrator
 *
 */
class Moby_Mgrsvr_Index_Model_DbTable_VirtualSingle extends Moby_Mgrsvr_Index_Model_DbTable_Virtual {
	
	protected static $fileext = ".php";
	
	public function __construct() {
		$this->init();
	}
	
	/**
	 * 根据记录id获取信息
	 * @param int|string $id
	 */
	public function getfilename( $id) {
		return $this->_virtualdbtablepath.'/'.$id.self::$fileext;
	}
	
	/* (non-PHPdoc)
	 * @see Moby_Accsvr_Model_DbTable_Virtual::findById()
	 */
	public function findById($id) {
		$recordpath = $this->getfilename( $id);
		if( !file_exists( $recordpath)) {
			return array();
		}
		return require $recordpath;
	}

	/* (non-PHPdoc)
	 * @see Moby_Accsvr_Model_DbTable_Virtual::save()
	 */
	public function save( $data, $id) {
		if( empty( $data) || !is_array( $data)) {
			return 0;
		}
		if( empty( $id)) {
			return 0;
		}
		$recordpath = $this->getfilename( $id);
		return file_put_contents( $recordpath, '<?php '.PHP_EOL.'return '.var_export( $data, true).';');
	}

	/* (non-PHPdoc)
	 * @see Moby_Accsvr_Model_DbTable_Virtual::delete()
	 */
	public function delete( $id) {
		$recordpath = $this->getfilename( $id);
		if( !file_exists( $recordpath)) {
			return 0;
		}
		return unlink( $recordpath);
	}
}