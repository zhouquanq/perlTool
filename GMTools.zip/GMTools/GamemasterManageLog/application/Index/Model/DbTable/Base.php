<?php

class Moby_Mgrsvr_Index_Model_DbTable_Base extends Moby_Db_Table {
	
	/**
	 * 执行sql语句
	 * @param string $sql
	 */
	public function _query( $sql) {
		try {
			return parent::_query( $sql);
		} catch ( PDOException $e) {
			throw new Exception( Moby_Mgrsvr_Index_Model_Util::decodeToDb( $e->getMessage()), $e->getCode());
		}
	}
	
	/**
	 * 执行sql语句
	 * @param string $sql
	 */
	public function _execute( $sql) {
		try {
			return parent::_execute( $sql);
		} catch ( PDOException $e) {
			throw new PDOException( Moby_Mgrsvr_Index_Model_Util::decodeToDb( $e->getMessage()), $e->getCode());
		}
	}
	
	/**
	 * 记录所有的sql日志
	 * @param string $sql
	 */
	public function logsql( $sql) {
		$log = Moby_Mgrsvr_Index_Model_Util_Log::getInstance( 'sql');
		$log->record( $sql);
	}
}