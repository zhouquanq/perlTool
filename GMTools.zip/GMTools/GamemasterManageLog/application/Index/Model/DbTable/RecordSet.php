<?php

class Moby_Mgrsvr_Index_Model_DbTable_RecordSet{
	
	public $count;
	public $data;
	public $page;
	
	public function __construct( $count, $data, $page) {
		$this->count = $count;
		$this->data = $data;
		$this->page = $page;
	}
	
	public function getRecordCount() {
		return $this->count;
	}
	
	public function getData() {
		return $this->data;
	}
	
	public function getPage() {
		return $this->page;
	}
}