<?php
class Moby_Mgrsvr_Index_Model_Lang {

	public function __construct() {
		$langcfgkey = "ConfigLanguage";
		if( !Zend_Registry::isRegistered( $langcfgkey)) {
			$result = new Zend_Config_Ini( APPLICATION_LANG_PATH.'/lang.ini');
			if( !Moby_Mgrsvr_Index_Model_Util_Cache::isExists( $langcfgkey)) {
				$result = new Zend_Config_Ini( APPLICATION_LANG_PATH.'/lang.ini');
				Moby_Mgrsvr_Index_Model_Util_Cache::save( $langcfgkey, $result->toArray());
			}
			$result = Moby_Mgrsvr_Index_Model_Util_Cache::load( $langcfgkey);
			Zend_Registry::set( $langcfgkey, $result);
		}
	}

	public static function get( $key, array $params = null) {
		$langcfgkey = "ConfigLanguage";
		$default = "__not_found__";
		//echo $key;
		//return $default;
		$langcfg = Zend_Registry::get( $langcfgkey);
		if( empty( $langcfg) || empty( $langcfg[$key])) {exit($langcfg[$key]);
			return $default;
		}
		$result = $langcfg[$key];
		if( empty( $params)) {
			return $result;
		}
		foreach( $params as $key=>$value) {
			$result = str_replace(  "(_{$key}_)", $value, $result);
		}
		return $result;
	}
}