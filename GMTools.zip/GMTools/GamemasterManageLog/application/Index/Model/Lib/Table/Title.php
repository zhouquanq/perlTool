<?php

/**
 * 玩家账号
 *
 */
class Moby_Mgrsvr_Index_Model_Lib_Table_Title {
	
	protected $title; 
	
	public function __construct( $title) {
		
	}
	
}
