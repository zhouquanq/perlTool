<?php

/**
 * 玩家账号
 *
 */
class Moby_Mgrsvr_Index_Model_Lib_Table_Data {
	protected $data; 
	
	public function __construct( $data) {
		
	}
}
