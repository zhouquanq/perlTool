<?php

/**
 * 玩家账号
 *
 */
class Moby_Mgrsvr_Index_Model_Lib_ResultSet {
	
	protected $title;
	protected $data;
	
	public function __construct( $title, $data) {
		$this->title = $title;
		$this->data = $data;
	}
	
	
	
}
