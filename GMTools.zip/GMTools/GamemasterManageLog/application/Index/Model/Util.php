<?php

class Moby_Mgrsvr_Index_Model_Util {
	
	public static $program_charset = 'UTF-8';
	public static $db_charset = 'GBK';
	
	public static $defaultPageSize = 10;
	public static $defaultListSize = 5;
	
	/**
	 * 生成用户密码
	 * @param string $passwd 要加密的密码
	 * @throws Exception 
	 * 
	 * @return string 返回加密后的密码
	 */
	public static function genPass( $passwd) {
		if( empty( $passwd)) {
			$passwd = "";
		}
		$str = md5( $passwd);
		return substr($str,5,16);
	}
	
	/**
	 * 生成分页对象
	 * @param int $pageIndex 当前页
     * @param int $rowCount 总共记录条数
	 * @param int $pageSize 每页记录条数
	 * @param int $listSize 分页列表链接显示数量
	 * 
	 * @return object 创建的分页对象:
	 * page->count:总页数
	 * page->curr:当前页号
	 * page->next:下页号,0代表无
	 * page->prev:上页号,0代表无
     * page->last:尾页号
     * 
     * page->list: 超链接数字页号列表
     * page->listmin:最小超链接数字页号
     * page->listmax:最大超链接数字页号
    */
	public static function genPage( $pageIndex, $rowCount, $pageSize=null, $listSize=null) {
		if( empty( $rowCount) || !is_numeric( $rowCount) || $rowCount < 0) {
			throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_UTIL_NoPage'));
		}
		
		if( empty( $pageSize) || !is_numeric( $pageSize) || $pageSize <= 0) {
			$pageSize = self::$defaultPageSize;
		}
		
		if( null === $listSize || !is_numeric( $listSize) || $listSize < 0) {
			$listSize = self::$defaultListSize;
		}
		
		$page = new stdClass();

		$page->count = ceil( $rowCount/$pageSize);
		if( $pageIndex > $page->count) {
			$pageIndex = $page->count;
		} 
		if( $pageIndex< 1) {
			$pageIndex = 1;
		}
		
		$page->curr = $pageIndex;
		if( $page->curr == $page->count) {
			$page->next = 0;
		} else {
			$page->next = $page->curr+1;
		}
		
		if( $page->curr <= 1) {
			$page->prev = 0;
		} else {
			$page->prev = $page->curr-1;
		}
		
		$page->last = $page->count;
		
		$page->list = array();
		
		if( $listSize > 0) {
			if( $page->count <= $listSize) {
				$min = 1;
				$max = $page->count;
			} else {
				$listSize = intval( $listSize);
				if( $listSize % 2 == 1) {
					$listd = ($listSize-1)/2;
				} else {
					$listd = ($listSize)/2;
				}
				
				if( $page->curr > $listd) {
					$min = $page->curr - $listd;
					$max = $min + $listSize - 1;
					if( $max > $page->count) {
						$max = $page->count;
						$min = $max - $listSize + 1;
					}
				} else {
					$min = 1;
					$max = $min + $listSize - 1;
				}
				
				if( $min < 1) {
					$min = 1;
				}
				
				if( $max > $page->count) {
					$max = $page->count;
				}
			}
			
			if( $max > $min) {
				for ( $i = $min; $i <= $max; $i++) {
					$page->list[] = $i;
				}
				$page->listmin = $min;
				$page->listmax = $max;
			}
		}
		
		return $page;
	}
	
	/**
	 * 编码到数据库字符集(支持数组)
	 */
	public static function encodeToDb($content) {
		return $content;
	}
	
	/**
     * 解码到网页字符集(支持数组)
	 */
	public static function decodeToDb($content) {
		return $content;	
	}
	
	/**
	 * 创建多级目录
	 * @param string $path
	 */
	public static function createFolder( $path) {
		if( !file_exists( $path)) {
			self::createFolder( dirname( $path));
			mkdir( $path, 0777);
		}
	}
	
	
	
	 /**
	 * 递归删除文件夹
	 * @param string $path
	 */
	public static function deleteFolder($path) {
		if (is_dir($path)) {
			$handle = opendir($path);
			while ($file = readdir($handle)) {
				if (is_dir("$path/$file")){
					if ($file !== '.'&&$file !== '..') {
						self::deleteFolder("$path/$file");
					}
				}else {
					unlink("$path/$file");
				}
			}
			closedir($handle);
			rmdir($path);
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * 获取字符串长度按gbk算(1个汉字两个长度,一个字母一个长度)
	 */
	public static function getStringLength( $str) {
		$length = 0;
		if( !$str) {
			return $length;
		}
		$str_ = iconv( "UTF-8", "GBK", $str);
		$length = strlen( $str_);
		return $length;
	}
	
	/**
	 * 保存文件到本地
	 * @param 文件路径 $url
	 * @param 保存本地路径 $savePath
	 * @return string
	 */
	public function downloadFile($url,$savePath='',$filename=null) {
		if ($filename == null) {
			$fileName = $this->getUrlFileExt($url);
	    	$fileName = rand(0,1000).$fileName;
		}else {
			$fileName = $filename;
		}
		
		//暂时关闭错误输出 和超时限制
        error_reporting(0);
        ini_set('max_execution_time', 0);
        
//		$file = file_get_contents($url);
//		
//		//打开错误和时限
//        ini_set('max_execution_time', 30);
//        error_reporting(E_ALL ^ E_NOTICE); 
//		
//		if ($file === false) {
//			return false;
//		}
//		$result = file_put_contents($savePath.$fileName,$file);
		$found = self::file_exists($url);
		if ($found == true) {
			$result = self::downloadBypieces($url,$savePath.$fileName);
		    return $fileName;
		}else {
			return false;
		}
	}
	
	/**
	 * 获取文件扩展名
	 * @param 网页URL $url
	 * @return string
	 */
	public function getUrlFileExt($url) {
		$ary = parse_url($url);
		$file = basename($ary['path']);
		$ext = explode('.',$file);
		return $ext[1];
	}
	
	public function downloadBypieces( $filenameSource, $filenameTarget) {
		$fhSrc = fopen( $filenameSource, "r");
		$fhTar = fopen( $filenameTarget, "w");
		while( !feof( $fhSrc )) {
		    $section = fread( $fhSrc, 1024);
		    fwrite( $fhTar, $section);
		}
		fclose( $fhTar);
		fclose( $fhSrc);
	}
	
	/**
	 * 文件下载
	 * @param $filepath 路径(相对)
	 * @param $filename 文件名(含扩展名)
	 */
	public function fileDowmload ($filepath=null,$filename=null) {
		if ($filepath&&$filename) {
			$filedown = $filepath.'/'.$filename;
			if(is_file($filedown)) {
				//暂时关闭错误输出 和超时限制
//		        error_reporting(0);
		        ini_set('max_execution_time', 0);
		        
//		        $result = file_get_contents( $filedown);
//		        
			    header("Pragma: public");
			    header("Expires: 0");
			    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
			    header("Cache-Control: private", false);
			    header("Content-Type: application/force-download");
			    header("Content-Disposition: attachment; filename=" . basename($filedown));
			    header("Content-Length: ". filesize($filedown));
			    header("Content-Transfer-Encoding: binary");
			    header("Cache-Control: no-cache, must-revalidate");
			    header("Moby-Mgrsvr-FileMd5: ". md5_file( $filedown));
			    header("Pragma: no-cache");
			    header("Connection: close");
//			    echo $result;
			    //readfile($filedown);
			    
			    //打开错误和时限
		        #ini_set('max_execution_time', 30);
		        #error_reporting(E_ALL ^ E_NOTICE); 
		        
			    $fhSrc = fopen( $filedown, "r");
				while( !feof( $fhSrc )) {
				    echo fread( $fhSrc, 1024);
				}
				fclose( $fhSrc);
			    
			}else {
				return false;
			}
		    return true;
		}else {
			return false;
		}
	}
	
	//Define autoloader
	function __autoload($className) {
	    if (file_exists($className . '.php')) require $className . '.php';
	    else throw new Exception('Class "' . $className . '" could not be autoloaded');
	}
	
	public static function factory ($type=null) {
		if ($type === null) {
			return false;
		}
		$class = 'Moby_Mgrsvr_Index_Model_'.$type;
		try {
			if (!class_exists($class)) {
				return false;
			}
		}
		
		catch (Exception $e) {
	        return false;
	    }
		
		return new $class ();
	}
	
	public function file_exists($url) {
		$curl = curl_init($url);
		// 不取回数据
		curl_setopt($curl, CURLOPT_NOBODY, true);
		// 发送请求
		$result = curl_exec($curl);
		$found = false;
		// 如果请求没有发送失败
		if ($result !== false) {
			// 再检查http响应码是否为200
			$statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);  
			if ($statusCode == 200) {
				$found = true;  
			}
		}
		curl_close($curl);
		
		return $found;

	}
}