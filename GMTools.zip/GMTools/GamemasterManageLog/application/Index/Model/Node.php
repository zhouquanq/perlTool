<?php
/**
 * 节点操作
 *
 */
class Moby_Mgrsvr_Index_Model_Node {
	
	private static $_instance = null;
	
	public static function getInstance(){
		if( null === self::$_instance) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	
	protected $adminnode = null;
	
	public function __construct() {
		$this->adminnode = new Moby_Mgrsvr_Index_Model_DbTable_Virtual_Node();
	}
	
	/**
	 * 根据id查询节点
	 * @param int $id 节点id
	 */
	public function getById( $id) {
		return $this->adminnode->findById( $id);
	}
	
	/**
	 * 查询节点列表根据节点id列表
	 * @param array|string $nodeids
	 * @param int 是否可用(1可用,2不可用,如果忽略则查询所有)
	 * 
	 * @return array 节点列表
	 */
	public function getListByIds( $nodeids, $enable=null) {
		return $this->adminnode->getListByIds( $nodeids, $enable);
	}
	
	public function getListByPowerIds( $powerids, $enable) {
		return $this->adminnode->getListByPowerIds( $powerids, $enable);
	}
	
	public function getListByNotApex( ) {
		return $this->adminnode->getListByNotApex( );
	}
	
	/**
	 * 查询管理员列表(分页)
	 * @param string $pageindex 当前页
	 * @param string $pagecount 每页记录条数
	 * @param string $account 账号
	 */
	public function getList( $page, $pageSize, $name=null, $enable=null) {
		$list = $this->adminnode->getList( $name);
		$rowCount = count( $list);
		if( $rowCount > 0) {
			$pages = Moby_Mgrsvr_Index_Model_Util::genPage( $page, $rowCount);
			$startindex = ($page-1)*$pageSize;
			$resultlist = array_slice ( $list, $startindex, $pageSize);
		} else {
			$pages = null;
			$resultlist = array();
		}
		
		return new Moby_Mgrsvr_Index_Model_DbTable_RecordSet( $rowCount, $resultlist, $pages);
	}
	
	public function getAvaiPweList( ) {
		return $this->adminnode->getAvaiPweList();
	}
	
	/**
	 * 添加节点
	 * @param stting $name 节点名称
	 * @param stting $parentid 父节点id
	 * @param int $powerid 权限id
	 * @param int $enable 是否可用(1可用,0不可用)
	 * 
	 * @return int|boolean 如果成佛那个返回插入数据的自增id,否则返回false
	 */
	public function add( $name, $parentid=0, $powerid=0, $enable=1) {
		return $this->adminnode->add( $name, $parentid, $powerid, $enable); 
	}
	
	/**
	 * 修改节点
	 * @param int $id 节点id
	 * @param stting $name 节点名称
	 * @param stting $parentid 父节点id
	 * @param int $powerid 权限id
	 
	 * 
	 * @return int|boolean 如果成佛那个返回插入数据的自增id,否则返回false
	 */
	public function modify( $id, $name=null, $parentid=null, $powerid=null, $enable=null) {
		return $this->adminnode->modify( $id, $name, $parentid, $powerid, $enable);
	}
	
	/**
	 * 禁用节点
	 * @param int $id
	 */
	public function lockout( $id) {
		return $this->adminnode->lockout( $id);
	}
	
	/**
	 * 解禁节点
	 * @param int $id
	 */
	public function unlock( $id) {
		return $this->adminnode->unlock( $id);
	}
	
	/**
	 * 删除节点
	 * @param int|string|array $id 节点id
	 */
	public function remove( $id) {
		return $this->adminnode->remove( $id);
	}
	
	public function getLeftMenu() {
		
	}
}