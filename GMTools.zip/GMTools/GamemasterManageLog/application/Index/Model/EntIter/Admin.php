<?php
/**
 * 角色信息实体
 */
class Moby_Mgrsvr_Index_Model_EntIter_Admin extends Moby_Mgrsvr_Index_Model_EntIter_Base{
	
	private $entityAdmin = null;
	private $modelAdmin = null;
	
	private $serverid = 0;
	
	public function __construct( $data) {
        parent::__construct( $data);
        $this->entityAdmin = new Moby_Mgrsvr_Index_Model_Entity_Admin();
		$this->modelAdmin = Moby_Mgrsvr_Index_Model_Admin::getInstance();
    }
	
	public function packCurrent( $current) {
		return $this->modelAdmin->_fillAccount( $current, $this->entityAdmin);
	}
}