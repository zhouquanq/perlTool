<?php
/**
 * 实体迭代器基类
 */
abstract class Moby_Mgrsvr_Index_Model_EntIter_Base implements Iterator,Countable  {
	private $position = 0;
    private $array = array();  

    public function __construct( $data) {
        $this->position = 0;
        $this->array = $data;
    }

    function rewind() {
        $this->position = 0;
    }

    function current() {
        return $this->packCurrent( $this->array[$this->position]);
    }

    function key() {
        return $this->position;
    }

    function next() {
        ++$this->position;
    }

    function valid() {
        return isset($this->array[$this->position]);
    }
    
    public function count() {
    	return count( $this->array);
    }
    
    abstract public function packCurrent( $current);
}