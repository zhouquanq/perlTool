<?php

class Moby_Mgrsvr_Index_Model_Util_Encode {
	
	private static $_instance;
	
	public static function getInstance() {
		if(empty(self::$_instance)) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	
	/**
	 * 礼包需要物品信息编码
	 * @param array $nditemsary 将物品信息编码成字符串
	 * 
	 * @throws Exception
	 * @return string
	 */
	public function acceEncode( $nditemsary=NULL, $goodNameList) {
		$result = "";
		if( $nditemsary && is_array( $nditemsary)) {
			$resultarr = array();
			//物品信息
			
			foreach( $nditemsary as $item) {
				if ($item['protoid'] == '0') {
					continue ;
				}
				if( empty( $item['protoid']) || $item['protoid'] <= 0 || !array_key_exists( $item['protoid'], $goodNameList)) {
					throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_GFTPKMGR_2').'id('. $item['protoid'].')');
				}
				if( empty( $item['count']) || $item['count'] <= 0) {
					throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_GFTPKMGR_4'));
				}
				$count = $item['count'];
				$maxnumber = $goodNameList[$item['protoid']]['maxCount'];
				while( $count>$maxnumber) {
					$resultarr[] =  $item['protoid'].','.intval( $maxnumber);
					$count -= $maxnumber;
				}
				$resultarr[] = $item['protoid'].','.intval( $count);
			}
			$result = implode( ';', $resultarr);
		}
		
		return $result;
	}
	
	/**
	 * 物品信息解码
	 * @param string $nditemsstr
	 * 
	 * @throws Exception
	 * @return array 
	 */
	public function acceDecode( $nditemsstr, $goodNameList) {
		$temp = array();
		$result = array();
		if( $nditemsstr && (false !== strpos( $nditemsstr, ';'))) {
			$resultarr = explode( ';', $nditemsstr);
			//物品信息
			foreach( $resultarr as $item) {
				$tmparr = explode( ',', trim( $item));
				
				$name = "";
				$desc = "";
				if( empty( $tmparr[0]) || $tmparr[0] <= 0 || !array_key_exists( $tmparr[0], $goodNameList)) {
					throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_GFTPKMGR_2'));
					$name = Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_GFTPKMGR_3');
					$desc = $name;
				} else {
					$name = $goodNameList[$tmparr[0]]['name'];
					$desc = $goodNameList[$tmparr[0]]['desc'];
				}
				if( empty( $item['count']) || $item['count'] <= 0) {
					continue;
				}
				if (isset($temp[$tmparr[0]])) {
					$temp[$tmparr[0]]['protoid'] = $tmparr[0];
					$temp[$tmparr[0]]['count'] += $tmparr[1];
					$temp[$tmparr[0]]['name'] = $name;
					$temp[$tmparr[0]]['desc'] = $desc;
				}else {
					$temp[$tmparr[0]] = array( 'protoid'=> $tmparr[0], 'count'=>intval( $tmparr[1]), 'name'=>$name, 'desc'=>$desc);
				}
			}
			foreach ($temp as $value) {
				$result[] = $value;
			}
		} else if( $nditemsstr && (false !== strpos( $nditemsstr, ','))){
			//物品信息
			$item = $nditemsstr;
			$tmparr = explode( ',', trim( $item));
			if( !empty( $tmparr[0]) && $tmparr[0] > 0) {
				$name = "";
				$desc = "";
				if( !array_key_exists( $tmparr[0], $goodNameList)) {
					throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_GFTPKMGR_2'));
					$name = Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_GFTPKMGR_3');
					$desc = $name;
				} else {
					$name = $goodNameList[$tmparr[0]]['name'];
					$desc = $goodNameList[$tmparr[0]]['desc'];
				}
				if( !empty( $item['count']) && $item['count'] > 0) {
					$result[] = array( 'protoid'=> $tmparr[0], 'count'=>intval( $tmparr[1]), 'name'=>$name, 'desc'=>$desc);
				}
			}
		}
		return $result;
	}
	
	public function GoodsEncode( $nditemsary) {
		$goodNameList = Moby_Mgrsvr_Index_Model_Config::getGoodsNameList();
		return $this->acceEncode( $nditemsary, $goodNameList);
	}
	
	public function GoodsDecode( $nditemsstr) {
		$goodNameList = Moby_Mgrsvr_Index_Model_Config::getGoodsNameList();
		return $this->acceDecode( $nditemsstr, $goodNameList);
	}
	
	public function CardsEncode( $nditemsary) {
		$cardNameList = Moby_Mgrsvr_Index_Model_Config::getCardsNameList();
		return $this->acceEncode( $nditemsary, $cardNameList);
	}
	
	public function CardsDecode( $nditemsstr) {
		$cardNameList = Moby_Mgrsvr_Index_Model_Config::getCardsNameList();
		return $this->acceDecode( $nditemsstr, $cardNameList);
	}
	
}