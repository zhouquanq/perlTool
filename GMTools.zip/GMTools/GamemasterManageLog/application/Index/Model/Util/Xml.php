<?php

class Moby_Mgrsvr_Index_Model_Util_Xml {
	
	public static function getXmlName( $name) {
		if( empty( $name)) {
			throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_UTIL_XML_NameNotNull'));
		}
		return APPLICATION_LANG_PATH.'/xml/'.$name.'.xml';
	}
	
	public static function simpleXMLLoad(  $name) {
		$xmlname = self::getXmlName( $name);
		return simplexml_load_file( $xmlname);
	}
	
	public static function load( $name) {
		if( empty( $name)) {
			throw new Exception( Moby_Mgrsvr_Index_Model_Util_Lang::getByKey( 'APP_INDEX_MODEL_UTIL_XML_NameNotNull'));
		}
		
		$key = 'ConfigXml2php'.$name;
		if( !Zend_Registry::isRegistered( $key)) {
			if( !Moby_Mgrsvr_Index_Model_Util_Cache::isExists( $key)) {
				$xmlname = self::getXmlName( $name);
				$simpleXml = simplexml_load_file( $xmlname);
				$result = self::_load( $simpleXml);
				Moby_Mgrsvr_Index_Model_Util_Cache::save( $key, $result);
			} else {
				$result = Moby_Mgrsvr_Index_Model_Util_Cache::load( $key);
			}
			Zend_Registry::set( $key, $result);
		} else {
			$result = Zend_Registry::get( $key);
		}
		return $result;
	}
	
	private static function _load( $simpleXml) {
		$result = array( 'childrenlist'=>array( ));
		$attributes = $simpleXml->attributes();
		foreach( $attributes as $key=>$value) {
			$result[$key]=(string)$value;
		}
		foreach( $simpleXml->children() as $item) {
			$loadItem = self::_load( $item);
			if (!isset($loadItem['id'])) {
                $result['childrenlist'][] = self::_load($item);
			} else {
                $result['childrenlist'][$loadItem['id']] = self::_load($item);			 
			}
		}
		return $result;
	}
	
}