<?php

class Moby_Mgrsvr_Index_Model_Util_Log {
	
	protected static $_instance = array();
	public static $logtype = array();
	public static function getInstance( $key) {
		if( empty( $key)) {
			throw new Exception( 'the log name can not be null');
		}
		if( !array_key_exists( $key, self::$_instance)) {
			self::$_instance[$key] = new self( APPLICATION_PATH.'/../data/logs/'.$key);
		} 
		return self::$_instance[$key];
	}
	
	protected $handle = null;
	
	public function __construct( $dir) {
		Moby_Mgrsvr_Index_Model_Util::createFolder( $dir);
		$filename = $dir.'/'.date('Y-m-d').'.log';
		$this->handle = fopen( $filename, 'a');
	}
	
	public function record( $content) {
		$content = sprintf( "[%s] [%s] [%s]\n", date( 'Y-m-d H:i:s'), APP_REQ_UUID, $content);
		
		fputs( $this->handle, $content);
	}
	
	public function close() {
		if( $this->handle) {
			fclose( $this->handle);
		}
	}
	
	public function __destruct() {
		$this->close();
	}
}