<?php
/**
 * 临时文件Model
 * @author Colin
 *
 */

class Moby_Mgrsvr_Index_Model_Util_Tmpfile {
	private $fid;
	private $tmpdir = '/../data/tmp/'; //临时文件存放目录
	
	public function __construct($fid) {
		$this->fid = $fid;
		Moby_Mgrsvr_Index_Model_Util::createFolder(APPLICATION_PATH.$this->tmpdir);
	}
	/*
	 * 追加写入
	 */
    public function putTmpFile($datas) {
        $file = $this->getTmpFile();   
        
        ob_start();
        $fh = fopen($file, 'ab');
        ob_end_clean();
        if (false == $fh)                                            
             throw new Exception();
        fwrite($fh, $datas);
        fclose($fh);    
    }
    
    /**
     * 删除
     */
    public function delTmpFile() {
        $file = $this->getTmpFile($this->fid);
        if (file_exists($file))
           unlink($file);
    }
    
    /**
     * 返回文件路径
     */
    public function getTmpFile() {              
        return APPLICATION_PATH.$this->tmpdir.$this->fid;       
    }       
    
    /**
     * 下载文件
     * @param $disp_filename 建议保存文件名
     */
    public function downFile($disp_filename) {
        $disp_filename = urlencode($disp_filename);
        $disp_filename = str_replace('+', '%20', $disp_filename);
        $ua = $_SERVER['HTTP_USER_AGENT'];
        
        header("Content-Type: application/force-download");
        //解决中文文件名乱码
        if (preg_match("/MSIE/", $ua)) {
            header('Content-Disposition: attachment; filename="'.$disp_filename.'"');
        } else if (preg_match("/Firefox/", $ua)) {
            header('Content-Disposition: attachment; filename*="utf8\'\''.$disp_filename.'"');
        } else {
            header('Content-Disposition: attachment; filename="'.$disp_filename.'"');
        }               
                                
        readfile($this->getTmpFile());        
        return;
    }	
}