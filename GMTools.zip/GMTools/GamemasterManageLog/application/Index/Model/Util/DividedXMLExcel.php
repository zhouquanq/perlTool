<?php
/**
 * DividedXMLExcel AND DividedXMLSheet 类
 * 可分段输出的XMLExcel
 * @author Colin
 */
require_once('XMLExcel.php');

class Moby_Mgrsvr_Index_Model_Util_DividedXMLExcel extends Moby_Mgrsvr_Index_Model_Util_XMLExcel {
    public function __construct($filename) {
    	parent::__construct($filename);
    }
    	
    public function getSheet(){
        if (!isset($this->workSheet)) {
            $this->workSheet = new DividedXMLSheet('sheet0');   //只支持一个工作表
        }
        return $this->workSheet;
    }

    /**
     * 获取Excel表格头部
     */
	public function getHeader() {
		$xmloutput = stripslashes(sprintf($this->header, $this->encoding));
        $xmloutput .= $this->styles;	    
        $xmloutput .= $this->workSheet->getHeader(); 

        return $xmloutput;
	}
	
	/**
	 * 获取(部分)行
	 */
	public function getRows() {
		$xmloutput = $this->workSheet->getRows();
		
		return $xmloutput;
	}
	
	/**
	 * 获取尾部
	 */
	public function getFooter() {
		$xmloutput = $this->workSheet->getFooter();
		$xmloutput .= $this->footer;
		
		return $xmloutput;
	}
}

class DividedXMLSheet extends XMLSheet {
    public function getHeader() {
        $lines = array();
        //工作表头
        $sheetTitle  = "\n<Worksheet ss:Name=\"" . $this->sheetTitle . "\">";
        $sheetTitle .= "\n<Table {$this->defaultHeight} {$this->defaultWidth}>\n";
        array_push($lines, $sheetTitle);
        
        //列属性数据XML元素
        array_push($lines, $this->_getColumns());
        return join("",$lines);    	
    }
    	
    public function getRows() {
    	$line = '';
        //按行的单元格数据XML元素
        foreach($this->units as $row => $cols) {
            $height = isset($this->rows_height[$row]) ? 
                      $this->rows_height[$row]:
                      '';
            //行头XML字符串          
            //$line .= "\n<Row ss:Index=\"{$row}\" {$height} >";
            $line .= "\n<Row {$height} >";  //部分行不能有Row Index
            
            //单元格按列循环
            foreach($cols as $col=> $ceil){
                //判断合并
                $mergeDown = isset($ceil['mergeDown']) ? 'ss:MergeDown="'.$ceil['mergeDown'].'"':'';
                $mergeAcross = isset($ceil['mergeAcross']) ? 'ss:MergeAcross="'.$ceil['mergeAcross'].'"':'';                
                //数据
                $data = isset($ceil['data']) ? $ceil['data']: '';                
                $type = is_string($data) ? 'String' : 'Number';
                
                //单元格XML字符串
                $line .= "\n<Cell ss:Index=\"$col\"  $mergeAcross $mergeDown><Data ss:Type=\"$type\">$data</Data></Cell>";
            }
            
            $line .= "\n</Row>";
        }
        
        return $line;
    }
        
    public function getFooter() {
    	return "\n</Table>\n</Worksheet>\n";
    }    	
}