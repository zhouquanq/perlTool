<?php
class Moby_Mgrsvr_Index_Model_Util_Code {
	
	protected static $_instance = array();
	public  $filename = null;
	
	public static function getInstance( $key) {
		if( empty( $key)) {
			throw new Exception( 'the code name can not be null');
		}
		//根据$key查找对应的文件,如果没有就创建文件
		if( !array_key_exists( $key, self::$_instance)) {
			self::$_instance[$key] = new self( $key,APPLICATION_PATH.'/../data/codes/'.$key);
		} 
		return self::$_instance[$key];
	}
	
	protected $handle = null;
	
	public function __construct( $key,$dir) {
		Moby_Mgrsvr_Index_Model_Util::createFolder( $dir);
		$this->filename = $key.'_'.date('Y-m-d').'.txt';
		$path = $dir.'/'.$key.'_'.date('Y-m-d').'.txt';
		$this->handle = fopen( $path, 'a');
	}
	
	public function format($strcode){
		return  sprintf( "[%s]\r\n",  $strcode);
	}
	public function record( $content) {
		 return fwrite( $this->handle, $content);
	}
	
	public function close() {
		if( $this->handle) {
			fclose( $this->handle);
		}
	}
	
	public function __destruct() {
		$this->close();
	}
}