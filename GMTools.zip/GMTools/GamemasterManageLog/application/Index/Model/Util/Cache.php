<?php
/**
 * 数据缓存
 * @author Administrator
 *
 */
class Moby_Mgrsvr_Index_Model_Util_Cache {
	
	public static function getFileName( $key) {
		$dir = APPLICATION_PATH.'/../data/cache';
		$filename = strtolower( MD5( "MOBY_MGR_CACHE_". $key).'_'.APPLICATION_LANG).'.php';
		Moby_Mgrsvr_Index_Model_Util::createFolder( $dir);
		$filename = $dir.'/'.$filename;
		return $filename;
	}
	
	/**
	 * 缓存数据
	 * @param string $key
	 * @param array|string $content
	 * @param int $timeout 过期(单位:秒, 0为永不过期)
	 * ps  var_export()函数返回合法的php代码,可以通过将函数的第二个参数设置为 TRUE，从而返回变量的表示
	 */
	public static function save( $key, $content, $timeout=0) {
		if( empty( $key) || empty($content)) {
			return 0;
		}
		$timenow = defined( 'APP_REQ_SARTTIME') ? APP_REQ_SARTTIME : time();
		$content = array( 
			'data'=>$content,
			'time'=>$timenow ,
			'timeout'=>$timeout,
		);
		$filename = self::getFileName( $key);
		return file_put_contents( $filename, '<?php '.PHP_EOL.'return '.var_export( $content, true).';');
	}
	
	public static function load( $key) {
		return self::isExists( $key);
	}
	
	public static function isExists( $key) {
		if( empty( $key)) {
			return 0;
		}
		$filename = self::getFileName( $key);
		if( !file_exists( $filename)) {
			return 0;
		}
		$timenow = defined( 'APP_REQ_SARTTIME') ? APP_REQ_SARTTIME : time();
		$result = require $filename;
		if( !isset( $result['data']) || !isset( $result['time']) || !isset( $result['timeout'])) {
			return 0;
		}
		if( $result['timeout'] !== 0 && $timenow - $result['time'] > $result['timeout']) {
			return 0;
		}
		return $result['data'];
	}
}