<?php
class Moby_Mgrsvr_Index_Model_Util_Lang {

	/**
	 * 获取应用配置
	 */
	public static function getall( $lang) {
		
		$langcfgkey = "ConfigLanguage";
		if( !Zend_Registry::isRegistered( $langcfgkey)) {
			$result = new Zend_Config_Ini( APPLICATION_LANG_PATH.'/lang.ini');
			if( !Moby_Mgrsvr_Index_Model_Util_Cache::isExists( $langcfgkey)) {
				$result = new Zend_Config_Ini( APPLICATION_LANG_PATH.'/lang.ini');
				Moby_Mgrsvr_Index_Model_Util_Cache::save( $langcfgkey, $result->toArray());
			}
			$result = Moby_Mgrsvr_Index_Model_Util_Cache::load( $langcfgkey);
			Zend_Registry::set( $langcfgkey, $result);
		}
		return Zend_Registry::get( $langcfgkey);
	}

	public static function getByKey( $key, array $params = null) {
		$default = "__not_found__";
		//echo $key;
		//return $default;
		$langcfg = self::getall( APPLICATION_LANG);
		if( empty( $langcfg) || empty( $langcfg[$key])) {exit($langcfg[$key]);
			return $default;
		}
		$result = $langcfg[$key];
		if( empty( $params)) {
			return $result;
		}
		foreach( $params as $key=>$value) {
			$result = str_replace(  "(_{$key}_)", $value, $result);
		}
		return $result;
	}
}