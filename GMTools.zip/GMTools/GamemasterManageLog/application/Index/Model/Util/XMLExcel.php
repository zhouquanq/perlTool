<?php
/**
 * XMLExcel AND XMLSheet 类
 *
 * @author Colin
 */

class Moby_Mgrsvr_Index_Model_Util_XMLExcel {
    private $filename;
    protected $workSheet;
    protected $encoding = 'utf-8';
    protected $styles = '';
    
    /**
     * header of html to export excel
     * @var string
     */
    protected $header = "<?xml version=\"1.0\" encoding=\"%s\"?\>\n<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:html=\"ht tp://ww w.w3.org/TR/REC-html40\">"; // please trim space

    /**
     * Footer (of document)
     * @var string
     */
    protected  $footer = "</Workbook>";

    public function __construct($filename) {
            $this->filename = $filename;
    }
    
    /**
     * 返回一张Sheet，如果没有则新建一个sheet对象
     * @param $index    sheet索引，默认0
     */
    public function getSheet($index = 0){
        if (!isset($this->workSheet[$index])){
            $this->workSheet[$index] = new XMLSheet('sheet'.$index);
        }
        return $this->workSheet[$index];
    }
    
    /**
     * 设置一张Sheet
     * @param $sheet    XMLSheet对象
     * @param $index    sheet索引,默认0
     */
    public function setSheet($sheet, $index = 0) {
            $this->workSheet[$index] = $sheet;
    }
    
    
    /*
     * 设置默认样式
     */
    public function setDefaultStyles($font='宋体', $size='10', $vertical='center'){
        $vertical = ucfirst($vertical);
        $this->styles = "\n<Styles>
                        <Style ss:ID=\"Default\" ss:Name=\"Normal\">
                        <Alignment ss:Vertical=\"{$vertical}\"/>
                        <Borders/>
                        <Font ss:FontName=\"{$font}\" x:CharSet=\"134\" ss:Size=\"{$size}\" ss:Color=\"#000000\"/>
                        <Interior/>
                        <NumberFormat/>
                        <Protection/>
                        </Style>
                        </Styles>
                        ";
    }
    
    /**
     * 输出Excel文件
     * @param string $filename
     */
    public function generateXMLs() {        
        header("Content-Type: application/vnd.ms-excel; charset=" . $this->encoding);
        header("Content-Disposition: inline; filename=\"" . $this->filename . ".xls\"");

        $xmloutput = stripslashes(sprintf($this->header, $this->encoding));
        $xmloutput .= $this->styles;
        
        foreach($this->workSheet as $sheet){
            $xmloutput .=$sheet->generateXML();
        }
        
        $xmloutput .= $this->footer;
        echo $xmloutput;
    }
}



/*
 *
 * 
 * 
 * 
 * 
 */
class XMLSheet{
    protected $sheetTitle ;
    
    /**
     * @var 单元格，三维数组:unit[$row][$col] = array('data', 'mergeDown', 'mergeAcross'),$row和$col从1开始
     */
    protected $units = array();    
    /**
     * @var 默认行高字符串
     */
    protected  $defaultHeight;
    /**
     * @var 默认列宽字符串
     */    
    protected $defaultWidth;
    /** 
     * @var 列宽数组 
     */
    private $cols_width = array();    
    /**
     * @var array 行高数组
     */
    protected $rows_height = array();
    
    public function __construct($sheetname) {
        $this->setSheetTitle($sheetname);
    }
    
    /**
     *  设置Sheet Title
     */
    public function setSheetTitle($name){
        $this->sheetTitle = $name;
    }

    /*
     * 设置默认高度
     */
    public function setDefaultHeight($h){
        $this->defaultHeight = "ss:DefaultRowHeight=\"{$h}\"";
    }

    /**
     * 设置默认宽度
     */
    public function setDefaultWidth($w){
        $this->defaultWidth = "ss:DefaultColumnWidth=\"{$w}\"";
    }
    
    /**
     * 设置单元格内容
     *
     *@param $cell string A1    bug: 只支持A-Z列
     *@param $value string 'value'
     */
    public function setCellValue($cell,$value) {
        $row = substr($cell, 1);        
        $col = $this->_toNumber($cell[0]);
        $this->units[$row][$col]['data'] = $value;
        return $this;
    }   
    
    /**
     * 插入一行(行数从1开始)
     * @param array $row_datas    一行数据
     * @param $index              指定的行数,默认下一行
     */
    public function setRow($row_datas, $index = NULL) { 
    	$i = 1;
    	foreach ($row_datas as $data) {
            $ceils[$i++] = array ('data' => $data);    
        }
        
        //判断行数
        if (NULL == $index) {
            if (isset($this->units[1]))
                $this->units[] = $ceils;
            else
                $this->units[1] = $ceils;
        }
        else {
            $this->units[$index] = $ceils;
        }
        
        return $this;
    }
    
    /**
     * 设置行高
     * @param int $row  数字
     * @param $height     
     */
    public function setHeight($row, $height) {
        $this->rows_height[$row] = "ss:Height=\"{$height}\"";
        return $this;
    }
    
    /*
    /**
     * 批量设置列宽度
     * @columns  string "A:100,B:200"
     
    public function setWidths($columns){
        $columns = explode(",",$columns);
        foreach($columns as $column){
            $value = explode(':',$column);
            $this->setWidth($value[0], $value[1]);
        }
    }
    */
    
    /**
     * 设置列宽度
     * @param stirng $col  字母
     * @param $width
     */
    public function setWidth($col, $width){
        $this->cols_width[$this->_toNumber($col)] = $width;
        return $this;
    }

    /**
     * 合并
     * @param string $merge
     */
    public function setMerge($merge){
        $merge = explode(":",$merge);
        
        $col1 = substr($merge[0],0,1);
        $row1  = substr($merge[0],1);
        
        $col2 = substr($merge[1],0,1);
        $row2 = substr($merge[1],1);
        
        //行相同,是横向合并
        if($col1.$row2 == $merge[0]) {
            return $this->setMergeAcross($merge[0].':'.$merge[1]);
        }
        //列相同,是纵向合并
        if($col2.$row1 == $merge[0]){
            return $this->setMergeDown($merge[0].':'.$merge[1]);            
        }       
    }

    /**
     * 批量合并，多个用逗号分隔
     * @param string "A3:D5" | "A3:D5,B3:E4"
     */
    public function setMerges($merges){
        $merges = explode(",",$merges);
        foreach($merges as $merge){
            $this->setMerge($merge);
        }
        return $this;
    }
    
    /*
     * 生成Sheet XML文本
     */
    public function generateXML(){
        $lines = array();
        //工作表头
        $sheetTitle  = "\n<Worksheet ss:Name=\"" . $this->sheetTitle . "\">";
        $sheetTitle .= "\n<Table {$this->defaultHeight} {$this->defaultWidth}>\n";
        array_push($lines, $sheetTitle);
        
        //列属性数据XML元素
        array_push($lines, $this->_getColumns());

        //按行的单元格数据XML元素
        foreach($this->units as $row => $cols) {
            $height = isset($this->rows_height[$row]) ? 
                      $this->rows_height[$row]:
                      '';
            //行头XML字符串          
            $line = "\n<Row ss:Index=\"{$row}\" {$height} >";
            
            //单元格按列循环
            foreach($cols as $col=> $ceil){
                //判断合并
                $mergeDown = isset($ceil['mergeDown']) ? 'ss:MergeDown="'.$ceil['mergeDown'].'"':'';
                $mergeAcross = isset($ceil['mergeAcross']) ? 'ss:MergeAcross="'.$ceil['mergeAcross'].'"':'';                
                //数据
                $data = isset($ceil['data']) ? $ceil['data']: '';                
                $type = is_string($data) ? 'String' : 'Number';
                
                //单元格XML字符串
                $line .= "\n<Cell ss:Index=\"$col\"  $mergeAcross $mergeDown><Data ss:Type=\"$type\">$data</Data></Cell>";
            }
            
            $line .= "\n</Row>";
            array_push($lines, $line);
        }

        array_push($lines,"\n</Table>\n</Worksheet>\n");
        return join("",$lines);
    }
    
    /*
     * 批量纵向合并(逗号分隔)
     *
     * @param string "A3:A5"|A3:A5,B3:B5
     *
     * @return void
     */
    private function setMergeDowns($mergeDowns){
        $mergeDowns = explode(",",$mergeDowns);
        foreach($mergeDowns as $mergeDown){
            $this->setMergeDown($mergeDown);
        }
        return $this;
    }
    
    /**
     * 纵向合并
     * @param string $mergeDown "A3:A5"
     */
    private function setMergeDown($mergeDown){
        $units = explode(":",$mergeDown);
        
        if($units[0][0] != $units[1][0]){
            return $this;//列不同无法合并
        }

        $md = substr($units[1],1) - substr($units[0],1);                
        if ($md <= 0){
            return $this;//顺序错误 
        }
        
        $col = $this->_toNumber($units[0][0]);
        $row = substr($units[0],1);        
        $this->units[$row][$col]['mergeDown'] = $md;
        
        return $this;
    }

    /*
     * 批量横向合并(逗号分隔)
     *
     * @param string "A3:D3" |"A3:D3,B6:E5"
     * @return void
     */
    private function setMergeAcrosses($mergeAcrosses){
        $mergeAcrosses = explode(",",$mergeAcrosses);
        foreach($mergeAcrosses as $mergeAcross){
            $this->setMergeAcross($mergeAcross);
        }
        return $this;
    }
    
    /**
     * 横向合并
     * @param string $mergeAcross  "A3:D3"
     */
    private function setMergeAcross($mergeAcross){
        $units = explode(":",$mergeAcross);
        
        if(substr($units[0],1) != substr($units[1],1)){
            return $this; //行不同无法合并
        }       

        $ma = $this->_toNumber($units[1][0]) - $this->_toNumber($units[0][0]);
        if ($ma <= 0){
            return $this; //顺序错误 
        }
        
        $col = $this->_toNumber($units[0][0]);
        $row = substr($units[0],1);
        $this->units[$row][$col]['mergeAcross'] = $ma;

        return $this;
    }
    
    /**
     * 返回XML列属性元素(含列宽属性)
     */
    protected  function _getColumns(){
        $columns = '';
        foreach($this->cols_width as $col=>$width){
            $columns .= "\n<Column ss:Index=\"".$col."\" ss:AutoFitWidth=\"0\" ss:Width=\"{$width}\"/>";
        }
        return $columns;
    }
    
    /*
     * 字母列转化为数字
     * @param $letter string
     * bug: 只支持A-Z列
     */
    private function _toNumber($letter){
        return ord($letter) - 64;
    }
    
    private function displayError($error){
        echo $error;
        exit;
    }
}
