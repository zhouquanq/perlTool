<?php
class Moby_Mgrsvr_Index_Model_AdminGroup {
	
	protected $adminGroup = NULL;
	
	public function __construct() {
		$this->adminGroup = new Moby_Mgrsvr_Index_Model_DbTable_Admin_Group();
	}
	
	/**
	 * 查询用户组
	 * @param int $groupid 用户组id
	 */
	public function getById( $groupid) {
		return $this->adminGroup->findById( $groupid);
	}
	
	/**
	 * 查询用户组根据组名 
	 * @param string $name
	 */
	public function getByName( $name) {
		return $this->adminGroup->rowCount( array( 'ag_name=?'=>$name));
	}
	
	/**
	 * 添加用户组
	 * @param string $name
	 * @param boolean $islock
	 * @param array $powerids
	 * @param array $pubchecklist
	 */
	public function add( $name, $islock, array $powerids=null) {
		$this->adminGroup->add( $name, $islock);
		$groupid = $this->adminGroup->lastInsertId();
		
		if( $powerids) {
			$adminGroupPower = new Moby_Mgrsvr_Index_Model_DbTable_Admin_GroupPower();
			$adminGroupPower->addPower( $groupid, $powerids);
		}
		
		return $groupid;
	}
	
	/**
	 * 修改用户组
	 * @param int $groupid
	 * @param string $name
	 * @param boolean $islock
	 * @param array $powerids
	 * @param array $pubchecklist
	 */
	public function modify( $groupid, $name, $islock, $powerids) {
		$this->adminGroup->modify( $groupid, $name, $islock);
		
		$adminGroupPower = new Moby_Mgrsvr_Index_Model_DbTable_Admin_GroupPower();
		$adminGroupPower->remove( $groupid);
		if( $powerids) {
			$adminGroupPower->addPower( $groupid, $powerids);
		}
		return $groupid;
	}
	
	/**
	 * 查询用户组列表(分页)
	 * @param string $pageindex 当前页
	 * @param string $pagecount 每页记录条数
	 * @param string $name 用户组名称
	 */
	public function getList( $pageIndex, $pageSize, $name=null) {
		return $this->adminGroup->getList( $pageIndex, $pageSize, $name);
	}

	public function getAll( ) {
		return $this->adminGroup->fetchAllByCond( );
	}
	
	public function getAvaiAll() {
		return $this->adminGroup->fetchAllByCond( array('ag_islock=?'=>0));
	}
	
	/**
	 * 查询用户组数量
	 * @param string $name 用户组名称
	 */
	public function getCount( $name=null) {
		return $this->adminGroup->getCount( $name);
	}
	
	/**
	 * 获取用户组权限
	 * @param int $groupid
	 */
	public function getPowerList( $groupid) {
		$result = array();
		$adminGroupPower = new Moby_Mgrsvr_Index_Model_DbTable_Admin_GroupPower();
		$groupPowerList = $adminGroupPower->getListByGroupids( $groupid);
		foreach( $groupPowerList as $item) {
			$result[$item] = 1;
		}
		return $result;
	}
	
	public function getListidByAccid( $accountid) {
		$dbTableAccGpr = new Moby_Mgrsvr_Index_Model_DbTable_Admin_AccountGroup();
		$dbTableGrp = new Moby_Mgrsvr_Index_Model_DbTable_Admin_Group();
		$lockGroupids = $dbTableGrp->getLock();
		return $dbTableAccGpr->getGroupList( $accountid, $lockGroupids, true);
	}
}