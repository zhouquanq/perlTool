<?php
/**
 * 账号信息实体
 */
class Moby_Mgrsvr_Index_Model_Entity_Admin extends Moby_Mgrsvr_Index_Model_Entity_Base{
	/**
	 * var $accountid 账号id
	 */
	private $accountid = 0;

	/**
	 * var $account string 账号
	 */
	private $account = "";
	
	/**
	 * var $realname string 真实名称
	 */
	private $realName = "";
	
	/**
	 * var $password string 密码
	 */
	private $password = "";
	
	/**
	 * var $savepass string 存储用的密码
	 */
	private $savepass = "";
	
	/**
	 * var $regTime datetime 注册时间
	 */
	private $regTime = '';
	
	/**
	 * var $lock string 是否被锁定
	 */
	private $lock = "";
	
	/**
	 * var $regip string 注册ip
	 */
	private $regip = "";
	
	/**
	 * var $lastip string 最后登录ip
	 */
	private $lastip = "";
	
	/**
	 * var $lastLoginTime datetime 最后登录时间
	 */
	private $lastLoginTime = '';
	
	/**
	 * var $sessionid string 最后登录会话id
	 */
	private $sessionid = "";
	
	/**
	 * var $powerIds array 用户权限id列表
	 */
	private $powerIds = array();
	
	/**
	 * var $groupIds array 用户组id列表
	 */
	private $groupIds = array();
	
	/************ get 方法 ************/
	public function getAccountid() {
		return $this->accountid;
	}

	public function getAccount() {
		return $this->account;
	}

	public function getRealName() {
		return $this->realName;
	}

	public function getPassword() {
		return $this->password;
	}

	public function getSavepass() {
		return $this->savepass;
	}

	public function getRegTime() {
		return $this->regTime;
	}

	public function getLock() {
		return $this->lock;
	}

	public function getRegip() {
		return $this->regip;
	}

	public function getLastip() {
		return $this->lastip;
	}

	public function getLastLoginTime() {
		return $this->lastLoginTime;
	}

	public function getSessionid() {
		return $this->sessionid;
	}

	public function getPowerIds() {
		return $this->powerIds;
	}

	public function getGroupIds() {
		return $this->groupIds;
	}

	/************ set 方法 ************/
	public function setAccountid( $accountid) {
		$this->accountid = $accountid;
		return $this;
	}

	public function setAccount( $account) {
		$this->account = $account;
		return $this;
	}

	public function setRealName( $realName) {
		$this->realName = $realName;
		return $this;
	}

	public function setPassword( $password) {
		$this->password = $password;
		return $this;
	}

	public function setSavepass( $savepass) {
		$this->savepass = $savepass;
		return $this;
	}

	public function setRegTime( $regTime) {
		$this->regTime = $regTime;
		return $this;
	}

	public function setLock( $lock) {
		$this->lock = $lock;
		return $this;
	}

	public function setRegip( $regip) {
		$this->regip = $regip;
		return $this;
	}

	public function setLastip( $lastip) {
		$this->lastip = $lastip;
		return $this;
	}

	public function setLastLoginTime( $lastLoginTime) {
		$this->lastLoginTime = $lastLoginTime;
		return $this;
	}

	public function setSessionid( $sessionid) {
		$this->sessionid = $sessionid;
		return $this;
	}

	public function setPowerIds( $powerIds) {
		$this->powerIds = $powerIds;
		return $this;
	}

	public function setGroupIds( $groupIds) {
		$this->groupIds = $groupIds;
		return $this;
	}
	
	public function getVars() {
		return get_class_vars( __CLASS__);
	}
}