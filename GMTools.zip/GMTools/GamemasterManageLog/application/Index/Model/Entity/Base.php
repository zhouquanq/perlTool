<?php
/**
 * 实体基类
 */
abstract class Moby_Mgrsvr_Index_Model_Entity_Base {
	
	protected static $_null;
	private $_isnull = 0;
	
	public function __construct( array $data=null) {
		$this->setData( $data);
	}
	
	/**
	 * 获取空对象
	 * 
	 * @return self 返回该类型的空对象
	 *
	 */
	public function getNull() {
		if( empty( $this->_null)) {
			$this->_null = new $this->getClass();
			$this->_null->setNull( 1);
		}
		return $this->_null;
	}
		
	/**
	 * 是否是空对象
	 *
	 * @return boolean 是否是空对象
	 */
	public function isNull() {
		return $this->_isnull;
	}
	
	/**
	 * 设置是否为空对象
	 * 
	 * @param boolean $isnull 是否为空对象
	 */
	public function setNull( $isnull) {
		$this->_isnull = $isnull;
	}
		
	/**
	 * 获取对象属性
	 *
	 * @param string $propertyName 属性名称
	 * @param mixd $default 默认值
	 */
	public function __get( $propertyName) {
		if( isset( $this->$propertyName)) {
			return $this->$propertyName;
		}
		else {
			return null;
		} 
	}
	
	/**
	 * 设置对象属性
	 *
	 * @param string $propertyName 属性名称
	 * @param mixd $value 属性值
	 */
	public function __set( $propertyName, $value) {
		if( isset( $this->$propertyName)) {
			$this->$propertyName = $value;
		}
	}
	
	/**
	 * 返回一个包含对象属性的键值对的形式的数据组
	 * 
	 * @return array 数据组
	 */
	public function toArray(){}
	
	/**
	 * 设置数据
	 * @param array $data 数据;
	 * 
	 */
	public function setData( $data){}
	
	/**
	 * 从数据库中的行读取
	 * 
	 * @param array $data 数据库中读取的行数据
	 * 
	 */
	public function setByDbRow( array $data){}
	
	/**
	 * 返回类名
	 * 
	 * @return string 类名
	 *
	 */
	public function getClass(){}
	
	/**
	 * 返回数据库行形式的数据数组
	 *
	 * @return array 数据库行格式数据
	 *
	 */
	public function toDbRow(){}

}