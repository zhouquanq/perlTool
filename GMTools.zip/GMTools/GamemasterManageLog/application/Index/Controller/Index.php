<?php

class Moby_Mgrsvr_Index_Controller_Index extends Moby_Mgrsvr_Index_Controller {

	/**
	 * 定义是否出现在权限列表中 
	 * @var int
	 */
	public $ispower = 1;
	
	/**
	 * 定义操作依赖关系
	 * @var array
	 */
	public $dependent=array();
	
	public function indexAction() {
		$this->_redirect( 'login');
	}
	
	public function loginAction() {
		if( $this->_http->isPost()) {
			$admin = Moby_Mgrsvr_Index_Model_Admin::getInstance();
			$account = $this->_http->getParam( 'account', null);
			$passwd = $this->_http->getParam( 'password', null);
			$code = $this->_http->getParam( 'code', 0);
			
			$servercode = isset( $_SESSION['login_rand_code']) ? $_SESSION['login_rand_code'] : '';
			unset( $_SESSION['login_rand_code']);
			//验证码验证
			if( $code != $servercode) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_INDEX_AuthCodeWrong');
				$this->_redirect( 'login', null, null, array( 'msg'=> $message));
			}
			
			$entityAdmin = new Moby_Mgrsvr_Index_Model_Entity_Admin();
			$entityAdmin->setAccount( $account)
						->setPassword( $passwd)
						->setSavepass( Moby_Mgrsvr_Index_Model_Util::genPass( $passwd))
						->setLastLoginTime( time())
						->setLastip( $this->_http->getClientIp())
						->setSessionid( Moby_Util_UUID::gen());
			try {
				//验证登录
				$entityAdmin = $admin->login( $entityAdmin);
				//更新登录信息(最后登录时间,最后ip)
			} catch( Exception $e) {
				
				$message = $e->getMessage();
				$this->_redirect( 'login', null, null, array( 'msg'=> $message));
			}
			$_SESSION['accountid'] = $entityAdmin->getAccountid();
			$_SESSION['session'] = $entityAdmin->getSessionid();
			$_SESSION['entityAdmin'] = $entityAdmin;
			$this->_redirect( 'index', 'main');
		}
		
		if( isset( $_SESSION['accountid']) && $_SESSION['accountid'] > 0) {
			$this->_redirect( 'index', 'main');
		}
		
		$this->display( 'Index/View/Index/login.tpl.php');
	}
	
	/**
	 * 退出登录
	 */
	public function logoutAction() {
		session_destroy();
		$this->_redirect( 'login');
	}
	
	/**
	 * 验证码
	 */
    public function codeAction() {
    	$this->_http->setRespHeader( 'Content-type', 'image/jpeg');
		//随机字符串/*
		$rand = '';
		for( $i=0; $i<4; $i++){
			$rand.=rand(0,9);
		}
		//生成带有字母的字符串
		/*
		for($i=0;$i<4;$i++){
		$rand.=dechex(rand(0,15));
		}
		*/
		//保存字符串在session中
		$_SESSION['login_rand_code']=$rand;
		
		//建立宽为50高为25的图像
		$im = imagecreate(55, 25);
		//黑色背景,白色文本
		$bg = imagecolorallocate($im, 0, 0, 0);
		$textcolor = imagecolorallocate($im, 255, 255, 255);
		//字符串写入图片
		imagestring($im,5,10,5,$rand,$textcolor);
		//输出图像
		imagejpeg($im);
		//释放内存
		imagedestroy($im);
    }
    
    public function templateAction() {
    	$this->display( 'Index/View/Public/template.tpl.php');
    }
}