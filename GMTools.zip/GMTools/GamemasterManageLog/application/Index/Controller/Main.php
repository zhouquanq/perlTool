<?php

class Moby_Mgrsvr_Index_Controller_Main extends Moby_Mgrsvr_Index_ControllerAuth {

	/**
	 * 定义是否出现在权限列表中 
	 * @var int
	 */
	public $ispower = 1;
	
	/**
	 * 定义操作依赖关系
	 * @var array
	 */
	public $dependent=array();
	
	/**
	 * 后台主页面
	 */
	public function indexAction() {
		$this->display( 'Index/View/Main/index.tpl.php');
	}
	
	public function leftAction() {
		$admin = Moby_Mgrsvr_Index_Model_Admin::getInstance();
		$nodelist = $admin->getLeftMenuList( $this->accountid);
		$this->assign( 'nodelist', $nodelist);
		$this->display( 'Index/View/Main/left_.tpl.php');
	}
	
	public function welcomeAction() {
		$admin = Moby_Mgrsvr_Index_Model_Admin::getInstance();
		$accountInfo = $admin->getById( $this->accountid);
		
		$this->assign( 'account', $accountInfo['a_account']);
		$this->assign( 'lasttime', date( 'Y-m-d H:i:s', $accountInfo['a_lasttime']));
		$this->display( 'Index/View/Main/welcome.tpl.php');
	}
	
	public function setpassAction() {
		if( $this->_http->isPost()) {
			$oldpasswd = $this->_http->getParam( 'oldpasswd', null);
			$newpasswd = $this->_http->getParam( 'newpasswd', null);
			$confirmwd = $this->_http->getParam( 'confirmpw', null);
			$passwd_ = Moby_Mgrsvr_Index_Model_Util::genPass( $newpasswd);

			$modelAdmin = Moby_Mgrsvr_Index_Model_Admin::getInstance();
			$entityAdmin = $modelAdmin->getEntityByAccountid( $this->accountid);
			
			if( empty( $oldpasswd) || empty( $newpasswd) || empty( $confirmwd)) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_MAIN_PutinMessage');
				$this->_redirect( 'setpass', null, null, array( 'msg'=> $message));
			}
			
			if( $newpasswd != $confirmwd) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_MAIN_NewPwdConfirmWrong');
				$this->_redirect( 'setpass', null, null, array( 'msg'=> $message));
			}
			
			if( $entityAdmin->getSavepass() != Moby_Mgrsvr_Index_Model_Util::genPass( $oldpasswd)) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_MAIN_OldPwdWrong');
				$this->_redirect( 'setpass', null, null, array( 'msg'=> $message));
			}
			
			$entityAdmin->setPassword( $newpasswd)
						->setSavepass( $passwd_);
			try {
				$modelAdmin->setInfo( $entityAdmin);
			} catch ( Exception $e) {
				$message = $e->getMessage();
				$this->_redirect( 'setpass', null, null, array( 'msg'=> $message));
			}
			
			$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_BULLETIN_ModifySuccess');
			$this->_redirect( 'setpass', null, null, array( 'msg'=> $message));
		}
		
		$this->display( 'Index/View/Main/setpass.tpl.php');
	}
	
	public function flushcacheAction() {
    	$dir = APPLICATION_PATH.'/../data/cache';
    	if( Moby_Mgrsvr_Index_Model_Util::deleteFolder( $dir)) {
    		$this->_redirect( 'welcome', null, null, array( 'msg'=>'ok'));
    	}
    }
    
    public function refreshpowerAction() {
    	$Power = Moby_Mgrsvr_Index_Model_Power::getInstance();
    	ob_start();
    	$Power->reset();
    	$dir = APPLICATION_PATH.'/../data/cache';
    	Moby_Mgrsvr_Index_Model_Util::deleteFolder( $dir);
    	ob_clean();
    	$this->_redirect( 'welcome', null, null, array( 'msg'=>'ok'));
    }
}