<?php
class Moby_Mgrsvr_Index_Controller_Group extends Moby_Mgrsvr_Index_ControllerPermValid {
	
	/**
	 * 定义操作依赖关系
	 * @var array
	 */
	public $dependent = array(
		'modify'=>'index',
	);
	
	public function indexAction() {
		$page = $this->_http->getParam( 'page', 1);
		$name = $this->_http->getParam( 'name', null);
		
		$ModelAdminGroup = new Moby_Mgrsvr_Index_Model_AdminGroup();
		
		$rowcount = $ModelAdminGroup->getCount( $name);
		
		$pages = null;
		$result = null;
		if( $rowcount > 0) {
			$pages = Moby_Mgrsvr_Index_Model_Util::genPage( $page, $rowcount);
			$result = $ModelAdminGroup->getList( $pages->curr, Moby_Mgrsvr_Index_Model_Util::$defaultPageSize, $name);
		}
		
		$this->assign( 'urlParams', $this->getUrlParams( array( 
			'name'
		)));
		
		$this->assign( 'pages', $pages);
		$this->assign( 'result', $result);
		$this->display( 'Index/View/Group/list.tpl.php');
	}
	
	public function addAction() {
		$Power = Moby_Mgrsvr_Index_Model_Power::getInstance();
		if( $this->_http->isPost()) {
			$name = $this->_http->getParam( 'name', null);
			$islock = $this->_http->getParam( 'islock', null);
			$powerids = $this->_http->getParam( 'powerids', null);
			
			if( empty( $name) || strlen( $name) > 32 || strlen( $name) < 1) {
				$msg = $this->getLang()->get( 'APP_INDEX_CONTROLLER_GROUP_UserGroupNameWrong');
				$this->_redirect( null, null, null, array( 'msg'=> $msg));
			}
			$ModelAdminGroup = new Moby_Mgrsvr_Index_Model_AdminGroup();
			if( $ModelAdminGroup->getByName( $name)) {
				$msg = $this->getLang()->get( 'APP_INDEX_CONTROLLER_GROUP_UserGroupExist');
				$this->_redirect( null, null, null, array( 'msg'=> $msg));
			}
			
			$powerids = $Power->format( $powerids);
			try {
				$ModelAdminGroup->add($name, $islock, array_keys($powerids));
				$msg = $this->getLang()->get( 'APP_INDEX_CONTROLLER_DOCKPUB_AddSuccess');
			} catch( Exception $e) {
				$msg = $e->getMessage();
			}
			$this->_redirect( null, null, null, array( 'msg'=> $msg));
		}
		
		$powerTree = $Power->getTree();
		
		$this->assign('powerTree', $powerTree);
		
		$this->display( 'Index/View/Group/add.tpl.php');
	}
	
	public function modifyAction() {
		$groupid = $this->_http->getParam( 'groupid', null);
		
		$ModelAdminGroup = new Moby_Mgrsvr_Index_Model_AdminGroup();
		$result = $ModelAdminGroup->getById( $groupid);
		
		if( empty( $result)) {
			$msg = $this->getLang()->get( 'APP_INDEX_CONTROLLER_GROUP_UserGroupNotFound');
			$this->_redirect( 'index', null, null, array( 'msg'=> $msg));
		}
	
		$Power = Moby_Mgrsvr_Index_Model_Power::getInstance();
		
		if( $this->_http->isPost()) {
			$name = $this->_http->getParam( 'name', null);
			$islock = $this->_http->getParam( 'islock', null);
			$powerids = $this->_http->getParam( 'powerids', null);
			
			if( empty( $name) || strlen( $name) > 32 || strlen( $name) < 1) {
				$msg = $this->getLang()->get( 'APP_INDEX_CONTROLLER_GROUP_UserGroupNameWrong');
				$this->_redirect( null, null, null, array( 'msg'=> $msg, 'groupid'=>$groupid));
			}
			if( $result['ag_name'] != $name && $ModelAdminGroup->getByName( $name)) {
				$msg = $this->getLang()->get( 'APP_INDEX_CONTROLLER_GROUP_UserGroupExist');
				$this->_redirect( null, null, null, array( 'msg'=> $msg, 'groupid'=>$groupid));
			}
			if( empty( $islock)) {
				$islock = 0;
			} else {
				$islock = 1;
			}
			
			
			$powerids = $Power->format( $powerids);
			try {
				$ModelAdminGroup->modify( $groupid, $name, $islock, array_keys( $powerids));
				$msg = $this->getLang()->get( 'APP_INDEX_CONTROLLER_BULLETIN_ModifySuccess');
			} catch( Exception $e) {
				$msg = $e->getMessage();
			}
			$this->_redirect( null, null, null, array( 'msg'=> $msg, 'groupid'=>$groupid));
		}
		
		$this->assign( 'result', $result);
		$this->assign('powerTree', $Power->getTree());
		$this->assign('grouppowerlist', $ModelAdminGroup->getPowerList( $groupid));
		
		$this->display( 'Index/View/Group/modify.tpl.php');
	}
	
}