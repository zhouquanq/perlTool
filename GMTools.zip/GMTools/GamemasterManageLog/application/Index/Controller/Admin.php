<?php

class Moby_Mgrsvr_Index_Controller_Admin extends Moby_Mgrsvr_Index_ControllerPermValid {
	
	/**
	 * 定义操作依赖关系
	 * @var array
	 */
	public $dependent = array(
		'modify'=>'index',
		'lockout'=>'index',
		'unlock'=>'index',
	);
	
	public function indexAction() {

		$page = $this->_http->getParam( 'page', 1);
		$account = $this->_http->getParam( 'account', null);
		$groupid = intval( $this->_http->getParam( 'groupid', 0));

		$modelAdmin = Moby_Mgrsvr_Index_Model_Admin::getInstance();
		$recordset = $modelAdmin->getList( $page, $account, $groupid);

		$Pages = $recordset->getPage();
		$resultlist = $recordset->getData();

		$this->assign( 'urlParams', $this->getUrlParams( array(
			'account', 'groupid'
		)));

		$mdAdminGrp = new Moby_Mgrsvr_Index_Model_AdminGroup();
		$this->assign( 'grouplist', $mdAdminGrp->getAvaiAll( ));
		$this->assign( 'pages', $Pages);
		$this->assign( 'result', $resultlist);
		$this->display( 'Index/View/Admin/list.tpl.php');
	}

	public function addAction() {

		if( $this->_http->isPost()) {
			$account = $this->_http->getParam( 'account', null);
			$passwd = $this->_http->getParam( 'passwd', "");
			$confirmwd = $this->_http->getParam( 'confirmwd', null);
			$realname = $this->_http->getParam( 'realname', null);
			$grouplist = $this->_http->getParam( 'grouplist', array());

			$passwd_ = Moby_Mgrsvr_Index_Model_Util::genPass( $passwd);
			$entityAdmin = new Moby_Mgrsvr_Index_Model_Entity_Admin();
			$entityAdmin->setAccount( $account)
						->setRealName( $realname)
						->setPassword( $passwd)
						->setSavepass( $passwd_)
						->setRegTime( time())
						->setLock( 0)
						->setLastip( $this->_http->getClientIp())
						->setLastLoginTime( time())
						->setSessionid( Moby_Util_UUID::gen())
						->setPowerIds( $powerids)
						->setGroupIds( $grouplist);

			if( !$entityAdmin->getAccount() || !$entityAdmin->getPassword() || !$confirmwd || !$entityAdmin->getRealName()) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ADMIN_FillinID');
				$this->_redirect( 'add', null, null, array( 'msg'=> $message));
			}

			if( preg_match ( '/\W/', $entityAdmin->getAccount())) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ADMIN_IDStyleWrong1');
				$this->_redirect( 'add', null, null, array( 'msg'=> $message));
			}

			if( strlen( $entityAdmin->getAccount()) > 32 || strlen( $entityAdmin->getAccount()) < 6) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ADMIN_IDStyleWrong2');
				$this->_redirect( 'add', null, null, array( 'msg'=> $message));
			}

			if( preg_match ( '/\W/', $entityAdmin->getPassword())) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ADMIN_PwdStyleWrong1');
				$this->_redirect( 'add', null, null, array( 'msg'=> $message));
			}

			if( strlen( $entityAdmin->getPassword()) > 32 || strlen( $entityAdmin->getPassword()) < 6) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ADMIN_PwdStyleWrong2');
				$this->_redirect( 'add', null, null, array( 'msg'=> $message));
			}

			if( $entityAdmin->getPassword() != $confirmwd) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ACCOUNT_ConfirmPwdWrong');
				$this->_redirect( 'add', null, null, array( 'msg'=> $message));
			}
			
			$modelAdmin = Moby_Mgrsvr_Index_Model_Admin::getInstance();
			
			try {
				$lastid = $modelAdmin->reg( $entityAdmin);
				if(FALSE == $lastid) {
					//失败
					$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ADMIN_CreateFailed');
					throw new Exception( $message);
				}
			} 
			catch( Exception $e) {
				$message = $e->getMessage();
				$this->_redirect( 'add', null, null, array( 'msg'=> $message));
			}

			//记录操作日志
			$this->operatelog( 'addadmin', $entityAdmin->getAccount());

			$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ADMIN_CreateSuccess');
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}

		$modelAdmGrp = new Moby_Mgrsvr_Index_Model_AdminGroup();
		$this->assign('grouplist', $modelAdmGrp->getAvaiAll());
		$this->display( 'Index/View/Admin/add.tpl.php');
	}

	public function modifyAction() {
		$accountid = $this->_http->getParam( 'accountid', null);

		$modelAdmin = Moby_Mgrsvr_Index_Model_Admin::getInstance();
		$entityAdmin = $modelAdmin->getEntityByAccountid( $accountid);
		if( empty( $entityAdmin)) {
			$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ACCOUNT_UserNotExist');
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}

		//处理提交
		if( $this->_http->isPost()) {
			
			$passwd = $this->_http->getParam('passwd', '');
			$confirmwd = $this->_http->getParam('confirmwd', null);
			$realname = $this->_http->getParam('realname', null);
			$powerids = $this->_http->getParam('powerids', array());
			$grouplist = $this->_http->getParam( 'grouplist', array());
			$passwd_ = Moby_Mgrsvr_Index_Model_Util::genPass( $passwd);
			
			$entityAdmin->setRealName( $realname)
						->setPassword( $passwd)
						->setSavepass( $passwd_)
						->setLastip( $this->_http->getClientIp())
						->setLastLoginTime( time())
						->setPowerIds( $powerids)
						->setGroupIds( $grouplist);

			if( !$entityAdmin->getPassword() && empty( $confirmwd) && !$entityAdmin->getRealName()) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ADMIN_FillinID');
				$this->_redirect( 'modify', null, null, array( 'accountid'=>$accountid, 'msg'=> $message));
			}

			if( preg_match ( '/\W/', $entityAdmin->getPassword())) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ADMIN_PwdStyleWrong1');
				$this->_redirect( 'modify', null, null, array( 'accountid'=>$accountid, 'msg'=> $message));
			}

			if( strlen( $entityAdmin->getPassword()) > 32 || strlen( $entityAdmin->getPassword()) < 6) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ADMIN_PwdStyleWrong2');
				$this->_redirect( 'modify', null, null, array( 'accountid'=>$accountid, 'msg'=> $message));
			}

			if( $entityAdmin->getPassword() != $confirmwd) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ACCOUNT_ConfirmPwdWrong');
				$this->_redirect( 'modify', null, null, array( 'accountid'=>$accountid, 'msg'=> $message));
			}
			
			try {
				$modelAdmin->setInfo( $entityAdmin);
			} 
			catch( Exception $e) {
				$message = $e->getMessage();
				$this->_redirect( 'modify', null, null, array( 'accountid'=>$accountid, 'msg'=> $message));
			}

			//记录操作日志
			$this->operatelog( 'modifyadmin', $entityAdmin->getAccount());

			$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ACCOUNT_ModifySuccess');
			$this->_redirect('index', null, null, array( 'msg'=>$message));
		}

		$modelAdmGrp = new Moby_Mgrsvr_Index_Model_AdminGroup();
		$this->assign('grouplist', $modelAdmGrp->getAvaiAll());
		$this->assign('usrgroupidlist', $modelAdmGrp->getListidByAccid( $accountid));
		$this->assign('entityAdmin', $entityAdmin);
		$this->display('Index/View/Admin/modify.tpl.php');
	}

	public function lockoutAction() {
		$accountid = $this->_http->getParam( 'accountid', null);

		$modelAdmin = Moby_Mgrsvr_Index_Model_Admin::getInstance();
		$entityAdmin = $modelAdmin->getEntityByAccountid( $accountid);
		if( empty( $entityAdmin)) {
			$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ACCOUNT_UserNotExist');
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}

		try {
			$modelAdmin->lockout( $accountid);
		} catch ( Exception $e) {
			$message = $e->getMessage();
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}

		//记录操作日志
		$this->operatelog( 'lockoutadmin', $entityAdmin->getAccount());

		$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ADMIN_LockUserSuccess');
		$this->_redirect( 'index', null, null, array( 'msg'=> $message));
	}

	public function unlockAction() {
		$accountid = $this->_http->getParam( 'accountid', null);

		$modelAdmin = Moby_Mgrsvr_Index_Model_Admin::getInstance();
		$entityAdmin = $modelAdmin->getEntityByAccountid( $accountid);
		if( empty( $entityAdmin)) {
			$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ACCOUNT_UserNotExist');
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}

		try {
			$modelAdmin->unlock( $accountid);
		} catch ( Exception $e) {
			$message = $e->getMessage();
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}

		//记录操作日志
		$this->operatelog( 'unlockadmin', $entityAdmin->getAccount());

		$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_ADMIN_UnlockUserSuccess');
		$this->_redirect( 'index', null, null, array( 'msg'=> $message));
	}
}