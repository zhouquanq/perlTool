<?php

class Moby_Mgrsvr_Index_Controller_Error extends Moby_Mgrsvr_Index_Controller {
	
	protected $errorException = null;
	 
	public function __construct( $http, $e) {
		parent::__construct( $http);
		$this->errorException =  $e;
	}
	
	public function indexAction() {}
	
	public function http404Action() {
		$this->display( 'Index/View/Error/http404.tpl.php');
	}
	
	public function http500Action() {
		$this->assign( 'exception', $this->errorException);
		$this->display( 'Index/View/Error/http500.tpl.php');
	}
	
	public function httpdebug500Action() {
		$this->assign( 'exception', $this->errorException);
		$this->display( 'Index/View/Error/httpdebug500.tpl.php');
	}
}