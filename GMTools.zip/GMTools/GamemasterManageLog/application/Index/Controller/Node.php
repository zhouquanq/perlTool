<?php

class Moby_Mgrsvr_Index_Controller_Node extends Moby_Mgrsvr_Index_ControllerPermValid {
	
	/**
	 * 定义操作依赖关系
	 * @var array
	 */
	public $dependent=array(
		'modify'=>'index',
		'lockout'=>'index',
		'unlock'=>'index',
		'remove'=>'index',
	);
	
	/**
	 * 节点列表
	 */
	public function indexAction() {
		//得到当前页数，如果没有就默认为第一页
		$page = $this->_http->getParam( 'page', 1);
		$name = $this->_http->getParam( 'name');
		$enable = $this->_http->getParam( 'enable');
		
		$node = Moby_Mgrsvr_Index_Model_Node::getInstance();
		$name = $this->encodeToDb( $name);
		
		$recordset = $node->getList( $page, Moby_Mgrsvr_Index_Model_Util::$defaultPageSize, $name, $enable);
		
		$Pages = $recordset->getPage();
		$rowCount = $recordset->getRecordCount();
		$resultlist = $recordset->getData();
		
		$this->assign( 'urlParams', $this->getUrlParams( array( 
			'name', 'enable'
		)));
		$this->assign( 'pages', $Pages);
		$this->assign( 'result', $resultlist);
		$this->display( 'Index/View/Node/list.tpl.php');
	}
	
	/**
	 * 添加节点
	 */
	public function addAction() {
		
		$node = Moby_Mgrsvr_Index_Model_Node::getInstance();
		if( $this->_http->isPost()) {
			$name = $this->_http->getParam( 'name', null);
			$parentid = $this->_http->getParam( 'parentid', null);
			$powerid = $this->_http->getParam( 'powerid', null);
			
			if( empty( $name) ) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_NODE_FillinNodeName');
				$this->_redirect( 'add', null, null, array( 'msg'=> $message));
			}
			
			$name = $this->encodeToDb( $name);
			try {
				if( !$node->add( $name, $parentid, $powerid)) {
					$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_NODE_AddFailed');
					$this->_redirect( 'add', null, null, array( 'msg'=> $message));
				}
			} catch( Exception $e) {
				throw new Exception( $e);
				$message = $e->getMessage();
				$this->_redirect( 'add', null, null, array( 'msg'=> $message));
			}
			
			//记录操作日志
			$this->operatelog( 'addnode', $this->decodeToDb( $name));
			
			$message = $this->getLang()->get('APP_INDEX_CONTROLLER_DOCKPUB_AddSuccess');
			$this->_redirect( 'add', null, null, array( 'msg'=> $message));
		}
		$power = Moby_Mgrsvr_Index_Model_Power::getInstance();
		$powerlist = $power->getTopList();
		$notApexList = $node->getListByNotApex();
		
		$this->assign( 'notApexList', $notApexList);
		$this->assign( 'powerlist', $powerlist);
		
		$this->display( 'Index/View/Node/add.tpl.php');
	}
	
	/**
	 * 修改节点信息
	 */
	public function modifyAction() {
		$id = $this->_http->getParam( 'nodeid');
		
		if( empty( $id)) {
			$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_NODE_NodeNotExist');
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}
		
		$node = Moby_Mgrsvr_Index_Model_Node::getInstance();
		$nodeInfo = $node->getById( $id);
		if( empty( $nodeInfo)) {
			$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_NODE_NodeNotExist');
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}
		
		if( $this->_http->isPost()) {
			$name = $this->_http->getParam( 'name', null);
			$parentid = $this->_http->getParam( 'parentid', null);
			$powerid = $this->_http->getParam( 'powerid', null);
			$enable = $this->_http->getParam( 'enable', null);
			
			if( empty( $name) ) {
				$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_NODE_FillinNodeName');
				$this->_redirect( 'modify', null, null, array( 'msg'=> $message));
			}
			
			$name = $this->encodeToDb( $name);
			try {
				$node->modify( $id, $name, $parentid, $powerid, $enable);
			} catch( Exception $e) {
				$message = $e->getMessage();
				$this->_redirect( 'modify', null, null, array( 'msg'=> $message));
			}
			
			//记录操作日志
			$this->operatelog( 'modifynode', $this->decodeToDb( $nodeInfo['n_name'])."\t".$this->decodeToDb( $name));
			
			$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_BULLETIN_ModifySuccess');
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}
		
		$power = Moby_Mgrsvr_Index_Model_Power::getInstance();
		$powerlist = $power->getTopList();
		$notApexList = $node->getListByNotApex();
		
		$this->assign( 'nodeInfo', $nodeInfo);
		$this->assign( 'notApexList', $notApexList);
		$this->assign( 'powerlist', $powerlist);
		
		$this->display( 'Index/View/Node/modify.tpl.php');
	}
	
	/**
	 * 禁用节点
	 */
	public function lockoutAction() {
		$id = $this->_http->getParam( 'nodeid', null);
		
		if( empty( $id)) {
			$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_NODE_NodeNotExist');
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}
		
		$node = Moby_Mgrsvr_Index_Model_Node::getInstance();
		$nodeInfo = $node->getById( $id);
		if( empty( $nodeInfo)) {
			$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_NODE_NodeNotExist');
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}
		
		try {
			$node->lockout( $id);
		} catch ( Exception $e) {
			$message = $e->getMessage();
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}
		
		//记录操作日志
		$this->operatelog( 'lockoutnode', $this->decodeToDb( $nodeInfo['n_name']));
		
		$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_NODE_LockNodeSuccess');
		$this->_redirect( 'index', null, null, array( 'msg'=> $message));
	}
	
	/**
	 * 解禁节点
	 */
	public function unlockAction() {
		$id = $this->_http->getParam( 'nodeid', null);
		
		if( empty( $id)) {
			$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_NODE_NodeNotExist');
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}
		
		$node = Moby_Mgrsvr_Index_Model_Node::getInstance();
		$nodeInfo = $node->getById( $id);
		if( empty( $nodeInfo)) {
			$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_NODE_NodeNotExist');
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}
		
		try {
			$node->unlock( $id);
		} catch ( Exception $e) {
			$message = $e->getMessage();
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}
		
		//记录操作日志
		$this->operatelog( 'unlocknode', $this->decodeToDb( $nodeInfo['n_name']));
		
		$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_NODE_UnlockNodeSuccess');
		$this->_redirect( 'index', null, null, array( 'msg'=> $message));
	}
	
	/**
	 * 删除节点
	 */
	public function removeAction() {
		$id = $this->_http->getParam( 'nodeid', null);
		
		if( empty( $id)) {
			$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_NODE_NodeNotExist');
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}
		
		$node = Moby_Mgrsvr_Index_Model_Node::getInstance();
		$nodeInfo = $node->getById( $id);
		if( empty( $nodeInfo)) {
			$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_NODE_NodeNotExist');
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}
		
		try {
			$node->remove( $id);
		} catch ( Exception $e) {
			$message = $e->getMessage();
			$this->_redirect( 'index', null, null, array( 'msg'=> $message));
		}
		
		$message = $this->getLang()->get( 'APP_INDEX_CONTROLLER_NODE_UnlockNodeSuccess');
		$this->_redirect( 'index', null, null, array( 'msg'=> $message));
	}
	
	public function getNameById( $id) {
		$node = Moby_Mgrsvr_Index_Model_Node::getInstance();
		$nodeInfo = $node->getById( $id);
		return empty( $nodeInfo) ? $this->getLang()->get( 'APP_INDEX_CONTROLLER_NODE_TopNode') : $this->decodeToDb( $nodeInfo['name']); 
	}
	
	public function getPowerById( $id) {
		$power = Moby_Mgrsvr_Index_Model_Power::getInstance();
		$powerInfo = $power->getById( $id);
		return empty( $powerInfo) ? $this->getLang()->get( 'APP_INDEX_CONTROLLER_ADDEXP_HaveNone') : $this->decodeToDb( $powerInfo['name']); 
	}
}