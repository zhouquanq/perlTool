<?php
/**
 * Author: Jason
 * Date  : 2012-7-6
 * Description: 数据后台账号接口
 */
 
class Moby_Mgrsvr_Index_Controller_Service_FileList extends Moby_Mgrsvr_Index_ControllerSvr{

	const KEY	=	'zSnJ5dDFShy6yORkkpJP';
	
	public function indexAction() {
		echo "filelist action";
	}
	
	public function getFileListAction (  ){
		$this->access('getFileList');

		$serverid = $this->getParam( 'serverid',null );
		$operate = $this->getParam( 'operate',null );
		$project = $this->getParam( 'project',null );
		
		$files = $this->FileList($serverid,$operate,$project);
		
		echo json_encode( array( 'status'=>1 , 'result'=>$files ) );
	}
	
	public function downFileAction (  ){
		$this->access('downFile');
		
		$param =	$this->getParam( 'param', null );
		$serverid = $this->getParam( 'serverid',null );
		$operate = $this->getParam( 'operate',null );
		$project = $this->getParam( 'project',null );
		
		$files = $this->FileList($serverid,$operate,$project);
		
		$info = pathinfo($_SERVER["SCRIPT_FILENAME"]);
		$dirname = $info['dirname'];
		$tmpdir = "$dirname/tmp";
		if(!is_dir($tmpdir)){
			die(json_encode( array( 'status'=>-1 , 'result'=>'临时目录不存在' ) ));
		}
		
		if(in_array($param,$files)){
			if($handle = opendir($tmpdir)){
				while(false !== ($item = readdir($handle))){
					if($item != "." && $item != ".."){
						unlink("$tmpdir/$item");
					}
				}
			}else{
				echo json_encode( array( 'status'=>-2 , 'result'=>"文件目录不存在或者权限不够打开失败" ) );
			}
			closedir($handle);
		
			$dirs = $this->getCfgPath($serverid,$operate,$project);
			$split = explode("_",$param);
			$dir = $dirs[$split[0]];
		
			if(copy("$dir/$split[1]", "$tmpdir/$split[1]")){
				$fileinfo = pathinfo($split[1]);
				$zipname = $fileinfo['filename'];
				$zip = new ZipArchive();
				if ($zip->open("$tmpdir/$zipname.zip", ZIPARCHIVE::CREATE) === TRUE) {
					$zip->addFile("$tmpdir/$split[1]", $split[1]);
					$zip->close();
					echo json_encode( array( 'status'=>1 , 'result'=>"tmp/$zipname.zip" ) );
				} else {
					die( json_encode( array( 'status'=>-3 , 'result'=>'文件压缩失败' ) ) );
				}
			}else{
				die( json_encode( array( 'status'=>-4 , 'result'=>'下载文件拷贝失败' ) ) );
			}
		}else{
			die( json_encode( array( 'status'=>-5 , 'result'=>'要下载的文件不存在' ) ) );
		}
	}
	
	private function access ($code) {
		$param = file_get_contents( "php://input");
		
        $data = json_decode( $param, true);
        
        if (!empty($data)) {
			foreach ($data as $key => $value) {
				$this->_http->setParam($key,$value);
			}
        }
		$sign				=	$this->_http->getParam( 'sign',null );
		if(  $sign != md5( self::KEY."$code".$param ) ) {
			die( json_encode( array( 'status'=> -8, 'result' => '验证失败')  ) );
		}
		return ;
	}
	
	private function getCfgPath ($serverid,$operate,$project) {
		$appconfig = Moby_Mgrsvr_Index_Model_Config::getApplicationConfig();
		$appcfg = $appconfig->toArray();
		if(empty($appcfg['application']['location']["$project"]["$operate"]["$serverid"])){
			die (json_encode( array( 'status'=>-6 , 'result'=>'访问的服务器不存在' ) ));
		}else{
			$arr = $appcfg['application']['location']["$project"]["$operate"]["$serverid"];

			foreach ($arr as $key => $value){
				// $paths[] = array($key =>$value);
				if(false == file_exists($value)){
					die (json_encode( array( 'status'=>-7 , 'result'=>"$key 路径不存在" ) ));
				}else{
					$paths[$key] = $value;
				}
			}
		}
		
		return $paths;
	}
	
	private function FileList ($serverid,$operate,$project) {
		$appconfig = Moby_Mgrsvr_Index_Model_Config::getApplicationConfig();
		$appcfg = $appconfig->toArray();
		if(empty($appcfg['application']['extension'])){
			die (json_encode( array( 'status'=>-9 , 'result'=>'查找文件格式未指定' ) ));
		}else{
			$format = explode(",",$appcfg['application']['extension']);
		}
		
		
		$dirs = $this->getCfgPath($serverid,$operate,$project);
		foreach ($dirs as $key => $value){
			$handler = opendir($value);
			while(($filename = readdir($handler)) !== false){//务必使用!==，防止目录下出现类似文件名“0”等情况
				if ($filename != "." && $filename != ".."){
					$fileinfo = pathinfo($filename);
					if(isset($fileinfo['extension'])){
						$extension = $fileinfo['extension'];
						// if($extension == 'log' || $extension == 'txt'){
						if(in_array($extension,$format)){
							$files[] = $key.'_'.$filename ;
						}
					}				
				}        
			} 
		}
		
		if(empty($files)){
			die(json_encode( array( 'status'=>-10 , 'result'=>'未找到文件' ) ));
		}
		
		return $files;
	}
}