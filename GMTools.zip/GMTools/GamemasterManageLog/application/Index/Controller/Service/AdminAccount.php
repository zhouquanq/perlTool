<?php
/**
 * Author: Jason
 * Date  : 2012-7-6
 * Description: 数据后台账号接口
 */
 
class Moby_Mgrsvr_Index_Controller_Service_AdminAccount extends Moby_Mgrsvr_Index_ControllerSvr{
	const KEY	=	'563za-ujnfl-dsqoi';
	public function getAccountByIDAction (  ){
		$sign				=	$this->getParam( 'sign' );
		if(  $sign != md5( self::KEY.'adminaccount' ) ) {
			$this->errorLog( $sign );
			die( json_encode( array( 'status'=>0 , 'result'=>'密钥验证失败' )  ) );
		}
		$id					=	$this->getParam( 'id', 0);
		$find_fields		=	$this->getParam( 'fields' );
		$model				=	Moby_Mgrsvr_Index_Model_Account::getInstance();
		$fields				=	$model->getAllFields();
		if( empty( $id)) {
			$id = 0;
		}
		if( empty( $find_fields ) ){
			$find_fields	=	$fields;			
		}else{
			is_array( $find_fields ) or $find_fields	=	array( $find_fields );
			foreach ( $find_fields as $field ){
				if( !is_string( $field ) || !in_array( $field , $fields ) ){
					die( json_encode( array( 'status'=>-1 , 'result'=>'查询字段有误，为'.$field ) ) );
				}
			}
		}
		$result				=	$model->getInfoById( $id , $find_fields );
		echo json_encode( array( 'status'=>1 , 'result'=>$result  ) );		
	}
	/**
	 * 错误日志
	 */
	public function errorLog( $sign ){
		$data		=	array(
				'sign'=>$sign,
				'ip'=>$this->_http->getClientIp(),
				'time'=>date( 'Y-m-d H:i:s' ,  time() ),
				'type'=>'数据后台账号接口密钥错误',
		);
		Moby_Mgrsvr_Index_Model_Util_Log::getInstance( 'interface' )->record( var_export( $data , true ) );
	}
}