<?php

class Moby_Mgrsvr_Index_ControllerAuth extends Moby_Mgrsvr_Index_Controller {

	protected $msg = null;
	protected $accountid = 0;
	protected $accountInfo = null;
	protected $serverid = 0;
	
	public function __construct( $http) {
		parent::__construct( $http);
		
		if( !isset( $_SESSION['accountid']) || $_SESSION['accountid'] < 1) {
			$message = $this->getLang()->get( 'APP_ACL_LOGINFIRST');
			$this->_redirect( 'login', 'index', 'index', array( 'msg'=> $message));
		}
		$modelAdmin = Moby_Mgrsvr_Index_Model_Admin::getInstance();
		$entityAdmin = $modelAdmin->getEntityByAccountid( $_SESSION['accountid']);
		if( empty( $entityAdmin) || $entityAdmin->getSessionid() != $_SESSION['session']) {
			// 初始化session.
			session_start();
			$_SESSION = array();
			
			// 最后彻底销毁session.
			session_destroy();
			$message = $this->getLang()->get( 'APP_INDEX_VIEW_MAIN_WELCOME_2');
			$this->_redirect( 'login', 'index', null, array( 'msg'=> $message));
		}
		
		$this->accountid = $_SESSION['accountid'];
		$this->msg = $this->_http->getParam('msg');
	}
	
	public function operatelog( $type, $content) {
		$entityAdmin = $this->getCurrentAdmin();
		$content = sprintf( "%s\t%s\t%s\t%s", 
			$entityAdmin->getAccount(), 
			$entityAdmin->getRealName(), 
			$type, $content
		);
		Moby_Mgrsvr_Index_Model_Util_Log::getInstance( 'operate')->record( $content);
	}
	
	public function getCurrentAdmin() {
		if( !isset( $_SESSION['entityAdmin'])) {
			$_SESSION['entityAdmin'] = Moby_Mgrsvr_Index_Model_Admin::getInstance()->getEntityByAccountid( $this->accountid);
		}
		return $_SESSION['entityAdmin'];
	}
	
	/**
	 * 获取服务器
	 */
	public function getServerId() {
		if( !Zend_Registry::isRegistered( 'MODEL_SERVER_ID')) {
			$serverlist = Moby_Mgrsvr_Index_Model_Game::getSvrCfg();
			$serverid = $this->_http->getParam( 'serverid', null);
			if( is_null( $serverid) || !array_key_exists( $serverid, $serverlist)) {
				$serverid = array_shift( array_keys( $serverlist));
			}
			$this->_http->setParam( 'serverid', $serverid);
			$this->serverid = $serverid;
			Zend_Registry::set( 'MODEL_SERVER_ID', $serverid);
		}
		return Zend_Registry::get( 'MODEL_SERVER_ID');
	}
	
	/**
	 * 获取多个服务器
	 */
	public function getServerIds() {
		$serverlist = Moby_Mgrsvr_Index_Model_Game::getSvrCfg();
		$temp = $this->_http->getParam( 'serverid', null);
		if (is_string($temp)) {
			if (strpos($temp,',')!==false) {
				$serverid = explode(',',$temp);
			}else {
				$serverid = intval($temp);
			}
		}else if (is_array($temp)) {
			if (count($temp) == 1) {
				$serverid = array_shift($temp);
				if( is_null( $serverid) || !array_key_exists( $serverid, $serverlist)) {
					$serverid = intval(array_shift( array_keys( $serverlist)));
				}
			}else {
				$serverid = array();
				foreach ($temp as $value) {
					if( is_null( $value) || !array_key_exists( $value, $serverlist)) {
						$serverid[] = intval(array_shift( array_keys( $serverlist)));
					}else {
						$serverid[] = intval($value);
					}
				}
				array_unique($serverid);
			}
		}else {
			if( is_null( $temp) || !array_key_exists( $temp, $serverlist)) {
				$serverid = intval(array_shift( array_keys( $serverlist)));
			}else {
				$serverid = intval($temp);
			}
		}
		$this->_http->setParam( 'serverid', $serverid);
		$this->serverid = $serverid;
		return $serverid;
	}
	
	/**
	 * 获取多个服务器(无默认值)
	 */
	public function getServerIdsUDF() {
		$serverlist = Moby_Mgrsvr_Index_Model_Game::getSvrCfg();
		$temp = $this->_http->getParam( 'serverid', null);
		if (is_string($temp)) {
			if (strpos($temp,',')!==false) {
				$serverid = explode(',',$temp);
			}else {
				$serverid = intval($temp);
			}
		}else if (is_array($temp)) {
			if (count($temp) == 1) {
				$serverid = array_shift($temp);
				if( is_null( $serverid) || !array_key_exists( $serverid, $serverlist)) {
					$serverid = null;
				}
			}else {
				$serverid = array();
				foreach ($temp as $value) {
					if( !is_null( $value) && array_key_exists( $value, $serverlist)) {
						$serverid[] = intval($value);
					}
				}
				array_unique($serverid);
			}
		}else {
			if( is_null( $temp) || !array_key_exists( $temp, $serverlist)) {
				$serverid = null;
			}else {
				$serverid = intval($temp);
			}
		}
		$this->_http->setParam( 'serverid', $serverid);
		$this->serverid = $serverid;
		return $serverid;
	}
	
	/**
	 * 获取游戏服务器(强制检查)
	 */
	public function checkServerId() {
		if( !Zend_Registry::isRegistered( 'MODEL_SERVER_ID')) {
			$serverlist = Moby_Mgrsvr_Index_Model_Game::getSvrCfg();
			
			$serverid = $this->_http->getParam( 'serverid', null);
			if( is_null( $serverid) || !array_key_exists( $serverid, $serverlist)) {
				$msg = $this->getLang()->get( 'APP_INDEX_ControllerAuth_ChooseServer');
				$this->_redirect( 'welcome', 'index', 'index', array( 'msg'=> $msg));
				
				//throw new Exception( '请选择服务器');
			}
			$this->_http->setParam( 'serverid', $serverid);
			$this->serverid = $serverid;
			Zend_Registry::set( 'MODEL_SERVER_ID', $serverid);
		}
		return Zend_Registry::get( 'MODEL_SERVER_ID');
	}
	
	/**
	 * 获取多个游戏服务器(强制检查)
	 */
	public function checkServerIds() {
		$serverlist = Moby_Mgrsvr_Index_Model_Game::getSvrCfg();
		
		$temp = $this->_http->getParam( 'serverid', null);
		if (is_string($temp)) {
			if (strpos($temp,',')!==false) {
				$serverid = explode(',',$temp);
			}else {
				$serverid = intval($temp);
			}
		}else if (is_array($temp)) {
			$serverid = $temp;
		}else if (is_numeric($temp)) {
			$serverid = $temp;
		}
		
		if (is_array($serverid)) {
			foreach ($serverid as $key => $value) {
				if( is_null( $value) || !array_key_exists( $value, $serverlist)) {
					$msg = $this->getLang()->get( 'APP_INDEX_ControllerAuth_ChooseServer');
					$this->_redirect( 'welcome', 'index', 'index', array( 'msg'=> $msg));
					
					//throw new Exception( '请选择服务器');
				}
				$serverid[$key] = intval($value);
			}
		}else {
			if( is_null( $serverid) || !array_key_exists( $serverid, $serverlist)) {
				$msg = $this->getLang()->get( 'APP_INDEX_ControllerAuth_ChooseServer');
				$this->_redirect( 'welcome', 'index', 'index', array( 'msg'=> $msg));
				
				//throw new Exception( '请选择服务器');
			}
		}
		$this->_http->setParam( 'serverid', $serverid);
		$this->serverid = $serverid;
		return $serverid;
	}
	
	public function _redirect( $action, $controller=null, $model=null, array $params=null) {
		if ( empty( $params)) {
			$params = array();
		}
		if( $this->serverid) {
			$params['serverid']=$this->serverid;
		}
		parent::_redirect( $action, $controller, $model, $params);
	}
	
	/**
	 * 取url参数时，给游戏服务器url参数附加server_id
	 * @param mixed $paramNames
	 */
	public function getUrlParams($paramNames) {
		if( $this->serverid) {
			if (is_array($paramNames)) {
			    if(!in_array( 'serverid', $paramNames)) {
				     array_push( $paramNames, 'serverid');
			    }
			}
			else {
				if (FALSE === strpos( $paramNames, 'serverid'))
	                $paramNames .= ',serverid';
	        }
		}
		return parent::getUrlParams( $paramNames);
	}
}