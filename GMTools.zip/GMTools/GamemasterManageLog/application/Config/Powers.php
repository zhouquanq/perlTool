<?php
return array (
  'index' => 
  array (
    'account' => 
    array (
      'name' => '用户账号',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'setpass' => 'index',
        'modify' => 'index',
        'remove' => 'index',
        'killoffline' => 'index',
        'unkilloffline' => 'index',
      ),
      'operalist' => 
      array (
        'index' => '查看账号',
        'setpass' => '重置密码',
        'modify' => '修改用户信息',
        'remove' => '删除账号',
        'killoffline' => '封锁用户账号',
        'unkilloffline' => '解除封锁账号',
        'removelist' => '查看被删除的账号',
      ),
    ),
    'active' => 
    array (
      'name' => '活动管理',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'add' => 'index',
        'modify' => 'index',
        'lock' => 'index',
        'unlock' => 'index',
      ),
      'operalist' => 
      array (
        'index' => '查看活动名称',
        'add' => '添加活动名称',
        'lock' => '禁用活动',
        'unlock' => '解禁活动',
        'modify' => '修改活动信息',
        'makeCode' => '生成邀请码',
      ),
    ),
    'addexp' => 
    array (
      'name' => '添加经验记录',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'verify' => 'verifylist',
        'batchverify' => 'verifylist',
      ),
      'operalist' => 
      array (
        'index' => '查看添加经验记录',
        'verifylist' => '查看待审核添加经验记录',
        'verify' => '审核添加经验记录',
        'batchverify' => '批量审核添加经验记录',
      ),
    ),
    'addingot' => 
    array (
      'name' => '添加元宝记录',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'verify' => 'verifylist',
        'batchverify' => 'verifylist',
      ),
      'operalist' => 
      array (
        'index' => '查看添加元宝记录',
        'verifylist' => '查看待审核添加元宝记录',
        'verify' => '审核添加元宝记录',
        'batchverify' => '批量审核添加元宝记录',
      ),
    ),
    'admin' => 
    array (
      'name' => '管理员',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'modify' => 'index',
        'lockout' => 'index',
        'unlock' => 'index',
      ),
      'operalist' => 
      array (
        'index' => '查看管理员',
        'add' => '添加管理员',
        'modify' => '修改管理员',
        'lockout' => '禁用管理员',
        'unlock' => '解禁管理员',
      ),
    ),
    'batchsendmail' => 
    array (
      'name' => '批量发送邮件',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
      ),
      'operalist' => 
      array (
        'index' => '批量发送邮件',
      ),
    ),
    'bulletin' => 
    array (
      'name' => '管理游戏布告栏',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'add' => 'list',
        'del' => 'list',
        'modify' => 'list',
      ),
      'operalist' => 
      array (
        'list' => '查看布告栏',
        'add' => '添加布告',
        'modify' => '修改布告',
        'del' => '删除布告',
      ),
    ),
    'camp' => 
    array (
      'name' => '阵营信息',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'cabinetinfo' => 'cabinet',
      ),
      'operalist' => 
      array (
        'cabinet' => '阵营成员职位',
        'cabinetinfo' => '阵营成员详细信息',
      ),
    ),
    'dockpub' => 
    array (
      'name' => '扣量管理',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'modify' => 'index',
      ),
      'operalist' => 
      array (
        'index' => '扣量渠道查询',
        'add' => '扣量渠道添加',
        'modify' => '扣量渠道修改',
      ),
    ),
    'expense' => 
    array (
      'name' => '消费记录',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
      ),
      'operalist' => 
      array (
        'ingot' => '元宝消费记录',
        'ticket' => '点卷消费记录',
      ),
    ),
    'faction' => 
    array (
      'name' => '游戏帮派',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'member' => 'index',
        'modify' => 'index',
      ),
      'operalist' => 
      array (
        'index' => '查看帮派',
        'member' => '帮派成员列表',
        'modify' => '修改帮派信息',
      ),
    ),
    'gamemail' => 
    array (
      'name' => '玩家邮件记录',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
      ),
      'operalist' => 
      array (
        'list' => '查看玩家邮件',
      ),
    ),
    'gamesetting' => 
    array (
      'name' => '游戏设置',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'setdragonlife' => 'index',
        'setdgnrkbns' => 'index',
      ),
      'operalist' => 
      array (
        'index' => '__not_found__',
        'setdragonlife' => '__not_found__',
        'setdgnrkbns' => '__not_found__',
      ),
    ),
    'gftpkmgr' => 
    array (
      'name' => '礼包管理',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'info' => 'index',
        'modify' => 'index',
        'sync' => 'index',
        'remove' => 'index',
      ),
      'operalist' => 
      array (
        'index' => '礼包列表',
        'info' => '礼包信息显示',
        'modify' => '礼包信息修改',
        'add' => '礼包添加',
        'sync' => '礼包信息同步',
        'remove' => '删除礼包',
      ),
    ),
    'goods' => 
    array (
      'name' => '物品',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
      ),
      'operalist' => 
      array (
        'index' => '查看物品',
      ),
    ),
    'group' => 
    array (
      'name' => '用户组管理',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'modify' => 'index',
      ),
      'operalist' => 
      array (
        'index' => '查看用户组',
        'add' => '添加用户组',
        'modify' => '修改用户组',
      ),
    ),
    'internal' => 
    array (
      'name' => '内部人员',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'form' => 'index',
        'del' => 'index',
      ),
      'operalist' => 
      array (
        'index' => '内部人员管理',
        'form' => '添加与修改内部人员',
        'del' => '删除内部人员',
      ),
    ),
    'node' => 
    array (
      'name' => '左边菜单',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'modify' => 'index',
        'lockout' => 'index',
        'unlock' => 'index',
        'remove' => 'index',
      ),
      'operalist' => 
      array (
        'index' => '查看菜单',
        'add' => '添加菜单',
        'modify' => '修改菜单',
        'lockout' => '禁用菜单',
        'unlock' => '解禁菜单',
        'remove' => '移除菜单',
      ),
    ),
    'payrecord' => 
    array (
      'name' => '充值记录',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
      ),
      'operalist' => 
      array (
        'index' => '查看充值记录',
        'submitting' => '查看充值提交记录',
      ),
    ),
    'player' => 
    array (
      'name' => '玩家角色',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'info' => 'index',
        'opera' => 'index',
        'forbidspeak' => 'opera',
        'unforbidspeak' => 'opera',
        'kickoffline' => 'opera',
        'unkickoffline' => 'opera',
        'addingot' => 'opera',
        'addexp' => 'opera',
        'sendsysmail' => 'opera',
        'goods' => 'info',
        'setpower' => 'opera',
      ),
      'operalist' => 
      array (
        'index' => '查看角色',
        'info' => '角色详情',
        'opera' => '角色操作',
        'forbidspeak' => '禁言角色',
        'unforbidspeak' => '解禁言角色',
        'kickoffline' => '封号角色',
        'unkickoffline' => '解封号角色',
        'addingot' => '增加角色元宝',
        'addexp' => '增加角色经验',
        'sendsysmail' => '发送系统邮件',
        'setpower' => '设置角色权限',
        'goods' => '查看用户物品',
      ),
    ),
    'sendmail' => 
    array (
      'name' => '发送邮件记录',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'verify' => 'verifylist',
        'batchverify' => 'verifylist',
      ),
      'operalist' => 
      array (
        'index' => '查看后台发送邮件',
        'verifylist' => '查看待审核后台发送邮件',
        'verify' => '审核后台发送邮件',
        'batchverify' => '批量审核后台发送邮件',
      ),
    ),
    'sensword' => 
    array (
      'name' => '敏感字管理',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'modify' => 'index',
        'remove' => 'index',
      ),
      'operalist' => 
      array (
        'index' => '查看敏感字',
        'addmult' => '增加敏感字',
        'modify' => '修改敏感字',
        'remove' => '删除敏感字',
      ),
    ),
    'setexp' => 
    array (
      'name' => '设置经验系数',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'modify' => 'index',
        'remove' => 'index',
      ),
      'operalist' => 
      array (
        'index' => '设置经验系数',
      ),
    ),
    'skill' => 
    array (
      'name' => '玩家武功',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
      ),
      'operalist' => 
      array (
        'index' => '查看玩家武功',
      ),
    ),
    'specialsales' => 
    array (
      'name' => '特殊商品管理',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
      ),
      'operalist' => 
      array (
        'index' => '特殊商品列表',
        'form' => '特殊商品修改',
        'del' => '特殊商品删除',
      ),
    ),
    'sysmsg' => 
    array (
      'name' => '游戏公告',
      'ispower' => 1,
      'isreqsvrid' => 0,
      'dependent' => 
      array (
        'sendsysmsg' => 'index',
        'verify' => 'verifylist',
        'batchverify' => 'verifylist',
      ),
      'operalist' => 
      array (
        'index' => '查看系统公告',
        'sendsysmsg' => '发送系统公告',
        'verifylist' => '查看待审核公告',
        'verify' => '审核系统公告',
        'batchverify' => '批量审核系统公告',
      ),
    ),
  ),
);