SET names UTF8;

/* DROP TABLE IF EXISTS `admin_account`; */
CREATE TABLE `admin_account` (												/* 后台用户表 */
	`a_id` INT NOT NULL AUTO_INCREMENT,										/* 后台用户账号id */
	`a_account` VARCHAR(32) CHARACTER SET utf8 NOT NULL,					/* 后台用户账号 */
	`a_password` VARCHAR(32) CHARACTER SET utf8 NOT NULL,					/* 后台用户密码 */
	`a_powers` TEXT CHARACTER SET utf8 NOT NULL,							/* 后台用户权限(已废弃) */
	`a_lasttime` INT NOT NULL,												/* 后台用户最后登录时间 */
	`a_lastip` VARCHAR(32) CHARACTER SET utf8 NOT NULL,						/* 后台用户最后登录ip */
	`a_realname` VARCHAR(10) CHARACTER SET utf8 NOT NULL,					/* 后台用户真实姓名 */
	`a_addtime` INT NOT NULL,												/* 后台用户添加时间 */
	`a_islock` INT NOT NULL DEFAULT 0,										/* 后台用户是否锁定 */
	`a_session` VARCHAR(50) NOT NULL DEFAULT '',							/* 后台用户登录标识*/
	PRIMARY KEY (`a_id`),
	INDEX `idx_admin_account_a_account`( `a_account`),
	UNIQUE `unique_admin_account_a_account`( `a_account`),
	INDEX `idx_admin_account_a_islock`( `a_islock`)
) ENGINE=InnoDB;
INSERT INTO `admin_account` (`a_id`, `a_account`, `a_password`, `a_powers`, `a_lasttime`, `a_lastip`, `a_realname`, `a_addtime`, `a_islock`, `a_session`) VALUES (1, 'admin', 'c3949ba59abbe56e', '0', 1383278363, '127.0.0.1', '管理员', 1312428842, 0, 'c536d6c9-54ae-aa96-83aa-ec8fdd11f4c7');

/* DROP TABLE IF EXISTS `admin_account_group`; */
CREATE TABLE `admin_account_group`(											/* 用户和用户组关系 */
	`aag_id` INT NOT NULL AUTO_INCREMENT,									/* 主键 */
	`aag_accountid` INT NOT NULL,											/* 用户id */
	`aag_groupid` INT NOT NULL,												/* 用户组id */
	PRIMARY KEY (`aag_id`),
	INDEX `idx_admin_account_group_aag_accountid` (`aag_accountid`),
	INDEX `idx_admin_account_group_aag_groupid` (`aag_groupid`)
) ENGINE=InnoDB;

/* DROP TABLE IF EXISTS `admin_account_power`; */									/* 后台用户权限 */
CREATE TABLE `admin_account_power` (
	`ap_id` INT NOT NULL AUTO_INCREMENT,									/* 组建 */
	`a_id` INT NOT NULL,													/* 后台用户账号id */
	`p_id` VARCHAR(100) NOT NULL,											/* 权限id */
	`ap_serverids` varchar(50) CHARACTER SET utf8 NOT NULL,					/* 后台用户服务器权限(已废弃) */
	PRIMARY KEY (`ap_id`),
	INDEX `idx_admin_account_power_a_id` (`a_id`),
	INDEX `idx_admin_account_power_p_id` (`p_id`)
) ENGINE=InnoDB;

/* DROP TABLE IF EXISTS `admin_group`; */
CREATE TABLE `admin_group`(													/* 用户组表 */
	`ag_id`  INT NOT NULL AUTO_INCREMENT,									/* 用户组id */
	`ag_name` VARCHAR(50) CHARACTER SET utf8 NOT NULL,						/* 用户组名称 */
	`ag_islock` TINYINT NOT NULL,											/* 用户组是否锁定(不可用) */
	PRIMARY KEY (`ag_id`),
	INDEX `idx_admin_group_ag_islock`( `ag_islock`)
) ENGINE=InnoDB;

/* DROP TABLE IF EXISTS `admin_group_power`; */									/* 用户组权限 */
CREATE TABLE `admin_group_power`(				
	`agp_id` INT NOT NULL AUTO_INCREMENT,									/* 主键 */
	`agp_groupid` INT NOT NULL,												/* 用户组id */
	`agp_powerid` VARCHAR(100) NOT NULL,									/* 权限id */
	PRIMARY KEY (`agp_id`),
	INDEX `IDX_admin_group_power_agp_groupid`( `agp_groupid`),
	INDEX `IDX_admin_group_power_agp_powerid`( `agp_powerid`)
) ENGINE=InnoDB;
