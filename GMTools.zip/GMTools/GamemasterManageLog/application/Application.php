<?php

/**
 * 应用
 *
 */
class Application {
	
	protected $controllerConfig = null;
	protected $_http;
	protected $_debug;
	
	public function __construct( $ctlConfig) {
		if( empty( $ctlConfig) || !is_array( $ctlConfig)) {
			throw new Exception( 'illegal controller config ');
		}
		
		Zend_Registry::set( 'controllerConfig', $ctlConfig);
		$this->controllerConfig = $ctlConfig;
		$this->initcfg();
		
		$this->inithtt();
	}
	
	public function initcfg() {
		$appconfig = Moby_Mgrsvr_Index_Model_Config::getApplicationConfig();
		$appcfg = $appconfig->toArray();
		defined( 'APPLICATION_LANG') || define( 'APPLICATION_LANG', empty( $appcfg['application']) || empty( $appcfg['application']['lang']) ? 'zh_cn' : $appcfg['application']['lang']);
		defined( 'APPLICATION_LANG_PATH') || define( 'APPLICATION_LANG_PATH', APPLICATION_PATH.'/Config/Lang/'.APPLICATION_LANG);
	}
	
	public function inithtt() {
		#session_start();
		$http = new Moby_Http_Custom();
		$debugpass = $http->getParam( 'debugpass', '');
		$debug = isset( $_SESSION['debug']) ? $_SESSION['debug'] : 'off';
		if( 'synchronized' == $debugpass) {
			$debug = $http->getParam( 'debug', $debug);
			$_SESSION['debug'] = $debug;
		}
		$this->_debug = $debug;
		Zend_Registry::set( 'MobyHttp', $http);
		Zend_Registry::set( 'APP_DEBUG', $debug);
		$this->_http = $http;
	}
		
	public function run() {
		$http= $this->_http;
		$model = $http->getModel();
		$controller = $http->getController();
		$action = $http->getAction();	
		
//		echo "<pre>";
//		echo "model:".$model."<br/>";
//		echo "controller:".$controller."<br/>";
//		echo "action:".$action."<br/>"; 
//		print_r($this->controllerConfig);
//		echo "<pre>";
//		die();
		try {
			if( empty( $this->controllerConfig[$model]) || empty( $this->controllerConfig[$model][$controller])) {
				$e = new Exception( 'not found the controller '.$model.'/'.$controller);
				$controller = new Moby_Mgrsvr_Index_Controller_Error( $http, $e);
				return $controller->http404Action( );
			}
			$controllerClass = $this->controllerConfig[$model][$controller];	//echo "controllerClass:".$controllerClass;
			Zend_Loader_Autoloader::autoload( $controllerClass);
			$controllerObject = new $controllerClass( $http);
			$action = strtolower( $action).'Action';
			if( !method_exists( $controllerObject, $action)) {
				$e = new Exception( 'not found the action '.$action.' in '.$controllerClass);
				$controller = new Moby_Mgrsvr_Index_Controller_Error( $http, $e);
				return $controller->http404Action( );
			}
			
			//调用控制器
			$controllerObject->$action();
		} catch( Exception $e) {
			$content = sprintf( "[msg:%s]", $e->getMessage());
			Moby_Mgrsvr_Index_Model_Util_Log::getInstance('error')->record( $content);
			$content = sprintf( "[content:%s]", $e->getTraceAsString());
			Moby_Mgrsvr_Index_Model_Util_Log::getInstance('error')->record( $content);
			$controller = new Moby_Mgrsvr_Index_Controller_Error( $http, $e);
			if( 'on' == $this->_debug) {
				return $controller->httpdebug500Action( );
			} else {
				return $controller->http500Action( );
			}
		}
	}
}