<?php 
return array (
  'e12ebb485985f6411720972d78646596' => 
  array (
    'id' => 'e12ebb485985f6411720972d78646596',
    'name' => '查看管理员',
    'model' => 'index',
    'controller' => 'admin',
    'action' => 'index',
    'depid' => 0,
    'reqsvrid' => 0,
  ),
  '4dde2f5438ecc1396460cd2c8e1da353' => 
  array (
    'id' => '4dde2f5438ecc1396460cd2c8e1da353',
    'name' => '添加管理员',
    'model' => 'index',
    'controller' => 'admin',
    'action' => 'add',
    'depid' => 0,
    'reqsvrid' => 0,
  ),
  '16513864e41092839ebe4b0a951e3b42' => 
  array (
    'id' => '16513864e41092839ebe4b0a951e3b42',
    'name' => '修改管理员',
    'model' => 'index',
    'controller' => 'admin',
    'action' => 'modify',
    'depid' => 'e12ebb485985f6411720972d78646596',
    'reqsvrid' => 0,
  ),
  'a0f4956df2a5d679b90ee642c13d3fa4' => 
  array (
    'id' => 'a0f4956df2a5d679b90ee642c13d3fa4',
    'name' => '禁用管理员',
    'model' => 'index',
    'controller' => 'admin',
    'action' => 'lockout',
    'depid' => 'e12ebb485985f6411720972d78646596',
    'reqsvrid' => 0,
  ),
  '4a0e711ce863f4512e7027d4aefb5d48' => 
  array (
    'id' => '4a0e711ce863f4512e7027d4aefb5d48',
    'name' => '解禁管理员',
    'model' => 'index',
    'controller' => 'admin',
    'action' => 'unlock',
    'depid' => 'e12ebb485985f6411720972d78646596',
    'reqsvrid' => 0,
  ),
  '419587f477b196756a41e21f1a04bfc8' => 
  array (
    'id' => '419587f477b196756a41e21f1a04bfc8',
    'name' => '查看用户组',
    'model' => 'index',
    'controller' => 'group',
    'action' => 'index',
    'depid' => 0,
    'reqsvrid' => 0,
  ),
  'd50326a5f3f301c3edebc1a5f274db8a' => 
  array (
    'id' => 'd50326a5f3f301c3edebc1a5f274db8a',
    'name' => '添加用户组',
    'model' => 'index',
    'controller' => 'group',
    'action' => 'add',
    'depid' => 0,
    'reqsvrid' => 0,
  ),
  '95b4536c33d395f8ad490fd4396fbca4' => 
  array (
    'id' => '95b4536c33d395f8ad490fd4396fbca4',
    'name' => '修改用户组',
    'model' => 'index',
    'controller' => 'group',
    'action' => 'modify',
    'depid' => '419587f477b196756a41e21f1a04bfc8',
    'reqsvrid' => 0,
  ),
  '41c350121f69080841530de99361db6b' => 
  array (
    'id' => '41c350121f69080841530de99361db6b',
    'name' => '查看菜单',
    'model' => 'index',
    'controller' => 'node',
    'action' => 'index',
    'depid' => 0,
    'reqsvrid' => 0,
  ),
  '3547b581bda93ec9d77ac6dbe74f2a81' => 
  array (
    'id' => '3547b581bda93ec9d77ac6dbe74f2a81',
    'name' => '添加菜单',
    'model' => 'index',
    'controller' => 'node',
    'action' => 'add',
    'depid' => 0,
    'reqsvrid' => 0,
  ),
  '3f42c8ebca217f0e1f23c06a7583dd45' => 
  array (
    'id' => '3f42c8ebca217f0e1f23c06a7583dd45',
    'name' => '修改菜单',
    'model' => 'index',
    'controller' => 'node',
    'action' => 'modify',
    'depid' => '41c350121f69080841530de99361db6b',
    'reqsvrid' => 0,
  ),
  '3ba9c13e94c44985ee9cabaa7915fed3' => 
  array (
    'id' => '3ba9c13e94c44985ee9cabaa7915fed3',
    'name' => '禁用菜单',
    'model' => 'index',
    'controller' => 'node',
    'action' => 'lockout',
    'depid' => '41c350121f69080841530de99361db6b',
    'reqsvrid' => 0,
  ),
  'a52119a922dffde1a72a5c9c5427b0bb' => 
  array (
    'id' => 'a52119a922dffde1a72a5c9c5427b0bb',
    'name' => '解禁菜单',
    'model' => 'index',
    'controller' => 'node',
    'action' => 'unlock',
    'depid' => '41c350121f69080841530de99361db6b',
    'reqsvrid' => 0,
  ),
  '9f57c17656ea0bd9a865249a873ab69d' => 
  array (
    'id' => '9f57c17656ea0bd9a865249a873ab69d',
    'name' => '移除菜单',
    'model' => 'index',
    'controller' => 'node',
    'action' => 'remove',
    'depid' => '41c350121f69080841530de99361db6b',
    'reqsvrid' => 0,
  ),
);