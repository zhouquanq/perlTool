<?php 
return array (
  '060e3f75-23fe-9397-56b4-b9e31aceb31f' => 
  array (
    'id' => '060e3f75-23fe-9397-56b4-b9e31aceb31f',
    'name' => '系统管理',
    'parentid' => '0',
    'powerid' => '0',
    'enable' => '1',
  ),
  '3a39ce9a-39f4-cd1b-da0c-73fd8ef9e101' => 
  array (
    'id' => '3a39ce9a-39f4-cd1b-da0c-73fd8ef9e101',
    'name' => '查看管理员',
    'parentid' => '060e3f75-23fe-9397-56b4-b9e31aceb31f',
    'powerid' => 'e12ebb485985f6411720972d78646596',
    'enable' => '1',
  ),
  'eed15c7e-981c-b122-0c39-e219f629a044' => 
  array (
    'id' => 'eed15c7e-981c-b122-0c39-e219f629a044',
    'name' => '添加管理员',
    'parentid' => '060e3f75-23fe-9397-56b4-b9e31aceb31f',
    'powerid' => '4dde2f5438ecc1396460cd2c8e1da353',
    'enable' => '1',
  ),
  '938d0d7e-07b5-d8b3-b854-492718a5059a' => 
  array (
    'id' => '938d0d7e-07b5-d8b3-b854-492718a5059a',
    'name' => '查看菜单',
    'parentid' => '060e3f75-23fe-9397-56b4-b9e31aceb31f',
    'powerid' => '41c350121f69080841530de99361db6b',
    'enable' => '1',
  ),
  '144baa3a-0cef-8bdc-68ed-e74e29454a72' => 
  array (
    'id' => '144baa3a-0cef-8bdc-68ed-e74e29454a72',
    'name' => '添加菜单',
    'parentid' => '060e3f75-23fe-9397-56b4-b9e31aceb31f',
    'powerid' => '3547b581bda93ec9d77ac6dbe74f2a81',
    'enable' => '1',
  ),
  '59e645f9-d906-8098-ea5a-af36342e3519' => 
  array (
    'id' => '59e645f9-d906-8098-ea5a-af36342e3519',
    'name' => '用户组管理',
    'parentid' => '060e3f75-23fe-9397-56b4-b9e31aceb31f',
    'powerid' => '419587f477b196756a41e21f1a04bfc8',
    'enable' => '1',
  ),
  '445fdf89-39b3-4ab1-77ce-982d19c1aa47' => 
  array (
    'id' => '445fdf89-39b3-4ab1-77ce-982d19c1aa47',
    'name' => '添加用户组',
    'parentid' => '060e3f75-23fe-9397-56b4-b9e31aceb31f',
    'powerid' => 'd50326a5f3f301c3edebc1a5f274db8a',
    'enable' => '1',
  ),
);