#! /opt/ActivePerl-5.14/bin/perl  -w

#########################################################################
# 
# 编译perl程序为可执行文件(linux CentOS5.7)
# perl 环境 
# 版本 ActivePerl 5.14
# 模块
#	cpan install PAR::Packer
#	cpan install PerlIO::encoding
#
#########################################################################

use strict;
use warnings;
use utf8;
use Archive::Zip qw( :ERROR_CODES :CONSTANTS );
BEGIN
{
	use FindBin;
	
	$::APPLICATION_PATH = scalar( $FindBin::Bin);
	chdir( $::APPLICATION_PATH);
}

#程序名称

#perl根目录
$::perlhome = "/opt/ActivePerl-5.14";
#编译器所在目录
$::buildbinpath = $::perlhome."/site/bin/pp";

print "svn updating...\n";
print `svn update`;

my $date = "";
my $sv = `svnversion`;
print $sv;
$sv =~ s/\s//g;
print "=====\n";
{
	my ($mday, $mon, $year) = (localtime( ))[3, 4, 5];
	$year += 1900;
	$mon += 1;
	$date = sprintf( "%04d-%02d-%02d", $year, $mon, $mday);
}

print "create version.txt\n";
open( my $fhv, ">", sprintf( "%s/%s", $::APPLICATION_PATH, "version.txt"));
print $fhv sprintf( "version:%s", $sv);
close( $fhv);

my $cmd = "";
#print "perl building auto_update \n";
$cmd = "$::buildbinpath -g -f Crypto -F Crypto -M Filter::Crypto::Decrypt -I $::APPLICATION_PATH/AutoUpdate/ -o $::APPLICATION_PATH/AutoUpdate/auto_update $::APPLICATION_PATH/AutoUpdate/auto_update.pl";
#printf( "%s\n", $cmd);
#system( $cmd);

#print "perl building auto_update_res \n";
$cmd = "$::buildbinpath -g -f Crypto -F Crypto -M Filter::Crypto::Decrypt -I $::APPLICATION_PATH/AutoUpdateRes/ -o $::APPLICATION_PATH/AutoUpdateRes/auto_update $::APPLICATION_PATH/AutoUpdateRes/auto_update.pl";
#printf( "%s\n", $cmd);
#system( $cmd);

#print "perl building check_tools \n";
$cmd = "$::buildbinpath -g -f Crypto -F Crypto -M Filter::Crypto::Decrypt -I $::APPLICATION_PATH/CheckTools/ -o $::APPLICATION_PATH/CheckTools/StartCheck $::APPLICATION_PATH/CheckTools/StartCheck.pl";
#printf( "%s\n", $cmd);
#system( $cmd);

#print "perl building FileUpload \n";
$cmd = "$::buildbinpath -g -f Crypto -F Crypto -M Filter::Crypto::Decrypt -I $::APPLICATION_PATH/FileUpload/ -o $::APPLICATION_PATH/FileUpload/FileUpload $::APPLICATION_PATH/FileUpload/ftp_load.pl";
#printf( "%s\n", $cmd);
#system( $cmd);

#print "perl building update_tools \n";
$cmd = "$::buildbinpath -g -f Crypto -F Crypto -M Filter::Crypto::Decrypt -I $::APPLICATION_PATH/UpdateTools/ -o $::APPLICATION_PATH/UpdateTools/update_tools $::APPLICATION_PATH/UpdateTools/update_tools.pl";
#printf( "%s\n", $cmd);
#system( $cmd);


my $uppath = "/www/docs/pkgload.ly.ta.cn/package/eagle/";
if( -e $uppath) { 
	
	#游戏服务器
	{
		my $appname = "GMTools";
		my $packagename = "GMTools_eagle_$sv";
		my $files = {
			'srv.pl'								=> 'srv.pl',
			'doc.gs.txt'							=> 'doc.txt',
			'common.pl'								=> 'common.pl',
			'MysqlX.pm'								=> 'MysqlX.pm',
			'services/install.cfg.gs.example'		=> 'services/install.cfg.example',
			'services/services.cfg.gs.example'		=> 'services/services.cfg.example',
			'services/bash_temple.txt'				=> 'services/bash_temple.txt',
			'services/install.pl'					=> 'services/install.pl',
			'services/restart.sh'					=> 'services/restart.sh',
			'services/restart_bak.sh'				=> 'services/restart_bak.sh',
			'services/auto_restart.pl'				=> 'services/auto_restart.pl',
			'services/serverRestart.pl'				=> 'services/serverRestart.pl',
			'AutoBak/auto_bak.pl'					=> 'AutoBak/auto_bak.pl',
			'AutoBak/auto_bak.cfg.gs.example'		=> 'AutoBak/auto_bak.cfg.example',
			'auto_clean.cfg.gs.example'				=> 'auto_clean.cfg.example',
			'auto_clean.pl'							=> 'auto_clean.pl',
			'CheckTools/check_tools.cfg.gs.example'	=> 'CheckTools/check_tools.cfg.example',
			'CheckTools/Moby/Business/LoggerMan.pm'	=> 'CheckTools/Moby/Business/LoggerMan.pm',
			'CheckTools/Moby/Business/TimeMan.pm'	=> 'CheckTools/Moby/Business/TimeMan.pm',
			'CheckTools/StartCheck.pl'				=> 'CheckTools/StartCheck.pl',
			'FileUpload/config.ini.gs.example'		=> 'FileUpload/config.ini.example',
			'FileUpload/Moby/Business/LoggerMan.pm'	=> 'FileUpload/Moby/Business/LoggerMan.pm',
			'FileUpload/Moby/Business/TimeMan.pm'	=> 'FileUpload/Moby/Business/TimeMan.pm',
			'FileUpload/Lib/Util/Ini.pm'			=> 'FileUpload/Lib/Util/Ini.pm',
			'FileUpload/ftp_load.pl'				=> 'FileUpload/ftp_load.pl',
			'AutoUpdate/auto_update.cfg.example'	=> 'AutoUpdate/auto_update.cfg.example',
			'AutoUpdate/Moby/Business/LoggerMan.pm'	=> 'AutoUpdate/Moby/Business/LoggerMan.pm',
			'AutoUpdate/Moby/Business/TimeMan.pm'	=> 'AutoUpdate/Moby/Business/TimeMan.pm',
			'AutoUpdate/Utils.pm'					=> 'AutoUpdate/Utils.pm',
			'AutoUpdate/auto_update.pl'				=> 'AutoUpdate/auto_update.pl',
			'UpdateTools/update_tools.cfg.gs.example'=> 'UpdateTools/update_tools.cfg.example',
			'UpdateTools/Moby/Business/LoggerMan.pm'=> 'UpdateTools/Moby/Business/LoggerMan.pm',
			'UpdateTools/Moby/Business/TimeMan.pm'	=> 'UpdateTools/Moby/Business/TimeMan.pm',
			'UpdateTools/update_tools.pl'			=>  'UpdateTools/update_tools.pl',
			'UpdateTools/fix.pl'				    =>  'UpdateTools/fix.pl',
			'UpdateTools/Utils.pm'				    =>  'UpdateTools/Utils.pm',
			'status_file/'							=> 'status_file/',
			'version.txt'							=> 'version.txt',
		};
	
		printf( "building %s\n", $appname);
		my $upzip = Archive::Zip->new();
		foreach my $file( keys %{$files}) {
			my $zipfile = $files->{$file};
			if( -f "$::APPLICATION_PATH/$file") {
				if( $file =~ m/\.pl$/) {
					system( "chmod 755 $::APPLICATION_PATH/$file");
				}
				if( $file =~ m/\.sh$/) {
					system( "chmod 755 $::APPLICATION_PATH/$file");
				}
				$upzip->addFile( "$::APPLICATION_PATH/$file", "$appname/$zipfile");
				
			} 
			else {
				$upzip->addDirectory( "$::APPLICATION_PATH/$file", "$appname/$zipfile");
			}
			printf( "\taddfile:%s\n", $file);
		}	
		$upzip->writeToFileNamed( sprintf( "%s/%s.zip", $uppath, $packagename)) == AZ_OK or die 'write error: $!';
		printf( "%s%s.zip\n", $uppath, $packagename);
	}
	
	#账号数据库
	{
		my $appname = "GMToolsAcc";
		my $packagename = "GMToolsAcc_eagle_$sv";
		my $files = {
			'srv.pl'								=> 'srv.pl',
			'doc.ga.txt'							=> 'doc.txt',
			'common.pl'								=> 'common.pl',
			'MysqlX.pm'								=> 'MysqlX.pm',
			'services/install.cfg.ga.example'		=> 'services/install.cfg.example',
			'services/bash_temple.txt'				=> 'services/bash_temple.txt',
			'services/install.pl'					=> 'services/install.pl',
			'services/restart.sh'					=> 'services/restart.sh',
			'AutoBak/auto_bak.pl'					=> 'AutoBak/auto_bak.pl',
			'AutoBak/auto_bak.cfg.ga.example'		=> 'AutoBak/auto_bak.cfg.example',
			'auto_clean.cfg.ga.example'				=> 'auto_clean.cfg.example',
			'auto_clean.pl'							=> 'auto_clean.pl',
			'CheckTools/check_tools.cfg.ga.example'	=> 'CheckTools/check_tools.cfg.example',
			'CheckTools/Moby/Business/LoggerMan.pm'	=> 'CheckTools/Moby/Business/LoggerMan.pm',
			'CheckTools/Moby/Business/TimeMan.pm'	=> 'CheckTools/Moby/Business/TimeMan.pm',
			'CheckTools/StartCheck.pl'				=> 'CheckTools/StartCheck.pl',
			'FileUpload/config.ini.ga.example'		=> 'FileUpload/config.ini.example',
			'FileUpload/Moby/Business/LoggerMan.pm'	=> 'FileUpload/Moby/Business/LoggerMan.pm',
			'FileUpload/Moby/Business/TimeMan.pm'	=> 'FileUpload/Moby/Business/TimeMan.pm',
			'FileUpload/Lib/Util/Ini.pm'			=> 'FileUpload/Lib/Util/Ini.pm',
			'FileUpload/ftp_load.pl'				=> 'FileUpload/ftp_load.pl',
			'UpdateTools/update_tools.cfg.ga.example'=> 'UpdateTools/update_tools.cfg.example',
			'UpdateTools/Moby/Business/LoggerMan.pm'=> 'UpdateTools/Moby/Business/LoggerMan.pm',
			'UpdateTools/Moby/Business/TimeMan.pm'	=> 'UpdateTools/Moby/Business/TimeMan.pm',
			'UpdateTools/update_tools.pl'			=>  'UpdateTools/update_tools.pl',
			'UpdateTools/fix.pl'				    =>  'UpdateTools/fix.pl',
			'UpdateTools/Utils.pm'				    =>  'UpdateTools/Utils.pm',
			'status_file/'							=> 'status_file/',
			'version.txt'							=> 'version.txt',
		};
		
		printf( "building %s\n", $appname);
		my $upzip = Archive::Zip->new();
		foreach my $file( keys %{$files}) {
			my $zipfile = $files->{$file};
			if( -f "$::APPLICATION_PATH/$file") {
				if( $file =~ m/\.pl$/) {
					system( "chmod 755 $::APPLICATION_PATH/$file");
				}
				if( $file =~ m/\.sh$/) {
					system( "chmod 755 $::APPLICATION_PATH/$file");
				}
				$upzip->addFile( "$::APPLICATION_PATH/$file", "$appname/$zipfile");
				
			} 
			else {
				$upzip->addDirectory( "$::APPLICATION_PATH/$file", "$appname/$zipfile");
			}
			printf( "\taddfile:%s\n", $file);
		}	
		$upzip->writeToFileNamed( sprintf( "%s/%s.zip", $uppath, $packagename)) == AZ_OK or die 'write error: $!';
		printf( "%s%s.zip\n", $uppath, $packagename);
	}
	#更新服务器
	
	{
		my $appname = "GMTools";
		my $packagename = "GMToolsGp_$sv";
		my $files = {
			'srv.pl'								=> 'srv.pl',
			'common.pl'								=> 'common.pl',
			'MysqlX.pm'								=> 'MysqlX.pm',
			'services/install.cfg.gp.example'		=> 'services/install.cfg.example',
			'services/bash_temple.txt'				=> 'services/bash_temple.txt',
			'services/install.pl'					=> 'services/install.pl',
			'services/restart.sh'					=> 'services/restart.sh',
			'AutoBak/auto_bak.pl'					=> 'AutoBak/auto_bak.pl',
			'AutoBak/auto_bak.cfg.gp.example'		=> 'AutoBak/auto_bak.cfg.example',
			'FileUpload/config.ini.gp.example'		=> 'FileUpload/config.ini.example',
			'FileUpload/FileUpload'					=> 'FileUpload/FileUpload',
			'status_file/'							=> 'status_file/',
			'version.txt'							=> 'version.txt',
		};
		
		printf( "building %s\n", $appname);
		my $upzip = Archive::Zip->new();
		foreach my $file( keys %{$files}) {
			my $zipfile = $files->{$file};
			if( -f "$::APPLICATION_PATH/$file") {
				if( $file =~ m/\.pl$/) {
					system( "chmod 755 $::APPLICATION_PATH/$file");
				}
				if( $file =~ m/\.sh$/) {
					system( "chmod 755 $::APPLICATION_PATH/$file");
				}
				$upzip->addFile( "$::APPLICATION_PATH/$file", "$appname/$zipfile");
				
			} 
			else {
				$upzip->addDirectory( "$::APPLICATION_PATH/$file", "$appname/$zipfile");
			}
			printf( "\taddfile:%s\n", $file);
		}	
		$upzip->writeToFileNamed( sprintf( "%s/%s.zip", $uppath, $packagename)) == AZ_OK or die 'write error: $!';
		printf( "%s%s.zip\n", $uppath, $packagename);
	}
	
	#资源服务器
	
	{
		my $appname = "GMTools";
		my $packagename = "GMToolsRes_$sv";
		my $files = {
			'srv.pl'								=> 'srv.pl',
			'common.pl'								=> 'common.pl',
			'MysqlX.pm'								=> 'MysqlX.pm',
			'services/install.cfg.res.example'		=> 'services/install.cfg.example',
			'services/services.cfg.res.example'		=> 'services/services.cfg.example',
			'services/bash_temple.txt'				=> 'services/bash_temple.txt',
			'services/install.pl'					=> 'services/install.pl',
			'services/restart.sh'					=> 'services/restart.sh',
			'services/auto_restart.pl'				=> 'services/auto_restart.pl',
			'AutoUpdateRes/auto_update.cfg.example'	=> 'AutoUpdate/auto_update.cfg.example',
			'AutoUpdateRes/auto_update'				=> 'AutoUpdate/auto_update',
			'UpdateTools/update_tools.cfg.res.example'=> 'UpdateTools/update_tools.cfg.example',
			'UpdateTools/update_tools'				=>  'UpdateTools/update_tools',
			'UpdateTools/fix.pl'				    =>  'UpdateTools/fix.pl',
			'status_file/'							=> 'status_file/',
			'version.txt'							=> 'version.txt',
		};
		
		printf( "building %s\n", $appname);
		my $upzip = Archive::Zip->new();
		foreach my $file( keys %{$files}) {
			my $zipfile = $files->{$file};
			if( -f "$::APPLICATION_PATH/$file") {
				if( $file =~ m/\.pl$/) {
					system( "chmod 755 $::APPLICATION_PATH/$file");
				}
				if( $file =~ m/\.sh$/) {
					system( "chmod 755 $::APPLICATION_PATH/$file");
				}
				$upzip->addFile( "$::APPLICATION_PATH/$file", "$appname/$zipfile");
				
			} 
			else {
				$upzip->addDirectory( "$::APPLICATION_PATH/$file", "$appname/$zipfile");
			}
			printf( "\taddfile:%s\n", $file);
		}	
		$upzip->writeToFileNamed( sprintf( "%s/%s.zip", $uppath, $packagename)) == AZ_OK or die 'write error: $!';
		printf( "%s%s.zip\n", $uppath, $packagename);
	}
}
