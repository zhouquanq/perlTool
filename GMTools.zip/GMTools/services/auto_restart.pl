#!/usr/bin/perl
use strict;
use warnings;
use FindBin;
use Encode; 

my $AppPath = $FindBin::Bin;

my $status_file = shift(@ARGV);
if (!defined($status_file) || length($status_file) <= 0) {
	die "perl -w auto_restart.pl path_of_status_file";
}

my $continue = 1;
my $WARN_LOCKCOUNT = 0;
BEGIN
{
    $WARN_LOCKCOUNT = 0;
    
	$SIG{TERM} = sub { $continue = 0 };
	
	sub __log
	{
        my ($file, $line, $text) = @_;
		
        my ($sec, $min, $hour, $day, $mon, $year) = localtime(time());
        $year += 1900;
        $mon += 1;

        my $time = sprintf("%04d-%02d-%02d %02d:%02d:%02d", $year, $mon, $day, $hour, $min, $sec);

		$WARN_LOCKCOUNT++;
        
		my $script_name = $0;
		$script_name =~ s/^.+[\\\/]([^\\\/]+)$/$1/;
        
        my $pathname = $AppPath . "/" . $script_name . ".log";
        if($pathname)
        {
            open LOGFILE, ">>$pathname";
            binmode(LOGFILE, ":encoding(utf8)");
			print LOGFILE "[$file($line)][$time] $text\n";
            close LOGFILE;
        }
        
		$WARN_LOCKCOUNT--;
        
        
	}

	$SIG{__WARN__} = sub
	{
		return if($WARN_LOCKCOUNT);
		
		my ($text) = @_;
	    my @loc = caller(0);
	   	chomp($text);

	    __log($loc[1], $loc[2], $text);
	    
		my $index = 1;
	    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
		{
			__log($loc[1], $loc[2], "$loc[3]");
		};

	    return 1;
	};

	$SIG{__DIE__} = sub
	{
		my ($text) = @_;
	    my @loc = caller(0);
	   	chomp($text);

	    __log($loc[1], $loc[2], $text);

		my $index = 1;
	    for(@loc = caller($index); scalar(@loc); @loc = caller(++$index))
		{
			__log($loc[1], $loc[2], "$loc[3]");
		};

	    return 1;
	};
}

$SIG{TERM} = sub { $continue = 0 };
BEGIN
{
	use FindBin;

	for(@ARGV)
	{
		next unless /^\-srv$/i;
		
		my $pid = fork();
		if ($pid < 0)
		{
			die "fork: $!";
		}
		elsif ($pid)
		{
			exit 0;
		}
	
		chdir($FindBin::Bin);
	
		open(STDIN,  "</dev/null");
		open(STDOUT, ">/dev/null");
		open(STDERR, ">&STDOUT");
		last;
	}
}

$|=1;
while($continue)
{
	run();
	sleep(10);
}

sub run
{
	 my ($sec, $min, $hour, $day, $mon, $year) = localtime(time());
     $year += 1900;
     $mon += 1;
     if($hour == 4 && $min ==0){
       system ("perl serverRestart.pl stop");
       sleep (1200);
       system ("yum -y install ntp");
       my $backaddress = ["ntp.ucweb.com","210.72.145.44","time.windows.com","asia.pool.ntp.org","219.158.14.130"];
       foreach my $address (@{$backaddress}){
       		next if(system ("/sbin/ntpdate $address >> /var/log/ntpdate.log 2>&1") !=0);
       		system("hwclock -w");
       		last;
       }
       system ("perl serverRestart.pl start");
     }
	open(F_STATUS, ">$status_file") or die "can't write status output file: $status_file";
	print F_STATUS time();
	close F_STATUS;
}

