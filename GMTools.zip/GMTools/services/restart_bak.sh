#!/bin/bash
if [  $# -lt 1 ]; then
echo "Usage restart.sh services.cfg start|stop [target]";
exit 4
fi
n=1
config=$1
if [ ! -r $config ]; then
  echo "$config can not found"
  exit 4
fi
name=()
array=()
count=$(grep cmd $config | wc -l)
while ((n<=$count))
do
    array[$n]=$(grep cmd $config | awk -F "=" '{print $2}'|sed -n "${n}p")
    name[$n]=$(grep '\[GM_.*\]' $config |sed -n "${n}p"|cut -d [ -f 2|cut -d ] -f 1 ) 
    ((n+=1))
done
target=$3
if [ $2 = "start" ]; then
	i=1
	while ((i<=$count))
	do
	targetname=${name[$i]}
	if [ ! -z "$target"  ] ; then
	 	if [ "$targetname" != "$target"  ]; then
		((i+=1)) 
	  	continue
         	fi
	fi 
  	cmd=${array[$i]}
	binary=$(echo $cmd | awk '{print $1}')
	if [ -x $binary ]; then
#	echo "check $binary ok"	
	RETVAL=0
#	echo -n "Starting $cmd"
	echo Starting $cmd
	nohup $cmd  >/dev/null &
#	$cmd
	RETVAL=$?	
		if [ $RETVAL -eq 0 ] ; then
		echo [ok]	
       		 PID=`ps axu|grep $binary |grep -v grep |awk '{print $2}'`
#		echo "PID is :$PID "
#		echo "$binary $PID" >>test.pid
		else
		exit 4
		fi
	else
		echo "check $binary fail";
		exit 4
	fi
	    ((i+=1))	
	done
fi

# stop 
if [ $2 = "stop" ];then
#cat test.pid | while read line
#do
#          echo $line | awk '{print $1}'
#done
#rm test.pid -f
j=1
  while ((j<=$count))
  do
	
  targetname=${name[$j]}
  if [ ! -z "$target"  ] ; then
	 if [ "$targetname" != "$target"  ]; then
         ((j+=1))
	  continue
         fi
  fi 
  cmd=${array[$j]}
  echo Stop $cmd
  binary=$(echo $cmd | awk '{print $1}')
  PID=`ps axu|grep $binary |grep -v grep |awk '{print $2}'`
#  echo "$binary PID value is:$PID"
	if [  -n "$PID" ];then
	
	echo "kill -TERM $PID"
	kill -TERM $PID
	sleep 15;
	proc=`ps axu|grep $binary |grep -v grep |awk '{print $2}'`
	#echo "now prco is:$proc"
		if [ -n "$proc" ];then
		echo "kill -9 $proc"
		kill -9 $proc
		else
		echo "kill succeed!"
		fi
	else
 	echo "$binary is already die!"
	fi
  ((j+=1))
  done
fi

