#!/usr/bin/perl
use strict;
use warnings;
use utf8;
use FindBin;
use Fcntl qw(:flock);

BEGIN
{
	use PerlIO::encoding;
    our $AppPath = $FindBin::Bin;
    chdir($FindBin::Bin);
}

if (@ARGV < 1) {
	usage();
}
my $cmd = shift(@ARGV);

my $config = $::AppPath . "/services.cfg";
if ( !(-e $config)){
	$config = $::AppPath . "../services/services.cfg";
}


my @name  = ();
my @array = ();
my @binarys =();
my $count=`grep cmd $config | wc -l`;
foreach my $n (1..$count)
{
    $array[$n]=`grep cmd $config | awk -F "=" '{print \$2}'|sed -n "${n}p"`;
    $binarys[$n] = `grep cmd $config | awk -F "=" '{print \$2}'|sed -n "${n}p"| awk '{print \$1}'`;
    $name[$n]=`grep '\[GM_.*\]' $config |sed -n "${n}p"|cut -d [ -f 2|cut -d ] -f 1`; 
}

if ($cmd =~ /^start$/i)
{
		foreach my $i (1..$count)
		{
			my $cmd = $array[$i];
			my $binary= $binarys[$i];
			chomp( $binary);
			if(-e $binary){
				print  "check $binary ok\n";
				print "Starting $cmd";
				my $result = system("nohup $cmd  >/dev/null 2>&1 &");
				if($result == 0){
				print "[ok]\n";	
       			my $pid ="ps axu|grep $binary |grep -v grep |awk '{print \$2}'";
       			my $PID = `$pid`;
       			print "PID is :$PID ","\n";
				}
			}
			else
			{
				print "check $binary fail\n";
			}
				
		}
}
elsif($cmd =~ /^stop$/i)
{
	foreach my $i (1..$count)
	{
		my $cmd = $array[$i];
		my $binary = $binarys[$i];
		chomp( $binary);
		if($binary =~/(.*)StartGMServer/)
       	 {
   			my $path = $1;
   			my $file;
   			my $checkfile = $path . "serverstatus.lock";
			my $accsql = $path . "_SaveDbCmds_Account.sql";
			my $gamesql = $path . "_SaveDbCmds_Game.sql";
			my $jsonsql =  $path . "_SaveDbCmdsDump.json";
   			my $pid  ="ps axu|grep $binary |grep -v grep |awk '{print \$2}'";
   			my $PID = `$pid`;
			if($PID){
				print "kill -TERM $PID\n";
	        	system("kill -TERM $PID");
	       		sleep (10);
	       		$pid  ="ps axu|grep $binary |grep -v grep |awk '{print \$2}'";
   			    $PID = `$pid`;
	       		while($PID){
	       			if(open($file, ">$checkfile")  && flock($file, Fcntl::LOCK_EX|Fcntl::LOCK_NB))
	       			{
	       				system("kill -9 $PID");
						unlink $accsql if(-e $accsql);
						unlink $gamesql if(-e $gamesql);
						unlink $jsonsql if(-e $jsonsql);
	       				print $checkfile,"unlock","\n";
	       				close $file;
	       				last;
	       			}
		 			sleep (10);
		 			$pid  ="ps axu|grep $binary |grep -v grep |awk '{print \$2}'";
   			    	$PID = `$pid`;
	       		}
			}
			else{
			print "$binary is already die!";
			}
        }  
	}
}
else
{
	usage();
}



sub usage
{
	die "serverRestart.pl  stop|start";
}