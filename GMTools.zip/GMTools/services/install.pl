#!/usr/bin/perl -w
use strict;
use warnings;
use FindBin;

my $AppPath = $FindBin::Bin;

my $g_level = 65;

my %services;
my @empty_child = ();
$services{'name'} = "";
$services{'child'} = \@empty_child;


if (@ARGV < 1) {
	usage();
}

my $cmd = shift(@ARGV);
my $target = shift(@ARGV);

if ($cmd =~ /^start$/i)
{
	my $p = sort_services();
	for(@{$p})
	{
		my $name = $_->{'name'};
		if (defined($target)) {
			next if ($name ne $target);
		}
		print $name,"\n";
		StartService($name);
	}
}
elsif ($cmd =~ /^stop$/i)
{
	my $p = sort_services();
	my $count = @{$p};
	for(my $i=$count-1; $i>=0; $i--)
	{
		my $name = $p->[$i]->{'name'};
		if (defined($target)) {
			next if ($name ne $target);
		}
		print $name,"\n";
		StopService($name);
	}
}
elsif ($cmd =~ /^install$/i)
{
    my $i = 0;
	my $p = sort_services();
	for(@{$p})
	{
		my $name = $_->{'name'};
		print $name,"\n";
		my $depend = $_->{'depend'};
		my $cmd = $_->{'cmd'};

		$cmd =~ s/__APP_PATH__/$AppPath/ig;

		my @params = split(/\s+/, $cmd);
		my $script = shift(@params);

		CreateService($g_level+$i, $name, $depend, $script, @params);
        $i ++;
	}
}
elsif ($cmd =~ /^remove$/i)
{
	my $p = sort_services();
	my $count = @{$p};
	for(my $i=$count-1; $i>=0; $i--)
	{
		my $name = $p->[$i]->{'name'};
		if (defined($target)) {
			next if ($name ne $target);
		}
		print $name,"\n";
		StopService($name);
		RemoveService($g_level+$i, $name);
	}
}
else
{
	usage();
}

sub parse_tree
{
	my $cfg_ini = load_ini($AppPath . "/install.cfg");

	for (@{$cfg_ini})
	{		
		my $section = $_;
		my $name = $section->{'name'};

		my $depend = get_section_value($section, "depend", "");
		my $cmd = get_section_value($section, "cmd", "");

		my %s;
		my @ar;
		$s{'name'} = $name;
		$s{'depend'} = $depend;
		$s{'cmd'} = $cmd;
		$s{'child'} = \@ar;

		push @{get_parent($depend)->{'child'}}, \%s;
	}
}

sub sort_services
{
	parse_tree();

	my @service_list;

	my @s;
	push @s, \%services;

	while(@s>0)
	{
		my $p = shift @s;

		if ($p->{'name'} !~ /^\s*$/) {
			push @service_list, $p;
		}

		for(@{$p->{'child'}})
		{
			push @s, $_;
		}
	}

	return \@service_list;
}

sub get_parent
{
	my ($name) = @_;

	return \%services if $name =~ /^\s*$/;

	my @s;
	push(@s, \%services);

	while(@s > 0)
	{
		my $pAr = shift @s;

		if ($pAr->{'name'} eq $name) {
			return $pAr;
		}

		for(@{$pAr->{'child'}})
		{
			push @s, $_;
		}
	}

	return \%services;
}

sub usage
{
	die "install.pl  start|stop|install|remove [target]";
}


sub StartService
{
	my ($name) = @_;
	#run service
	{
		print "start..\n";
		my @cmds;
		push @cmds, "service";
		push @cmds, $name;
		push @cmds, "start";

		system(@cmds) == 0
			or print "system @cmds failed: $?";
	}
}

sub StopService
{
	my ($name) = @_;
	#stop service
	{
		print "start..\n";
		my @cmds;
		push @cmds, "service";
		push @cmds, $name;
		push @cmds, "stop";

		system(@cmds) == 0
			or print "system @cmds failed: $?";
	}
}

sub RemoveService
{
	my ($index, $name) = @_;

	if (defined($target)) {
		return if ($name ne $target);
	}

    for(2 .. 5)
    {
        my $id = $_;        
        unlink(</etc/rc$id.d/S*$name>);        
    }

    my @cmds;
    push @cmds, "rm";
    push @cmds, "/etc/rc.d/init.d/$name";
    
    system(@cmds) == 0
        or print "system failed: $?";
}

sub CreateService
{
	my ($index, $name, $depend, $script_path, @argv) = @_;

	if (defined($target)) {
		return if ($name ne $target);
	}

	#create service
	{
        $script_path =~ /[\\\/]([^\\\/]+)$/;
        my $process_name = $1;
        my $script_name = $1;
        $script_name =~ s/\.[^\.]+$//;
 
		my $args = "";
		for(@argv)
		{
			$args .= "$_ ";
		}
		$args =~ s/^\s+//;
		$args =~ s/\s+$//;
        
        my $content = readin("$AppPath/bash_temple.txt");
        $content =~ s/__SCRIPT_NAME__/$script_name/ig;
        $content =~ s/__PROCESS_NAME__/$process_name/ig;
        $content =~ s/__SCRIPT_PATH__/$script_path/ig;
        $content =~ s/__ARGS__/$args/ig;

        my $outfile = "/etc/rc.d/init.d/$name";        
		open(OUTFILE, ">$outfile") or die "Open $outfile failed";
		print OUTFILE $content;
		close(OUTFILE);

		system("chmod 755 $script_path") == 0 or die $?;
		system("chmod 755 $outfile") == 0 or die $?;
		
		for(2 .. 5)
		{
			system("ln -s $outfile /etc/rc$_.d/S$index$name");
		}
	}
}


sub readin
{
    my ($file) = @_;
    
    my $len = -s $file;
    return "" unless $len>0;

    my $f;
    open $f, $file;
    binmode $f;
    my $cont = "";
    sysread($f, $cont, $len);
    close $f;
    
    return $cont;
}


sub load_ini_from_buffer
{
    my ($buffer) = @_;
    
    my @lines = split(/\r?\n/, $buffer);
    
	my @ret;
	my $section_name = "";
	my $kvs;
	my $text = "";

	for(@lines)
	{
		my $line = $_;
		my $raw_line = $_;
		next if $line=~ /^\s*$/ or $line =~ /^\s*\#/;

		$line =~ s/^\s+//;
		$line =~ s/\s+$//;
		$raw_line =~ s/\r?\n//g;

		if ($line =~ /^\[([^\]]+)\]$/) {
			my $tmp_name = $1;
			$tmp_name =~ s/^\s+//;
			$tmp_name =~ s/\s+$//;

			if (length($section_name) > 0) {
				my %ini_info;
				$ini_info{'name'} = $section_name;
				$ini_info{'text'} = $text;
				$ini_info{'kvs'} = $kvs;

				push @ret, \%ini_info;
			}

			my @arKvs;
			$kvs = \@arKvs;
			$section_name = $tmp_name;
			$text = "";
		}
		elsif ($line =~ /^([^=]+)=(.*)$/){
			my $key = $1;
			my $value = $2;

			$key =~ s/^\s+//;
			$key =~ s/\s+$//;

			$value =~ s/^\s+//;
			$value =~ s/\s+$//;

			if (length($section_name) > 0) {
				my %kv;
				$kv{'key'} = $key;
				$kv{'value'} = $value;

				push @{$kvs}, \%kv;
			}
			$text .= $raw_line."\n";
		}
		else{
			$text .= $raw_line."\n";
		}
	}

	if (length($section_name) > 0) {
		my %ini_info;
		$ini_info{'name'} = $section_name;
		$ini_info{'text'} = $text;
		$ini_info{'kvs'} = $kvs;


		push @ret, \%ini_info;
	}

	return \@ret;
}

sub load_ini
{
	my ($file) = @_;
    
    return load_ini_from_buffer(readin($file));
}

sub get_section_value
{
	my ($section, $key, $default_value) = @_;

	for (@{$section->{'kvs'}}) {
		my $kv = $_;
		
		if (lc($kv->{'key'}) eq lc($key)) {
			if (length($kv->{'value'})>0) {
				return $kv->{'value'};
			}
		
			return defined($default_value)?$default_value:"";
		}
	}

	return defined($default_value)?$default_value:"";
}

sub format_time
{
	my ($time) = @_;

	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);
	$mon++;
	$year += 1900;

	return "$year-$mon-$mday $hour:$min:$sec";
}
